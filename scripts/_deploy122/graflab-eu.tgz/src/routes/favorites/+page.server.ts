import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
  // Все товары — фильтрация по избранным происходит на клиенте
  // (избранное в localStorage). При 95 товарах это ок.
  const products = await db
    .select({
      id: schema.euProducts.id,
      name: schema.euProducts.name,
      nameSr: schema.euProducts.nameSr,
      imageUrl: schema.euProducts.imageUrl,
      priceRub: schema.euProducts.priceRub,
      priceOldRub: schema.euProducts.priceOldRub,
      rating: schema.euProducts.rating,
      reviewsCount: schema.euProducts.reviewsCount,
      inStock: schema.euProducts.inStock
    })
    .from(schema.euProducts)
    .where(eq(schema.euProducts.active, true));

  return { allProducts: products };
};
