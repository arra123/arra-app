<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import Pcard from '$lib/components/Pcard.svelte';
  import { favorites } from '$lib/stores/favorites';
  import { t } from '$lib/i18n';
  import type { PageData } from './$types';

  export let data: PageData;

  $: favProducts = data.allProducts.filter((p) => $favorites.has(p.id));
</script>

<svelte:head>
  <title>{$t('favoritesTitle')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="fav-page">
  <h1>{$t('favoritesTitle')} {#if favProducts.length > 0}<span class="num">· {favProducts.length}</span>{/if}</h1>

  {#if favProducts.length === 0}
    <div class="empty">
      <p>{$t('favoritesEmpty')}</p>
      <a href="/" class="btn-back">{$t('toCatalog')}</a>
    </div>
  {:else}
    <div class="grid">
      {#each favProducts as p (p.id)}
        <Pcard
          id={p.id}
          name={p.name}
          nameSr={p.nameSr}
          imageUrl={p.imageUrl}
          priceRub={p.priceRub}
          priceOldRub={p.priceOldRub}
          rating={p.rating}
          reviewsCount={p.reviewsCount}
          inStock={p.inStock}
        />
      {/each}
    </div>
  {/if}
</main>

<Tabbar />

<style>
  .fav-page {
    max-width: var(--maxw); margin: 0 auto;
    padding: var(--s-4) var(--gutter) var(--s-6);
  }
  h1 { font-size: 26px; font-weight: 700; margin: 0 0 var(--s-4); }
  h1 .num { color: var(--ink-soft); font-weight: 500; font-size: 16px; }
  .empty {
    text-align: center; padding: var(--s-6) var(--s-3);
    background: var(--paper-card); border: 1px dashed var(--line-strong);
    border-radius: var(--r);
  }
  .empty p { color: var(--ink-soft); margin: 0 0 var(--s-3); }
  .btn-back {
    display: inline-block; padding: 12px 24px;
    background: var(--brand); color: #fff; border-radius: 99px;
    font-weight: 700; font-size: 14px;
  }
  .grid {
    display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--s-2);
  }
  @media (min-width: 600px) { .grid { grid-template-columns: repeat(3, 1fr); gap: var(--s-3); } }
  @media (min-width: 1100px) { .grid { grid-template-columns: repeat(4, 1fr); } }
</style>
