import { db, schema } from '$server/db';
import { eq, ilike, desc } from 'drizzle-orm';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ url }) => {
  const q = url.searchParams.get('q')?.trim() ?? '';

  if (!q) {
    return { query: '', results: [] };
  }

  const results = await db
    .select({
      id: schema.euProducts.id,
      name: schema.euProducts.name,
      nameSr: schema.euProducts.nameSr,
      categorySlug: schema.euCategories.slug,
      priceRub: schema.euProducts.priceRub,
      priceOldRub: schema.euProducts.priceOldRub,
      imageUrl: schema.euProducts.imageUrl,
      rating: schema.euProducts.rating,
      reviewsCount: schema.euProducts.reviewsCount,
      inStock: schema.euProducts.inStock
    })
    .from(schema.euProducts)
    .leftJoin(schema.euCategories, eq(schema.euProducts.categoryId, schema.euCategories.id))
    .where(ilike(schema.euProducts.name, `%${q}%`))
    .orderBy(desc(schema.euProducts.priceRub))
    .limit(50);

  return { query: q, results };
};
