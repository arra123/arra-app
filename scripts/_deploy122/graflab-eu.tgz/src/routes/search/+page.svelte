<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import Pcard from '$lib/components/Pcard.svelte';
  import { goto } from '$app/navigation';
  import { t } from '$lib/i18n';
  import type { PageData } from './$types';

  export let data: PageData;
  let q = data.query;

  function doSearch() {
    if (q.trim()) goto(`/search?q=${encodeURIComponent(q.trim())}`);
  }
</script>

<svelte:head>
  <title>{data.query ? `"${data.query}" — ${$t('search')}` : $t('search')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="search-page">
  <form class="search-form" on:submit|preventDefault={doSearch}>
    <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
      <circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" />
    </svg>
    <input
      type="search"
      bind:value={q}
      placeholder={$t('searchPlaceholder')}
      autofocus
    />
    <button type="submit">{$t('find')}</button>
  </form>

  {#if data.query}
    <h1 class="results-title">
      {#if data.results.length > 0}
        {$t('resultsFor')} "{data.query}" <span class="num">· {data.results.length}</span>
      {:else}
        {$t('nothingFoundFor')} "{data.query}"
      {/if}
    </h1>

    {#if data.results.length > 0}
      <div class="grid">
        {#each data.results as p (p.id)}
          <Pcard
            id={p.id}
            name={p.name}
            nameSr={p.nameSr}
            imageUrl={p.imageUrl}
            priceRub={p.priceRub}
            priceOldRub={p.priceOldRub}
            rating={p.rating}
            reviewsCount={p.reviewsCount}
            inStock={p.inStock}
          />
        {/each}
      </div>
    {:else}
      <p class="empty">{$t('tryAnotherQuery')}</p>
    {/if}
  {:else}
    <div class="hints">
      <h2>{$t('popularSearches')}</h2>
      <div class="chips">
        {#each ['NMN', 'Magnesium', 'Vitamin D3', 'Lactoferrin', 'Quercetin', 'Omega', 'Collagen', 'Melatonin'] as hint}
          <a href="/search?q={encodeURIComponent(hint)}" class="chip">{hint}</a>
        {/each}
      </div>
    </div>
  {/if}
</main>

<Tabbar />

<style>
  .search-page {
    max-width: var(--maxw); margin: 0 auto;
    padding: var(--s-4) var(--gutter) var(--s-6);
  }
  .search-form {
    display: flex; align-items: center; gap: var(--s-2);
    background: var(--paper-card); border: 2px solid var(--line);
    border-radius: 99px; padding: 6px 6px 6px 20px;
    margin-bottom: var(--s-4);
  }
  .search-form:focus-within { border-color: var(--accent); }
  .search-form svg { width: 18px; height: 18px; stroke: var(--ink-soft); flex: 0 0 auto; }
  .search-form input {
    flex: 1; border: 0; outline: 0; background: transparent;
    font-size: 16px; color: var(--ink); min-width: 0;
  }
  .search-form input::placeholder { color: var(--ink-faint); }
  .search-form button {
    background: var(--brand); color: #fff; border: 0;
    border-radius: 99px; padding: 12px 24px;
    font-size: 14px; font-weight: 700;
  }
  .search-form button:hover { background: var(--brand-hover); }

  .results-title {
    font-size: 20px; font-weight: 700; margin: 0 0 var(--s-3);
  }
  .results-title .num { color: var(--ink-soft); font-weight: 500; font-size: 15px; }

  .grid {
    display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--s-2);
  }
  @media (min-width: 600px) { .grid { grid-template-columns: repeat(3, 1fr); gap: var(--s-3); } }
  @media (min-width: 1100px) { .grid { grid-template-columns: repeat(4, 1fr); } }

  .empty { color: var(--ink-soft); font-size: 15px; }
  .empty a { color: var(--accent); font-weight: 600; }

  .hints { text-align: center; padding: var(--s-5) 0; }
  .hints h2 { font-size: 16px; font-weight: 600; color: var(--ink-soft); margin: 0 0 var(--s-3); }
  .chips { display: flex; flex-wrap: wrap; justify-content: center; gap: 8px; }
  .chip {
    padding: 10px 18px; background: var(--paper-card); border: 1px solid var(--line);
    border-radius: 99px; font-size: 14px; font-weight: 500; color: var(--ink);
    box-shadow: var(--shadow-sm);
  }
  .chip:hover { border-color: var(--accent); color: var(--accent); }
</style>
