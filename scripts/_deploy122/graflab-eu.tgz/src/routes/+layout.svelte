<script lang="ts">
  import '$lib/styles/global.css';
  import { page } from '$app/stores';
  import Footer from '$lib/components/Footer.svelte';

  $: isAdmin = $page.url.pathname.startsWith('/admin');
</script>

<slot />

{#if !isAdmin}
  <Footer />
{/if}
