<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import SearchBar from '$lib/components/SearchBar.svelte';
  import Sidebar from '$lib/components/Sidebar.svelte';
  import Pcard from '$lib/components/Pcard.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { t, locale } from '$lib/i18n';
  import type { PageData } from './$types';

  export let data: PageData;

  let searchQuery = '';
  let selectedCategories: Set<string> = new Set();
  let priceMin = '';
  let priceMax = '';
  let inStockOnly = true;
  let sort: 'popular' | 'price-asc' | 'price-desc' | 'rating' | 'reviews' | 'name' | 'discount' = 'popular';

  $: catCounts = data.categories.map((c) => ({
    slug: c.slug, name: c.name, nameSr: c.nameSr, count: c.count
  }));

  $: hits = data.products
    .filter((p) => p.reviewsCount > 0 && p.rating && p.rating >= 40)
    .sort((a, b) => b.reviewsCount - a.reviewsCount)
    .slice(0, 8);

  $: filteredProducts = (() => {
    let list = data.products;
    if (selectedCategories.size > 0) list = list.filter((p) => p.categorySlug && selectedCategories.has(p.categorySlug));
    if (inStockOnly) list = list.filter((p) => p.inStock);
    // В фильтре пользователь вводит цену в евро — сравниваем в центах
    const min = parseFloat(priceMin.replace(/\s/g, '').replace(',', '.'));
    const max = parseFloat(priceMax.replace(/\s/g, '').replace(',', '.'));
    if (!isNaN(min)) list = list.filter((p) => p.priceRub >= min * 100);
    if (!isNaN(max)) list = list.filter((p) => p.priceRub <= max * 100);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q));
    }
    if (sort === 'price-asc') list = [...list].sort((a, b) => a.priceRub - b.priceRub);
    else if (sort === 'price-desc') list = [...list].sort((a, b) => b.priceRub - a.priceRub);
    else if (sort === 'rating') list = [...list].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
    else if (sort === 'reviews') list = [...list].sort((a, b) => b.reviewsCount - a.reviewsCount);
    else if (sort === 'name') list = [...list].sort((a, b) => a.name.localeCompare(b.name, 'ru'));
    else if (sort === 'discount') list = [...list].sort((a, b) => {
      const dA = a.priceOldRub ? (a.priceOldRub - a.priceRub) / a.priceOldRub : 0;
      const dB = b.priceOldRub ? (b.priceOldRub - b.priceRub) / b.priceOldRub : 0;
      return dB - dA;
    });
    return list;
  })();

  $: activeFilters = selectedCategories.size + (priceMin ? 1 : 0) + (priceMax ? 1 : 0) + (inStockOnly ? 0 : 0);

  const CAT_EMOJI: Record<string, string> = {
    longevity: '🧬', vitamins: '💊', minerals: '⚡', immunity: '🛡️',
    brain: '🧠', antioxidants: '🍇', cardiovascular: '❤️', beauty: '✨',
    vision: '👁️', weight: '🏋️', womens: '🌸',
  };
  function catEmoji(slug: string) { return CAT_EMOJI[slug] ?? '💊'; }

  let hitsEl: HTMLElement;
  function scrollHits(dir: number) {
    if (!hitsEl) return;
    hitsEl.scrollBy({ left: dir * 260, behavior: 'smooth' });
  }

</script>

<svelte:head>
  <title>{$t('heroTitle')}</title>
  <meta name="description" content={$t('heroDesc')} />
</svelte:head>

<Header />
<SearchBar bind:value={searchQuery} {activeFilters} />

<!-- ═══ ПРОМО-БАННЕР ═══ -->
<section class="promo">
  <div class="promo__inner">
    <div class="promo__text">
      <span class="promo__eyebrow">{$t('heroBadge')}</span>
      <h1 class="promo__title">{$t('heroTagline1')}<br /><em>{$t('heroTagline2')}</em></h1>
      <p class="promo__lead">{$t('heroSubline')}</p>
      <div class="promo__stats">
        <div class="promo__stat"><strong class="num">{data.products.length}</strong><span>{$t('heroStat1')}</span></div>
        <div class="promo__stat"><strong>GMP</strong><span>{$t('heroStat2')}</span></div>
        <div class="promo__stat"><strong>100%</strong><span>{$t('heroStat3')}</span></div>
      </div>
    </div>
    <div class="promo__visual">
      <img src="/brand/logo-mark.png" alt="" class="promo__diamond" />
    </div>
  </div>
</section>

<!-- ═══ КАТЕГОРИИ — иконки ═══ -->
<section class="section cat-section">
  <div class="section__inner">
    <h2 class="section__title">{$t('categories')}</h2>
    <div class="cat-scroll">
      {#each data.categories as cat (cat.id)}
        <a
          class="cat-card"
          href="/category/{cat.slug}"
        >
          <img class="cat-card__icon" src="/icons/cat-{cat.slug}.png" alt="" loading="lazy" on:error={(e) => { e.currentTarget.style.display='none'; e.currentTarget.nextElementSibling.style.display='block'; }} />
          <span class="cat-card__emoji" style="display:none">{catEmoji(cat.slug)}</span>
          <div class="cat-card__name">{$locale === 'sr' && cat.nameSr ? cat.nameSr : cat.name}</div>
        </a>
      {/each}
    </div>
  </div>
</section>

<!-- ═══ ХИТЫ ПРОДАЖ ═══ -->
{#if hits.length > 0}
<section class="section hits">
  <div class="section__inner">
    <div class="section__head">
      <h2>{$t('bestSellers')}</h2>
      <div class="scroll-arrows">
        <button class="scroll-arrow" type="button" on:click={() => scrollHits(-1)} aria-label={$t('back')}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <button class="scroll-arrow" type="button" on:click={() => scrollHits(1)} aria-label={$t('forward')}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg>
        </button>
      </div>
    </div>
    <div class="hits__scroll" bind:this={hitsEl}>
      {#each hits as p (p.id)}
        <div class="hits__card">
          <Pcard id={p.id} name={p.name} nameSr={p.nameSr} imageUrl={p.imageUrl} priceRub={p.priceRub} priceOldRub={p.priceOldRub} rating={p.rating} reviewsCount={p.reviewsCount} inStock={p.inStock} />
        </div>
      {/each}
    </div>
  </div>
</section>
{/if}

<!-- ═══ КАТАЛОГ ═══ -->
<div id="catalog">
  <main class="layout">
    <Sidebar categories={catCounts} bind:selectedCategories bind:priceMin bind:priceMax bind:inStockOnly />
    <section class="catalog">
      <div class="catalog__head">
        <h2 class="catalog__title">
          {$t('allSupplements')}
          <span class="num">· {filteredProducts.length}</span>
        </h2>
        <label class="sort">
          <span>{$t('sorting')}:</span>
          <select bind:value={sort}>
            <option value="popular">{$t('sortPopular')}</option>
            <option value="price-asc">{$t('sortCheapest')}</option>
            <option value="price-desc">{$t('sortExpensive')}</option>
            <option value="discount">{$t('sortDiscount')}</option>
            <option value="rating">{$t('sortRating')}</option>
            <option value="reviews">{$t('sortReviews')}</option>
            <option value="name">{$t('sortName')}</option>
          </select>
          <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round"><path d="m6 9 6 6 6-6" /></svg>
        </label>
      </div>
      {#if filteredProducts.length === 0}
        <div class="empty">{$t('nothingFound')}</div>
      {:else}
        <div class="grid">
          {#each filteredProducts as p (p.id)}
            <Pcard id={p.id} name={p.name} nameSr={p.nameSr} imageUrl={p.imageUrl} priceRub={p.priceRub} priceOldRub={p.priceOldRub} rating={p.rating} reviewsCount={p.reviewsCount} inStock={p.inStock} />
          {/each}
        </div>
      {/if}
    </section>
  </main>
</div>

<Tabbar />

<style>
  /* ═══ ПРОМО ═══ */
  .promo {
    background: linear-gradient(135deg, #1a3a25 0%, #2d5a3d 50%, #3a7a47 100%);
    color: #fff; padding: var(--s-5) var(--gutter) var(--s-4); overflow: hidden;
  }
  .promo__inner {
    max-width: var(--maxw); margin: 0 auto;
    display: flex; align-items: center; justify-content: space-between; gap: var(--s-4);
  }
  .promo__text { max-width: 580px; }
  .promo__eyebrow { font-size: 11px; letter-spacing: 0.2em; text-transform: uppercase; opacity: 0.6; display: block; margin-bottom: var(--s-2); }
  .promo__title { font-family: var(--brand-font); font-size: clamp(26px, 5.5vw, 48px); line-height: 1.1; letter-spacing: 0.02em; margin: 0 0 var(--s-2); text-transform: uppercase; }
  .promo__title em { font-style: normal; color: #b8e6a0; }
  .promo__lead { font-size: 15px; line-height: 1.5; opacity: 0.8; margin: 0 0 var(--s-4); }
  .promo__stats { display: flex; gap: var(--s-4); }
  .promo__stat { display: flex; flex-direction: column; gap: 2px; }
  .promo__stat strong { font-size: 24px; font-weight: 800; letter-spacing: -0.02em; }
  .promo__stat span { font-size: 11px; opacity: 0.55; text-transform: uppercase; letter-spacing: 0.1em; }
  .promo__visual { flex: 0 0 auto; }
  .promo__diamond { width: clamp(70px, 12vw, 140px); height: auto; opacity: 0.15; filter: brightness(3); }
  @media (max-width: 600px) { .promo__visual { display: none; } }

  /* ═══ СЕКЦИИ ═══ */
  .section { padding: var(--s-4) var(--gutter); }
  .section__inner { max-width: var(--maxw); margin: 0 auto; }
  .section__title { font-size: 22px; font-weight: 700; margin: 0 0 var(--s-3); }
  .section__head { display: flex; align-items: baseline; justify-content: space-between; gap: var(--s-3); margin-bottom: var(--s-3); }
  .section__head h2 { font-size: 22px; font-weight: 700; margin: 0; }
  .section__link { font-size: 13px; color: var(--accent); font-weight: 600; }

  /* ═══ КАТЕГОРИИ — иконки ═══ */
  .cat-scroll {
    display: flex; gap: 4px; overflow-x: auto;
    scrollbar-width: none;
  }
  .cat-scroll::-webkit-scrollbar { display: none; }
  .cat-card {
    flex: 0 0 72px; background: transparent;
    border: 0; border-radius: var(--r);
    padding: 8px 4px; cursor: pointer;
    text-align: center; display: flex; flex-direction: column;
    align-items: center; gap: 4px;
    transition: transform 180ms ease;
  }
  .cat-card:hover { transform: translateY(-2px); }
  @media (min-width: 600px) { .cat-card { flex: 0 0 100px; gap: 6px; } }
  .cat-card__icon {
    width: 40px; height: 40px; object-fit: contain;
  }
  @media (min-width: 600px) { .cat-card__icon { width: 48px; height: 48px; } }
  .cat-card__emoji {
    font-size: 28px; line-height: 1;
  }
  @media (min-width: 600px) { .cat-card__emoji { font-size: 32px; } }
  .cat-card__name {
    font-size: 11px; font-weight: 600; color: var(--ink);
    line-height: 1.15;
  }
  @media (min-width: 600px) { .cat-card__name { font-size: 12px; } }

  /* ═══ ХИТЫ — горизонтальный скролл со стрелками ═══ */
  .hits { border-bottom: 0; }
  .hits__scroll {
    display: flex; gap: var(--s-2); overflow-x: auto; scrollbar-width: none;
    scroll-snap-type: x mandatory;
  }
  .hits__scroll::after {
    content: ''; flex: 0 0 1px; /* чтобы последняя карточка не прижималась к краю */
  }
  .hits__scroll::-webkit-scrollbar { display: none; }
  .hits__card { flex: 0 0 calc(50% - 6px); scroll-snap-align: start; }
  @media (min-width: 600px) { .hits__card { flex: 0 0 200px; } }
  @media (min-width: 900px) { .hits__card { flex: 0 0 210px; } }
  .scroll-arrows { display: flex; gap: 6px; }
  .scroll-arrow {
    width: 34px; height: 34px; border-radius: 99px;
    border: 1px solid var(--line); background: var(--paper-card);
    display: inline-flex; align-items: center; justify-content: center;
    cursor: pointer; padding: 0; transition: all 150ms ease;
  }
  .scroll-arrow:hover { border-color: var(--accent); background: var(--accent-soft); }
  .scroll-arrow svg { width: 16px; height: 16px; stroke: var(--ink); }

  /* ═══ КАТАЛОГ ═══ */
  .layout {
    max-width: var(--maxw); margin: 0 auto;
    padding: var(--s-3) var(--gutter) var(--s-6);
    display: grid; grid-template-columns: 1fr; gap: var(--s-4);
  }
  @media (min-width: 900px) {
    .layout { grid-template-columns: 240px 1fr; gap: var(--s-5); padding-top: var(--s-4); }
  }
  .catalog__head {
    display: flex; align-items: baseline; justify-content: space-between;
    gap: var(--s-3); margin-bottom: var(--s-3); flex-wrap: wrap;
  }
  .catalog__title { font-size: 22px; font-weight: 700; margin: 0; }
  .catalog__title .num { color: var(--ink-soft); font-weight: 500; font-size: 15px; margin-left: 6px; }
  .sort { display: inline-flex; align-items: center; gap: 6px; font-size: 13px; color: var(--ink); position: relative; }
  .sort span { color: var(--ink-soft); }
  .sort select { appearance: none; background: transparent; border: 0; font: inherit; color: var(--ink); padding-right: 16px; cursor: pointer; }
  .sort svg { width: 12px; height: 12px; stroke: var(--ink); position: absolute; right: 0; pointer-events: none; }

  .grid {
    display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: var(--s-2);
  }
  @media (min-width: 600px) { .grid { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: var(--s-3); } }
  @media (min-width: 1100px) { .grid { grid-template-columns: repeat(4, minmax(0, 1fr)); } }

  .empty {
    text-align: center; padding: var(--s-6) var(--s-3);
    color: var(--ink-soft); font-size: 14px;
    background: var(--paper-card); border: 1px dashed var(--line-strong); border-radius: var(--r);
  }
</style>
