<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { t } from '$lib/i18n';
</script>

<svelte:head>
  <title>{$t('contactsTitle')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="info-page">
  <h1>{$t('contactsHeading')}</h1>

  <div class="contacts-grid">
    <div class="card">
      <h3>{$t('customerSupport')}</h3>
      <p>{$t('customerSupportDesc')}</p>
      <a href="mailto:support@graflab.ru" class="link">support@graflab.ru</a>
    </div>
    <div class="card">
      <h3>{$t('partnership')}</h3>
      <p>{$t('partnershipDesc')}</p>
      <a href="mailto:b2b@graflab.ru" class="link">b2b@graflab.ru</a>
    </div>
    <div class="card">
      <h3>{$t('generalQuestions')}</h3>
      <p>{$t('generalQuestionsDesc')}</p>
      <a href="mailto:info@graflab.ru" class="link">info@graflab.ru</a>
    </div>
  </div>

  <section class="block">
    <h2>{$t('companyDetails')}</h2>
    <p>{$t('companyDetailsText')}</p>
  </section>
</main>

<Tabbar />

<style>
  .info-page {
    max-width: 800px; margin: 0 auto;
    padding: var(--s-4) var(--gutter) var(--s-6);
  }
  h1 { font-size: 28px; font-weight: 700; margin: 0 0 var(--s-4); }
  .contacts-grid {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: var(--s-3); margin-bottom: var(--s-5);
  }
  .card {
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: var(--r); padding: var(--s-4);
  }
  .card h3 { font-size: 16px; font-weight: 700; margin: 0 0 6px; }
  .card p { color: var(--ink-soft); font-size: 13px; margin: 0 0 var(--s-2); line-height: 1.5; }
  .link { color: var(--accent); font-weight: 600; font-size: 14px; }
  .block h2 { font-size: 18px; font-weight: 700; margin: 0 0 var(--s-2); }
  .block p { color: var(--ink-soft); font-size: 15px; line-height: 1.6; margin: 0; }
</style>
