<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { formatPrice } from '$lib/utils/format';
  import { t } from '$lib/i18n';

  let phone = '';
  let orders: any[] | null = null;
  let loading = false;
  let error = '';

  $: statusLabels = {
    new: $t('statusNew'), paid: $t('statusPaid'), packed: $t('statusPacked'),
    shipped: $t('statusShipped'), delivered: $t('statusDelivered'), cancelled: $t('statusCancelled')
  } as Record<string, string>;

  async function findOrders() {
    if (!phone.trim()) return;
    loading = true;
    error = '';
    try {
      const res = await fetch(`/api/my-orders?phone=${encodeURIComponent(phone.trim())}`);
      if (res.ok) {
        orders = await res.json();
      } else {
        error = $t('couldNotFindOrders');
        orders = [];
      }
    } catch {
      error = $t('connectionError');
    } finally {
      loading = false;
    }
  }
</script>

<svelte:head>
  <title>{$t('myOrdersTitle')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="account-page">
  <h1>{$t('myOrdersTitle')}</h1>
  <p class="desc">{$t('orderLookupHint')}</p>

  <form class="phone-form" on:submit|preventDefault={findOrders}>
    <input
      type="tel"
      bind:value={phone}
      placeholder="+49 ___-___-____"
      required
    />
    <button type="submit" disabled={loading}>
      {loading ? $t('searching') : $t('findOrders')}
    </button>
  </form>

  {#if error}
    <div class="error-msg">{error}</div>
  {/if}

  {#if orders !== null}
    {#if orders.length === 0}
      <p class="empty">{$t('noOrdersForPhone')}</p>
    {:else}
      <div class="orders-list">
        {#each orders as o}
          <div class="order-card">
            <div class="order-head">
              <span class="order-num num">{o.number}</span>
              <span class="status status--{o.status}">{statusLabels[o.status] ?? o.status}</span>
              <span class="order-date">{new Date(o.createdAt).toLocaleDateString('ru-RU')}</span>
            </div>
            <div class="order-total num">{formatPrice(o.totalRub)}</div>
            {#if o.items?.length > 0}
              <div class="order-items">
                {#each o.items as item}
                  <span class="item-name">{item.name} × {item.quantity}</span>
                {/each}
              </div>
            {/if}
          </div>
        {/each}
      </div>
    {/if}
  {/if}
</main>

<Tabbar />

<style>
  .account-page {
    max-width: 600px; margin: 0 auto;
    padding: var(--s-4) var(--gutter) var(--s-6);
  }
  h1 { font-size: 26px; font-weight: 700; margin: 0 0 var(--s-2); }
  .desc { color: var(--ink-soft); font-size: 14px; margin: 0 0 var(--s-4); }

  .phone-form {
    display: flex; gap: var(--s-2); margin-bottom: var(--s-4);
  }
  .phone-form input {
    flex: 1; border: 1px solid var(--line-strong);
    border-radius: 99px; padding: 14px 20px; font-size: 15px;
    background: var(--paper-card);
  }
  .phone-form input:focus { outline: 0; border-color: var(--accent); }
  .phone-form button {
    background: var(--brand); color: #fff; border: 0;
    border-radius: 99px; padding: 14px 24px;
    font-size: 14px; font-weight: 700; white-space: nowrap;
  }
  .phone-form button:hover:not(:disabled) { background: var(--brand-hover); }
  .phone-form button:disabled { opacity: 0.5; }

  .error-msg {
    background: #fef2f2; color: #c33; padding: 12px 16px;
    border-radius: var(--r); margin-bottom: var(--s-3); font-size: 14px;
  }
  .empty { color: var(--ink-soft); }

  .orders-list { display: flex; flex-direction: column; gap: var(--s-2); }
  .order-card {
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: var(--r); padding: var(--s-3);
  }
  .order-head {
    display: flex; align-items: center; gap: var(--s-2); flex-wrap: wrap;
    margin-bottom: 8px;
  }
  .order-num { font-weight: 700; font-size: 15px; }
  .status {
    display: inline-block; padding: 3px 10px; border-radius: 99px;
    font-size: 11px; font-weight: 600;
  }
  .status--new { background: #e3f2fd; color: #1565c0; }
  .status--paid { background: #e8f5e9; color: #2e7d32; }
  .status--packed { background: #fff3e0; color: #e65100; }
  .status--shipped { background: #f3e5f5; color: #7b1fa2; }
  .status--delivered { background: #e8f5e9; color: #1b5e20; }
  .status--cancelled { background: #fafafa; color: #999; }
  .order-date { color: var(--ink-faint); font-size: 13px; }
  .order-total { font-size: 18px; font-weight: 700; margin-bottom: 8px; }
  .order-items { display: flex; flex-wrap: wrap; gap: 6px; }
  .item-name {
    font-size: 12px; color: var(--ink-soft);
    background: var(--paper-deep); padding: 4px 10px; border-radius: 99px;
  }
</style>
