<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { t } from '$lib/i18n';
</script>

<svelte:head>
  <title>{$t('labTitle')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="info-page">
  <h1>{$t('labHeading')}</h1>

  <section class="hero-lab">
    <img src="/brand/logo-mark.png" alt="" class="hero-mark" />
    <p class="hero-text">
      {$t('labIntro')}
    </p>
  </section>

  <div class="pillars">
    <div class="pillar">
      <div class="pillar__num">01</div>
      <h3>{$t('workingDoses')}</h3>
      <p>{$t('workingDosesText')}</p>
    </div>
    <div class="pillar">
      <div class="pillar__num">02</div>
      <h3>{$t('batchControl')}</h3>
      <p>{$t('batchControlText')}</p>
    </div>
    <div class="pillar">
      <div class="pillar__num">03</div>
      <h3>{$t('euManufacturing')}</h3>
      <p>{$t('euManufacturingText')}</p>
    </div>
    <div class="pillar">
      <div class="pillar__num">04</div>
      <h3>{$t('transparency')}</h3>
      <p>{$t('transparencyText')}</p>
    </div>
  </div>

  <section class="block">
    <h2>{$t('certificatesSection')}</h2>
    <p>{$t('certificatesText')}</p>
  </section>
</main>

<Tabbar />

<style>
  .info-page {
    max-width: 900px; margin: 0 auto;
    padding: var(--s-4) var(--gutter) var(--s-6);
  }
  h1 { font-size: 28px; font-weight: 700; margin: 0 0 var(--s-4); }

  .hero-lab {
    display: flex; align-items: center; gap: var(--s-4);
    background: var(--paper-deep); border-radius: var(--r);
    padding: var(--s-4); margin-bottom: var(--s-5);
  }
  .hero-mark { width: 64px; height: 64px; object-fit: contain; flex: 0 0 auto; }
  .hero-text { margin: 0; font-size: 16px; line-height: 1.6; color: var(--ink); }

  .pillars {
    display: grid; grid-template-columns: 1fr 1fr; gap: var(--s-3);
    margin-bottom: var(--s-5);
  }
  @media (max-width: 600px) { .pillars { grid-template-columns: 1fr; } }
  .pillar {
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: var(--r); padding: var(--s-4);
  }
  .pillar__num {
    font-size: 12px; font-weight: 700; color: var(--accent);
    letter-spacing: 0.1em; margin-bottom: 8px;
  }
  .pillar h3 { font-size: 16px; font-weight: 700; margin: 0 0 8px; }
  .pillar p { color: var(--ink-soft); font-size: 13px; line-height: 1.5; margin: 0; }

  .block h2 { font-size: 18px; font-weight: 700; margin: 0 0 var(--s-2); }
  .block p { color: var(--ink-soft); font-size: 15px; line-height: 1.6; margin: 0; }
  .block a { color: var(--accent); font-weight: 600; }
</style>
