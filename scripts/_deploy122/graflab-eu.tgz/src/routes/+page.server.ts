import { db, schema } from '$server/db';
import { eq, desc, sql, count } from 'drizzle-orm';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
  const [products, cats] = await Promise.all([
    db
      .select({
        id: schema.euProducts.id,
        article: schema.euProducts.article,
        slug: schema.euProducts.slug,
        name: schema.euProducts.name,
        nameSr: schema.euProducts.nameSr,
        categorySlug: schema.euCategories.slug,
        priceRub: schema.euProducts.priceRub,
        priceOldRub: schema.euProducts.priceOldRub,
        imageUrl: schema.euProducts.imageUrl,
        rating: schema.euProducts.rating,
        reviewsCount: schema.euProducts.reviewsCount,
        inStock: schema.euProducts.inStock
      })
      .from(schema.euProducts)
      .leftJoin(schema.euCategories, eq(schema.euProducts.categoryId, schema.euCategories.id))
      .where(eq(schema.euProducts.active, true))
      .orderBy(desc(schema.euProducts.priceRub)),

    db
      .select({
        id: schema.euCategories.id,
        slug: schema.euCategories.slug,
        name: schema.euCategories.name,
        nameSr: schema.euCategories.nameSr,
        sortOrder: schema.euCategories.sortOrder,
        count: count(schema.euProducts.id)
      })
      .from(schema.euCategories)
      .leftJoin(
        schema.euProducts,
        sql`${schema.euProducts.categoryId} = ${schema.euCategories.id} and ${schema.euProducts.active} = true`
      )
      .groupBy(
        schema.euCategories.id,
        schema.euCategories.slug,
        schema.euCategories.name,
        schema.euCategories.nameSr,
        schema.euCategories.sortOrder
      )
      .orderBy(schema.euCategories.sortOrder)
  ]);

  // Для каждой категории — фото первого товара (для визуальных плиток)
  const catsWithImage = cats.filter((c) => c.count > 0).map((c) => {
    const firstProduct = products.find((p) => p.categorySlug === c.slug);
    return { ...c, imageUrl: firstProduct?.imageUrl ?? null };
  });

  return {
    products,
    categories: catsWithImage
  };
};
