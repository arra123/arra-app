import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import type { RequestHandler } from './$types';

export const GET: RequestHandler = async ({ url }) => {
  const base = url.origin;

  const products = await db
    .select({ id: schema.euProducts.id, slug: schema.euProducts.slug })
    .from(schema.euProducts)
    .where(eq(schema.euProducts.active, true));

  const categories = await db
    .select({ slug: schema.euCategories.slug })
    .from(schema.euCategories);

  const staticPages = ['/', '/delivery', '/lab', '/contacts', '/about', '/search'];

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

  for (const page of staticPages) {
    xml += `  <url><loc>${base}${page}</loc><changefreq>weekly</changefreq></url>\n`;
  }

  for (const p of products) {
    xml += `  <url><loc>${base}/product/${p.id}</loc><changefreq>daily</changefreq></url>\n`;
  }

  xml += '</urlset>';

  return new Response(xml, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'max-age=3600'
    }
  });
};
