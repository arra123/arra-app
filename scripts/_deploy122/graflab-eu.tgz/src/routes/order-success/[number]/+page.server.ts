import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import { error } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ params }) => {
  const number = params.number;
  if (!number) throw error(404, 'Order not found');

  const [order] = await db
    .select({
      id: schema.euOrders.id,
      number: schema.euOrders.number,
      totalRub: schema.euOrders.totalRub,
      status: schema.euOrders.status,
      deliveryAddress: schema.euOrders.deliveryAddress,
      createdAt: schema.euOrders.createdAt,
      customerPhone: schema.euCustomers.phone,
      customerName: schema.euCustomers.name
    })
    .from(schema.euOrders)
    .leftJoin(schema.euCustomers, eq(schema.euOrders.customerId, schema.euCustomers.id))
    .where(eq(schema.euOrders.number, number))
    .limit(1);

  if (!order) throw error(404, 'Order not found');

  const items = await db
    .select({
      id: schema.euOrderItems.id,
      quantity: schema.euOrderItems.quantity,
      priceRub: schema.euOrderItems.priceRub,
      productName: schema.euProducts.name,
      productNameSr: schema.euProducts.nameSr,
      productImageUrl: schema.euProducts.imageUrl
    })
    .from(schema.euOrderItems)
    .leftJoin(schema.euProducts, eq(schema.euOrderItems.productId, schema.euProducts.id))
    .where(eq(schema.euOrderItems.orderId, order.id));

  return { order, items };
};
