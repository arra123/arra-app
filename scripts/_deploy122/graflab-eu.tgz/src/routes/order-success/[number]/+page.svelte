<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { formatPrice } from '$lib/utils/format';
  import { t, locale } from '$lib/i18n';
  import type { PageData } from './$types';

  export let data: PageData;
</script>

<svelte:head>
  <title>{$t('orderPlaced')} {data.order.number} — GRAFLAB</title>
  <meta name="robots" content="noindex" />
</svelte:head>

<Header />

<main class="page">
  <div class="success">
    <div class="success__icon">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
        <polyline points="22 4 12 14.01 9 11.01"/>
      </svg>
    </div>
    <h1>{$t('orderPlaced')}</h1>
    <p class="success__sub">{$t('orderPlacedMsg')}</p>

    <div class="order-card">
      <div class="order-num">
        <span class="order-num__label">{$t('orderNumber')}</span>
        <span class="order-num__value num">{data.order.number}</span>
      </div>

      <div class="items">
        {#each data.items as item (item.id)}
          <div class="item">
            <img src={item.productImageUrl ?? '/brand/logo-mark.png'} alt="" />
            <div class="item__info">
              <div class="item__name">
                {$locale === 'sr' && item.productNameSr ? item.productNameSr : (item.productName ?? '—')}
              </div>
              <div class="item__qty num">{item.quantity} × {formatPrice(item.priceRub)}</div>
            </div>
            <div class="item__total num">{formatPrice(item.priceRub * item.quantity)}</div>
          </div>
        {/each}
      </div>

      <div class="total-row">
        <span>{$t('total')}</span>
        <span class="num total-value">{formatPrice(data.order.totalRub)}</span>
      </div>

      {#if data.order.deliveryAddress}
        <div class="addr">
          <div class="addr__label">{$t('deliveryAddress')}</div>
          <div class="addr__value">{data.order.deliveryAddress}</div>
        </div>
      {/if}

      {#if data.order.customerPhone}
        <p class="contact-note">
          {$t('weWillContact')} <span class="num">+{data.order.customerPhone}</span>
        </p>
      {/if}
    </div>

    <a href="/" class="btn-back">{$t('returnToCatalog')}</a>
  </div>
</main>

<Tabbar />

<style>
  .page {
    max-width: 640px;
    margin: 0 auto;
    padding: var(--s-5) var(--gutter) var(--s-6);
  }
  .success {
    text-align: center;
  }
  .success__icon {
    width: 72px;
    height: 72px;
    margin: 0 auto var(--s-3);
    border-radius: 50%;
    background: var(--accent-soft);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: var(--ok);
  }
  .success__icon svg { width: 40px; height: 40px; }
  h1 {
    font-size: 28px;
    font-weight: 800;
    margin: 0 0 8px;
    color: var(--ok);
    letter-spacing: -0.01em;
  }
  .success__sub {
    color: var(--ink-soft);
    margin: 0 0 var(--s-4);
    font-size: 15px;
  }

  .order-card {
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: var(--r);
    padding: var(--s-3) var(--s-3) var(--s-4);
    text-align: left;
    margin-bottom: var(--s-4);
  }
  .order-num {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    padding-bottom: var(--s-2);
    border-bottom: 1px solid var(--line);
    margin-bottom: var(--s-3);
  }
  .order-num__label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--ink-soft);
    font-weight: 600;
  }
  .order-num__value {
    font-size: 17px;
    font-weight: 800;
    color: var(--accent);
    letter-spacing: 0.02em;
  }

  .items {
    display: flex;
    flex-direction: column;
    gap: var(--s-2);
    margin-bottom: var(--s-3);
  }
  .item {
    display: grid;
    grid-template-columns: 48px 1fr auto;
    gap: 12px;
    align-items: center;
    font-size: 13px;
  }
  .item img {
    width: 48px; height: 48px;
    object-fit: contain;
    background: #fff;
    border: 1px solid var(--line);
    border-radius: 8px;
  }
  .item__info { min-width: 0; }
  .item__name {
    font-weight: 500;
    color: var(--ink);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .item__qty {
    color: var(--ink-soft);
    font-size: 12px;
  }
  .item__total {
    font-weight: 700;
    color: var(--ink);
  }

  .total-row {
    display: flex;
    justify-content: space-between;
    align-items: baseline;
    padding-top: var(--s-3);
    border-top: 2px solid var(--line);
    font-size: 15px;
    font-weight: 600;
  }
  .total-value {
    font-size: 22px;
    font-weight: 800;
  }

  .addr {
    margin-top: var(--s-3);
    padding-top: var(--s-3);
    border-top: 1px solid var(--line);
  }
  .addr__label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--ink-soft);
    margin-bottom: 4px;
    font-weight: 600;
  }
  .addr__value { font-size: 14px; color: var(--ink); }

  .contact-note {
    margin: var(--s-3) 0 0;
    font-size: 13px;
    color: var(--ink-soft);
    padding-top: var(--s-2);
    border-top: 1px dashed var(--line);
  }

  .btn-back {
    display: inline-block;
    padding: 14px 28px;
    background: var(--brand);
    color: #fff;
    border-radius: 99px;
    font-weight: 700;
    font-size: 14px;
  }
  .btn-back:hover { background: var(--brand-hover); }
</style>
