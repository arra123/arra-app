import { db, schema } from '$server/db';
import { getCustomerBySession } from '$lib/server/customer-auth';
import type { PageServerLoad } from './$types';

/**
 * Корзина хранится на клиенте (localStorage). На сервере мы не знаем
 * что в ней лежит — поэтому load грузит ВСЕ активные товары (95 шт —
 * они и так нужны для каталога, кешируются Svelte), а страница на
 * клиенте фильтрует по линиям cart store.
 *
 * Когда товаров будет >500 — переделаем на API POST с массивом id.
 * Сейчас при 95 товарах это overkill.
 */
export const load: PageServerLoad = async ({ cookies }) => {
  const products = await db
    .select({
      id: schema.euProducts.id,
      name: schema.euProducts.name,
      nameSr: schema.euProducts.nameSr,
      imageUrl: schema.euProducts.imageUrl,
      priceRub: schema.euProducts.priceRub,
      priceOldRub: schema.euProducts.priceOldRub,
      inStock: schema.euProducts.inStock
    })
    .from(schema.euProducts);

  // Узнаём балансы покупателя, если он залогинен (для списания бонусов)
  const sessionId = cookies.get('customer_session');
  const customer = sessionId ? await getCustomerBySession(sessionId) : null;

  return {
    allProducts: products,
    customer: customer
      ? {
          name: customer.name,
          phone: customer.phone,
          bonusBalance: customer.bonusBalance ?? 0
        }
      : null
  };
};
