<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import Pcard from '$lib/components/Pcard.svelte';
  import { cart } from '$lib/stores/cart';
  import { formatPrice } from '$lib/utils/format';
  import { t, locale } from '$lib/i18n';
  import { goto } from '$app/navigation';
  import type { PageData } from './$types';

  export let data: PageData;

  // Соединяем линии корзины с данными товаров из БД.
  $: productMap = new Map(data.allProducts.map((p) => [p.id, p]));
  $: lines = $cart.lines
    .map((l) => {
      const p = productMap.get(l.productId);
      if (!p) return null;
      return { ...l, product: p };
    })
    .filter(Boolean) as { productId: number; qty: number; product: (typeof data.allProducts)[0] }[];
  $: totalRub = lines.reduce((sum, l) => sum + l.product.priceRub * l.qty, 0);
  $: totalCount = lines.reduce((sum, l) => sum + l.qty, 0);

  // Прогресс-бар бесплатной доставки (€50 в центах)
  const FREE_DELIVERY = 5000;
  $: deliveryProgress = Math.min((totalRub / FREE_DELIVERY) * 100, 100);
  $: deliveryLeft = Math.max(FREE_DELIVERY - totalRub, 0);
  $: hasFreeDelivery = totalRub >= FREE_DELIVERY;

  // "Вам может понравиться" — 4 случайных товара не из корзины
  $: cartProductIds = new Set(lines.map((l) => l.productId));
  $: suggestions = data.allProducts
    .filter((p) => !cartProductIds.has(p.id))
    .sort(() => Math.random() - 0.5)
    .slice(0, 4);

  // Форма оформления
  let customerName = data.customer?.name ?? '';
  let customerPhone = data.customer?.phone ?? '';
  let deliveryAddress = '';
  let comment = '';
  let useBonuses = false;
  let orderError = '';
  let submitting = false;

  // Сколько бонусов реально применится: не больше чем на балансе и не больше чем totalRub
  $: bonusBalance = data.customer?.bonusBalance ?? 0;
  $: bonusApplied = useBonuses ? Math.min(bonusBalance, totalRub) : 0;
  $: totalAfterBonus = Math.max(totalRub - bonusApplied, 0);

  function clearCart() {
    if (confirm($t('clearCartConfirm'))) cart.clear();
  }

  async function submitOrder() {
    if (!customerPhone.trim()) return;
    submitting = true;
    orderError = '';
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lines: lines.map((l) => ({ productId: l.productId, qty: l.qty })),
          customerName: customerName.trim(),
          customerPhone: customerPhone.trim(),
          deliveryAddress: deliveryAddress.trim(),
          comment: comment.trim(),
          useBonuses
        })
      });
      const d = await res.json().catch(() => ({}));
      if (res.ok && d.orderNumber) {
        cart.clear();
        await goto(`/order-success/${d.orderNumber}`);
      } else {
        orderError = d.message || 'Ошибка оформления';
      }
    } catch {
      orderError = 'Ошибка сети';
    } finally {
      submitting = false;
    }
  }
</script>

<svelte:head>
  <title>{$t('cartTitle')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="page">
  <div class="head">
    <h1>{$t('cartTitle')}</h1>
    {#if lines.length > 0}
      <button class="clear-btn" type="button" on:click={clearCart}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
        </svg>
        {$t('clearCart')}
      </button>
    {/if}
  </div>

  {#if lines.length === 0}
    <div class="empty">
      <p>{$t('cartEmpty')}</p>
      <a href="/" class="btn-back">{$t('toCatalog')}</a>
    </div>
  {:else}
    <div class="cart-layout">
      <section class="cart-lines">
        {#each lines as line (line.productId)}
          <div class="line">
            <a href="/product/{line.product.id}" class="line__img">
              <img src={line.product.imageUrl} alt={$locale === 'sr' && line.product.nameSr ? line.product.nameSr : line.product.name} loading="lazy" />
            </a>
            <div class="line__info">
              <a href="/product/{line.product.id}" class="line__name">{$locale === 'sr' && line.product.nameSr ? line.product.nameSr : line.product.name}</a>
              <div class="line__price num">{formatPrice(line.product.priceRub)}</div>
            </div>
            <div class="line__qty">
              <button on:click={() => cart.remove(line.productId)}>−</button>
              <span class="num">{line.qty}</span>
              <button on:click={() => cart.add(line.productId)}>+</button>
            </div>
            <div class="line__total num">{formatPrice(line.product.priceRub * line.qty)}</div>
            <button
              class="line__del"
              type="button"
              on:click={() => cart.removeLine(line.productId)}
              aria-label={$t('removeLine')}
              title={$t('removeLine')}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/>
              </svg>
            </button>
          </div>
        {/each}
      </section>

      <aside class="checkout">
        <div class="delivery-bar">
          {#if hasFreeDelivery}
            <div class="delivery-bar__msg delivery-bar__msg--ok">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
                <path d="M5 13l4 4L19 7"/>
              </svg>
              {$t('freeDeliveryApplied')}
            </div>
          {:else}
            <div class="delivery-bar__msg">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
                <rect x="1" y="3" width="15" height="13" rx="2"/>
                <path d="M16 8h4l3 5v4h-7V8z"/>
                <circle cx="5.5" cy="18.5" r="2.5"/>
                <circle cx="18.5" cy="18.5" r="2.5"/>
              </svg>
              {$t('untilFreeDelivery')}: <strong class="num">{formatPrice(deliveryLeft)}</strong>
            </div>
          {/if}
          <div class="delivery-bar__track">
            <div class="delivery-bar__fill" style="width: {deliveryProgress}%"></div>
          </div>
          {#if !hasFreeDelivery}
            <div class="delivery-bar__labels">
              <span>€0</span>
              <span>{$t('freeDeliveryThreshold')}</span>
            </div>
          {/if}
        </div>

        <div class="checkout__summary">
          <div class="checkout__row">
            <span>{$t('items')}</span>
            <span class="num">{totalCount} {$t('pcs')}</span>
          </div>
          {#if data.customer && bonusBalance > 0}
            <label class="checkout__bonus">
              <input type="checkbox" bind:checked={useBonuses} />
              <span>{$t('useBonusesLabel')} <strong class="num">{formatPrice(bonusBalance)}</strong></span>
            </label>
            {#if bonusApplied > 0}
              <div class="checkout__row checkout__row--discount">
                <span>{$t('bonusDiscount')}</span>
                <span class="num">−{formatPrice(bonusApplied)}</span>
              </div>
            {/if}
          {/if}
          <div class="checkout__row checkout__row--total">
            <span>{$t('total')}</span>
            <span class="num">{formatPrice(totalAfterBonus)}</span>
          </div>
        </div>

        <form on:submit|preventDefault={submitOrder} class="checkout__form">
          <h2>{$t('placeOrder')}</h2>
          <input type="text" bind:value={customerName} placeholder={$t('yourName')} />
          <input
            type="tel"
            bind:value={customerPhone}
            placeholder={$t('phone') + ' *'}
            required
          />
          <input type="text" bind:value={deliveryAddress} placeholder={$t('deliveryAddress')} />
          <textarea bind:value={comment} placeholder={$t('orderComment')} rows="2"></textarea>
          <button class="btn-submit" type="submit" disabled={submitting || !customerPhone.trim()}>
            {submitting ? $t('sending') : $t('placeOrder')}
          </button>
          {#if orderError}
            <p class="checkout__err">{orderError}</p>
          {/if}
          <p class="checkout__note">
            {$t('paymentNote')}
          </p>
        </form>
      </aside>
    </div>
  {/if}

  {#if suggestions.length > 0}
    <section class="suggestions">
      <h2 class="suggestions__title">{$t('youMightLike')}</h2>
      <div class="suggestions__grid">
        {#each suggestions as s (s.id)}
          <Pcard
            id={s.id}
            name={s.name}
            nameSr={s.nameSr}
            imageUrl={s.imageUrl}
            priceRub={s.priceRub}
            priceOldRub={s.priceOldRub}
            inStock={s.inStock}
          />
        {/each}
      </div>
    </section>
  {/if}
</main>

<Tabbar />

<style>
  .page {
    max-width: var(--maxw);
    margin: 0 auto;
    padding: var(--s-3) var(--gutter) var(--s-6);
  }
  .head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--s-3);
    margin: 0 0 var(--s-4);
  }
  h1 {
    font-size: 26px;
    font-weight: 700;
    margin: 0;
  }
  .clear-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: transparent;
    border: 1px solid var(--line);
    border-radius: 99px;
    color: var(--ink-soft);
    font-size: 13px;
    font-weight: 600;
    padding: 7px 14px;
    cursor: pointer;
    transition: color 0.12s, border-color 0.12s, background 0.12s;
  }
  .clear-btn svg { width: 14px; height: 14px; }
  .clear-btn:hover { color: #c43; border-color: #c43; background: #fff5f3; }
  .empty {
    text-align: center;
    padding: var(--s-6) var(--s-3);
    background: var(--paper-card);
    border: 1px dashed var(--line-strong);
    border-radius: var(--r);
  }
  .empty p {
    color: var(--ink-soft);
    margin: 0 0 var(--s-3);
  }
  .btn-back {
    display: inline-block;
    padding: 12px 24px;
    background: var(--brand);
    color: #fff;
    border-radius: 99px;
    font-weight: 700;
    font-size: 14px;
  }

  .cart-layout {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--s-4);
  }
  @media (min-width: 760px) {
    .cart-layout {
      grid-template-columns: 1fr 360px;
      gap: var(--s-5);
    }
  }

  .cart-lines {
    display: flex;
    flex-direction: column;
    gap: 0;
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: var(--r);
    overflow: hidden;
  }
  .line {
    display: grid;
    grid-template-columns: 60px 1fr auto auto auto;
    gap: var(--s-3);
    align-items: center;
    padding: var(--s-3);
    background: var(--paper-card);
  }
  .line + .line {
    border-top: 1px solid var(--line);
  }
  @media (max-width: 500px) {
    .line {
      grid-template-columns: 50px 1fr auto auto;
      gap: var(--s-2);
    }
    .line__total {
      display: none;
    }
  }
  .line__del {
    width: 32px;
    height: 32px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: transparent;
    border: 0;
    border-radius: 8px;
    color: var(--ink-faint);
    cursor: pointer;
    padding: 0;
    transition: color 0.12s, background 0.12s;
  }
  .line__del svg { width: 16px; height: 16px; }
  .line__del:hover { color: #c43; background: #fff5f3; }
  .line__img {
    width: 60px;
    height: 60px;
    border-radius: 8px;
    background: #fff;
    overflow: hidden;
    border: 1px solid var(--line);
  }
  .line__img img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  .line__info {
    min-width: 0;
  }
  .line__name {
    font-size: 13px;
    font-weight: 500;
    color: var(--ink);
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    margin-bottom: 4px;
  }
  .line__price {
    font-size: 14px;
    font-weight: 700;
    color: var(--ink);
  }
  .line__qty {
    display: flex;
    align-items: center;
    border: 1px solid var(--line-strong);
    border-radius: 99px;
    overflow: hidden;
    height: 36px;
  }
  .line__qty button {
    width: 32px;
    height: 100%;
    border: 0;
    background: transparent;
    font-size: 16px;
    font-weight: 600;
    color: var(--ink);
  }
  .line__qty button:hover {
    background: var(--paper-deep);
  }
  .line__qty span {
    padding: 0 6px;
    font-size: 14px;
    font-weight: 600;
  }
  .line__total {
    font-size: 15px;
    font-weight: 700;
    min-width: 80px;
    text-align: right;
  }

  .checkout {
    position: sticky;
    top: 130px;
    align-self: start;
  }
  .checkout__summary {
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: var(--r);
    padding: var(--s-3);
    margin-bottom: var(--s-3);
  }
  .checkout__row {
    display: flex;
    justify-content: space-between;
    font-size: 14px;
    color: var(--ink-soft);
    padding: 6px 0;
  }
  .checkout__row--total {
    font-size: 20px;
    font-weight: 700;
    color: var(--ink);
    border-top: 1px solid var(--line);
    padding-top: 12px;
    margin-top: 6px;
  }
  .checkout__row--discount {
    color: var(--ok);
    font-weight: 600;
  }
  .checkout__bonus {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 0;
    font-size: 13px;
    color: var(--ink);
    cursor: pointer;
    border-top: 1px dashed var(--line);
    margin-top: 4px;
  }
  .checkout__bonus input {
    accent-color: var(--brand);
  }
  .checkout__bonus strong {
    color: var(--ok);
  }
  .checkout__err {
    margin: 4px 0 0;
    font-size: 13px;
    color: #c33;
    text-align: center;
  }

  .checkout__form {
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: var(--r);
    padding: var(--s-3);
    display: flex;
    flex-direction: column;
    gap: var(--s-2);
  }
  .checkout__form h2 {
    font-size: 15px;
    font-weight: 700;
    margin: 0;
  }
  .checkout__form input,
  .checkout__form textarea {
    border: 1px solid var(--line-strong);
    border-radius: 10px;
    padding: 12px 14px;
    font-size: 14px;
    background: var(--paper);
    color: var(--ink);
    resize: vertical;
  }
  .checkout__form input:focus,
  .checkout__form textarea:focus {
    outline: 0;
    border-color: var(--accent);
  }
  .btn-submit {
    background: var(--brand);
    color: #fff;
    border: 0;
    border-radius: 99px;
    padding: 14px 20px;
    font-size: 15px;
    font-weight: 700;
    margin-top: var(--s-1);
  }
  .btn-submit:hover:not(:disabled) {
    background: var(--brand-hover);
  }
  .btn-submit:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  .checkout__note {
    font-size: 11px;
    color: var(--ink-faint);
    margin: 0;
    line-height: 1.4;
  }

  /* ── прогресс-бар доставки ── */
  .delivery-bar {
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: var(--r);
    padding: var(--s-3);
    margin-bottom: var(--s-3);
  }
  .delivery-bar__msg {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: var(--ink-soft);
    margin-bottom: var(--s-2);
  }
  .delivery-bar__msg svg {
    width: 16px;
    height: 16px;
    flex-shrink: 0;
    color: var(--accent);
  }
  .delivery-bar__msg strong {
    color: var(--ink);
  }
  .delivery-bar__msg--ok {
    color: var(--ok);
    font-weight: 600;
  }
  .delivery-bar__msg--ok svg {
    color: var(--ok);
  }
  .delivery-bar__track {
    height: 6px;
    background: var(--line);
    border-radius: 99px;
    overflow: hidden;
  }
  .delivery-bar__fill {
    height: 100%;
    background: var(--brand);
    border-radius: 99px;
    transition: width 0.4s ease;
  }
  .delivery-bar__labels {
    display: flex;
    justify-content: space-between;
    font-size: 10px;
    color: var(--ink-faint);
    margin-top: 5px;
    letter-spacing: 0.02em;
  }

  /* ── "Вам может понравиться" ── */
  .suggestions {
    margin-top: var(--s-6);
    padding-top: var(--s-5);
    border-top: 1px solid var(--line);
  }
  .suggestions__title {
    font-size: 20px;
    font-weight: 700;
    margin: 0 0 var(--s-3);
    letter-spacing: -0.01em;
  }
  .suggestions__grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: var(--s-2);
  }
  @media (min-width: 600px) {
    .suggestions__grid {
      grid-template-columns: repeat(4, 1fr);
      gap: var(--s-3);
    }
  }
</style>
