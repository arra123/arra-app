import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import { fail } from '@sveltejs/kit';
import { verifyPassword, hashPassword, getSessionCookie, validateSession } from '$server/auth';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
  return {};
};

export const actions: Actions = {
  default: async ({ request, cookies }) => {
    const sessionId = getSessionCookie(cookies);
    const user = await validateSession(sessionId);
    if (!user) return fail(401, { error: 'Не авторизован' });

    const data = await request.formData();
    const current = data.get('current')?.toString() || '';
    const next = data.get('next')?.toString() || '';
    const confirm = data.get('confirm')?.toString() || '';

    if (!current || !next) return fail(400, { error: 'Заполните все поля' });
    if (next.length < 6) return fail(400, { error: 'Минимум 6 символов' });
    if (next !== confirm) return fail(400, { error: 'Пароли не совпадают' });

    const users = await db
      .select()
      .from(schema.euAdminUsers)
      .where(eq(schema.euAdminUsers.id, user.userId))
      .limit(1);
    if (users.length === 0) return fail(500, { error: 'Пользователь не найден' });

    const valid = await verifyPassword(current, users[0].passwordHash);
    if (!valid) return fail(401, { error: 'Текущий пароль неверный' });

    const newHash = await hashPassword(next);
    await db
      .update(schema.euAdminUsers)
      .set({ passwordHash: newHash })
      .where(eq(schema.euAdminUsers.id, user.userId));

    return { success: true };
  }
};
