<script lang="ts">
  import { enhance } from '$app/forms';
  import { t } from '$lib/i18n';
  export let form: { error?: string; success?: boolean } | null = null;
</script>

<svelte:head>
  <title>{$t('changePassword')} — GRAFLAB Admin</title>
</svelte:head>

<div class="adm">
  <a href="/admin" class="back">← {$t('back')}</a>
  <h1>{$t('changePassword')}</h1>

  {#if form?.success}
    <div class="msg msg--ok">{$t('passwordChanged')}</div>
  {/if}
  {#if form?.error}
    <div class="msg msg--error">{form.error}</div>
  {/if}

  <form method="POST" use:enhance class="pw-form">
    <input type="password" name="current" placeholder={$t('currentPassword')} required autocomplete="current-password" />
    <input type="password" name="next" placeholder={$t('newPassword')} required autocomplete="new-password" />
    <input type="password" name="confirm" placeholder={$t('confirmPassword')} required autocomplete="new-password" />
    <button type="submit">{$t('changePassword')}</button>
  </form>
</div>

<style>
  .adm {
    max-width: 420px;
    margin: 0 auto;
    padding: 24px 20px 60px;
  }
  .back {
    display: inline-block;
    color: #666;
    font-size: 13px;
    margin-bottom: 20px;
  }
  h1 {
    font-size: 22px;
    font-weight: 700;
    margin: 0 0 20px;
  }
  .msg {
    padding: 10px 14px;
    border-radius: 8px;
    font-size: 13px;
    text-align: center;
    margin-bottom: 16px;
  }
  .msg--error { background: #fef2f2; color: #c33; }
  .msg--ok { background: #f0faf0; color: #2e7d32; }
  .pw-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .pw-form input {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 12px 14px;
    font-size: 14px;
  }
  .pw-form input:focus {
    outline: 0;
    border-color: #4a9159;
  }
  .pw-form button {
    background: #4a9159;
    color: #fff;
    border: 0;
    border-radius: 8px;
    padding: 12px;
    font-size: 15px;
    font-weight: 700;
    margin-top: 4px;
  }
  .pw-form button:hover {
    background: #3a7a47;
  }
</style>
