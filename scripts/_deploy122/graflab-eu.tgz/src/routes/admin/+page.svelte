<script lang="ts">
  import { formatPrice } from '$lib/utils/format';
  import { t } from '$lib/i18n';
  import type { PageData } from './$types';

  export let data: PageData;
  let search = '';

  $: filtered = data.products.filter((p) =>
    search ? p.name.toLowerCase().includes(search.toLowerCase()) || p.article.includes(search) : true
  );
</script>

<svelte:head>
  <title>{$t('products')} — GRAFLAB Admin</title>
</svelte:head>

<div class="adm">
  <div class="adm__head">
    <h1>{$t('products')} <span class="count">{data.products.length}</span></h1>
    <div class="adm__actions">
      <input type="search" bind:value={search} placeholder={$t('searchProducts')} class="adm__search" />
      <a href="/admin/categories" class="btn-secondary">{$t('categories')}</a>
      <a href="/admin/product/new" class="btn-primary">+ {$t('newProduct')}</a>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th></th>
          <th>{$t('colName')}</th>
          <th>{$t('colCategory')}</th>
          <th>{$t('colPrice')}</th>
          <th>{$t('colStatus')}</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {#each filtered as p (p.id)}
          <tr class:inactive={!p.active}>
            <td class="td-img">
              <img src={p.imageUrl} alt="" />
            </td>
            <td>
              <div class="td-name">{p.name}</div>
              <div class="td-art num">{$t('article')} {p.article}</div>
            </td>
            <td class="td-cat">{p.categoryName ?? '—'}</td>
            <td class="td-price num">{formatPrice(p.priceRub)}</td>
            <td>
              {#if !p.active}
                <span class="badge-off">{$t('hidden')}</span>
              {:else if p.inStock}
                <span class="badge-ok">{$t('inStock')}</span>
              {:else}
                <span class="badge-out">{$t('outOfStock')}</span>
              {/if}
            </td>
            <td>
              <a href="/admin/product/{p.id}" class="btn-edit">{$t('edit')}</a>
            </td>
          </tr>
        {/each}
      </tbody>
    </table>
  </div>
</div>

<style>
  .adm {
    max-width: 1200px;
    margin: 0 auto;
    padding: 24px 20px 60px;
  }
  .adm__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 20px;
    flex-wrap: wrap;
  }
  h1 {
    font-size: 24px;
    font-weight: 700;
    margin: 0;
  }
  h1 .count {
    color: #888;
    font-weight: 500;
    font-size: 16px;
  }
  .adm__actions {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
  }
  .adm__search {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 14px;
    width: 100%;
    max-width: 280px;
  }
  .btn-primary {
    background: #4a9159;
    color: #fff;
    padding: 10px 16px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    white-space: nowrap;
  }
  .btn-primary:hover { background: #3a7a47; }
  .btn-secondary {
    background: transparent;
    color: #333;
    border: 1px solid #ddd;
    padding: 9px 14px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 500;
    white-space: nowrap;
  }
  .btn-secondary:hover { border-color: #999; }
  .table-wrap {
    overflow-x: auto;
  }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
  }
  th {
    text-align: left;
    padding: 8px 12px;
    font-size: 11px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #888;
    border-bottom: 2px solid #eee;
    white-space: nowrap;
  }
  td {
    padding: 10px 12px;
    border-bottom: 1px solid #f0f0f0;
    vertical-align: middle;
  }
  tr.inactive {
    opacity: 0.45;
  }
  .td-img {
    width: 48px;
  }
  .td-img img {
    width: 42px;
    height: 42px;
    object-fit: contain;
    border-radius: 6px;
    border: 1px solid #eee;
  }
  .td-name {
    font-weight: 500;
    max-width: 360px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .td-art {
    font-size: 11px;
    color: #999;
    margin-top: 2px;
  }
  .td-cat {
    color: #666;
    white-space: nowrap;
  }
  .td-price {
    font-weight: 700;
    white-space: nowrap;
  }
  .badge-ok {
    display: inline-block;
    padding: 3px 8px;
    background: #e8f5e9;
    color: #2e7d32;
    border-radius: 99px;
    font-size: 11px;
    font-weight: 600;
  }
  .badge-off {
    display: inline-block;
    padding: 3px 8px;
    background: #fafafa;
    color: #999;
    border-radius: 99px;
    font-size: 11px;
    font-weight: 600;
  }
  .badge-out {
    display: inline-block;
    padding: 3px 8px;
    background: #fff3e0;
    color: #e65100;
    border-radius: 99px;
    font-size: 11px;
    font-weight: 600;
  }
  .btn-edit {
    display: inline-block;
    padding: 6px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 12px;
    color: #333;
    white-space: nowrap;
  }
  .btn-edit:hover {
    background: #f5f5f5;
    border-color: #bbb;
  }
</style>
