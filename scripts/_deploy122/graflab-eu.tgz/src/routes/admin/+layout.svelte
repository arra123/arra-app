<script lang="ts">
  import { page } from '$app/stores';
  import { t, locale, type Locale } from '$lib/i18n';
  import type { LayoutData } from './$types';
  export let data: LayoutData;

  const LANGS: { code: Locale; label: string }[] = [
    { code: 'en', label: 'EN' },
    { code: 'sr', label: 'SR' },
    { code: 'ru', label: 'RU' }
  ];
</script>

{#if data.adminUser}
  <nav class="admin-bar">
    <a href="/admin/dashboard" class="admin-bar__brand">GRAFLAB Admin</a>
    <div class="admin-bar__links">
      <a href="/admin/dashboard" class:active={$page.url.pathname === '/admin/dashboard'}>{$t('dashboard')}</a>
      <a href="/admin" class:active={$page.url.pathname === '/admin'}>{$t('products')}</a>
      <a href="/admin/orders" class:active={$page.url.pathname.startsWith('/admin/orders')}>{$t('orders')}</a>
    </div>
    <div class="admin-bar__right">
      <div class="admin-bar__lang" role="group" aria-label="Language">
        {#each LANGS as l}
          <button
            type="button"
            class:active={$locale === l.code}
            on:click={() => locale.set(l.code)}
          >{l.label}</button>
        {/each}
      </div>
      <a href="/admin/password" class="admin-bar__pw">{$t('password')}</a>
      <span class="admin-bar__user">{data.adminUser.login}</span>
      <form method="POST" action="/admin/logout" style="display:inline">
        <button type="submit" class="admin-bar__logout">{$t('logout')}</button>
      </form>
    </div>
  </nav>
{/if}

<slot />

<style>
  .admin-bar {
    background: #1a1a1a;
    color: #fff;
    display: flex;
    align-items: center;
    gap: 24px;
    padding: 0 20px;
    height: 52px;
    font-size: 14px;
    position: sticky;
    top: 0;
    z-index: 100;
  }
  .admin-bar__brand {
    font-weight: 700;
    font-size: 16px;
    letter-spacing: 0.04em;
    color: #fff;
    white-space: nowrap;
  }
  .admin-bar__links {
    display: flex;
    gap: 4px;
  }
  .admin-bar__links a {
    color: #aaa;
    padding: 6px 12px;
    border-radius: 6px;
    transition: color 0.15s, background 0.15s;
  }
  .admin-bar__links a:hover {
    color: #fff;
    background: #2a2a2a;
  }
  .admin-bar__links a.active {
    color: #fff;
    background: #2d6b3e;
  }
  .admin-bar__right {
    margin-left: auto;
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .admin-bar__pw {
    color: #666;
    font-size: 12px;
  }
  .admin-bar__pw:hover {
    color: #fff;
  }
  .admin-bar__user {
    color: #888;
    font-size: 13px;
  }
  .admin-bar__logout {
    background: transparent;
    border: 1px solid #444;
    color: #aaa;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 12px;
  }
  .admin-bar__logout:hover {
    color: #fff;
    border-color: #666;
  }
  .admin-bar__lang {
    display: inline-flex;
    background: #2a2a2a;
    border-radius: 6px;
    padding: 2px;
    gap: 2px;
  }
  .admin-bar__lang button {
    background: transparent;
    border: 0;
    color: #888;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.04em;
    padding: 4px 9px;
    border-radius: 4px;
    cursor: pointer;
    transition: color 0.12s, background 0.12s;
  }
  .admin-bar__lang button:hover {
    color: #fff;
  }
  .admin-bar__lang button.active {
    background: #2d6b3e;
    color: #fff;
  }
</style>
