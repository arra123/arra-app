import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
  const products = await db
    .select({
      id: schema.euProducts.id,
      article: schema.euProducts.article,
      name: schema.euProducts.name,
      categoryName: schema.euCategories.name,
      priceRub: schema.euProducts.priceRub,
      inStock: schema.euProducts.inStock,
      active: schema.euProducts.active,
      imageUrl: schema.euProducts.imageUrl
    })
    .from(schema.euProducts)
    .leftJoin(schema.euCategories, eq(schema.euProducts.categoryId, schema.euCategories.id))
    .orderBy(schema.euProducts.name);

  return { products };
};
