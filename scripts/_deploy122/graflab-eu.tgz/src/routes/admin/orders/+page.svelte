<script lang="ts">
  import { formatPrice } from '$lib/utils/format';
  import { goto } from '$app/navigation';
  import { enhance } from '$app/forms';
  import { t } from '$lib/i18n';
  import type { PageData } from './$types';
  export let data: PageData;

  $: statusLabels = {
    new: $t('statusNew'),
    paid: $t('statusPaid'),
    packed: $t('statusPacked'),
    shipped: $t('statusShipped'),
    delivered: $t('statusDelivered'),
    cancelled: $t('statusCancelled')
  } as Record<string, string>;

  let search = data.search;
  let statusFilter = data.statusFilter;

  function applyFilters() {
    const params = new URLSearchParams();
    if (search) params.set('q', search);
    if (statusFilter) params.set('status', statusFilter);
    goto(`/admin/orders${params.toString() ? '?' + params.toString() : ''}`, { replaceState: true });
  }

  function clearFilters() {
    search = '';
    statusFilter = '';
    goto('/admin/orders', { replaceState: true });
  }

  const hasFilter = search || statusFilter;

  const STATUS_ORDER = ['new', 'paid', 'packed', 'shipped', 'delivered', 'cancelled'] as const;
  $: statusCounts = data.orders.reduce<Record<string, number>>((acc, o) => {
    acc[o.status] = (acc[o.status] ?? 0) + 1;
    return acc;
  }, {});
  function filterByStatus(s: string) {
    statusFilter = statusFilter === s ? '' : s;
    applyFilters();
  }
</script>

<svelte:head>
  <title>{$t('orders')} — GRAFLAB Admin</title>
</svelte:head>

<div class="adm">
  <div class="adm__head">
    <h1>{$t('orders')} <span class="count">{data.orders.length}</span></h1>
    <div class="status-chips">
      {#each STATUS_ORDER as s}
        {#if statusCounts[s]}
          <button
            type="button"
            class="chip chip--{s}"
            class:active={statusFilter === s}
            on:click={() => filterByStatus(s)}
          >
            {statusLabels[s]}
            <span class="chip__n num">{statusCounts[s]}</span>
          </button>
        {/if}
      {/each}
    </div>
  </div>

  <!-- Поиск и фильтры -->
  <form class="filters" on:submit|preventDefault={applyFilters}>
    <input
      type="search"
      bind:value={search}
      placeholder={$t('searchOrders')}
      class="filters__search"
      on:keydown={(e) => e.key === 'Enter' && applyFilters()}
    />

    <select bind:value={statusFilter} class="filters__status" on:change={applyFilters}>
      <option value="">{$t('allStatuses')}</option>
      {#each Object.entries(statusLabels) as [val, label]}
        <option value={val}>{label}</option>
      {/each}
    </select>

    <button type="submit" class="btn-apply">{$t('find')}</button>

    {#if hasFilter}
      <button type="button" class="btn-clear" on:click={clearFilters}>{$t('reset')}</button>
    {/if}
  </form>

  {#if data.orders.length === 0}
    <p class="empty">
      {hasFilter ? $t('nothingFound') : $t('noOrders')}
    </p>
  {:else}
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>{$t('colNumber')}</th>
            <th>{$t('colStatus')}</th>
            <th>{$t('colCustomer')}</th>
            <th>{$t('colAmount')}</th>
            <th>{$t('colDate')}</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {#each data.orders as o (o.id)}
            <tr>
              <td class="td-num num">{o.number}</td>
              <td>
                <form method="POST" action="?/setStatus" use:enhance class="status-form">
                  <input type="hidden" name="id" value={o.id} />
                  <select
                    name="status"
                    class="status-select status--{o.status}"
                    on:change={(e) => e.currentTarget.form?.requestSubmit()}
                    value={o.status}
                  >
                    {#each Object.entries(statusLabels) as [val, label]}
                      <option value={val}>{label}</option>
                    {/each}
                  </select>
                </form>
              </td>
              <td>
                <div>{o.customerName || '—'}</div>
                <div class="td-phone num">{o.customerPhone || ''}</div>
              </td>
              <td class="td-total num">{formatPrice(o.totalRub)}</td>
              <td class="td-date">
                {new Date(o.createdAt).toLocaleDateString('ru-RU')}
                {new Date(o.createdAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
              </td>
              <td>
                <a href="/admin/orders/{o.id}" class="btn-view">{$t('open')}</a>
              </td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
  {/if}
</div>

<style>
  .adm {
    max-width: 1100px;
    margin: 0 auto;
    padding: 24px 20px 60px;
  }
  .adm__head {
    margin-bottom: 16px;
  }
  h1 {
    font-size: 24px;
    font-weight: 700;
    margin: 0;
  }
  h1 .count {
    color: #888;
    font-weight: 500;
    font-size: 16px;
  }
  .status-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-top: 10px;
  }
  .chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px 4px 12px;
    border: 1px solid #ddd;
    background: #fff;
    color: #555;
    font-size: 12px;
    font-weight: 600;
    border-radius: 99px;
    cursor: pointer;
    transition: border-color 0.12s, color 0.12s;
  }
  .chip:hover { border-color: #4a9159; color: #4a9159; }
  .chip.active { border-color: #4a9159; background: #4a9159; color: #fff; }
  .chip__n {
    min-width: 18px;
    padding: 0 6px;
    border-radius: 99px;
    background: #f0f0f0;
    color: #555;
    font-size: 11px;
    text-align: center;
  }
  .chip.active .chip__n { background: rgba(255,255,255,0.25); color: #fff; }
  .chip--new .chip__n { background: #fff3d0; color: #8a5c00; }
  .chip.active.chip--new .chip__n { background: rgba(255,255,255,0.25); color: #fff; }

  /* Фильтры */
  .filters {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
    margin-bottom: 20px;
  }
  .filters__search {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 9px 14px;
    font-size: 14px;
    flex: 1;
    min-width: 200px;
    max-width: 340px;
  }
  .filters__status {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 9px 12px;
    font-size: 14px;
    background: #fff;
  }
  .btn-apply {
    padding: 9px 18px;
    background: #4a9159;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
  }
  .btn-apply:hover { background: #3a7448; }
  .btn-clear {
    padding: 9px 14px;
    background: transparent;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 13px;
    color: #888;
    cursor: pointer;
  }
  .btn-clear:hover { color: #333; border-color: #bbb; }

  .empty { color: #888; }
  .table-wrap { overflow-x: auto; }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
  }
  th {
    text-align: left;
    padding: 8px 12px;
    font-size: 11px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #888;
    border-bottom: 2px solid #eee;
  }
  td {
    padding: 10px 12px;
    border-bottom: 1px solid #f0f0f0;
    vertical-align: middle;
  }
  .td-num { font-weight: 600; white-space: nowrap; }
  .status-form { margin: 0; }
  .status-select {
    padding: 4px 24px 4px 10px;
    border: 1px solid transparent;
    border-radius: 99px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    appearance: none;
    -webkit-appearance: none;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='%23666' d='M5 6L0 0h10z'/></svg>");
    background-repeat: no-repeat;
    background-position: right 8px center;
  }
  .status-select:hover { border-color: rgba(0,0,0,0.1); }
  .status-select.status--new { background-color: #e3f2fd; color: #1565c0; }
  .status-select.status--paid { background-color: #e8f5e9; color: #2e7d32; }
  .status-select.status--packed { background-color: #fff3e0; color: #e65100; }
  .status-select.status--shipped { background-color: #f3e5f5; color: #7b1fa2; }
  .status-select.status--delivered { background-color: #e8f5e9; color: #1b5e20; }
  .status-select.status--cancelled { background-color: #fafafa; color: #999; }
  .td-phone { font-size: 12px; color: #999; margin-top: 2px; }
  .td-total { font-weight: 700; white-space: nowrap; }
  .td-date { color: #888; white-space: nowrap; font-size: 13px; }
  .btn-view {
    display: inline-block;
    padding: 5px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 12px;
    color: #333;
    white-space: nowrap;
  }
  .btn-view:hover { background: #f5f5f5; border-color: #bbb; }
</style>
