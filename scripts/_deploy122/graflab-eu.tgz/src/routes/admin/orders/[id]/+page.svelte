<script lang="ts">
  import { formatPrice } from '$lib/utils/format';
  import { enhance } from '$app/forms';
  import { t } from '$lib/i18n';
  import type { PageData, ActionData } from './$types';

  export let data: PageData;
  export let form: ActionData;

  // Локально обновляем статус после action без перезагрузки
  let currentStatus = data.order.status;
  $: if (form?.success && form.status) currentStatus = form.status as string;

  $: statusLabels = {
    new: $t('statusNew'),
    paid: $t('statusPaid'),
    packed: $t('statusPacked'),
    shipped: $t('statusShipped'),
    delivered: $t('statusDelivered'),
    cancelled: $t('statusCancelled')
  } as Record<string, string>;

  const statusFlow = ['new', 'paid', 'packed', 'shipped', 'delivered'];

  $: deliveryLabels = {
    cdek: $t('deliveryCdek'),
    pickup: $t('deliveryPickup')
  } as Record<string, string>;
  $: paymentLabels = {
    yoomoney: $t('paymentYoomoney'),
    cod: $t('paymentCod')
  } as Record<string, string>;
</script>

<svelte:head>
  <title>{$t('order')} {data.order.number} — GRAFLAB Admin</title>
</svelte:head>

<div class="wrap">
  <div class="breadcrumb">
    <a href="/admin/orders">← {$t('orders')}</a>
  </div>

  <div class="head">
    <div>
      <h1>{$t('order')} <span class="num">#{data.order.number}</span></h1>
      <div class="head__date">
        {new Date(data.order.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}
        &nbsp;
        {new Date(data.order.createdAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
      </div>
    </div>
    <span class="status status--{currentStatus}">{statusLabels[currentStatus] ?? currentStatus}</span>
  </div>

  <!-- Смена статуса -->
  <div class="card">
    <div class="card__title">{$t('orderStatus')}</div>

    <!-- Прогресс-бар (не для cancelled) -->
    {#if currentStatus !== 'cancelled'}
      <div class="progress">
        {#each statusFlow as s}
          <div class="progress__step" class:done={statusFlow.indexOf(currentStatus) >= statusFlow.indexOf(s)} class:current={s === currentStatus}>
            <div class="progress__dot"></div>
            <div class="progress__label">{statusLabels[s]}</div>
          </div>
          {#if s !== 'delivered'}
            <div class="progress__line" class:done={statusFlow.indexOf(currentStatus) > statusFlow.indexOf(s)}></div>
          {/if}
        {/each}
      </div>
    {/if}

    <form method="POST" action="?/setStatus" use:enhance class="status-form">
      <select name="status" class="status-select" bind:value={currentStatus}>
        {#each Object.entries(statusLabels) as [val, label]}
          <option value={val}>{label}</option>
        {/each}
      </select>
      <button type="submit" class="btn-primary">{$t('save')}</button>
    </form>

    {#if form?.error}
      <p class="form-error">{form.error}</p>
    {/if}
  </div>

  <div class="layout">
    <!-- Левая колонка: позиции заказа -->
    <div class="col-main">
      <div class="card">
        <div class="card__title">{$t('orderItems')}</div>
        {#if data.items.length === 0}
          <p class="empty">{$t('noItems')}</p>
        {:else}
          <table class="items-table">
            <thead>
              <tr>
                <th></th>
                <th>{$t('colProduct')}</th>
                <th class="ta-right">{$t('colPrice')}</th>
                <th class="ta-right">{$t('colQty')}</th>
                <th class="ta-right">{$t('colAmount')}</th>
              </tr>
            </thead>
            <tbody>
              {#each data.items as item (item.id)}
                <tr>
                  <td class="td-img">
                    {#if item.productImageUrl}
                      <img src={item.productImageUrl} alt="" />
                    {/if}
                  </td>
                  <td>
                    <div class="item-name">{item.productName || '—'}</div>
                    {#if item.productArticle}
                      <div class="item-art">{$t('article')} {item.productArticle}</div>
                    {/if}
                  </td>
                  <td class="ta-right num">{formatPrice(item.priceRub)}</td>
                  <td class="ta-right num">{item.quantity}</td>
                  <td class="ta-right num bold">{formatPrice(item.priceRub * item.quantity)}</td>
                </tr>
              {/each}
            </tbody>
            <tfoot>
              <tr>
                <td colspan="4" class="tfoot-label">{$t('total')}</td>
                <td class="ta-right num total">{formatPrice(data.order.totalRub)}</td>
              </tr>
            </tfoot>
          </table>
        {/if}
      </div>
    </div>

    <!-- Правая колонка: покупатель + доставка -->
    <div class="col-side">
      <div class="card">
        <div class="card__title">{$t('customer')}</div>
        <dl class="dl">
          <dt>{$t('customerName')}</dt>
          <dd>{data.order.customerName || '—'}</dd>
          <dt>{$t('customerPhone')}</dt>
          <dd class="num">{data.order.customerPhone || '—'}</dd>
          {#if data.order.customerEmail}
            <dt>Email</dt>
            <dd>{data.order.customerEmail}</dd>
          {/if}
        </dl>
      </div>

      <div class="card">
        <div class="card__title">{$t('deliveryAndPayment')}</div>
        <dl class="dl">
          <dt>{$t('deliveryMethod')}</dt>
          <dd>{deliveryLabels[data.order.deliveryMethod ?? ''] ?? data.order.deliveryMethod ?? '—'}</dd>
          <dt>{$t('address')}</dt>
          <dd>{data.order.deliveryAddress || '—'}</dd>
          <dt>{$t('payment')}</dt>
          <dd>{paymentLabels[data.order.paymentMethod ?? ''] ?? data.order.paymentMethod ?? '—'}</dd>
        </dl>
      </div>

      {#if data.order.comment}
        <div class="card">
          <div class="card__title">{$t('comment')}</div>
          <p class="comment">{data.order.comment}</p>
        </div>
      {/if}
    </div>
  </div>
</div>

<style>
  .wrap {
    max-width: 1100px;
    margin: 0 auto;
    padding: 24px 20px 60px;
  }

  .breadcrumb {
    margin-bottom: 16px;
    font-size: 13px;
  }
  .breadcrumb a {
    color: #4a9159;
    font-weight: 600;
  }
  .breadcrumb a:hover { color: #2d6b3e; }

  .head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 24px;
    flex-wrap: wrap;
  }
  h1 {
    font-size: 24px;
    font-weight: 700;
    margin: 0 0 4px;
  }
  h1 .num { color: #4a9159; }
  .head__date { font-size: 13px; color: #888; }

  /* Карточки */
  .card {
    background: #fff;
    border: 1px solid #e8e8e8;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 16px;
  }
  .card__title {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #888;
    font-weight: 700;
    margin-bottom: 16px;
  }

  /* Статус badge */
  .status {
    display: inline-block;
    padding: 5px 14px;
    border-radius: 99px;
    font-size: 13px;
    font-weight: 700;
    white-space: nowrap;
  }
  .status--new { background: #e3f2fd; color: #1565c0; }
  .status--paid { background: #e8f5e9; color: #2e7d32; }
  .status--packed { background: #fff3e0; color: #e65100; }
  .status--shipped { background: #f3e5f5; color: #7b1fa2; }
  .status--delivered { background: #e8f5e9; color: #1b5e20; }
  .status--cancelled { background: #fafafa; color: #999; }

  /* Прогресс-бар */
  .progress {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
    overflow-x: auto;
    padding-bottom: 4px;
  }
  .progress__step {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    flex-shrink: 0;
  }
  .progress__dot {
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: #e0e0e0;
    border: 2px solid #e0e0e0;
    transition: background 0.2s;
  }
  .progress__step.done .progress__dot {
    background: #4a9159;
    border-color: #4a9159;
  }
  .progress__step.current .progress__dot {
    background: #fff;
    border-color: #4a9159;
    box-shadow: 0 0 0 3px #c8e6c9;
  }
  .progress__label {
    font-size: 11px;
    color: #bbb;
    white-space: nowrap;
  }
  .progress__step.done .progress__label,
  .progress__step.current .progress__label {
    color: #333;
    font-weight: 600;
  }
  .progress__line {
    flex: 1;
    height: 2px;
    background: #e0e0e0;
    min-width: 24px;
    margin: 0 4px;
    margin-bottom: 22px;
  }
  .progress__line.done { background: #4a9159; }

  /* Форма статуса */
  .status-form {
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
  }
  .status-select {
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 14px;
    min-width: 180px;
  }
  .btn-primary {
    padding: 8px 20px;
    background: #4a9159;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
  }
  .btn-primary:hover { background: #3a7448; }
  .form-error { color: #c62828; font-size: 13px; margin-top: 8px; }

  /* Двухколоночная раскладка */
  .layout {
    display: grid;
    grid-template-columns: 1fr 300px;
    gap: 16px;
    align-items: start;
  }
  @media (max-width: 820px) {
    .layout { grid-template-columns: 1fr; }
  }
  .col-side { display: flex; flex-direction: column; gap: 0; }

  /* Таблица товаров */
  .items-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
  }
  .items-table th {
    text-align: left;
    padding: 8px 10px;
    font-size: 11px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #888;
    border-bottom: 2px solid #eee;
  }
  .items-table td {
    padding: 10px 10px;
    border-bottom: 1px solid #f0f0f0;
    vertical-align: middle;
  }
  .items-table tfoot td {
    border-top: 2px solid #eee;
    border-bottom: none;
    padding-top: 12px;
  }
  .ta-right { text-align: right; }
  .td-img { width: 50px; }
  .td-img img {
    width: 44px;
    height: 44px;
    object-fit: contain;
    border-radius: 6px;
    border: 1px solid #eee;
  }
  .item-name { font-weight: 500; }
  .item-art { font-size: 11px; color: #999; margin-top: 2px; }
  .bold { font-weight: 700; }
  .total { font-size: 16px; font-weight: 800; color: #111; }
  .tfoot-label { color: #888; font-size: 13px; text-align: right; padding-right: 12px; }
  .empty { color: #888; }

  /* Описание */
  .dl { display: grid; grid-template-columns: auto 1fr; gap: 6px 12px; font-size: 14px; }
  dt { color: #888; white-space: nowrap; }
  dd { margin: 0; font-weight: 500; word-break: break-word; }
  .comment { font-size: 14px; color: #444; line-height: 1.5; margin: 0; }
</style>
