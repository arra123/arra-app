import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import { error, fail } from '@sveltejs/kit';
import type { PageServerLoad, Actions } from './$types';

const STATUSES = ['new', 'paid', 'packed', 'shipped', 'delivered', 'cancelled'] as const;
type OrderStatus = typeof STATUSES[number];

export const load: PageServerLoad = async ({ params }) => {
  const id = Number(params.id);
  if (!id) throw error(404, 'Заказ не найден');

  // Основные данные заказа + покупатель
  const [order] = await db
    .select({
      id: schema.euOrders.id,
      number: schema.euOrders.number,
      status: schema.euOrders.status,
      totalRub: schema.euOrders.totalRub,
      deliveryAddress: schema.euOrders.deliveryAddress,
      deliveryMethod: schema.euOrders.deliveryMethod,
      paymentMethod: schema.euOrders.paymentMethod,
      comment: schema.euOrders.comment,
      createdAt: schema.euOrders.createdAt,
      customerName: schema.euCustomers.name,
      customerPhone: schema.euCustomers.phone,
      customerEmail: schema.euCustomers.email
    })
    .from(schema.euOrders)
    .leftJoin(schema.euCustomers, eq(schema.euOrders.customerId, schema.euCustomers.id))
    .where(eq(schema.euOrders.id, id));

  if (!order) throw error(404, 'Заказ не найден');

  // Позиции заказа с названиями товаров
  const items = await db
    .select({
      id: schema.euOrderItems.id,
      quantity: schema.euOrderItems.quantity,
      priceRub: schema.euOrderItems.priceRub,
      productId: schema.euOrderItems.productId,
      productName: schema.euProducts.name,
      productArticle: schema.euProducts.article,
      productImageUrl: schema.euProducts.imageUrl
    })
    .from(schema.euOrderItems)
    .leftJoin(schema.euProducts, eq(schema.euOrderItems.productId, schema.euProducts.id))
    .where(eq(schema.euOrderItems.orderId, id));

  return { order, items };
};

export const actions: Actions = {
  setStatus: async ({ request, params }) => {
    const id = Number(params.id);
    if (!id) return fail(400, { error: 'Неверный ID заказа' });

    const formData = await request.formData();
    const status = formData.get('status') as string;

    if (!STATUSES.includes(status as OrderStatus)) {
      return fail(400, { error: 'Неверный статус' });
    }

    await db
      .update(schema.euOrders)
      .set({ status: status as OrderStatus })
      .where(eq(schema.euOrders.id, id));

    return { success: true, status };
  }
};
