import { db, schema } from '$server/db';
import { desc, eq } from 'drizzle-orm';
import { fail } from '@sveltejs/kit';
import type { Actions, PageServerLoad } from './$types';

const STATUSES = ['new', 'paid', 'packed', 'shipped', 'delivered', 'cancelled'] as const;
type OrderStatus = (typeof STATUSES)[number];

export const load: PageServerLoad = async ({ url }) => {
  const search = url.searchParams.get('q') ?? '';
  const statusFilter = url.searchParams.get('status') ?? '';

  // Получаем все заказы с покупателем
  const allOrders = await db
    .select({
      id: schema.euOrders.id,
      number: schema.euOrders.number,
      status: schema.euOrders.status,
      totalRub: schema.euOrders.totalRub,
      customerName: schema.euCustomers.name,
      customerPhone: schema.euCustomers.phone,
      createdAt: schema.euOrders.createdAt
    })
    .from(schema.euOrders)
    .leftJoin(schema.euCustomers, eq(schema.euOrders.customerId, schema.euCustomers.id))
    .orderBy(desc(schema.euOrders.createdAt));

  // Фильтрация на JS (для поддержки поиска по phone клиента без сложных joins)
  let orders = allOrders;

  if (statusFilter) {
    orders = orders.filter((o) => o.status === statusFilter);
  }

  if (search) {
    const q = search.toLowerCase();
    orders = orders.filter(
      (o) =>
        o.number.toLowerCase().includes(q) ||
        (o.customerPhone ?? '').toLowerCase().includes(q) ||
        (o.customerName ?? '').toLowerCase().includes(q)
    );
  }

  return { orders, search, statusFilter };
};

export const actions: Actions = {
  setStatus: async ({ request }) => {
    const data = await request.formData();
    const id = parseInt(data.get('id')?.toString() || '', 10);
    const status = data.get('status')?.toString() || '';

    if (!id) return fail(400, { error: 'Неверный ID' });
    if (!STATUSES.includes(status as OrderStatus)) {
      return fail(400, { error: 'Неверный статус' });
    }

    await db
      .update(schema.euOrders)
      .set({ status: status as OrderStatus })
      .where(eq(schema.euOrders.id, id));

    return { success: true, id, status };
  }
};
