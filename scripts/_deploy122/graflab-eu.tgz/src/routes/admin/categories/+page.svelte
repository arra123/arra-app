<script lang="ts">
  import { enhance } from '$app/forms';
  import { t } from '$lib/i18n';
  import type { PageData, ActionData } from './$types';

  export let data: PageData;
  export let form: ActionData;

  let editingId: number | null = null;
</script>

<svelte:head>
  <title>{$t('categories')} — GRAFLAB Admin</title>
</svelte:head>

<div class="adm">
  <a href="/admin" class="back">← {$t('allProducts')}</a>

  <h1>{$t('categories')} <span class="count">{data.categories.length}</span></h1>

  {#if form?.error}
    <div class="msg msg--error">{form.error}</div>
  {/if}

  <!-- Создание -->
  <section class="new-cat">
    <h2>{$t('newCategory')}</h2>
    <form method="POST" action="?/create" use:enhance class="row-form">
      <input name="name" placeholder={$t('nameEn')} required />
      <input name="nameSr" placeholder={$t('nameSr')} />
      <input name="slug" placeholder="slug (auto)" />
      <input name="sortOrder" type="number" placeholder={$t('sortOrder')} value="0" />
      <button type="submit" class="btn-primary">+ {$t('add')}</button>
    </form>
  </section>

  <!-- Список -->
  <section class="cats">
    {#each data.categories as c (c.id)}
      {#if editingId === c.id}
        <form method="POST" action="?/update" use:enhance={() => async ({ update }) => { await update(); editingId = null; }} class="cat-row cat-row--edit">
          <input type="hidden" name="id" value={c.id} />
          <div class="cat-slug">{c.slug}</div>
          <input name="name" value={c.name} required />
          <input name="nameSr" value={c.nameSr ?? ''} placeholder={$t('nameSr')} />
          <input name="sortOrder" type="number" value={c.sortOrder} />
          <span class="cat-count">{c.productsCount} шт</span>
          <button type="submit" class="btn-save">{$t('save')}</button>
          <button type="button" class="btn-cancel" on:click={() => (editingId = null)}>{$t('cancel')}</button>
        </form>
      {:else}
        <div class="cat-row">
          <div class="cat-slug">{c.slug}</div>
          <div class="cat-name">{c.name}</div>
          <div class="cat-name-sr">{c.nameSr ?? '—'}</div>
          <div class="cat-sort num">#{c.sortOrder}</div>
          <span class="cat-count">{c.productsCount} шт</span>
          <button type="button" class="btn-edit" on:click={() => (editingId = c.id)}>{$t('edit')}</button>
          <form
            method="POST"
            action="?/delete"
            use:enhance={({ cancel }) => {
              if (!confirm($t('deleteCategoryConfirm'))) cancel();
            }}
            style="display:inline"
          >
            <input type="hidden" name="id" value={c.id} />
            <button type="submit" class="btn-del">×</button>
          </form>
        </div>
      {/if}
    {/each}
    {#if data.categories.length === 0}
      <p class="empty">{$t('noCategoriesYet')}</p>
    {/if}
  </section>
</div>

<style>
  .adm { max-width: 1100px; margin: 0 auto; padding: 24px 20px 60px; }
  .back { display: inline-block; color: #666; font-size: 13px; margin-bottom: 20px; }
  .back:hover { color: #111; }
  h1 { font-size: 24px; font-weight: 700; margin: 0 0 24px; }
  h1 .count { color: #888; font-weight: 500; font-size: 16px; margin-left: 6px; }
  h2 { font-size: 14px; font-weight: 600; margin: 0 0 12px; color: #555; }
  .msg { padding: 10px 14px; border-radius: 8px; font-size: 13px; margin-bottom: 16px; }
  .msg--error { background: #fef2f2; color: #c33; }

  .new-cat { margin-bottom: 28px; padding: 16px; background: #fafafa; border-radius: 10px; }
  .row-form {
    display: grid;
    grid-template-columns: 2fr 2fr 1.5fr 0.8fr auto;
    gap: 8px;
  }
  .row-form input {
    border: 1px solid #ddd; border-radius: 8px; padding: 9px 12px;
    font-size: 13px; background: #fff;
    min-width: 0;
  }
  .row-form input:focus { outline: 0; border-color: #4a9159; }

  .cats { display: flex; flex-direction: column; gap: 4px; }
  .cat-row {
    display: grid;
    grid-template-columns: 140px 1.5fr 1.5fr 60px 80px auto auto;
    gap: 10px;
    align-items: center;
    padding: 10px 12px;
    border-bottom: 1px solid #f0f0f0;
    font-size: 14px;
  }
  .cat-row--edit { background: #fffdf0; border-radius: 8px; }
  .cat-row--edit input {
    border: 1px solid #ddd; border-radius: 6px; padding: 6px 10px;
    font-size: 13px;
    min-width: 0;
  }
  .cat-slug { font-family: monospace; font-size: 12px; color: #888; }
  .cat-name { font-weight: 500; }
  .cat-name-sr { color: #666; }
  .cat-sort { color: #999; text-align: center; font-size: 12px; }
  .cat-count { color: #999; font-size: 12px; white-space: nowrap; }
  .btn-primary {
    background: #4a9159; color: #fff; border: 0; padding: 9px 14px;
    border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer;
  }
  .btn-primary:hover { background: #3a7a47; }
  .btn-save {
    background: #4a9159; color: #fff; border: 0; padding: 6px 12px;
    border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer;
  }
  .btn-cancel, .btn-edit {
    background: transparent; border: 1px solid #ddd; padding: 5px 10px;
    border-radius: 6px; font-size: 12px; color: #555; cursor: pointer;
  }
  .btn-edit:hover { border-color: #4a9159; color: #4a9159; }
  .btn-del {
    background: transparent; border: 0; color: #c33;
    font-size: 18px; cursor: pointer; padding: 0 8px;
    line-height: 1;
  }
  .btn-del:hover { color: #f55; }
  .empty { color: #888; text-align: center; padding: 24px 0; }
</style>
