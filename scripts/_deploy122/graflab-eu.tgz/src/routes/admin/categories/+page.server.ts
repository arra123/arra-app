import { db, schema } from '$server/db';
import { eq, sql } from 'drizzle-orm';
import { fail } from '@sveltejs/kit';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
  const rows = await db
    .select({
      id: schema.euCategories.id,
      slug: schema.euCategories.slug,
      name: schema.euCategories.name,
      nameSr: schema.euCategories.nameSr,
      sortOrder: schema.euCategories.sortOrder,
      productsCount: sql<number>`(
        select count(*) from ${schema.euProducts}
        where ${schema.euProducts.categoryId} = ${schema.euCategories.id}
      )`.as('products_count')
    })
    .from(schema.euCategories)
    .orderBy(schema.euCategories.sortOrder);

  return { categories: rows };
};

function normalizeSlug(s: string): string {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 64);
}

export const actions: Actions = {
  create: async ({ request }) => {
    const data = await request.formData();
    const name = data.get('name')?.toString()?.trim();
    const nameSr = data.get('nameSr')?.toString()?.trim() || null;
    const slugInput = data.get('slug')?.toString()?.trim();
    const sortOrderInput = parseInt(data.get('sortOrder')?.toString() || '', 10);
    const sortOrder = isNaN(sortOrderInput) ? 0 : sortOrderInput;

    if (!name) return fail(400, { error: 'Название обязательно' });

    const slug = normalizeSlug(slugInput || name);
    if (!slug) return fail(400, { error: 'Slug некорректен' });

    try {
      await db.insert(schema.euCategories).values({ slug, name, nameSr, sortOrder });
    } catch {
      return fail(400, { error: 'Slug уже занят' });
    }

    return { success: true };
  },

  update: async ({ request }) => {
    const data = await request.formData();
    const id = parseInt(data.get('id')?.toString() || '', 10);
    const name = data.get('name')?.toString()?.trim();
    const nameSr = data.get('nameSr')?.toString()?.trim() || null;
    const sortOrderInput = parseInt(data.get('sortOrder')?.toString() || '', 10);
    const sortOrder = isNaN(sortOrderInput) ? 0 : sortOrderInput;

    if (!id || !name) return fail(400, { error: 'Неверные данные' });

    await db
      .update(schema.euCategories)
      .set({ name, nameSr, sortOrder })
      .where(eq(schema.euCategories.id, id));

    return { success: true };
  },

  delete: async ({ request }) => {
    const data = await request.formData();
    const id = parseInt(data.get('id')?.toString() || '', 10);
    if (!id) return fail(400, { error: 'Неверный ID' });

    // Сбрасываем categoryId у товаров, затем удаляем категорию
    await db
      .update(schema.euProducts)
      .set({ categoryId: null })
      .where(eq(schema.euProducts.categoryId, id));

    await db.delete(schema.euCategories).where(eq(schema.euCategories.id, id));

    return { success: true };
  }
};
