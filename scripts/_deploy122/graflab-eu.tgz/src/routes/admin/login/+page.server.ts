import { fail, redirect } from '@sveltejs/kit';
import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import { verifyPassword, createSession, setSessionCookie } from '$server/auth';
import type { Actions } from './$types';

export const actions: Actions = {
  default: async ({ request, cookies }) => {
    const data = await request.formData();
    const login = data.get('login')?.toString()?.trim();
    const password = data.get('password')?.toString();

    if (!login || !password) {
      return fail(400, { error: 'Введите логин и пароль' });
    }

    const users = await db
      .select()
      .from(schema.euAdminUsers)
      .where(eq(schema.euAdminUsers.login, login))
      .limit(1);

    if (users.length === 0) {
      return fail(401, { error: 'Неверный логин или пароль' });
    }

    const user = users[0];
    const valid = await verifyPassword(password, user.passwordHash);
    if (!valid) {
      return fail(401, { error: 'Неверный логин или пароль' });
    }

    const sessionId = await createSession(user.id);
    setSessionCookie(cookies, sessionId);
    throw redirect(303, '/admin');
  }
};
