<script lang="ts">
  import { enhance } from '$app/forms';
  import { t, locale, type Locale } from '$lib/i18n';

  let loading = false;
  let showPassword = false;
  export let form: { error?: string } | null = null;

  const LANGS: { code: Locale; label: string }[] = [
    { code: 'en', label: 'EN' },
    { code: 'sr', label: 'SR' },
    { code: 'ru', label: 'RU' }
  ];
</script>

<svelte:head>
  <title>{$t('adminLogin')} — GRAFLAB Admin</title>
</svelte:head>

<div class="login-page">
  <div class="lang-switch" role="group" aria-label="Language">
    {#each LANGS as l}
      <button type="button" class:active={$locale === l.code} on:click={() => locale.set(l.code)}>{l.label}</button>
    {/each}
  </div>
  <form method="POST" use:enhance={() => { loading = true; return async ({ update }) => { loading = false; await update(); }; }}>
    <h1>GRAFLAB</h1>
    <p class="sub">{$t('adminLoginHeading')}</p>

    {#if form?.error}
      <div class="error">{form.error}</div>
    {/if}

    <input name="login" type="text" placeholder={$t('loginPlaceholder')} required autocomplete="username" />
    <div class="pw-wrap">
      <input
        name="password"
        type={showPassword ? 'text' : 'password'}
        placeholder={$t('passwordPlaceholder')}
        required
        autocomplete="current-password"
      />
      <button
        type="button"
        class="eye"
        on:click={() => (showPassword = !showPassword)}
        aria-label={showPassword ? $t('hidePassword') : $t('showPassword')}
      >
        {#if showPassword}
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
            <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
            <path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"/>
            <line x1="1" y1="1" x2="23" y2="23"/>
          </svg>
        {:else}
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z"/>
            <circle cx="12" cy="12" r="3"/>
          </svg>
        {/if}
      </button>
    </div>
    <button type="submit" class="btn-submit" disabled={loading}>
      {loading ? $t('loggingIn') : $t('login')}
    </button>
  </form>
</div>

<style>
  .login-page {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #111;
    padding: 20px;
    position: relative;
  }
  .lang-switch {
    position: absolute;
    top: 16px;
    right: 16px;
    display: inline-flex;
    background: #1a1a1a;
    border: 1px solid #2a2a2a;
    border-radius: 6px;
    padding: 2px;
    gap: 2px;
  }
  .lang-switch button {
    background: transparent;
    border: 0;
    color: #888;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.04em;
    padding: 4px 9px;
    border-radius: 4px;
    cursor: pointer;
    transition: color 0.12s, background 0.12s;
  }
  .lang-switch button:hover { color: #fff; }
  .lang-switch button.active { background: #2d6b3e; color: #fff; }
  form {
    width: 100%;
    max-width: 360px;
    display: flex;
    flex-direction: column;
    gap: 14px;
  }
  h1 {
    font-size: 28px;
    font-weight: 800;
    letter-spacing: 0.06em;
    color: #fff;
    text-align: center;
    margin: 0;
  }
  .sub {
    text-align: center;
    color: #666;
    font-size: 14px;
    margin: 0 0 8px;
  }
  .error {
    background: #3a1818;
    color: #f88;
    padding: 10px 14px;
    border-radius: 8px;
    font-size: 13px;
    text-align: center;
  }
  input {
    border: 1px solid #333;
    background: #1a1a1a;
    color: #eee;
    padding: 14px 16px;
    border-radius: 10px;
    font-size: 15px;
    width: 100%;
  }
  input:focus {
    outline: 0;
    border-color: #4a9159;
  }
  .pw-wrap {
    position: relative;
  }
  .pw-wrap input {
    padding-right: 48px;
  }
  .eye {
    position: absolute;
    right: 4px;
    top: 50%;
    transform: translateY(-50%);
    width: 40px;
    height: 40px;
    background: transparent;
    border: 0;
    color: #666;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    border-radius: 8px;
  }
  .eye:hover {
    color: #aaa;
  }
  .eye svg {
    width: 18px;
    height: 18px;
  }
  .btn-submit {
    background: #4a9159;
    color: #fff;
    border: 0;
    border-radius: 10px;
    padding: 14px;
    font-size: 15px;
    font-weight: 700;
    margin-top: 4px;
    width: 100%;
  }
  .btn-submit:hover:not(:disabled) {
    background: #3a7a47;
  }
  .btn-submit:disabled {
    opacity: 0.5;
  }
</style>
