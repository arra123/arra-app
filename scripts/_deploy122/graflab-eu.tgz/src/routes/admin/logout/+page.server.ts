import { redirect } from '@sveltejs/kit';
import { deleteSession, getSessionCookie, clearSessionCookie } from '$server/auth';
import type { Actions } from './$types';

export const actions: Actions = {
  default: async ({ cookies }) => {
    const sid = getSessionCookie(cookies);
    if (sid) await deleteSession(sid);
    clearSessionCookie(cookies);
    throw redirect(303, '/admin/login');
  }
};
