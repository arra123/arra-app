<script lang="ts">
  import { enhance } from '$app/forms';
  import { t } from '$lib/i18n';
  import type { PageData, ActionData } from './$types';

  export let data: PageData;
  export let form: ActionData;

  $: v = (form?.values ?? {}) as Record<string, string>;
</script>

<svelte:head>
  <title>{$t('newProduct')} — GRAFLAB Admin</title>
</svelte:head>

<div class="adm">
  <a href="/admin" class="back">← {$t('allProducts')}</a>

  <h1>{$t('newProduct')}</h1>

  <form method="POST" use:enhance class="edit-form">
    {#if form?.error}
      <div class="msg msg--error">{form.error}</div>
    {/if}

    <label>
      <span class="label">{$t('productName')}</span>
      <input name="name" value={v.name ?? ''} required />
    </label>

    <div class="row2">
      <label>
        <span class="label">{$t('article')}</span>
        <input name="article" value={v.article ?? ''} required placeholder="GL-001" />
      </label>
      <label>
        <span class="label">Slug</span>
        <input name="slug" value={v.slug ?? ''} placeholder={$t('slugAuto')} />
      </label>
    </div>

    <label>
      <span class="label">{$t('description')}</span>
      <textarea name="description" rows="5">{v.description ?? ''}</textarea>
    </label>

    <label>
      <span class="label">{$t('colCategory')}</span>
      <select name="categoryId">
        <option value="">{$t('noCategory')}</option>
        {#each data.categories as c (c.id)}
          <option value={c.id} selected={String(c.id) === v.categoryId}>{c.name}</option>
        {/each}
      </select>
    </label>

    <div class="row2">
      <label>
        <span class="label">{$t('price')} (€)</span>
        <input name="priceRub" type="number" step="0.01" min="0" value={v.priceRub ?? ''} required />
      </label>
      <label>
        <span class="label">{$t('oldPrice')} (€)</span>
        <input name="priceOldRub" type="number" step="0.01" min="0" value={v.priceOldRub ?? ''} />
      </label>
    </div>

    <label>
      <span class="label">{$t('photoUrl')}</span>
      <input name="imageUrl" value={v.imageUrl ?? ''} placeholder="https://..." />
    </label>

    <div class="checks">
      <label class="check">
        <input type="checkbox" name="inStock" checked={v.inStock === 'on' || !v.inStock} />
        {$t('inStock')}
      </label>
      <label class="check">
        <input type="checkbox" name="active" checked={v.active === 'on' || !v.active} />
        {$t('activeVisible')}
      </label>
    </div>

    <button type="submit" class="btn-save">{$t('create')}</button>
  </form>
</div>

<style>
  .adm { max-width: 760px; margin: 0 auto; padding: 24px 20px 60px; }
  .back { display: inline-block; color: #666; font-size: 13px; margin-bottom: 20px; }
  .back:hover { color: #111; }
  h1 { font-size: 24px; font-weight: 700; margin: 0 0 24px; }
  .edit-form { display: flex; flex-direction: column; gap: 16px; }
  .label { display: block; font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; color: #888; margin-bottom: 4px; font-weight: 600; }
  input, textarea, select { width: 100%; border: 1px solid #ddd; border-radius: 8px; padding: 10px 14px; font-size: 14px; background: #fff; }
  input:focus, textarea:focus, select:focus { outline: 0; border-color: #4a9159; }
  .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .checks { display: flex; gap: 24px; flex-wrap: wrap; }
  .check { display: flex; align-items: center; gap: 6px; font-size: 14px; }
  .check input { width: 16px; height: 16px; accent-color: #4a9159; }
  .msg { padding: 10px 14px; border-radius: 8px; font-size: 13px; text-align: center; }
  .msg--error { background: #fef2f2; color: #c33; }
  .btn-save { background: #4a9159; color: #fff; border: 0; border-radius: 8px; padding: 12px 20px; font-size: 15px; font-weight: 700; align-self: flex-start; cursor: pointer; }
  .btn-save:hover { background: #3a7a47; }
</style>
