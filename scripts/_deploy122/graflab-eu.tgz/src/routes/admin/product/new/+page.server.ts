import { db, schema } from '$server/db';
import { error, fail, redirect } from '@sveltejs/kit';
import { eurosToCents } from '$lib/utils/format';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
  const categories = await db
    .select({ id: schema.euCategories.id, slug: schema.euCategories.slug, name: schema.euCategories.name })
    .from(schema.euCategories)
    .orderBy(schema.euCategories.sortOrder);

  return { categories };
};

function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .slice(0, 120) || 'product-' + Date.now();
}

export const actions: Actions = {
  default: async ({ request }) => {
    const data = await request.formData();
    const name = data.get('name')?.toString()?.trim();
    const article = data.get('article')?.toString()?.trim();
    const slugInput = data.get('slug')?.toString()?.trim();
    const description = data.get('description')?.toString()?.trim() || null;
    const categoryId = parseInt(data.get('categoryId')?.toString() || '', 10) || null;
    const priceRub = eurosToCents(data.get('priceRub')?.toString());
    const priceOldInput = data.get('priceOldRub')?.toString()?.trim();
    const priceOldRub = priceOldInput ? eurosToCents(priceOldInput) : null;
    const inStock = data.get('inStock') === 'on';
    const active = data.get('active') === 'on';
    const imageUrl = data.get('imageUrl')?.toString()?.trim() || '';

    if (!name) return fail(400, { error: 'Название обязательно', values: Object.fromEntries(data) });
    if (!article) return fail(400, { error: 'Артикул обязателен', values: Object.fromEntries(data) });
    if (!priceRub || priceRub < 0) return fail(400, { error: 'Цена некорректна', values: Object.fromEntries(data) });

    const slug = slugInput || slugify(article || name);

    let created;
    try {
      [created] = await db
        .insert(schema.euProducts)
        .values({
          article,
          slug,
          name,
          description,
          categoryId,
          priceRub,
          priceOldRub,
          inStock,
          active,
          imageUrl: imageUrl || '/brand/logo-mark.png'
        })
        .returning({ id: schema.euProducts.id });
    } catch (e: any) {
      return fail(400, { error: 'Артикул или slug уже существуют', values: Object.fromEntries(data) });
    }

    throw redirect(303, `/admin/product/${created.id}`);
  }
};
