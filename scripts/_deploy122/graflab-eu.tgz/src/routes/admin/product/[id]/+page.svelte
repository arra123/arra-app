<script lang="ts">
  import { enhance } from '$app/forms';
  import { t } from '$lib/i18n';
  import { centsToEuros } from '$lib/utils/format';
  import type { PageData, ActionData } from './$types';

  export let data: PageData;
  export let form: ActionData;
  $: p = data.product;
</script>

<svelte:head>
  <title>{$t('editProduct')}: {p.name} — GRAFLAB Admin</title>
</svelte:head>

<div class="adm">
  <a href="/admin" class="back">← {$t('allProducts')}</a>

  <div class="edit-layout">
    <div class="preview">
      <img src={p.imageUrl} alt={p.name} />
      <div class="preview__art num">{$t('article')} {p.article}</div>
      <form method="POST" action="?/uploadPhoto" enctype="multipart/form-data" use:enhance class="upload-form">
        <label class="upload-btn">
          {$t('uploadPhoto')}
          <input type="file" name="photo" accept="image/*" on:change={(e) => e.currentTarget.form?.requestSubmit()} />
        </label>
      </form>
    </div>

    <form method="POST" action="?/save" use:enhance class="edit-form">
      {#if form?.error}
        <div class="msg msg--error">{form.error}</div>
      {/if}
      {#if form?.success}
        <div class="msg msg--ok">{$t('saved')}</div>
      {/if}

      <label>
        <span class="label">{$t('productName')}</span>
        <input name="name" value={p.name} required />
      </label>

      <label>
        <span class="label">{$t('article')}</span>
        <input name="article" value={p.article} required />
      </label>

      <label>
        <span class="label">{$t('description')}</span>
        <textarea name="description" rows="5">{p.description ?? ''}</textarea>
      </label>

      <label>
        <span class="label">{$t('colCategory')}</span>
        <select name="categoryId">
          <option value="">{$t('noCategory')}</option>
          {#each data.categories as c (c.id)}
            <option value={c.id} selected={c.id === p.categoryId}>{c.name}</option>
          {/each}
        </select>
      </label>

      <div class="row2">
        <label>
          <span class="label">{$t('price')} (€)</span>
          <input name="priceRub" type="number" step="0.01" min="0" value={centsToEuros(p.priceRub)} required />
        </label>
        <label>
          <span class="label">{$t('oldPrice')} (€)</span>
          <input name="priceOldRub" type="number" step="0.01" min="0" value={p.priceOldRub ? centsToEuros(p.priceOldRub) : ''} />
        </label>
      </div>

      <label>
        <span class="label">{$t('photoUrl')}</span>
        <input name="imageUrl" value={p.imageUrl} placeholder="https://..." />
      </label>

      <div class="checks">
        <label class="check">
          <input type="checkbox" name="inStock" checked={p.inStock} />
          {$t('inStock')}
        </label>
        <label class="check">
          <input type="checkbox" name="active" checked={p.active} />
          {$t('activeVisible')}
        </label>
      </div>

      <button type="submit" class="btn-save">{$t('save')}</button>
    </form>
  </div>

  <div class="danger-zone">
    <form method="POST" action="?/toggleActive" use:enhance>
      <button type="submit" class="btn-toggle">
        {p.active ? $t('hideFromSite') : $t('showOnSite')}
      </button>
    </form>
    <form
      method="POST"
      action="?/delete"
      use:enhance={({ cancel }) => {
        if (!confirm($t('deleteConfirm'))) cancel();
      }}
    >
      <button type="submit" class="btn-delete">{$t('deleteProduct')}</button>
    </form>
  </div>
</div>

<style>
  .adm {
    max-width: 960px;
    margin: 0 auto;
    padding: 24px 20px 60px;
  }
  .back {
    display: inline-block;
    color: #666;
    font-size: 13px;
    margin-bottom: 20px;
  }
  .back:hover {
    color: #111;
  }

  .edit-layout {
    display: grid;
    grid-template-columns: 1fr;
    gap: 24px;
  }
  @media (min-width: 700px) {
    .edit-layout {
      grid-template-columns: 280px 1fr;
      gap: 36px;
    }
  }

  .preview {
    text-align: center;
  }
  .preview img {
    width: 100%;
    max-width: 260px;
    aspect-ratio: 3/4;
    object-fit: contain;
    background: #fff;
    border: 1px solid #eee;
    border-radius: 12px;
    margin: 0 auto;
  }
  .preview__art {
    margin-top: 8px;
    color: #999;
    font-size: 12px;
  }
  .upload-form {
    margin-top: 12px;
  }
  .upload-btn {
    display: inline-block;
    padding: 8px 16px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 13px;
    color: #555;
    cursor: pointer;
    text-align: center;
    width: 100%;
    max-width: 260px;
  }
  .upload-btn:hover {
    background: #f5f5f5;
    border-color: #bbb;
  }
  .upload-btn input[type="file"] {
    display: none;
  }

  .edit-form {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  .label {
    display: block;
    font-size: 11px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: #888;
    margin-bottom: 4px;
    font-weight: 600;
  }
  .edit-form input,
  .edit-form textarea,
  .edit-form select {
    width: 100%;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 10px 14px;
    font-size: 14px;
    background: #fff;
  }
  .edit-form input:focus,
  .edit-form textarea:focus,
  .edit-form select:focus {
    outline: 0;
    border-color: #4a9159;
  }
  .row2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
  }
  .checks {
    display: flex;
    gap: 24px;
    flex-wrap: wrap;
  }
  .check {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
  }
  .check input {
    width: 16px;
    height: 16px;
    accent-color: #4a9159;
  }

  .msg {
    padding: 10px 14px;
    border-radius: 8px;
    font-size: 13px;
    text-align: center;
  }
  .msg--error {
    background: #fef2f2;
    color: #c33;
  }
  .msg--ok {
    background: #f0faf0;
    color: #2e7d32;
  }

  .btn-save {
    background: #4a9159;
    color: #fff;
    border: 0;
    border-radius: 8px;
    padding: 12px 20px;
    font-size: 15px;
    font-weight: 700;
    align-self: flex-start;
  }
  .btn-save:hover {
    background: #3a7a47;
  }

  .danger-zone {
    margin-top: 36px;
    padding-top: 24px;
    border-top: 1px solid #eee;
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
  }
  .btn-toggle {
    background: transparent;
    border: 1px solid #ddd;
    color: #888;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    cursor: pointer;
  }
  .btn-toggle:hover {
    border-color: #999;
    color: #333;
  }
  .btn-delete {
    background: transparent;
    border: 1px solid #f3c2c2;
    color: #c33;
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 13px;
    cursor: pointer;
  }
  .btn-delete:hover {
    background: #fff0f0;
    border-color: #e88;
  }
</style>
