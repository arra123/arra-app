import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import { error, fail, redirect } from '@sveltejs/kit';
import { uploadProductImage } from '$server/s3';
import { eurosToCents } from '$lib/utils/format';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ params }) => {
  const id = parseInt(params.id, 10);
  if (isNaN(id)) throw error(404);

  const products = await db
    .select()
    .from(schema.euProducts)
    .where(eq(schema.euProducts.id, id))
    .limit(1);

  if (products.length === 0) throw error(404, 'Товар не найден');

  const categories = await db
    .select({ id: schema.euCategories.id, slug: schema.euCategories.slug, name: schema.euCategories.name })
    .from(schema.euCategories)
    .orderBy(schema.euCategories.sortOrder);

  return { product: products[0], categories };
};

export const actions: Actions = {
  save: async ({ request, params }) => {
    const id = parseInt(params.id, 10);
    if (isNaN(id)) throw error(404);

    const data = await request.formData();
    const name = data.get('name')?.toString()?.trim();
    const article = data.get('article')?.toString()?.trim();
    const description = data.get('description')?.toString()?.trim() || null;
    const categoryId = parseInt(data.get('categoryId')?.toString() || '', 10) || null;
    const priceRub = eurosToCents(data.get('priceRub')?.toString());
    const priceOldInput = data.get('priceOldRub')?.toString()?.trim();
    const priceOldRub = priceOldInput ? eurosToCents(priceOldInput) : null;
    const inStock = data.get('inStock') === 'on';
    const active = data.get('active') === 'on';
    const imageUrl = data.get('imageUrl')?.toString()?.trim();

    if (!name) return fail(400, { error: 'Название обязательно' });
    if (!article) return fail(400, { error: 'Артикул обязателен' });
    if (!priceRub || priceRub < 0) return fail(400, { error: 'Цена некорректна' });

    await db
      .update(schema.euProducts)
      .set({
        name,
        article,
        description,
        categoryId,
        priceRub,
        priceOldRub,
        inStock,
        active,
        imageUrl: imageUrl || undefined,
        updatedAt: new Date()
      })
      .where(eq(schema.euProducts.id, id));

    return { success: true };
  },

  delete: async ({ params }) => {
    const id = parseInt(params.id, 10);
    if (isNaN(id)) throw error(404);

    await db.delete(schema.euProducts).where(eq(schema.euProducts.id, id));
    throw redirect(303, '/admin');
  },

  uploadPhoto: async ({ request, params }) => {
    const id = parseInt(params.id, 10);
    if (isNaN(id)) throw error(404);

    const data = await request.formData();
    const file = data.get('photo') as File | null;
    if (!file || file.size === 0) return fail(400, { error: 'Выберите файл' });
    if (file.size > 10 * 1024 * 1024) return fail(400, { error: 'Максимум 10 МБ' });
    if (!file.type.startsWith('image/')) return fail(400, { error: 'Только изображения' });

    const products = await db
      .select({ article: schema.euProducts.article })
      .from(schema.euProducts)
      .where(eq(schema.euProducts.id, id))
      .limit(1);
    if (products.length === 0) throw error(404);

    const buf = Buffer.from(await file.arrayBuffer());
    const url = await uploadProductImage(products[0].article, buf, file.type);

    await db
      .update(schema.euProducts)
      .set({ imageUrl: url, updatedAt: new Date() })
      .where(eq(schema.euProducts.id, id));

    return { success: true, uploadedUrl: url };
  },

  toggleActive: async ({ params }) => {
    const id = parseInt(params.id, 10);
    if (isNaN(id)) throw error(404);

    const rows = await db
      .select({ active: schema.euProducts.active })
      .from(schema.euProducts)
      .where(eq(schema.euProducts.id, id))
      .limit(1);
    if (rows.length === 0) throw error(404);

    await db
      .update(schema.euProducts)
      .set({ active: !rows[0].active, updatedAt: new Date() })
      .where(eq(schema.euProducts.id, id));

    return { success: true };
  }
};
