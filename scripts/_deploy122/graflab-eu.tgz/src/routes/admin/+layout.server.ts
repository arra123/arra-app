import { validateSession, getSessionCookie, ensureAdminExists } from '$server/auth';
import { redirect } from '@sveltejs/kit';
import type { LayoutServerLoad } from './$types';

export const load: LayoutServerLoad = async ({ cookies, url }) => {
  // Bootstrap: если нет ни одного админа — создаём дефолтного
  await ensureAdminExists();

  const sessionId = getSessionCookie(cookies);
  const user = await validateSession(sessionId);

  // Если не авторизован и не на странице логина — редирект
  if (!user && !url.pathname.endsWith('/login')) {
    throw redirect(303, '/admin/login');
  }

  return { adminUser: user };
};
