import { db, schema } from '$server/db';
import { desc, eq } from 'drizzle-orm';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async () => {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekStart = new Date(todayStart);
  weekStart.setDate(weekStart.getDate() - 6); // последние 7 дней включая сегодня

  // Все заказы — для агрегации на JS-стороне (объём небольшой)
  const allOrders = await db
    .select({
      id: schema.euOrders.id,
      status: schema.euOrders.status,
      totalRub: schema.euOrders.totalRub,
      createdAt: schema.euOrders.createdAt
    })
    .from(schema.euOrders);

  const ordersToday = allOrders.filter((o) => new Date(o.createdAt) >= todayStart);
  const ordersWeek = allOrders.filter((o) => new Date(o.createdAt) >= weekStart);
  const ordersNew = allOrders.filter((o) => o.status === 'new');

  const sumToday = ordersToday.reduce((acc, o) => acc + o.totalRub, 0);
  const sumWeek = ordersWeek.reduce((acc, o) => acc + o.totalRub, 0);

  // Товары
  const productsAll = await db
    .select({ id: schema.euProducts.id, active: schema.euProducts.active, inStock: schema.euProducts.inStock })
    .from(schema.euProducts);

  const productsActive = productsAll.filter((p) => p.active).length;
  const productsInStock = productsAll.filter((p) => p.active && p.inStock).length;

  // Последние 8 заказов с именем покупателя
  const recentOrders = await db
    .select({
      id: schema.euOrders.id,
      number: schema.euOrders.number,
      status: schema.euOrders.status,
      totalRub: schema.euOrders.totalRub,
      createdAt: schema.euOrders.createdAt,
      customerName: schema.euCustomers.name,
      customerPhone: schema.euCustomers.phone
    })
    .from(schema.euOrders)
    .leftJoin(schema.euCustomers, eq(schema.euOrders.customerId, schema.euCustomers.id))
    .orderBy(desc(schema.euOrders.createdAt))
    .limit(8);

  return {
    stats: {
      ordersToday: ordersToday.length,
      sumToday,
      ordersWeek: ordersWeek.length,
      sumWeek,
      ordersNew: ordersNew.length,
      ordersTotal: allOrders.length,
      productsActive,
      productsInStock,
      productsTotal: productsAll.length
    },
    recentOrders
  };
};
