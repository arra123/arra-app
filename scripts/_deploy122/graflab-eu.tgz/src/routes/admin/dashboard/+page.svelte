<script lang="ts">
  import { formatPrice } from '$lib/utils/format';
  import { t } from '$lib/i18n';
  import type { PageData } from './$types';
  export let data: PageData;

  $: statusLabels = {
    new: $t('statusNew'),
    paid: $t('statusPaid'),
    packed: $t('statusPacked'),
    shipped: $t('statusShipped'),
    delivered: $t('statusDelivered'),
    cancelled: $t('statusCancelled')
  } as Record<string, string>;
</script>

<svelte:head>
  <title>{$t('dashboard')} — GRAFLAB Admin</title>
</svelte:head>

<div class="dash">
  <h1>{$t('dashboard')}</h1>

  <!-- Карточки статистики -->
  <div class="cards">
    <div class="card card--accent">
      <div class="card__label">{$t('newOrders')}</div>
      <div class="card__val">{data.stats.ordersNew}</div>
      <div class="card__sub">{$t('awaitingProcessing')}</div>
    </div>
    <div class="card">
      <div class="card__label">{$t('ordersToday')}</div>
      <div class="card__val">{data.stats.ordersToday}</div>
      <div class="card__sub">{formatPrice(data.stats.sumToday)}</div>
    </div>
    <div class="card">
      <div class="card__label">{$t('ordersWeek')}</div>
      <div class="card__val">{data.stats.ordersWeek}</div>
      <div class="card__sub">{formatPrice(data.stats.sumWeek)}</div>
    </div>
    <div class="card">
      <div class="card__label">{$t('totalOrders')}</div>
      <div class="card__val">{data.stats.ordersTotal}</div>
      <div class="card__sub">{$t('allTime')}</div>
    </div>
    <div class="card">
      <div class="card__label">{$t('productsInStock')}</div>
      <div class="card__val">{data.stats.productsInStock}</div>
      <div class="card__sub">{$t('ofActive', { n: data.stats.productsActive })}</div>
    </div>
  </div>

  <!-- Последние заказы -->
  <div class="section">
    <div class="section__head">
      <h2>{$t('recentOrders')}</h2>
      <a href="/admin/orders" class="section__link">{$t('allOrders')} →</a>
    </div>

    {#if data.recentOrders.length === 0}
      <p class="empty">{$t('noOrders')}</p>
    {:else}
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>{$t('colNumber')}</th>
              <th>{$t('colStatus')}</th>
              <th>{$t('colCustomer')}</th>
              <th>{$t('colAmount')}</th>
              <th>{$t('colDate')}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {#each data.recentOrders as o (o.id)}
              <tr>
                <td class="td-num num">{o.number}</td>
                <td>
                  <span class="status status--{o.status}">{statusLabels[o.status] ?? o.status}</span>
                </td>
                <td>
                  <div>{o.customerName || '—'}</div>
                  <div class="td-phone num">{o.customerPhone || ''}</div>
                </td>
                <td class="td-total num">{formatPrice(o.totalRub)}</td>
                <td class="td-date">
                  {new Date(o.createdAt).toLocaleDateString('ru-RU')}
                  {new Date(o.createdAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}
                </td>
                <td>
                  <a href="/admin/orders/{o.id}" class="btn-view">{$t('open')}</a>
                </td>
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
    {/if}
  </div>
</div>

<style>
  .dash {
    max-width: 1100px;
    margin: 0 auto;
    padding: 24px 20px 60px;
  }
  h1 {
    font-size: 24px;
    font-weight: 700;
    margin: 0 0 24px;
  }
  h2 {
    font-size: 18px;
    font-weight: 700;
    margin: 0;
  }

  /* Карточки */
  .cards {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(190px, 1fr));
    gap: 16px;
    margin-bottom: 36px;
  }
  .card {
    background: #fff;
    border: 1px solid #e8e8e8;
    border-radius: 12px;
    padding: 20px 22px;
  }
  .card--accent {
    border-color: #4a9159;
    background: #f0f9f2;
  }
  .card__label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #888;
    font-weight: 600;
    margin-bottom: 8px;
  }
  .card--accent .card__label {
    color: #3a7448;
  }
  .card__val {
    font-size: 36px;
    font-weight: 800;
    line-height: 1;
    color: #111;
    margin-bottom: 6px;
  }
  .card--accent .card__val {
    color: #2d6b3e;
  }
  .card__sub {
    font-size: 13px;
    color: #999;
  }
  .card--accent .card__sub {
    color: #5aaa6a;
    font-weight: 600;
  }

  /* Section */
  .section {
    background: #fff;
    border: 1px solid #e8e8e8;
    border-radius: 12px;
    padding: 20px;
  }
  .section__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
  }
  .section__link {
    font-size: 13px;
    color: #4a9159;
    font-weight: 600;
  }
  .section__link:hover {
    color: #2d6b3e;
  }

  .empty { color: #888; }

  .table-wrap { overflow-x: auto; }
  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
  }
  th {
    text-align: left;
    padding: 8px 12px;
    font-size: 11px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #888;
    border-bottom: 2px solid #eee;
    white-space: nowrap;
  }
  td {
    padding: 10px 12px;
    border-bottom: 1px solid #f0f0f0;
    vertical-align: middle;
  }
  .td-num { font-weight: 600; white-space: nowrap; }
  .td-phone { font-size: 12px; color: #999; margin-top: 2px; }
  .td-total { font-weight: 700; white-space: nowrap; }
  .td-date { color: #888; white-space: nowrap; font-size: 13px; }

  .status {
    display: inline-block;
    padding: 3px 10px;
    border-radius: 99px;
    font-size: 11px;
    font-weight: 600;
  }
  .status--new { background: #e3f2fd; color: #1565c0; }
  .status--paid { background: #e8f5e9; color: #2e7d32; }
  .status--packed { background: #fff3e0; color: #e65100; }
  .status--shipped { background: #f3e5f5; color: #7b1fa2; }
  .status--delivered { background: #e8f5e9; color: #1b5e20; }
  .status--cancelled { background: #fafafa; color: #999; }

  .btn-view {
    display: inline-block;
    padding: 5px 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 12px;
    color: #333;
    white-space: nowrap;
  }
  .btn-view:hover { background: #f5f5f5; border-color: #bbb; }
</style>
