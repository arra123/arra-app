import { json } from '@sveltejs/kit';
import { getCustomerBySession, applyReferral } from '$lib/server/customer-auth';
import type { RequestHandler } from './$types';

export const POST: RequestHandler = async ({ request, cookies }) => {
  const sessionId = cookies.get('customer_session');
  if (!sessionId) return json({ error: 'Не авторизован' }, { status: 401 });

  const customer = await getCustomerBySession(sessionId);
  if (!customer) return json({ error: 'Не авторизован' }, { status: 401 });

  const { code } = await request.json();
  if (!code) return json({ error: 'Укажите код' }, { status: 400 });

  const ok = await applyReferral(customer.id, code.trim().toUpperCase());
  if (!ok) return json({ error: 'Код не найден или уже использован' }, { status: 400 });

  return json({ ok: true });
};
