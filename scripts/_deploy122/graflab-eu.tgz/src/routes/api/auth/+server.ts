import { json } from '@sveltejs/kit';
import { sendCode, verifyCode, logout } from '$lib/server/customer-auth';
import type { RequestHandler } from './$types';

export const POST: RequestHandler = async ({ request, cookies }) => {
  const body = await request.json();
  const { action, phone, code } = body;

  if (action === 'send-code') {
    if (!phone || typeof phone !== 'string') {
      return json({ error: 'Enter phone number' }, { status: 400 });
    }
    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      return json({ error: 'Invalid number' }, { status: 400 });
    }
    await sendCode(cleanPhone);
    return json({ ok: true });
  }

  if (action === 'verify') {
    if (!phone || !code) {
      return json({ error: 'Enter phone and code' }, { status: 400 });
    }
    const cleanPhone = phone.replace(/\D/g, '');
    const result = await verifyCode(cleanPhone, code);
    if (!result) {
      return json({ error: 'Invalid or expired code' }, { status: 400 });
    }

    cookies.set('customer_session', result.sessionId, {
      path: '/',
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60,
    });

    return json({ ok: true, customerId: result.customerId });
  }

  if (action === 'logout') {
    const sessionId = cookies.get('customer_session');
    if (sessionId) {
      await logout(sessionId);
      cookies.delete('customer_session', { path: '/' });
    }
    return json({ ok: true });
  }

  return json({ error: 'Unknown action' }, { status: 400 });
};
