import { json, error } from '@sveltejs/kit';
import { db, schema } from '$server/db';
import { eq, inArray } from 'drizzle-orm';
import { getCustomerBySession } from '$lib/server/customer-auth';
import { notifyOrderCreated } from '$lib/server/notify';
import type { RequestHandler } from './$types';

function generateOrderNumber(): string {
  const now = new Date();
  const date = now.toISOString().slice(2, 10).replace(/-/g, '');
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `EU-${date}-${rand}`;
}

export const POST: RequestHandler = async ({ request, cookies }) => {
  let body: {
    lines: { productId: number; qty: number }[];
    customerName?: string;
    customerPhone: string;
    deliveryAddress?: string;
    comment?: string;
    useBonuses?: boolean;
  };

  try {
    body = await request.json();
  } catch {
    throw error(400, 'Invalid JSON');
  }

  if (!body.customerPhone?.trim()) {
    throw error(400, 'Phone is required');
  }
  if (!Array.isArray(body.lines) || body.lines.length === 0) {
    throw error(400, 'Cart is empty');
  }

  const phone = body.customerPhone.trim();

  // ── покупатель: берём из сессии если залогинен, иначе ищем/создаём по телефону ──
  const sessionId = cookies.get('customer_session');
  const sessionCustomer = sessionId ? await getCustomerBySession(sessionId) : null;

  let customerId: number;
  let customerBonusBalance = 0;

  if (sessionCustomer) {
    customerId = sessionCustomer.id;
    customerBonusBalance = sessionCustomer.bonusBalance ?? 0;
  } else {
    const existing = await db
      .select({ id: schema.euCustomers.id, bonusBalance: schema.euCustomers.bonusBalance })
      .from(schema.euCustomers)
      .where(eq(schema.euCustomers.phone, phone))
      .limit(1);

    if (existing.length > 0) {
      customerId = existing[0].id;
      customerBonusBalance = existing[0].bonusBalance ?? 0;
    } else {
      const ins = await db
        .insert(schema.euCustomers)
        .values({
          phone,
          name: body.customerName?.trim() || null,
          email: null
        })
        .returning({ id: schema.euCustomers.id });
      customerId = ins[0].id;
    }
  }

  // ── Позиции: один SELECT через inArray вместо N+1 ──
  const requestedIds = body.lines
    .filter((l) => l.productId && l.qty && l.qty >= 1)
    .map((l) => l.productId);

  if (requestedIds.length === 0) {
    throw error(400, 'No valid products in cart');
  }

  const priceRows = await db
    .select({ id: schema.euProducts.id, priceRub: schema.euProducts.priceRub })
    .from(schema.euProducts)
    .where(inArray(schema.euProducts.id, requestedIds));

  const priceMap = new Map(priceRows.map((r) => [r.id, r.priceRub]));

  let subtotal = 0;
  const validLines: { productId: number; qty: number; priceRub: number }[] = [];
  for (const line of body.lines) {
    if (!line.productId || !line.qty || line.qty < 1) continue;
    const priceRub = priceMap.get(line.productId);
    if (priceRub == null) continue;
    subtotal += priceRub * line.qty;
    validLines.push({ productId: line.productId, qty: line.qty, priceRub });
  }

  if (validLines.length === 0) {
    throw error(400, 'No valid products in cart');
  }

  // ── Списание бонусов ──
  const wantBonuses = body.useBonuses === true && sessionCustomer;
  const bonusApplied = wantBonuses ? Math.min(customerBonusBalance, subtotal) : 0;
  const totalRub = Math.max(subtotal - bonusApplied, 0);

  const number = generateOrderNumber();

  const [order] = await db
    .insert(schema.euOrders)
    .values({
      number,
      customerId,
      status: 'new',
      totalRub,
      deliveryAddress: body.deliveryAddress?.trim() || null,
      deliveryMethod: null,
      paymentMethod: null,
      comment: body.comment?.trim() || null
    })
    .returning({ id: schema.euOrders.id, number: schema.euOrders.number });

  await db.insert(schema.euOrderItems).values(
    validLines.map((l) => ({
      orderId: order.id,
      productId: l.productId,
      quantity: l.qty,
      priceRub: l.priceRub
    }))
  );

  // Списываем бонусы после успешного создания заказа
  if (bonusApplied > 0) {
    await db
      .update(schema.euCustomers)
      .set({ bonusBalance: customerBonusBalance - bonusApplied })
      .where(eq(schema.euCustomers.id, customerId));
  }

  // Уведомление (пока только в лог)
  notifyOrderCreated({ phone, orderNumber: order.number, totalRub });

  return json({ ok: true, orderNumber: order.number, totalRub, bonusApplied });
};
