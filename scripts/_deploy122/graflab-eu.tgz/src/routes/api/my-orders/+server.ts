import { json, error } from '@sveltejs/kit';
import { db, schema } from '$server/db';
import { eq, desc } from 'drizzle-orm';
import type { RequestHandler } from './$types';

export const GET: RequestHandler = async ({ url }) => {
  const phone = url.searchParams.get('phone')?.trim();
  if (!phone) throw error(400, 'Телефон обязателен');

  const customers = await db
    .select({ id: schema.euCustomers.id })
    .from(schema.euCustomers)
    .where(eq(schema.euCustomers.phone, phone))
    .limit(1);

  if (customers.length === 0) return json([]);

  const orders = await db
    .select({
      id: schema.euOrders.id,
      number: schema.euOrders.number,
      status: schema.euOrders.status,
      totalRub: schema.euOrders.totalRub,
      createdAt: schema.euOrders.createdAt
    })
    .from(schema.euOrders)
    .where(eq(schema.euOrders.customerId, customers[0].id))
    .orderBy(desc(schema.euOrders.createdAt));

  // Для каждого заказа — список товаров
  const result = [];
  for (const o of orders) {
    const items = await db
      .select({
        name: schema.euProducts.name,
        quantity: schema.euOrderItems.quantity,
        priceRub: schema.euOrderItems.priceRub
      })
      .from(schema.euOrderItems)
      .innerJoin(schema.euProducts, eq(schema.euOrderItems.productId, schema.euProducts.id))
      .where(eq(schema.euOrderItems.orderId, o.id));

    result.push({ ...o, items });
  }

  return json(result);
};
