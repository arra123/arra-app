<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { formatPrice } from '$lib/utils/format';
  import { t } from '$lib/i18n';
  import type { PageData } from './$types';

  export let data: PageData;

  // Форма входа
  let phone = '';
  let code = '';
  let step: 'phone' | 'code' | 'done' = data.customer ? 'done' : 'phone';
  let error = '';
  let loading = false;
  let name = data.customer?.name ?? '';
  let email = data.customer?.email ?? '';
  let refInput = '';
  let refMsg = '';

  async function sendCode() {
    error = '';
    loading = true;
    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'send-code', phone })
      });
      const d = await res.json();
      if (d.ok) { step = 'code'; }
      else { error = d.error || $t('sendError'); }
    } finally { loading = false; }
  }

  async function verify() {
    error = '';
    loading = true;
    try {
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify', phone, code })
      });
      const d = await res.json();
      if (d.ok) { window.location.reload(); }
      else { error = d.error || $t('invalidCode'); }
    } finally { loading = false; }
  }

  async function doLogout() {
    await fetch('/api/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'logout' })
    });
    window.location.reload();
  }

  async function applyRef() {
    refMsg = '';
    const res = await fetch('/api/referral', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: refInput })
    });
    const d = await res.json();
    refMsg = d.ok ? $t('codeApplied') : (d.error || $t('sendError'));
  }

  $: STATUS_LABELS = {
    new: $t('statusNew'), paid: $t('statusPaid'), packed: $t('statusPacked'),
    shipped: $t('statusShipped'), delivered: $t('statusDelivered'), cancelled: $t('statusCancelled'),
  } as Record<string, string>;
</script>

<svelte:head>
  <title>{$t('myProfile')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="page">
  {#if step !== 'done' || !data.customer}
    <!-- ═══ ВХОД ═══ -->
    <div class="auth-card">
      <h1>{$t('accountLogin')}</h1>
      <p class="auth-sub">{$t('loginHint')}</p>

      {#if step === 'phone'}
        <form on:submit|preventDefault={sendCode}>
          <input
            type="tel"
            bind:value={phone}
            placeholder="+49 ___-___-____"
            required
            class="auth-input"
          />
          <button type="submit" class="auth-btn" disabled={loading || !phone.trim()}>
            {loading ? $t('sendingCode') : $t('getCode')}
          </button>
        </form>
      {:else if step === 'code'}
        <form on:submit|preventDefault={verify}>
          <p class="auth-phone-info">{$t('codeSentTo')} {phone}</p>
          <input
            type="text"
            bind:value={code}
            placeholder={$t('smsCode')}
            maxlength="6"
            inputmode="numeric"
            required
            class="auth-input auth-input--code"
          />
          <button type="submit" class="auth-btn" disabled={loading || code.length < 4}>
            {loading ? $t('checking') : $t('signIn')}
          </button>
          <button type="button" class="auth-back" on:click={() => { step = 'phone'; code = ''; }}>
            {$t('changeNumber')}
          </button>
        </form>
      {/if}

      {#if error}
        <p class="auth-error">{error}</p>
      {/if}
    </div>

  {:else}
    <!-- ═══ ПРОФИЛЬ ═══ -->
    <div class="profile">
      <div class="profile__header">
        <h1>{$t('myProfile')}</h1>
        <button class="logout-btn" on:click={doLogout}>{$t('logout')}</button>
      </div>

      <div class="profile__grid">
        <section class="profile__card">
          <h2>{$t('data')}</h2>
          <div class="info-row">
            <span class="info-label">{$t('phoneLbl')}</span>
            <span>{data.customer.phone}</span>
          </div>
          <div class="info-row">
            <span class="info-label">{$t('name')}</span>
            <span>{data.customer.name || $t('notSpecified')}</span>
          </div>
          <div class="info-row">
            <span class="info-label">{$t('email')}</span>
            <span>{data.customer.email || $t('notSpecified')}</span>
          </div>
        </section>

        <section class="profile__card bonus-card">
          <h2>{$t('bonuses')}</h2>
          <div class="bonus-balance">
            <span class="bonus-amount num">{formatPrice(data.customer.bonusBalance)}</span>
            <span class="bonus-label">{$t('onBalance')}</span>
          </div>
          <div class="referral-block">
            <p class="ref-title">{$t('yourReferralCode')}:</p>
            <div class="ref-code">{data.customer.referralCode}</div>
            <p class="ref-desc">{$t('referralHint')}</p>
          </div>
          {#if !data.customer.referredBy}
            <div class="ref-apply">
              <input type="text" bind:value={refInput} placeholder={$t('friendCode')} class="ref-input" />
              <button class="ref-btn" on:click={applyRef} disabled={!refInput.trim()}>{$t('apply')}</button>
            </div>
            {#if refMsg}<p class="ref-msg">{refMsg}</p>{/if}
          {:else}
            <p class="ref-msg ref-msg--done">{$t('referralAlreadyUsed')}</p>
          {/if}
        </section>
      </div>

      {#if data.orders.length > 0}
        <section class="orders">
          <h2>{$t('myOrdersTitle')}</h2>
          <div class="orders-list">
            {#each data.orders as order (order.id)}
              <div class="order-row">
                <span class="order-number">{order.number}</span>
                <span class="order-status status-{order.status}">{STATUS_LABELS[order.status] ?? order.status}</span>
                <span class="order-total num">{formatPrice(order.totalRub)}</span>
                <span class="order-date">{new Date(order.createdAt).toLocaleDateString('ru')}</span>
              </div>
            {/each}
          </div>
        </section>
      {:else}
        <p class="no-orders">{$t('noOrdersYet')}</p>
      {/if}
    </div>
  {/if}
</main>

<Tabbar />

<style>
  .page {
    max-width: var(--maxw); margin: 0 auto;
    padding: var(--s-4) var(--gutter) var(--s-6);
  }

  /* ═══ ВХОД ═══ */
  .auth-card {
    max-width: 400px; margin: var(--s-5) auto;
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: var(--r-card); padding: var(--s-5);
    text-align: center;
  }
  .auth-card h1 { font-size: 24px; font-weight: 700; margin: 0 0 var(--s-1); }
  .auth-sub { color: var(--ink-soft); font-size: 14px; margin: 0 0 var(--s-4); }
  .auth-input {
    width: 100%; border: 1px solid var(--line-strong); border-radius: 12px;
    padding: 14px 16px; font-size: 16px; text-align: center;
    background: var(--paper); color: var(--ink); margin-bottom: var(--s-2);
  }
  .auth-input:focus { outline: 0; border-color: var(--accent); }
  .auth-input--code { font-size: 24px; letter-spacing: 0.3em; font-weight: 700; }
  .auth-btn {
    width: 100%; background: var(--brand); color: #fff; border: 0;
    border-radius: 99px; padding: 14px; font-size: 15px; font-weight: 700;
    margin-top: var(--s-1);
  }
  .auth-btn:hover:not(:disabled) { background: var(--brand-hover); }
  .auth-btn:disabled { opacity: 0.5; }
  .auth-back {
    background: transparent; border: 0; color: var(--ink-soft);
    font-size: 13px; margin-top: var(--s-2); cursor: pointer;
  }
  .auth-back:hover { color: var(--ink); }
  .auth-phone-info { font-size: 13px; color: var(--ink-soft); margin: 0 0 var(--s-2); }
  .auth-error { color: #e44; font-size: 13px; margin-top: var(--s-2); }

  /* ═══ ПРОФИЛЬ ═══ */
  .profile__header {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: var(--s-4);
  }
  .profile__header h1 { font-size: 24px; font-weight: 700; margin: 0; }
  .logout-btn {
    background: transparent; border: 1px solid var(--line-strong);
    border-radius: 99px; padding: 8px 18px; font-size: 13px;
    color: var(--ink-soft); cursor: pointer;
  }
  .logout-btn:hover { background: var(--paper-deep); color: var(--ink); }

  .profile__grid {
    display: grid; grid-template-columns: 1fr; gap: var(--s-3);
  }
  @media (min-width: 700px) { .profile__grid { grid-template-columns: 1fr 1fr; } }

  .profile__card {
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: var(--r); padding: var(--s-3);
  }
  .profile__card h2 { font-size: 15px; font-weight: 700; margin: 0 0 var(--s-2); }

  .info-row {
    display: flex; justify-content: space-between;
    padding: 8px 0; border-bottom: 1px solid var(--line);
    font-size: 14px;
  }
  .info-label { color: var(--ink-soft); }

  .bonus-card { background: linear-gradient(135deg, #e8f5e9 0%, #f1f8e9 100%); }
  .bonus-balance { display: flex; align-items: baseline; gap: 8px; margin-bottom: var(--s-3); }
  .bonus-amount { font-size: 32px; font-weight: 800; color: var(--brand); }
  .bonus-label { font-size: 14px; color: var(--ink-soft); }

  .referral-block { margin-bottom: var(--s-3); }
  .ref-title { font-size: 12px; color: var(--ink-soft); margin: 0 0 6px; }
  .ref-code {
    font-size: 20px; font-weight: 800; letter-spacing: 0.1em;
    color: var(--brand); background: var(--paper-card);
    border: 2px dashed var(--brand); border-radius: 10px;
    padding: 10px; text-align: center;
  }
  .ref-desc { font-size: 12px; color: var(--ink-soft); margin: 8px 0 0; }

  .ref-apply { display: flex; gap: 8px; }
  .ref-input {
    flex: 1; border: 1px solid var(--line-strong); border-radius: 8px;
    padding: 8px 12px; font-size: 14px;
  }
  .ref-btn {
    background: var(--brand); color: #fff; border: 0;
    border-radius: 8px; padding: 8px 16px; font-size: 13px; font-weight: 700;
  }
  .ref-msg { font-size: 12px; margin-top: 6px; color: var(--ok); }

  /* ═══ ЗАКАЗЫ ═══ */
  .orders { margin-top: var(--s-4); }
  .orders h2 { font-size: 20px; font-weight: 700; margin: 0 0 var(--s-3); }
  .orders-list {
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: var(--r); overflow: hidden;
  }
  .order-row {
    display: grid; grid-template-columns: 1fr auto auto auto;
    gap: var(--s-2); padding: 12px var(--s-3); align-items: center;
    font-size: 14px;
  }
  .order-row + .order-row { border-top: 1px solid var(--line); }
  .order-number { font-weight: 600; }
  .order-status { font-size: 12px; font-weight: 600; padding: 3px 10px; border-radius: 99px; }
  .status-new { background: #fff3e0; color: #e65100; }
  .status-paid { background: #e8f5e9; color: #2e7d32; }
  .status-shipped { background: #e3f2fd; color: #1565c0; }
  .status-delivered { background: #e8f5e9; color: #1b5e20; }
  .status-cancelled { background: #fce4ec; color: #c62828; }
  .order-total { font-weight: 700; }
  .order-date { color: var(--ink-soft); font-size: 13px; }

  .no-orders {
    text-align: center; color: var(--ink-soft); font-size: 14px;
    margin-top: var(--s-4);
  }
  .no-orders a { color: var(--accent); font-weight: 600; }
</style>
