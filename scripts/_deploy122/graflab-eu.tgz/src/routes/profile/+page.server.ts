import { getCustomerBySession } from '$lib/server/customer-auth';
import { db, schema } from '$server/db';
import { eq, desc } from 'drizzle-orm';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ cookies }) => {
  const sessionId = cookies.get('customer_session');
  if (!sessionId) return { customer: null, orders: [] };

  const customer = await getCustomerBySession(sessionId);
  if (!customer) return { customer: null, orders: [] };

  // Загружаем заказы
  const orders = await db
    .select()
    .from(schema.euOrders)
    .where(eq(schema.euOrders.customerId, customer.id))
    .orderBy(desc(schema.euOrders.createdAt))
    .limit(20);

  return { customer, orders };
};
