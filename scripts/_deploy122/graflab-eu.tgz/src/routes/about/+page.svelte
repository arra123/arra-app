<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { t } from '$lib/i18n';
</script>

<svelte:head>
  <title>{$t('aboutTitle')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="info-page">
  <h1>{$t('aboutHeading')}</h1>

  <div class="about-hero">
    <img src="/brand/logo.png" alt="GRAFLAB" class="about-logo" />
  </div>

  <section class="block">
    <h2>{$t('whoWeAre')}</h2>
    <p>{$t('whoWeAreText')}</p>
    <p>{$t('whoWeAreText2')}</p>
  </section>

  <section class="block">
    <h2>{$t('whyDirect')}</h2>
    <p>{$t('whyDirectText')}</p>
  </section>

  <section class="block">
    <h2>{$t('ourAudience')}</h2>
    <p>{$t('ourAudienceText')}</p>
  </section>
</main>

<Tabbar />

<style>
  .info-page {
    max-width: 800px; margin: 0 auto;
    padding: var(--s-4) var(--gutter) var(--s-6);
  }
  h1 { font-size: 28px; font-weight: 700; margin: 0 0 var(--s-4); }
  .about-hero {
    text-align: center; margin-bottom: var(--s-5);
    padding: var(--s-5) var(--s-3);
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: var(--r);
  }
  .about-logo { max-width: 280px; margin: 0 auto; }
  .block { margin-bottom: var(--s-4); }
  .block h2 { font-size: 18px; font-weight: 700; margin: 0 0 var(--s-2); }
  .block p {
    color: var(--ink-soft); font-size: 15px; line-height: 1.65; margin: 0 0 var(--s-2);
  }
  .block p:last-child { margin-bottom: 0; }
</style>
