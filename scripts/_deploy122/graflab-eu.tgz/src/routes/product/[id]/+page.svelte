<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import Pcard from '$lib/components/Pcard.svelte';
  import { cart } from '$lib/stores/cart';
  import { favorites } from '$lib/stores/favorites';
  import {
    formatPrice,
    discountPercent,
    formatRating,
    reviewsLabel
  } from '$lib/utils/format';
  import { t, locale } from '$lib/i18n';
  import type { PageData } from './$types';

  export let data: PageData;
  $: p = data.product;
  $: pName = $locale === 'sr' && p.nameSr ? p.nameSr : p.name;
  $: catName = $locale === 'sr' && p.categoryNameSr ? p.categoryNameSr : p.categoryName;
  $: discount = discountPercent(p.priceRub, p.priceOldRub);
  $: ratingStr = formatRating(p.rating);
  $: qty = cart.qtyOf($cart, p.id);
  $: isFav = $favorites.has(p.id);

  let shareToast = false;
  function copyLink() {
    navigator.clipboard.writeText(window.location.href).then(() => {
      shareToast = true;
      setTimeout(() => { shareToast = false; }, 2000);
    });
  }
</script>

<svelte:head>
  <title>{pName} — GRAFLAB</title>
  {#if p.description}
    <meta name="description" content={p.description.slice(0, 160)} />
  {/if}
  <meta property="og:title" content="{pName} — GRAFLAB" />
  <meta property="og:image" content={p.imageUrl} />
  <meta property="og:type" content="product" />
</svelte:head>

<Header />

<main class="page">
  <div class="topbar">
    <a
      href={p.categorySlug ? `/?cat=${p.categorySlug}` : '/'}
      class="icon-btn back-btn"
      aria-label={$t('backToCatalog')}
      title={catName ?? $t('backToCatalog')}
    >
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M19 12H5M12 5l-7 7 7 7" />
      </svg>
    </a>

    <nav class="crumbs" aria-label="Breadcrumbs">
      <a href="/">{$t('catalog')}</a>
      {#if p.categorySlug}
        <span class="sep">/</span>
        <a href="/?cat={p.categorySlug}">{catName}</a>
      {/if}
    </nav>

    <div class="topbar__actions">
      <button
        class="icon-btn"
        type="button"
        on:click={copyLink}
        aria-label={$t('share')}
        title={shareToast ? $t('copied') : $t('share')}
      >
        {#if shareToast}
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M5 13l4 4L19 7" />
          </svg>
        {:else}
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M12 3v12M7 8l5-5 5 5M5 15v4a2 2 0 002 2h10a2 2 0 002-2v-4" />
          </svg>
        {/if}
      </button>

      <button
        class="icon-btn fav-btn"
        class:is-fav={isFav}
        type="button"
        on:click={() => favorites.toggle(p.id)}
        aria-label={isFav ? $t('removeFromFavorites') : $t('addToFavorites')}
      >
        <svg viewBox="0 0 24 24" stroke-width="1.8" stroke-linecap="round">
          <path d="M12 21s-7-4.5-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.5-9 9-9 9Z" />
        </svg>
      </button>
    </div>
  </div>

  <article class="product">
    <div class="product__media">
      <img src={p.imageUrl} alt={pName} />
    </div>

    <div class="product__info">
      {#if catName}
        <div class="product__cat">{catName}</div>
      {/if}

      <h1 class="product__name">{pName}</h1>

      <div class="product__meta">
        {#if p.inStock}
          <span class="ok">{$t('inStock')}</span>
        {:else}
          <span class="out">{$t('outOfStock')}</span>
        {/if}
        {#if ratingStr && p.reviewsCount > 0}
          <span class="dot"></span>
          <span class="rating">
            <svg viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
              <path
                d="M8 1.2l1.95 4.27 4.65.42-3.5 3.1 1.04 4.55L8 11.18l-4.14 2.36 1.04-4.55-3.5-3.1 4.65-.42L8 1.2z"
              />
            </svg>
            {ratingStr}
            <span class="reviews num">· {reviewsLabel(p.reviewsCount)}</span>
          </span>
        {/if}
        <span class="dot"></span>
        <span class="article num">{$t('article')} {p.article}</span>
      </div>

      <div class="product__price-row">
        <span class="product__price num">{formatPrice(p.priceRub)}</span>
        {#if p.priceOldRub && p.priceOldRub > p.priceRub}
          <span class="product__price-old num">{formatPrice(p.priceOldRub)}</span>
        {/if}
        {#if discount}
          <span class="product__discount num">{discount}</span>
        {/if}
      </div>

      <div class="product__buy">
        {#if qty === 0}
          <button class="buy" type="button" on:click={() => cart.add(p.id)}>
            <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round">
              <path d="M12 5v14M5 12h14" />
            </svg>
            {$t('addToCart')} · {formatPrice(p.priceRub)}
          </button>
        {:else}
          <div class="counter">
            <button type="button" on:click={() => cart.remove(p.id)} aria-label={$t('removeOne')}>−</button>
            <span class="num">{qty} {$t('pcs')}</span>
            <button type="button" on:click={() => cart.add(p.id)} aria-label={$t('addAnother')}>+</button>
          </div>
          <a class="to-cart" href="/cart">{$t('goToCart')} →</a>
        {/if}
      </div>

      {#if p.description}
        <section class="product__desc">
          <h2>{$t('description')}</h2>
          <p>{p.description}</p>
        </section>
      {:else}
        <section class="product__desc product__desc--empty">
          <h2>{$t('description')}</h2>
          <p>{$t('descriptionPlaceholder')}</p>
        </section>
      {/if}

      <section class="product__lab">
        <div class="lab__line">
          <strong>{$t('manufacturing')}:</strong> {$t('manufacturingValue')}
        </div>
        <div class="lab__line">
          <strong>{$t('labControl')}:</strong> {$t('labControlValue')}
        </div>
        <div class="lab__line">
          <strong>{$t('certificates')}:</strong> {$t('certificatesValue')}
        </div>
      </section>

      <section class="product__accordion">
        <details class="accordion-item">
          <summary class="accordion-summary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
              <path d="M9 3H5a2 2 0 00-2 2v4M9 3h6M9 3v18m6-18h4a2 2 0 012 2v4M15 3v18M3 9h18M3 15h18M9 21h6" />
            </svg>
            <span>{$t('composition')}</span>
            <svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
              <path d="M6 9l6 6 6-6" />
            </svg>
          </summary>
          <div class="accordion-body">
            <p class="placeholder-text">{$t('compositionPlaceholder')}</p>
          </div>
        </details>

        <details class="accordion-item">
          <summary class="accordion-summary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/>
              <path d="M12 8v4l3 3"/>
            </svg>
            <span>{$t('howToTake')}</span>
            <svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
              <path d="M6 9l6 6 6-6" />
            </svg>
          </summary>
          <div class="accordion-body">
            <p class="placeholder-text">{$t('howToTakePlaceholder')}</p>
          </div>
        </details>
      </section>
    </div>
  </article>

  {#if data.related.length > 0}
    <section class="related">
      <h2>{$t('fromSameCategory')}</h2>
      <div class="grid">
        {#each data.related as r (r.id)}
          <Pcard
            id={r.id}
            name={r.name}
            nameSr={r.nameSr}
            imageUrl={r.imageUrl}
            priceRub={r.priceRub}
            priceOldRub={r.priceOldRub}
            rating={r.rating}
            reviewsCount={r.reviewsCount}
            inStock={r.inStock}
          />
        {/each}
      </div>
    </section>
  {/if}
</main>

<Tabbar />

<style>
  .page {
    max-width: var(--maxw);
    margin: 0 auto;
    padding: var(--s-3) var(--gutter) var(--s-6);
  }

  .crumbs {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    color: var(--ink-soft);
    margin-bottom: var(--s-3);
  }
  .crumbs a {
    color: var(--ink-soft);
  }
  .crumbs a:hover {
    color: var(--ink);
  }
  .crumbs .sep {
    color: var(--ink-faint);
  }
  .crumbs .current {
    color: var(--ink);
    font-weight: 500;
    /* clamp длинных имён */
    max-width: 60vw;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .product {
    display: grid;
    grid-template-columns: 1fr;
    gap: var(--s-4);
  }
  @media (min-width: 760px) {
    .product {
      grid-template-columns: minmax(0, 5fr) minmax(0, 6fr);
      gap: var(--s-5);
    }
  }

  .product__media {
    aspect-ratio: 3 / 4;
    background: #ffffff;
    border: 1px solid var(--line);
    border-radius: var(--r-card);
    overflow: hidden;
    box-shadow: var(--shadow-md);
  }
  .product__media img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    display: block;
  }

  .product__info {
    display: flex;
    flex-direction: column;
    gap: var(--s-3);
  }

  .product__cat {
    font-size: 11px;
    letter-spacing: 0.16em;
    text-transform: uppercase;
    color: var(--accent);
    font-weight: 600;
  }

  .product__name {
    font-size: clamp(22px, 4vw, 32px);
    font-weight: 700;
    line-height: 1.2;
    letter-spacing: -0.01em;
    margin: 0;
  }

  .product__meta {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    font-size: 13px;
    color: var(--ink-soft);
  }
  .product__meta .ok {
    color: var(--ok);
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-weight: 500;
  }
  .product__meta .ok::before {
    content: '';
    width: 6px;
    height: 6px;
    background: var(--ok);
    border-radius: 99px;
  }
  .product__meta .out {
    color: var(--ink-faint);
    font-weight: 500;
  }
  .product__meta .dot {
    width: 3px;
    height: 3px;
    background: var(--ink-faint);
    border-radius: 99px;
  }
  .product__meta .rating {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    color: var(--ink);
    font-weight: 500;
  }
  .product__meta .rating svg {
    width: 13px;
    height: 13px;
    color: var(--accent);
  }
  .product__meta .reviews {
    color: var(--ink-faint);
    font-weight: 400;
  }
  .product__meta .article {
    color: var(--ink-faint);
  }

  .product__price-row {
    display: flex;
    align-items: baseline;
    gap: 12px;
    flex-wrap: wrap;
    margin-top: var(--s-1);
  }
  .product__price {
    font-size: 36px;
    font-weight: 800;
    color: var(--price);
    letter-spacing: -0.02em;
  }
  .product__price-old {
    font-size: 18px;
    color: var(--price-old);
    text-decoration: line-through;
  }
  .product__discount {
    background: var(--accent-soft);
    color: var(--accent);
    font-size: 13px;
    font-weight: 600;
    padding: 4px 10px;
    border-radius: 99px;
    letter-spacing: 0.01em;
    align-self: center;
  }

  .product__buy {
    display: flex;
    align-items: center;
    gap: var(--s-3);
    flex-wrap: wrap;
    margin-top: var(--s-2);
  }
  .buy {
    background: var(--brand);
    color: #fff;
    border: 0;
    border-radius: 99px;
    padding: 16px 28px;
    font-size: 15px;
    font-weight: 700;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    box-shadow: var(--shadow-md);
  }
  .buy svg {
    width: 14px;
    height: 14px;
    stroke: #fff;
  }
  .buy:hover {
    background: var(--brand-hover);
  }
  .counter {
    display: flex;
    align-items: stretch;
    background: var(--brand);
    border-radius: 99px;
    overflow: hidden;
    height: 50px;
    min-width: 160px;
  }
  .counter button {
    width: 48px;
    background: transparent;
    border: 0;
    color: #fff;
    font-size: 22px;
    font-weight: 600;
  }
  .counter button:hover {
    background: rgba(255, 255, 255, 0.12);
  }
  .counter span {
    flex: 1;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 15px;
    font-weight: 700;
  }
  .to-cart {
    color: var(--accent);
    font-size: 14px;
    font-weight: 600;
    border-bottom: 1px solid var(--accent);
    padding-bottom: 2px;
  }

  .product__desc {
    margin-top: var(--s-3);
    padding-top: var(--s-3);
    border-top: 1px solid var(--line);
  }
  .product__desc h2 {
    font-size: 11px;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: var(--ink-soft);
    margin: 0 0 var(--s-2);
    font-weight: 600;
  }
  .product__desc p {
    margin: 0;
    color: var(--ink);
    line-height: 1.55;
    font-size: 14px;
  }
  .product__desc--empty p {
    color: var(--ink-soft);
    font-style: italic;
  }

  .product__lab {
    margin-top: var(--s-3);
    padding: var(--s-3);
    background: var(--paper-deep);
    border-radius: var(--r);
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .product__lab .lab__line {
    font-size: 13px;
    color: var(--ink-soft);
  }
  .product__lab strong {
    color: var(--ink);
    font-weight: 600;
    margin-right: 4px;
  }

  .related {
    margin-top: var(--s-6);
    padding-top: var(--s-5);
    border-top: 1px solid var(--line);
  }
  .related h2 {
    font-size: 22px;
    font-weight: 700;
    margin: 0 0 var(--s-3);
    letter-spacing: -0.01em;
  }
  .grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: var(--s-2);
  }
  @media (min-width: 600px) {
    .grid {
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: var(--s-3);
    }
  }
  @media (min-width: 1100px) {
    .grid {
      grid-template-columns: repeat(4, minmax(0, 1fr));
    }
  }

  /* ── topbar (хлебные крошки + иконки действий) ── */
  .topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: var(--s-2);
    gap: var(--s-3);
    min-height: 36px;
  }
  .topbar .crumbs {
    margin-bottom: 0;
    flex: 1;
    min-width: 0;
  }
  .topbar__actions {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }
  .icon-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    background: transparent;
    border: 1px solid var(--line);
    border-radius: 99px;
    cursor: pointer;
    padding: 0;
    color: var(--ink-soft);
    transition: background 0.15s, color 0.15s, border-color 0.15s;
  }
  .icon-btn svg {
    width: 16px;
    height: 16px;
    fill: none;
  }
  .icon-btn:hover {
    background: var(--paper-deep);
    color: var(--ink);
    border-color: var(--line-strong);
  }
  .back-btn {
    flex-shrink: 0;
    color: var(--ink);
    background: var(--paper-card);
  }
  .back-btn:hover {
    background: var(--brand);
    color: #fff;
    border-color: var(--brand);
  }
  .fav-btn svg {
    stroke: currentColor;
  }
  .fav-btn.is-fav {
    border-color: #e44;
    background: #fff0f0;
    color: #e44;
  }
  .fav-btn.is-fav svg {
    stroke: #e44;
    fill: #e44;
  }

  /* ── аккордеон (состав / как принимать) ── */
  .product__accordion {
    margin-top: var(--s-3);
    display: flex;
    flex-direction: column;
    gap: 1px;
    border: 1px solid var(--line);
    border-radius: var(--r);
    overflow: hidden;
  }
  .accordion-item {
    background: var(--paper-card);
  }
  .accordion-item + .accordion-item {
    border-top: 1px solid var(--line);
  }
  .accordion-summary {
    list-style: none;
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 16px;
    cursor: pointer;
    user-select: none;
    font-size: 14px;
    font-weight: 600;
    color: var(--ink);
  }
  .accordion-summary::-webkit-details-marker { display: none; }
  .accordion-summary svg:first-child {
    width: 18px;
    height: 18px;
    color: var(--accent);
    flex-shrink: 0;
  }
  .accordion-summary span {
    flex: 1;
  }
  .accordion-summary .chevron {
    width: 16px;
    height: 16px;
    color: var(--ink-faint);
    transition: transform 0.2s;
  }
  .accordion-item[open] .accordion-summary .chevron {
    transform: rotate(180deg);
  }
  .accordion-summary:hover {
    background: var(--paper-deep);
  }
  .accordion-body {
    padding: 0 16px 16px 44px;
  }
  .placeholder-text {
    margin: 0;
    font-size: 14px;
    color: var(--ink-soft);
    font-style: italic;
    line-height: 1.55;
  }
</style>
