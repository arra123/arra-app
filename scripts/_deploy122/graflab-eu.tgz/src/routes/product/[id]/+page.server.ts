import { db, schema } from '$server/db';
import { and, eq, ne } from 'drizzle-orm';
import { error } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ params }) => {
  const id = parseInt(params.id, 10);
  if (isNaN(id)) throw error(404, 'Не товар');

  const rows = await db
    .select({
      id: schema.euProducts.id,
      article: schema.euProducts.article,
      slug: schema.euProducts.slug,
      name: schema.euProducts.name,
      nameSr: schema.euProducts.nameSr,
      description: schema.euProducts.description,
      categoryId: schema.euProducts.categoryId,
      categoryName: schema.euCategories.name,
      categoryNameSr: schema.euCategories.nameSr,
      categorySlug: schema.euCategories.slug,
      priceRub: schema.euProducts.priceRub,
      priceOldRub: schema.euProducts.priceOldRub,
      imageUrl: schema.euProducts.imageUrl,
      rating: schema.euProducts.rating,
      reviewsCount: schema.euProducts.reviewsCount,
      inStock: schema.euProducts.inStock
    })
    .from(schema.euProducts)
    .leftJoin(schema.euCategories, eq(schema.euProducts.categoryId, schema.euCategories.id))
    .where(and(eq(schema.euProducts.id, id), eq(schema.euProducts.active, true)))
    .limit(1);

  if (rows.length === 0) throw error(404, 'Товар не найден');

  const product = rows[0];

  // Похожие из той же категории — берём 6 без текущего, в произвольном
  // порядке (по article как proxy «новизны»). На фазе 5 заменим
  // на «популярные по числу заказов».
  const related =
    product.categoryId == null
      ? []
      : await db
          .select({
            id: schema.euProducts.id,
            name: schema.euProducts.name,
            nameSr: schema.euProducts.nameSr,
            imageUrl: schema.euProducts.imageUrl,
            priceRub: schema.euProducts.priceRub,
            priceOldRub: schema.euProducts.priceOldRub,
            rating: schema.euProducts.rating,
            reviewsCount: schema.euProducts.reviewsCount,
            inStock: schema.euProducts.inStock
          })
          .from(schema.euProducts)
          .where(
            and(
              eq(schema.euProducts.categoryId, product.categoryId),
              ne(schema.euProducts.id, product.id),
              eq(schema.euProducts.active, true)
            )
          )
          .limit(6);

  return { product, related };
};
