<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { t } from '$lib/i18n';
</script>

<svelte:head>
  <title>{$t('deliveryTitle')} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="info-page">
  <h1>{$t('deliveryHeading')}</h1>

  <section class="block">
    <h2>{$t('deliverySection')}</h2>
    <p>{$t('deliveryText')}</p>
    <div class="cards">
      <div class="card">
        <strong>{$t('pickupPoint')}</strong>
        <p>{$t('pickupPointDesc')}</p>
      </div>
      <div class="card">
        <strong>{$t('courier')}</strong>
        <p>{$t('courierDesc')}</p>
      </div>
    </div>
  </section>

  <section class="block" id="payment">
    <h2>{$t('paymentSection')}</h2>
    <p>{$t('paymentText')}</p>
  </section>

  <section class="block" id="returns">
    <h2>{$t('returnSection')}</h2>
    <p>{$t('returnText')}</p>
  </section>
</main>

<Tabbar />

<style>
  .info-page {
    max-width: 800px;
    margin: 0 auto;
    padding: var(--s-4) var(--gutter) var(--s-6);
  }
  h1 {
    font-size: 28px; font-weight: 700; margin: 0 0 var(--s-4);
  }
  .block {
    margin-bottom: var(--s-5);
    padding-bottom: var(--s-4);
    border-bottom: 1px solid var(--line);
  }
  .block:last-child { border-bottom: 0; }
  .block h2 {
    font-size: 18px; font-weight: 700; margin: 0 0 var(--s-2);
  }
  .block p {
    color: var(--ink-soft); line-height: 1.6; margin: 0 0 var(--s-3); font-size: 15px;
  }
  .cards {
    display: grid; grid-template-columns: 1fr 1fr; gap: var(--s-3);
  }
  @media (max-width: 500px) { .cards { grid-template-columns: 1fr; } }
  .card {
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: var(--r); padding: var(--s-3);
  }
  .card strong { display: block; margin-bottom: 6px; font-size: 15px; }
  .card p { margin: 0; font-size: 13px; }
</style>
