<script lang="ts">
  import { page } from '$app/stores';
  import Header from '$lib/components/Header.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { t } from '$lib/i18n';
</script>

<svelte:head>
  <title>{$page.status} — GRAFLAB</title>
</svelte:head>

<Header />

<main class="error-page">
  <div class="error-code num">{$page.status}</div>
  <h1>
    {#if $page.status === 404}
      {$t('pageNotFound')}
    {:else}
      {$t('somethingWrong')}
    {/if}
  </h1>
  <p>
    {#if $page.status === 404}
      {$t('error404Hint')}
    {:else}
      {$t('error500Hint')}
    {/if}
  </p>
  <a href="/" class="btn">{$t('backToCatalogLink')}</a>
</main>

<Tabbar />

<style>
  .error-page {
    max-width: 500px; margin: 0 auto;
    padding: var(--s-7) var(--gutter);
    text-align: center;
  }
  .error-code {
    font-size: 80px; font-weight: 900; color: var(--line-strong);
    line-height: 1; margin-bottom: var(--s-2);
  }
  h1 { font-size: 24px; font-weight: 700; margin: 0 0 var(--s-2); }
  p { color: var(--ink-soft); font-size: 15px; margin: 0 0 var(--s-4); line-height: 1.5; }
  .btn {
    display: inline-block; padding: 14px 28px;
    background: var(--brand); color: #fff; border-radius: 99px;
    font-weight: 700; font-size: 14px;
  }
  .btn:hover { background: var(--brand-hover); }
</style>
