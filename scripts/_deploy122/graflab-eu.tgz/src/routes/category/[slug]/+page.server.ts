import { db, schema } from '$server/db';
import { and, eq, desc, count } from 'drizzle-orm';
import { error } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';

export const load: PageServerLoad = async ({ params }) => {
  // Текущая категория
  const catRows = await db
    .select()
    .from(schema.euCategories)
    .where(eq(schema.euCategories.slug, params.slug))
    .limit(1);

  if (catRows.length === 0) throw error(404, 'Категория не найдена');
  const category = catRows[0];

  // Товары этой категории
  const products = await db
    .select({
      id: schema.euProducts.id,
      article: schema.euProducts.article,
      slug: schema.euProducts.slug,
      name: schema.euProducts.name,
      nameSr: schema.euProducts.nameSr,
      priceRub: schema.euProducts.priceRub,
      priceOldRub: schema.euProducts.priceOldRub,
      imageUrl: schema.euProducts.imageUrl,
      rating: schema.euProducts.rating,
      reviewsCount: schema.euProducts.reviewsCount,
      inStock: schema.euProducts.inStock
    })
    .from(schema.euProducts)
    .where(
      and(
        eq(schema.euProducts.categoryId, category.id),
        eq(schema.euProducts.active, true)
      )
    )
    .orderBy(desc(schema.euProducts.reviewsCount));

  // Все категории для навигации
  const allCats = await db
    .select({
      id: schema.euCategories.id,
      slug: schema.euCategories.slug,
      name: schema.euCategories.name,
      nameSr: schema.euCategories.nameSr,
      sortOrder: schema.euCategories.sortOrder,
      count: count(schema.euProducts.id)
    })
    .from(schema.euCategories)
    .leftJoin(
      schema.euProducts,
      and(
        eq(schema.euProducts.categoryId, schema.euCategories.id),
        eq(schema.euProducts.active, true)
      )
    )
    .groupBy(
      schema.euCategories.id,
      schema.euCategories.slug,
      schema.euCategories.name,
      schema.euCategories.nameSr,
      schema.euCategories.sortOrder
    )
    .orderBy(schema.euCategories.sortOrder);

  return {
    category,
    products,
    categories: allCats.filter(c => c.count > 0)
  };
};
