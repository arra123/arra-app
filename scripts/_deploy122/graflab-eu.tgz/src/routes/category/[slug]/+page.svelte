<script lang="ts">
  import Header from '$lib/components/Header.svelte';
  import Pcard from '$lib/components/Pcard.svelte';
  import Tabbar from '$lib/components/Tabbar.svelte';
  import { t, locale } from '$lib/i18n';
  import type { PageData } from './$types';

  export let data: PageData;

  const CAT_EMOJI: Record<string, string> = {
    longevity: '🧬', vitamins: '💊', minerals: '⚡', immunity: '🛡️',
    brain: '🧠', antioxidants: '🍇', cardiovascular: '❤️', beauty: '✨',
    vision: '👁️', weight: '🏋️', womens: '🌸',
  };

  let sort: 'popular' | 'price-asc' | 'price-desc' | 'discount' | 'rating' | 'name' = 'popular';
  let inStockOnly = true;
  let priceMin = '';
  let priceMax = '';
  let onlyWithDiscount = false;
  let onlyWithRating = false;

  $: sorted = (() => {
    let list = inStockOnly ? data.products.filter(p => p.inStock) : data.products;
    // Пользователь вводит цену в евро — сравниваем в центах
    const min = parseFloat(priceMin.replace(/\s/g, '').replace(',', '.'));
    const max = parseFloat(priceMax.replace(/\s/g, '').replace(',', '.'));
    if (!isNaN(min)) list = list.filter(p => p.priceRub >= min * 100);
    if (!isNaN(max)) list = list.filter(p => p.priceRub <= max * 100);
    if (onlyWithDiscount) list = list.filter(p => p.priceOldRub && p.priceOldRub > p.priceRub);
    if (onlyWithRating) list = list.filter(p => p.rating && p.rating > 0 && p.reviewsCount > 0);
    if (sort === 'price-asc') list = [...list].sort((a, b) => a.priceRub - b.priceRub);
    else if (sort === 'price-desc') list = [...list].sort((a, b) => b.priceRub - a.priceRub);
    else if (sort === 'rating') list = [...list].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
    else if (sort === 'discount') list = [...list].sort((a, b) => {
      const dA = a.priceOldRub ? (a.priceOldRub - a.priceRub) / a.priceOldRub : 0;
      const dB = b.priceOldRub ? (b.priceOldRub - b.priceRub) / b.priceOldRub : 0;
      return dB - dA;
    });
    else if (sort === 'name') list = [...list].sort((a, b) => a.name.localeCompare(b.name, 'ru'));
    return list;
  })();
</script>

<svelte:head>
  <title>{$locale === 'sr' && data.category.nameSr ? data.category.nameSr : data.category.name} — GRAFLAB</title>
  <meta name="description" content="{$locale === 'sr' && data.category.nameSr ? data.category.nameSr : data.category.name} — GRAFLAB. {data.products.length} products." />
</svelte:head>

<Header />

<main class="page">
  <!-- Навигация по категориям -->
  <nav class="cat-nav" aria-label={$t('categories')}>
    <a href="/" class="cat-nav__item">
      <span class="cat-nav__emoji">🏠</span>
      <span>{$t('toHome')}</span>
    </a>
    {#each data.categories as cat (cat.id)}
      <a
        href="/category/{cat.slug}"
        class="cat-nav__item"
        class:is-active={cat.slug === data.category.slug}
      >
        <img class="cat-nav__icon" src="/icons/cat-{cat.slug}.png" alt="" loading="lazy"
          on:error={(e) => { e.currentTarget.style.display='none'; e.currentTarget.nextElementSibling.style.display='inline'; }} />
        <span class="cat-nav__emoji" style="display:none">{CAT_EMOJI[cat.slug] ?? '💊'}</span>
        <span>{$locale === 'sr' && cat.nameSr ? cat.nameSr : cat.name}</span>
      </a>
    {/each}
  </nav>

  <!-- Заголовок категории -->
  <div class="cat-header">
    <div class="cat-header__left">
      <a href="/" class="cat-header__back" aria-label={$t('toHome')}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
      </a>
      <h1>{$locale === 'sr' && data.category.nameSr ? data.category.nameSr : data.category.name}</h1>
      <span class="cat-header__count num">{data.products.length}</span>
    </div>
    <!-- Сортировка для мобиле (sidebar скрыт) -->
    <label class="sort-mobile">
      <select bind:value={sort}>
        <option value="popular">{$t('sortPopular')}</option>
        <option value="price-asc">{$t('sortCheapest')}</option>
        <option value="price-desc">{$t('sortExpensive')}</option>
        <option value="discount">{$t('sortDiscount')}</option>
        <option value="rating">{$t('sortRating')}</option>
      </select>
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round"><path d="m6 9 6 6 6-6" /></svg>
    </label>
  </div>

  <!-- Layout: sidebar + grid -->
  <div class="layout">
    <aside class="sidebar">
      <div class="filter-group">
        <h3>{$t('sorting')}</h3>
        <div class="price-inputs">
          <input type="text" bind:value={priceMin} placeholder="min" inputmode="numeric" />
          <span>—</span>
          <input type="text" bind:value={priceMax} placeholder="max" inputmode="numeric" />
        </div>
      </div>

      <div class="filter-group">
        <h3>{$t('sorting')}</h3>
        <label class="checkbox">
          <input type="checkbox" bind:checked={inStockOnly} />
          <span>{$t('inStock')}</span>
        </label>
        <label class="checkbox">
          <input type="checkbox" bind:checked={onlyWithDiscount} />
          <span>{$t('sortDiscount')}</span>
        </label>
        <label class="checkbox">
          <input type="checkbox" bind:checked={onlyWithRating} />
          <span>{$t('sortReviews')}</span>
        </label>
      </div>

      <div class="filter-group">
        <h3>{$t('sorting')}</h3>
        <select class="sort-select" bind:value={sort}>
          <option value="popular">{$t('sortPopular')}</option>
          <option value="price-asc">{$t('sortCheapest')}</option>
          <option value="price-desc">{$t('sortExpensive')}</option>
          <option value="discount">{$t('sortDiscount')}</option>
          <option value="rating">{$t('sortRating')}</option>
          <option value="name">{$t('sortName')}</option>
        </select>
      </div>
    </aside>

    <section class="catalog-area">
      {#if sorted.length === 0}
        <div class="empty">{$t('nothingFound')}</div>
      {:else}
        <div class="grid">
          {#each sorted as p (p.id)}
            <Pcard
              id={p.id} name={p.name} nameSr={p.nameSr} imageUrl={p.imageUrl}
              priceRub={p.priceRub} priceOldRub={p.priceOldRub}
              rating={p.rating} reviewsCount={p.reviewsCount} inStock={p.inStock}
            />
          {/each}
        </div>
      {/if}
    </section>
  </div>
</main>

<Tabbar />

<style>
  .page {
    max-width: var(--maxw);
    margin: 0 auto;
    padding: 0 var(--gutter) var(--s-6);
  }

  /* ═══ Навигация категорий ═══ */
  .cat-nav {
    display: flex; gap: 4px; overflow-x: auto;
    scrollbar-width: none; padding: var(--s-3) 0;
  }
  .cat-nav::-webkit-scrollbar { display: none; }
  .cat-nav__item {
    flex: 0 0 auto; display: inline-flex; align-items: center; gap: 6px;
    padding: 6px 14px; border-radius: 99px;
    font-size: 13px; font-weight: 600; color: var(--ink-soft);
    white-space: nowrap; transition: all 150ms ease;
    border: 1px solid transparent;
  }
  .cat-nav__item:hover { background: var(--paper-deep); color: var(--ink); }
  .cat-nav__item.is-active {
    background: var(--brand); color: #fff; border-color: var(--brand);
  }
  .cat-nav__icon { width: 20px; height: 20px; object-fit: contain; }
  .cat-nav__item.is-active .cat-nav__icon { filter: brightness(10); }
  .cat-nav__emoji { font-size: 16px; line-height: 1; }

  @media (max-width: 599px) {
    .cat-nav__item { padding: 5px 10px; font-size: 12px; }
    .cat-nav__icon { width: 16px; height: 16px; }
  }

  /* ═══ Заголовок ═══ */
  .cat-header {
    display: flex; align-items: center; justify-content: space-between;
    gap: var(--s-2); margin-bottom: var(--s-3); flex-wrap: wrap;
  }
  .cat-header__left {
    display: flex; align-items: center; gap: var(--s-2);
  }
  .cat-header__back {
    width: 36px; height: 36px; border-radius: 99px;
    border: 1px solid var(--line); background: var(--paper-card);
    display: inline-flex; align-items: center; justify-content: center;
  }
  .cat-header__back svg { width: 18px; height: 18px; }
  .cat-header__back:hover { background: var(--paper-deep); }
  .cat-header h1 { font-size: 22px; font-weight: 700; margin: 0; }
  .cat-header__count { color: var(--ink-soft); font-size: 15px; }

  .sort-mobile {
    display: inline-flex; align-items: center; gap: 4px;
    font-size: 13px; color: var(--ink); position: relative;
  }
  @media (min-width: 900px) { .sort-mobile { display: none; } }
  .sort-mobile select {
    appearance: none; background: transparent; border: 0;
    font: inherit; color: var(--ink); padding-right: 16px; cursor: pointer;
  }
  .sort-mobile svg {
    width: 12px; height: 12px; stroke: var(--ink);
    position: absolute; right: 0; pointer-events: none;
  }

  @media (max-width: 599px) {
    .cat-header h1 { font-size: 18px; }
    .cat-header__back { width: 32px; height: 32px; }
    .cat-header__back svg { width: 16px; height: 16px; }
  }

  /* ═══ Layout: sidebar + catalog ═══ */
  .layout {
    display: grid; grid-template-columns: 1fr; gap: var(--s-3);
  }
  @media (min-width: 900px) {
    .layout { grid-template-columns: 220px 1fr; gap: var(--s-4); }
  }

  /* ═══ Sidebar ═══ */
  .sidebar {
    display: none; /* скрыт на мобиле */
  }
  @media (min-width: 900px) {
    .sidebar {
      display: flex; flex-direction: column; gap: var(--s-3);
      position: sticky; top: 80px; align-self: start;
    }
  }
  .filter-group h3 {
    font-size: 12px; font-weight: 700; color: var(--ink);
    text-transform: uppercase; letter-spacing: 0.08em;
    margin: 0 0 8px;
  }
  .price-inputs {
    display: flex; align-items: center; gap: 6px;
  }
  .price-inputs input {
    width: 100%; border: 1px solid var(--line-strong); border-radius: 8px;
    padding: 8px 10px; font-size: 13px; background: var(--paper-card);
    color: var(--ink);
  }
  .price-inputs input:focus { outline: 0; border-color: var(--accent); }
  .price-inputs span { color: var(--ink-faint); font-size: 12px; }

  .checkbox {
    display: flex; align-items: center; gap: 8px;
    font-size: 13px; color: var(--ink); cursor: pointer;
    padding: 4px 0;
  }
  .checkbox input[type="checkbox"] {
    width: 16px; height: 16px; accent-color: var(--brand);
  }

  .sort-select {
    width: 100%; border: 1px solid var(--line-strong); border-radius: 8px;
    padding: 8px 10px; font-size: 13px; background: var(--paper-card);
    color: var(--ink); appearance: auto;
  }

  /* ═══ Грид ═══ */
  .grid {
    display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: var(--s-2);
  }
  @media (min-width: 600px) { .grid { grid-template-columns: repeat(3, minmax(0, 1fr)); gap: var(--s-3); } }
  @media (min-width: 1100px) { .grid { grid-template-columns: repeat(3, minmax(0, 1fr)); } }

  .empty {
    text-align: center; padding: var(--s-6) var(--s-3);
    color: var(--ink-soft); font-size: 14px;
    background: var(--paper-card); border: 1px dashed var(--line-strong); border-radius: var(--r);
  }
</style>
