<script lang="ts">
  import { t } from '$lib/i18n';
  export let value = '';
  export let activeFilters = 0;
</script>

<div class="searchbar">
  <div class="searchbar__inner">
    <label class="search">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-3.5-3.5" />
      </svg>
      <input
        type="search"
        bind:value
        placeholder={$t('searchPlaceholder')}
        autocomplete="off"
      />
    </label>

    <button class="filter-btn" type="button">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
        <path d="M4 6h16M7 12h10M10 18h4" />
      </svg>
      {$t('filters')}
      {#if activeFilters > 0}
        <span class="num">·{activeFilters}</span>
      {/if}
    </button>
  </div>
</div>

<style>
  .searchbar {
    position: sticky;
    top: 65px;
    z-index: 39;
    background: var(--paper);
    border-bottom: 1px solid var(--line);
    padding: var(--s-2) var(--gutter);
  }
  .searchbar__inner {
    max-width: var(--maxw);
    margin: 0 auto;
    display: flex;
    gap: var(--s-2);
  }

  .search {
    flex: 1;
    display: flex;
    align-items: center;
    gap: var(--s-2);
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: 99px;
    padding: 0 var(--s-4);
    height: 50px;
    box-shadow: var(--shadow-sm);
  }
  .search:focus-within {
    border-color: var(--accent);
    box-shadow: var(--shadow-md);
  }
  .search svg {
    width: 16px;
    height: 16px;
    stroke: var(--ink-soft);
    flex: 0 0 auto;
  }
  .search input {
    flex: 1;
    border: 0;
    outline: 0;
    background: transparent;
    font-size: 15px;
    color: var(--ink);
    min-width: 0;
  }
  .search input::placeholder {
    color: var(--ink-faint);
  }
  .search kbd {
    display: none;
    font-family: var(--sans);
    font-size: 11px;
    color: var(--ink-soft);
    border: 1px solid var(--line);
    padding: 2px 6px;
    border-radius: var(--r);
    background: var(--paper);
  }
  @media (min-width: 900px) {
    .search kbd {
      display: inline-block;
    }
  }

  .filter-btn {
    height: 50px;
    padding: 0 var(--s-3);
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: 99px;
    box-shadow: var(--shadow-sm);
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    font-weight: 600;
    color: var(--ink);
  }
  .filter-btn svg {
    width: 14px;
    height: 14px;
    stroke: var(--ink);
  }
  @media (min-width: 900px) {
    .filter-btn {
      display: none;
    }
  }
</style>
