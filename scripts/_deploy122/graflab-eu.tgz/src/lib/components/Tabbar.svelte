<script lang="ts">
  import { page } from '$app/stores';
  import { cart } from '$lib/stores/cart';
  import { t } from '$lib/i18n';

  $: cartCount = cart.totalCount($cart);
  $: path = $page.url.pathname;
</script>

<nav class="tabbar" aria-label="Main navigation">
  <a href="/" class:is-active={path === '/'}>
    <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
      <path d="M4 7h16M4 12h16M4 17h10" />
    </svg>
    {$t('tabCatalog')}
  </a>
  <a href="/search" class:is-active={path.startsWith('/search')}>
    <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" />
    </svg>
    {$t('tabSearch')}
  </a>
  <a href="/cart" class:is-active={path.startsWith('/cart')}>
    <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
      <path d="M5 7h14l-1.5 11a2 2 0 0 1-2 1.7h-7a2 2 0 0 1-2-1.7L5 7Z" />
      <path d="M9 7V5a3 3 0 0 1 6 0v2" />
    </svg>
    {$t('tabCart')}
    {#if cartCount > 0}
      <span class="badge num">{cartCount}</span>
    {/if}
  </a>
  <a href="/account" class:is-active={path.startsWith('/account')}>
    <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21c0-4 4-7 8-7s8 3 8 7" />
    </svg>
    {$t('tabProfile')}
  </a>
</nav>

<style>
  .tabbar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 50;
    background: var(--paper-card);
    border-top: 1px solid var(--line);
    box-shadow: 0 -8px 24px rgba(20, 40, 25, 0.06);
    display: flex;
    height: var(--tabbar-h);
    padding-bottom: env(safe-area-inset-bottom);
  }
  .tabbar a {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 4px;
    font-size: 10px;
    color: var(--ink-soft);
    position: relative;
  }
  .tabbar a svg {
    width: 20px;
    height: 20px;
    stroke: var(--ink-soft);
    fill: none;
  }
  .tabbar a.is-active {
    color: var(--ink);
  }
  .tabbar a.is-active svg {
    stroke: var(--ink);
  }
  .tabbar a .badge {
    position: absolute;
    top: 8px;
    right: 50%;
    transform: translateX(14px);
    background: var(--accent);
    color: #fff;
    font-size: 10px;
    font-weight: 700;
    min-width: 16px;
    height: 16px;
    border-radius: 8px;
    padding: 0 4px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 1.5px solid var(--paper-card);
  }
  @media (min-width: 900px) {
    .tabbar {
      display: none;
    }
  }
</style>
