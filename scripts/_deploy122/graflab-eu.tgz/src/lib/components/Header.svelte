<script lang="ts">
  import { cart } from '$lib/stores/cart';
  import { favorites } from '$lib/stores/favorites';
  import { t, locale } from '$lib/i18n';

  $: cartCount = cart.totalCount($cart);
  $: favCount = favorites.count($favorites);

  let menuOpen = false;
</script>

<header class="topbar">
  <div class="topbar__inner">
    <button class="hamburger" type="button" aria-label={$t('menu')} on:click={() => (menuOpen = true)}>
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
        <line x1="3" y1="7" x2="21" y2="7" />
        <line x1="3" y1="12" x2="21" y2="12" />
        <line x1="3" y1="17" x2="14" y2="17" />
      </svg>
    </button>

    <a class="brand" href="/">
      <img src="/brand/logo-mark.png" alt="" class="brand__mark" />
      <span class="brand__word">GRAFLAB</span>
    </a>

    <span class="topbar__city">
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
        <path d="M12 22s7-7.5 7-13a7 7 0 1 0-14 0c0 5.5 7 13 7 13Z" />
        <circle cx="12" cy="9" r="2.5" />
      </svg>
      {$t('location')}
    </span>

    <div class="lang-switch">
      <button class:active={$locale === 'en'} on:click={() => $locale = 'en'}>EN</button>
      <button class:active={$locale === 'sr'} on:click={() => $locale = 'sr'}>SR</button>
    </div>

    <nav class="topbar__nav">
      <a href="/">{$t('catalog')}</a>
      <a href="/delivery">{$t('delivery')}</a>
      <a href="/lab">{$t('laboratory')}</a>
      <a href="/contacts">{$t('contacts')}</a>
    </nav>

    <div class="topbar__spacer"></div>

    <a class="topbar__icon-btn" href="/favorites" aria-label={$t('favorites')}>
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
        <path d="M12 21s-7-4.5-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.5-9 9-9 9Z" />
      </svg>
      {#if favCount > 0}
        <span class="badge badge--fav num">{favCount}</span>
      {/if}
    </a>
    <a class="topbar__icon-btn hide-mobile" href="/account" aria-label={$t('profile')}>
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21c0-4 4-7 8-7s8 3 8 7" />
      </svg>
    </a>
    <a class="topbar__icon-btn" href="/cart" aria-label={$t('cart')}>
      <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
        <path d="M5 7h14l-1.5 11a2 2 0 0 1-2 1.7h-7a2 2 0 0 1-2-1.7L5 7Z" />
        <path d="M9 7V5a3 3 0 0 1 6 0v2" />
      </svg>
      {#if cartCount > 0}
        <span class="badge num">{cartCount}</span>
      {/if}
    </a>
  </div>
</header>

<!-- Мобильное меню-drawer -->
{#if menuOpen}
  <div class="drawer-overlay" on:click={() => (menuOpen = false)} on:keydown={() => {}}></div>
  <nav class="drawer">
    <div class="drawer__head">
      <a href="/" class="brand" on:click={() => (menuOpen = false)}>
        <img src="/brand/logo-mark.png" alt="" class="brand__mark" />
        <span class="brand__word">GRAFLAB</span>
      </a>
      <button class="drawer__close" type="button" on:click={() => (menuOpen = false)} aria-label={$t('close')}>
        <svg viewBox="0 0 24 24" fill="none" stroke-width="1.5" stroke-linecap="round">
          <path d="M18 6 6 18M6 6l12 12" />
        </svg>
      </button>
    </div>
    <div class="drawer__links">
      <a href="/" on:click={() => (menuOpen = false)}>{$t('catalog')}</a>
      <a href="/search" on:click={() => (menuOpen = false)}>{$t('search')}</a>
      <a href="/favorites" on:click={() => (menuOpen = false)}>{$t('favorites')} {#if favCount > 0}<span class="num">{favCount}</span>{/if}</a>
      <a href="/cart" on:click={() => (menuOpen = false)}>{$t('cart')} {#if cartCount > 0}<span class="num">{cartCount}</span>{/if}</a>
      <a href="/account" on:click={() => (menuOpen = false)}>{$t('myOrders')}</a>
    </div>
    <div class="drawer__sep"></div>
    <div class="drawer__links drawer__links--secondary">
      <a href="/delivery" on:click={() => (menuOpen = false)}>{$t('deliveryAndPayment')}</a>
      <a href="/lab" on:click={() => (menuOpen = false)}>{$t('laboratory')}</a>
      <a href="/about" on:click={() => (menuOpen = false)}>{$t('aboutBrand')}</a>
      <a href="/contacts" on:click={() => (menuOpen = false)}>{$t('contacts')}</a>
    </div>
  </nav>
{/if}

<style>
  .topbar {
    background: var(--paper);
    border-bottom: 1px solid var(--line);
    position: sticky;
    top: 0;
    z-index: 40;
  }
  .topbar__inner {
    display: flex;
    align-items: center;
    gap: var(--s-2);
    padding: var(--s-3) var(--gutter);
    max-width: var(--maxw);
    margin: 0 auto;
  }

  .hamburger {
    width: 36px; height: 36px;
    background: transparent; border: 0; padding: 6px;
    display: inline-flex; align-items: center; justify-content: center;
  }
  .hamburger svg { width: 22px; height: 22px; stroke: var(--ink); }
  @media (min-width: 900px) { .hamburger { display: none; } }

  .brand {
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  .brand__mark {
    width: 28px; height: 28px; object-fit: contain;
  }
  .brand__word {
    font-family: var(--brand-font);
    font-size: 20px;
    letter-spacing: 0.08em;
    color: var(--ink);
    text-transform: uppercase;
  }

  .topbar__city {
    font-size: 12px; color: var(--ink-soft);
    display: none; align-items: center; gap: 6px;
    border-left: 1px solid var(--line); padding-left: var(--s-3);
  }
  .topbar__city svg { width: 12px; height: 12px; stroke: var(--ink-soft); }
  @media (min-width: 600px) { .topbar__city { display: inline-flex; } }

  .lang-switch { display: flex; gap: 4px; }
  .lang-switch button { background: none; border: 1px solid var(--c-border, #ddd); border-radius: 6px; padding: 2px 8px; font-size: 12px; cursor: pointer; color: var(--c-text-soft, var(--ink-soft)); }
  .lang-switch button.active { background: var(--c-primary, #4a9159); color: #fff; border-color: var(--c-primary, #4a9159); }

  .topbar__nav {
    display: none; gap: var(--s-4); margin-left: var(--s-4); font-size: 14px;
  }
  .topbar__nav a { color: var(--ink-soft); }
  .topbar__nav a:hover { color: var(--ink); }
  @media (min-width: 900px) { .topbar__nav { display: flex; } }

  .topbar__spacer { flex: 1; }

  .topbar__icon-btn {
    width: 40px; height: 40px;
    background: var(--paper-card); border: 1px solid var(--line);
    border-radius: 99px; box-shadow: var(--shadow-sm);
    display: inline-flex; align-items: center; justify-content: center;
    position: relative;
  }
  .topbar__icon-btn svg { width: 18px; height: 18px; stroke: var(--ink); }
  .badge {
    position: absolute; top: -4px; right: -4px;
    background: var(--accent); color: #fff;
    font-size: 10px; font-weight: 700;
    min-width: 18px; height: 18px; border-radius: 99px;
    padding: 0 5px;
    display: inline-flex; align-items: center; justify-content: center;
    border: 2px solid var(--paper);
  }
  .badge--fav { background: #e44; }

  .hide-mobile { display: none; }
  @media (min-width: 600px) { .hide-mobile { display: inline-flex; } }

  /* ── Drawer ── */
  .drawer-overlay {
    position: fixed; inset: 0; z-index: 90;
    background: rgba(0,0,0,0.4);
    backdrop-filter: blur(2px);
  }
  .drawer {
    position: fixed; top: 0; left: 0; bottom: 0;
    width: 300px; max-width: 85vw;
    background: var(--paper); z-index: 91;
    padding: var(--s-3) var(--s-3) var(--s-5);
    overflow-y: auto;
    box-shadow: 8px 0 30px rgba(0,0,0,0.15);
    animation: slideIn 200ms ease;
  }
  @keyframes slideIn { from { transform: translateX(-100%); } to { transform: translateX(0); } }

  .drawer__head {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: var(--s-4); padding-bottom: var(--s-3);
    border-bottom: 1px solid var(--line);
  }
  .drawer__close {
    width: 36px; height: 36px;
    background: transparent; border: 0; padding: 6px;
  }
  .drawer__close svg { width: 22px; height: 22px; stroke: var(--ink); }

  .drawer__links {
    display: flex; flex-direction: column; gap: 4px;
  }
  .drawer__links a {
    display: flex; align-items: center; justify-content: space-between;
    padding: 12px 14px; border-radius: 10px;
    font-size: 16px; font-weight: 600; color: var(--ink);
  }
  .drawer__links a:hover { background: var(--paper-deep); }
  .drawer__links a .num {
    background: var(--accent-soft); color: var(--accent);
    font-size: 12px; font-weight: 700;
    padding: 2px 8px; border-radius: 99px;
  }
  .drawer__links--secondary a {
    font-weight: 500; color: var(--ink-soft); font-size: 15px;
  }
  .drawer__sep {
    height: 1px; background: var(--line);
    margin: var(--s-3) 0;
  }
</style>
