<script lang="ts">
  import { t, locale } from '$lib/i18n';
  export let categories: { slug: string; name: string; nameSr?: string | null; count: number }[] = [];
  export let selectedCategories: Set<string> = new Set();
  export let priceMin: string = '';
  export let priceMax: string = '';
  export let inStockOnly = true;

  function toggleCategory(slug: string) {
    if (selectedCategories.has(slug)) selectedCategories.delete(slug);
    else selectedCategories.add(slug);
    selectedCategories = new Set(selectedCategories);
  }
</script>

<aside class="sidebar" aria-label={$t('filters')}>
  <section class="filtergrp">
    <h3 class="filtergrp__h">{$t('categories')}</h3>
    <ul>
      {#each categories as c (c.slug)}
        <li>
          <label>
            <input
              type="checkbox"
              checked={selectedCategories.has(c.slug)}
              on:change={() => toggleCategory(c.slug)}
            />
            {$locale === 'sr' && c.nameSr ? c.nameSr : c.name}
          </label>
          <span class="num">{c.count}</span>
        </li>
      {/each}
    </ul>
  </section>

  <section class="filtergrp">
    <h3 class="filtergrp__h">{$t('price')}</h3>
    <div class="pricerange">
      <input type="text" bind:value={priceMin} placeholder={$t('priceFrom')} class="num" />
      <input type="text" bind:value={priceMax} placeholder={$t('priceTo')} class="num" />
    </div>
  </section>

  <section class="filtergrp">
    <h3 class="filtergrp__h">{$t('availability')}</h3>
    <ul>
      <li>
        <label>
          <input type="checkbox" bind:checked={inStockOnly} />
          {$t('inStockOnly')}
        </label>
      </li>
    </ul>
  </section>
</aside>

<style>
  .sidebar {
    display: none;
  }
  @media (min-width: 900px) {
    .sidebar {
      display: block;
    }
  }
  .filtergrp {
    padding: var(--s-3) 0;
    border-bottom: 1px solid var(--line);
  }
  .filtergrp:first-child {
    padding-top: 0;
  }
  .filtergrp__h {
    font-size: 11px;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: var(--ink-soft);
    margin: 0 0 var(--s-2);
    font-weight: 600;
  }
  .filtergrp ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  .filtergrp li {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 6px 0;
    font-size: 14px;
    color: var(--ink);
  }
  .filtergrp li .num {
    color: var(--ink-faint);
    font-size: 12px;
  }
  .filtergrp label {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
  }
  .filtergrp input[type='checkbox'] {
    appearance: none;
    -webkit-appearance: none;
    width: 16px;
    height: 16px;
    border: 1.5px solid var(--line-strong);
    border-radius: 5px;
    background: var(--paper-card);
    flex: 0 0 auto;
    position: relative;
  }
  .filtergrp input[type='checkbox']:checked {
    background: var(--accent);
    border-color: var(--accent);
  }
  .filtergrp input[type='checkbox']:checked::after {
    content: '';
    position: absolute;
    left: 4px;
    top: 1px;
    width: 4px;
    height: 8px;
    border: solid #fff;
    border-width: 0 2px 2px 0;
    transform: rotate(45deg);
  }
  .pricerange {
    display: flex;
    gap: 8px;
    margin-top: var(--s-2);
  }
  .pricerange input {
    width: 100%;
    border: 1px solid var(--line-strong);
    background: var(--paper-card);
    border-radius: 10px;
    padding: 10px 12px;
    font-size: 13px;
    color: var(--ink);
  }
</style>
