<script lang="ts">
  import { t } from '$lib/i18n';
</script>

<footer class="footer">
  <div class="foot">
    <div class="foot__brand">
      <a href="/" class="foot__logo">
        <img src="/brand/logo-mark.png" alt="" class="foot__mark" />
        <span>GRAFLAB</span>
      </a>
      <p>{$t('footerDesc')}</p>

      <div class="foot__contacts">
        <a href="tel:+78000000000" class="foot__contact-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
            <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 10.8a19.79 19.79 0 01-3.07-8.68A2 2 0 012.18 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006.18 6.18l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/>
          </svg>
          +7 (800) 000-00-00
        </a>
        <a href="mailto:support@graflab.ru" class="foot__contact-item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
            <rect x="2" y="4" width="20" height="16" rx="2"/>
            <path d="M2 7l10 7 10-7"/>
          </svg>
          support@graflab.ru
        </a>
      </div>

      <div class="foot__social">
        <a href="https://t.me/graflabofficial" class="foot__social-btn" target="_blank" rel="noopener noreferrer" aria-label="Telegram">
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M11.944 0A12 12 0 1 0 24 12 12 12 0 0 0 11.944 0zm5.94 8.197l-2.01 9.484c-.15.66-.54.82-1.09.51l-3-2.21-1.45 1.4c-.16.16-.3.3-.62.3l.22-3.12 5.68-5.13c.25-.22-.05-.34-.38-.12L6.16 14.8l-2.97-.93c-.64-.2-.66-.64.14-.95l11.6-4.47c.54-.19 1.01.13.97.76z"/>
          </svg>
        </a>
        <a href="https://vk.com/graflab" class="foot__social-btn" target="_blank" rel="noopener noreferrer" aria-label="ВКонтакте">
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M15.684 0H8.316C1.592 0 0 1.592 0 8.316v7.368C0 22.408 1.592 24 8.316 24h7.368C22.408 24 24 22.408 24 15.684V8.316C24 1.592 22.391 0 15.684 0zm3.692 17.123h-1.744c-.66 0-.862-.523-2.049-1.711-1.033-1.01-1.49-.9-1.49.186v1.549c0 .371-.119.594-1.086.594-1.602 0-3.38-.97-4.629-2.777C6.89 12.77 6.28 10.37 6.28 9.744c0-.389.118-.748.527-.748h1.744c.39 0 .54.178.693.595.762 2.204 2.038 4.135 2.565 4.135.196 0 .287-.09.287-.585V10.84c-.065-1.053-.62-1.144-.62-1.52 0-.19.157-.38.406-.38h2.742c.329 0 .45.174.45.55v2.962c0 .329.143.44.233.44.196 0 .362-.111.72-.47 1.115-1.25 1.908-3.175 1.908-3.175.105-.224.293-.432.683-.432h1.744c.524 0 .638.27.524.648-.218.978-2.31 3.962-2.31 3.962-.183.3-.25.432 0 .765.183.249.782.76 1.18 1.218.73.834 1.289 1.534 1.44 2.017.138.467-.107.705-.574.705z"/>
          </svg>
        </a>
      </div>
    </div>
    <div>
      <h4>{$t('footerCatalog')}</h4>
      <ul>
        <li><a href="/?cat=longevity">{$t('footerLongevity')}</a></li>
        <li><a href="/?cat=vitamins">{$t('footerVitamins')}</a></li>
        <li><a href="/?cat=minerals">{$t('footerMinerals')}</a></li>
        <li><a href="/?cat=immunity">{$t('footerImmunity')}</a></li>
        <li><a href="/?cat=brain">{$t('footerBrainFocus')}</a></li>
      </ul>
    </div>
    <div>
      <h4>{$t('footerForCustomers')}</h4>
      <ul>
        <li><a href="/delivery">{$t('footerDelivery')}</a></li>
        <li><a href="/delivery#payment">{$t('footerPayment')}</a></li>
        <li><a href="/delivery#returns">{$t('footerReturns')}</a></li>
        <li><a href="/lab">{$t('footerCertificates')}</a></li>
      </ul>
    </div>
    <div>
      <h4>{$t('footerCompany')}</h4>
      <ul>
        <li><a href="/about">{$t('footerAbout')}</a></li>
        <li><a href="/lab">{$t('footerLab')}</a></li>
        <li><a href="/contacts">{$t('footerContacts')}</a></li>
      </ul>
    </div>
  </div>
  <div class="foot__legal">
    <span>{$t('footerCopyright')}</span>
    <span>{$t('footerDisclaimer')}</span>
  </div>
</footer>

<style>
  .footer {
    border-top: 1px solid var(--line);
    padding: var(--s-5) var(--gutter) var(--s-4);
    background: var(--paper-deep);
    margin-top: var(--s-6);
  }
  .foot {
    max-width: var(--maxw);
    margin: 0 auto;
    display: grid;
    gap: var(--s-4);
    grid-template-columns: 1fr;
  }
  @media (min-width: 760px) {
    .foot { grid-template-columns: 2fr 1fr 1fr 1fr; }
  }
  .foot__brand { }
  .foot__logo {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 800;
    font-size: 20px;
    letter-spacing: 0.04em;
    color: var(--ink);
    margin-bottom: var(--s-2);
  }
  .foot__mark {
    width: 24px; height: 24px; object-fit: contain;
  }
  .foot__brand p {
    font-size: 13px; color: var(--ink-soft); max-width: 320px;
    line-height: 1.55; margin: 0;
  }
  .foot h4 {
    font-size: 11px; letter-spacing: 0.18em; text-transform: uppercase;
    color: var(--ink-soft); margin: 0 0 var(--s-2); font-weight: 600;
  }
  .foot ul { list-style: none; padding: 0; margin: 0; }
  .foot li { margin-bottom: 8px; }
  .foot li a { font-size: 14px; color: var(--ink); }
  .foot li a:hover { color: var(--accent); }
  .foot__legal {
    max-width: var(--maxw); margin: var(--s-4) auto 0;
    padding-top: var(--s-3); border-top: 1px solid var(--line);
    display: flex; flex-wrap: wrap; gap: var(--s-3);
    font-size: 11px; color: var(--ink-faint); letter-spacing: 0.04em;
  }

  .foot__contacts {
    margin-top: var(--s-3);
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .foot__contact-item {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: var(--ink-soft);
  }
  .foot__contact-item svg {
    width: 14px;
    height: 14px;
    flex-shrink: 0;
    color: var(--accent);
  }
  .foot__contact-item:hover {
    color: var(--ink);
  }

  .foot__social {
    display: flex;
    gap: 8px;
    margin-top: var(--s-3);
  }
  .foot__social-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    border-radius: 10px;
    background: var(--paper);
    border: 1px solid var(--line);
    color: var(--ink-soft);
    transition: background 0.15s, color 0.15s, border-color 0.15s;
  }
  .foot__social-btn svg {
    width: 17px;
    height: 17px;
  }
  .foot__social-btn:hover {
    background: var(--brand);
    color: #fff;
    border-color: var(--brand);
  }
</style>
