<script lang="ts">
  import { cart } from '$lib/stores/cart';
  import { favorites } from '$lib/stores/favorites';
  import { formatPrice, discountPercent, formatRating, reviewsLabel } from '$lib/utils/format';
  import { t, locale } from '$lib/i18n';

  export let id: number;
  export let name: string;
  export let nameSr: string | null = null;
  export let imageUrl: string;
  export let priceRub: number;
  export let priceOldRub: number | null = null;
  export let rating: number | null = null;
  export let reviewsCount = 0;
  export let inStock = true;

  $: displayName = $locale === 'sr' && nameSr ? nameSr : name;
  $: discount = discountPercent(priceRub, priceOldRub);
  $: ratingStr = formatRating(rating);
  $: isFav = $favorites.has(id);
  $: qty = cart.qtyOf($cart, id);
</script>

<article class="pcard">
  <a href="/product/{id}" class="pcard__media" aria-label={displayName}>
    <img src={imageUrl} alt={displayName} loading="lazy" />
    <button
      class="pcard__fav"
      class:is-fav={isFav}
      type="button"
      on:click|preventDefault|stopPropagation={() => favorites.toggle(id)}
      aria-label={isFav ? $t('removeFromFavorites') : $t('addToFavorites')}
    >
      <svg viewBox="0 0 24 24" stroke-width="1.5" stroke-linecap="round">
        <path d="M12 21s-7-4.5-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.5-9 9-9 9Z" />
      </svg>
    </button>
  </a>

  <div class="pcard__price-row">
    <span class="pcard__price num">{formatPrice(priceRub)}</span>
    {#if priceOldRub && priceOldRub > priceRub}
      <span class="pcard__price-old num">{formatPrice(priceOldRub)}</span>
    {/if}
    {#if discount}
      <span class="pcard__discount num">{discount}</span>
    {/if}
  </div>

  <h3 class="pcard__name">{displayName}</h3>

  <div class="pcard__meta">
    {#if inStock}
      <span class="ok">{$t('inStock')}</span>
    {:else}
      <span class="out">{$t('outOfStock')}</span>
    {/if}

    {#if ratingStr && reviewsCount > 0}
      <span class="dot"></span>
      <span class="rating">
        <svg viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
          <path
            d="M8 1.2l1.95 4.27 4.65.42-3.5 3.1 1.04 4.55L8 11.18l-4.14 2.36 1.04-4.55-3.5-3.1 4.65-.42L8 1.2z"
          />
        </svg>
        {ratingStr}
        <span class="reviews num">· {reviewsLabel(reviewsCount)}</span>
      </span>
    {/if}
  </div>

  {#if qty === 0}
    <button class="pcard__add" type="button" on:click={() => cart.add(id)}>
      <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round">
        <path d="M12 5v14M5 12h14" />
      </svg>
      {$t('addToCart')}
    </button>
  {:else}
    <div class="pcard__counter">
      <button type="button" on:click={() => cart.remove(id)} aria-label={$t('removeOne')}>−</button>
      <span class="num">{qty} {$t('pcs')}</span>
      <button type="button" on:click={() => cart.add(id)} aria-label={$t('addAnother')}>+</button>
    </div>
  {/if}
</article>

<style>
  .pcard {
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: 12px;
    padding: 6px;
    display: flex;
    flex-direction: column;
    position: relative;
    box-shadow: var(--shadow-sm);
    transition: box-shadow 220ms ease, transform 220ms ease;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
  }
  @media (min-width: 600px) {
    .pcard { padding: 10px; border-radius: var(--r-card); }
  }
  .pcard:hover {
    box-shadow: var(--shadow-lg);
    transform: translateY(-2px);
  }

  /* Фото: aspect-ratio на IMG, не на контейнере. Контейнер просто
     overflow hidden + border-radius. Img блочный, width 100%,
     aspect-ratio 3/4 — высота одинаковая для всех карточек в ряду
     (зависит только от ширины колонки). Никаких padding-bottom трюков. */
  .pcard__media {
    overflow: hidden;
    border-radius: 8px;
    margin-bottom: 8px;
    position: relative;
    background: #ffffff;
    display: block;
  }
  @media (min-width: 600px) {
    .pcard__media { border-radius: 12px; margin-bottom: 14px; }
  }
  .pcard__media img {
    width: 100%;
    max-width: 100%;
    aspect-ratio: 3 / 4;
    object-fit: contain;
    display: block;
  }

  .pcard__fav {
    position: absolute;
    top: 8px;
    right: 8px;
    width: 30px;
    height: 30px;
    background: rgba(255, 255, 255, 0.9);
    border: 0;
    border-radius: 99px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    box-shadow: var(--shadow-sm);
    z-index: 2;
  }
  .pcard__fav svg {
    width: 14px;
    height: 14px;
    stroke: var(--ink-soft);
    fill: none;
  }
  .pcard__fav:hover svg {
    stroke: var(--accent);
  }
  .pcard__fav.is-fav svg {
    stroke: #e44;
    fill: #e44;
  }

  .pcard__price-row {
    display: flex;
    align-items: baseline;
    gap: 8px;
    margin-bottom: 4px;
    flex-wrap: wrap;
  }
  .pcard__price {
    font-size: 15px;
    font-weight: 700;
    color: var(--price);
    letter-spacing: -0.015em;
  }
  @media (min-width: 600px) { .pcard__price { font-size: 19px; } }
  .pcard__price-old {
    font-size: 10px;
    color: var(--price-old);
    text-decoration: line-through;
  }
  @media (min-width: 600px) { .pcard__price-old { font-size: 12px; } }
  .pcard__discount {
    margin-left: auto;
    background: var(--accent-soft);
    color: var(--accent);
    font-size: 11px;
    font-weight: 600;
    padding: 3px 8px;
    border-radius: 99px;
    letter-spacing: 0.01em;
    align-self: center;
  }

  .pcard__name {
    font-size: 11px;
    line-height: 1.25;
    font-weight: 500;
    color: var(--ink);
    margin: 0 0 3px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    min-height: 2.5em;
  }
  @media (min-width: 600px) { .pcard__name { font-size: 13px; line-height: 1.3; margin: 0 0 4px; } }

  .pcard__meta {
    font-size: 10px;
    color: var(--ink-soft);
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 6px;
    flex-wrap: wrap;
    min-height: 16px;
  }
  @media (min-width: 600px) { .pcard__meta { font-size: 12px; gap: 10px; margin-bottom: 10px; min-height: 20px; } }
  .pcard__meta .ok {
    color: var(--ok);
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-weight: 500;
  }
  .pcard__meta .ok::before {
    content: '';
    width: 6px;
    height: 6px;
    background: var(--ok);
    border-radius: 99px;
  }
  .pcard__meta .out {
    color: var(--ink-faint);
    font-weight: 500;
  }
  .pcard__meta .dot {
    width: 3px;
    height: 3px;
    background: var(--ink-faint);
    border-radius: 99px;
  }
  .pcard__meta .rating {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    color: var(--ink);
    font-weight: 500;
  }
  .pcard__meta .rating svg {
    width: 12px;
    height: 12px;
    color: var(--accent);
  }
  .pcard__meta .reviews {
    color: var(--ink-faint);
    font-weight: 400;
  }

  .pcard__add {
    margin-top: auto;
    background: var(--brand);
    color: #fff;
    border: 0;
    border-radius: 99px;
    padding: 8px 10px;
    font-size: 11px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
  }
  @media (min-width: 600px) { .pcard__add { padding: 12px 14px; font-size: 13px; gap: 6px; } }
  .pcard__add svg {
    width: 12px;
    height: 12px;
    stroke: #fff;
  }
  .pcard__add:hover {
    background: var(--brand-hover);
  }

  .pcard__counter {
    margin-top: auto;
    display: flex;
    align-items: stretch;
    border: 0;
    background: var(--brand);
    border-radius: 99px;
    overflow: hidden;
    height: 34px;
  }
  @media (min-width: 600px) { .pcard__counter { height: 42px; } }
  .pcard__counter button {
    width: 32px;
    background: transparent;
    border: 0;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
  }
  @media (min-width: 600px) { .pcard__counter button { width: 38px; font-size: 18px; } }
  .pcard__counter button:hover {
    background: rgba(255, 255, 255, 0.12);
  }
  .pcard__counter span {
    flex: 1;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 13px;
    font-weight: 700;
  }
</style>
