<script lang="ts">
  import { t, locale } from '$lib/i18n';
  export let categories: { slug: string; name: string; nameSr?: string | null; count: number }[] = [];
  export let active: string = 'all';
  export let totalCount = 0;

  // Перед обычными категориями всегда два «виртуальных» чипа: Все и Хиты+Скидки
  // (хиты/скидки реализуем фильтром на фазе 3.5, пока показываем как заглушки).
</script>

<nav class="catstrip" aria-label={$t('categories')}>
  <div class="catstrip__row">
    <button
      class="chip"
      class:is-active={active === 'all'}
      on:click={() => (active = 'all')}
    >
      {$t('all')} <span class="num">{totalCount}</span>
    </button>
    {#each categories as cat (cat.slug)}
      <button
        class="chip"
        class:is-active={active === cat.slug}
        on:click={() => (active = cat.slug)}
      >
        {$locale === 'sr' && cat.nameSr ? cat.nameSr : cat.name} <span class="num">{cat.count}</span>
      </button>
    {/each}
  </div>
</nav>

<style>
  .catstrip {
    background: var(--paper);
    border-bottom: 1px solid var(--line);
  }
  .catstrip__row {
    max-width: var(--maxw);
    margin: 0 auto;
    display: flex;
    gap: 6px;
    padding: var(--s-2) var(--gutter);
    overflow-x: auto;
    scrollbar-width: none;
  }
  .catstrip__row::-webkit-scrollbar {
    display: none;
  }

  .chip {
    flex: 0 0 auto;
    padding: 10px 18px;
    background: var(--paper-card);
    border: 1px solid var(--line);
    border-radius: 99px;
    font-size: 13px;
    font-weight: 600;
    color: var(--ink);
    display: inline-flex;
    align-items: center;
    gap: 6px;
    white-space: nowrap;
    box-shadow: var(--shadow-sm);
  }
  .chip .num {
    color: var(--ink-soft);
    font-size: 11px;
    font-weight: 500;
  }
  .chip.is-active {
    background: var(--ink);
    color: #fff;
    border-color: var(--ink);
    box-shadow: var(--shadow-md);
  }
  .chip.is-active .num {
    color: #fff;
    opacity: 0.6;
  }
</style>
