import { writable, derived } from 'svelte/store';
import { browser } from '$app/environment';
import en from './en';
import sr from './sr';
import ru from './ru';

export type Locale = 'en' | 'sr' | 'ru';
export type TranslationKey = keyof typeof en;

const translations = { en, sr, ru } as const;

const STORAGE_KEY = 'graflab-eu.lang';

function loadLocale(): Locale {
  if (!browser) return 'en';
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved === 'en' || saved === 'sr' || saved === 'ru') return saved;
  // Auto-detect from browser. RU не авто-детектим: публичный сайт EN/SR,
  // русский — только ручной выбор в админке.
  const lang = navigator.language.toLowerCase();
  if (lang.startsWith('sr') || lang.startsWith('hr') || lang.startsWith('bs')) return 'sr';
  return 'en';
}

export const locale = writable<Locale>(loadLocale());

if (browser) {
  locale.subscribe((v) => localStorage.setItem(STORAGE_KEY, v));
}

export const t = derived(locale, ($locale) => {
  const dict = translations[$locale];
  return (key: TranslationKey, params?: Record<string, string | number>): string => {
    let s = (dict[key] as string) ?? key;
    if (params) {
      for (const [k, v] of Object.entries(params)) {
        s = s.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      }
    }
    return s;
  };
});

/** For use outside reactive context (e.g., server-side or one-off calls) */
export function getTranslations(loc: Locale = 'en') {
  return translations[loc];
}
