/**
 * S3-клиент для twcstorage.ru / бакет sprav / папка graflab/.
 *
 * Используется для загрузки фото товаров из админки.
 * Файлы ложатся в: sprav/graflab/products/{article}.webp
 * Публичный URL: https://s3.twcstorage.ru/sprav/graflab/products/{article}.webp
 */
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';

function getClient() {
  return new S3Client({
    region: process.env.S3_REGION || 'ru-1',
    endpoint: process.env.S3_ENDPOINT || 'https://s3.twcstorage.ru',
    forcePathStyle: true,
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY || '',
      secretAccessKey: process.env.S3_SECRET_KEY || ''
    }
  });
}

export async function uploadProductImage(
  article: string,
  data: Buffer | Uint8Array,
  contentType: string
): Promise<string> {
  const ext = contentType.includes('webp')
    ? 'webp'
    : contentType.includes('png')
      ? 'png'
      : 'jpg';
  const key = `${process.env.S3_PREFIX || 'graflab/'}products/${article}.${ext}`;
  const bucket = process.env.S3_BUCKET || 'sprav';

  const client = getClient();
  await client.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: data,
      ContentType: contentType,
      ACL: 'public-read'
    })
  );

  const endpoint = (process.env.S3_ENDPOINT || 'https://s3.twcstorage.ru').replace(/\/$/, '');
  return `${endpoint}/${bucket}/${key}`;
}
