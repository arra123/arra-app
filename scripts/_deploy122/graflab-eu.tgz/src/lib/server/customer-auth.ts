/**
 * Customer auth via SMS code.
 * SMS not yet integrated — code is logged to server console.
 */
import { db, schema } from '$server/db';
import { eq, and, gt } from 'drizzle-orm';
import crypto from 'node:crypto';
import { sendLoginCode } from './notify';

function generateCode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function generateSessionId(): string {
  return crypto.randomBytes(32).toString('hex');
}

function generateReferralCode(): string {
  return 'EU' + crypto.randomBytes(4).toString('hex').toUpperCase();
}

/** Send SMS code. Реальный провайдер подключается в $lib/server/notify.ts */
export async function sendCode(phone: string): Promise<void> {
  const code = generateCode();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

  await db.insert(schema.euSmsCodes).values({ phone, code, expiresAt });
  await sendLoginCode(phone, code);
}

/** Verify code and create session */
export async function verifyCode(
  phone: string,
  code: string
): Promise<{ sessionId: string; customerId: number } | null> {
  const rows = await db
    .select()
    .from(schema.euSmsCodes)
    .where(
      and(
        eq(schema.euSmsCodes.phone, phone),
        eq(schema.euSmsCodes.code, code),
        eq(schema.euSmsCodes.used, false),
        gt(schema.euSmsCodes.expiresAt, new Date())
      )
    )
    .limit(1);

  if (rows.length === 0) return null;

  await db
    .update(schema.euSmsCodes)
    .set({ used: true })
    .where(eq(schema.euSmsCodes.id, rows[0].id));

  let customer = await db
    .select()
    .from(schema.euCustomers)
    .where(eq(schema.euCustomers.phone, phone))
    .limit(1)
    .then((r) => r[0]);

  if (!customer) {
    const refCode = generateReferralCode();
    const inserted = await db
      .insert(schema.euCustomers)
      .values({ phone, referralCode: refCode })
      .returning();
    customer = inserted[0];
  }

  const sessionId = generateSessionId();
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

  await db
    .insert(schema.euCustomerSessions)
    .values({ id: sessionId, customerId: customer.id, expiresAt });

  return { sessionId, customerId: customer.id };
}

/** Get customer by session */
export async function getCustomerBySession(sessionId: string) {
  const rows = await db
    .select({
      id: schema.euCustomers.id,
      phone: schema.euCustomers.phone,
      name: schema.euCustomers.name,
      email: schema.euCustomers.email,
      referralCode: schema.euCustomers.referralCode,
      referredBy: schema.euCustomers.referredBy,
      bonusBalance: schema.euCustomers.bonusBalance,
    })
    .from(schema.euCustomerSessions)
    .innerJoin(
      schema.euCustomers,
      eq(schema.euCustomerSessions.customerId, schema.euCustomers.id)
    )
    .where(
      and(
        eq(schema.euCustomerSessions.id, sessionId),
        gt(schema.euCustomerSessions.expiresAt, new Date())
      )
    )
    .limit(1);

  return rows[0] ?? null;
}

/** Logout */
export async function logout(sessionId: string): Promise<void> {
  await db
    .delete(schema.euCustomerSessions)
    .where(eq(schema.euCustomerSessions.id, sessionId));
}

/** Apply referral code — €4 for referrer, €2 for new customer */
export async function applyReferral(
  customerId: number,
  referralCode: string
): Promise<boolean> {
  const referrer = await db
    .select()
    .from(schema.euCustomers)
    .where(eq(schema.euCustomers.referralCode, referralCode))
    .limit(1)
    .then((r) => r[0]);

  if (!referrer || referrer.id === customerId) return false;

  const customer = await db
    .select()
    .from(schema.euCustomers)
    .where(eq(schema.euCustomers.id, customerId))
    .limit(1)
    .then((r) => r[0]);

  if (!customer || customer.referredBy) return false;

  await db.update(schema.euCustomers)
    .set({ referredBy: referrer.id, bonusBalance: (customer.bonusBalance ?? 0) + 200 })
    .where(eq(schema.euCustomers.id, customerId));

  await db.update(schema.euCustomers)
    .set({ bonusBalance: (referrer.bonusBalance ?? 0) + 400 })
    .where(eq(schema.euCustomers.id, referrer.id));

  return true;
}
