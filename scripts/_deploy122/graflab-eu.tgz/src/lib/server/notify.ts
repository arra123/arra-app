/**
 * Уведомления (SMS / Telegram / email) — сейчас заглушка в консоль.
 *
 * Чтобы подключить реальный провайдер — реализуй sendSms() через API
 * (Twilio, Vonage, SMSC, etc.). Остальной код через эти хелперы.
 */

type SmsPayload = { phone: string; message: string };

async function sendSms({ phone, message }: SmsPayload): Promise<void> {
  // TODO: заменить на вызов реального провайдера
  console.log(`[SMS→${phone}] ${message}`);
}

export async function sendLoginCode(phone: string, code: string): Promise<void> {
  await sendSms({ phone, message: `GRAFLAB: код входа ${code}. Не сообщайте никому.` });
}

export function notifyOrderCreated(opts: {
  phone: string;
  orderNumber: string;
  totalRub: number;
}): void {
  const euros = (opts.totalRub / 100).toFixed(2);
  // fire-and-forget — не блокируем ответ на /api/orders
  void sendSms({
    phone: opts.phone,
    message: `GRAFLAB: заказ ${opts.orderNumber} принят на сумму €${euros}. Мы свяжемся для подтверждения.`
  });
}
