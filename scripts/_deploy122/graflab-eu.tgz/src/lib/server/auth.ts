/**
 * Минимальная auth для админки. Без Lucia (deprecated).
 *
 * Схема:
 * - eu_admin_users (id, login, password_hash)
 * - eu_admin_sessions (id, user_id, expires_at)
 *
 * Пароль хешируем через Node crypto.scrypt (встроен, без зависимостей).
 * Сессия — random hex 40 символов, в cookie `admin_session`, httpOnly.
 */
import { db, schema } from '$server/db';
import { eq } from 'drizzle-orm';
import { randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';

const scryptAsync = promisify(scrypt);

const SESSION_COOKIE = 'admin_session';
const SESSION_DAYS = 30;

// ── Хеширование ────────────────────────────────────────────────

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString('hex');
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return salt + ':' + derived.toString('hex');
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const [salt, key] = hash.split(':');
  if (!salt || !key) return false;
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  const keyBuf = Buffer.from(key, 'hex');
  if (derived.length !== keyBuf.length) return false;
  return timingSafeEqual(derived, keyBuf);
}

// ── Сессии ─────────────────────────────────────────────────────

export async function createSession(userId: string): Promise<string> {
  const id = randomBytes(20).toString('hex');
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400_000);
  await db.insert(schema.euAdminSessions).values({ id, userId, expiresAt });
  return id;
}

export async function validateSession(sessionId: string | undefined) {
  if (!sessionId) return null;
  const rows = await db
    .select({
      userId: schema.euAdminSessions.userId,
      expiresAt: schema.euAdminSessions.expiresAt,
      login: schema.euAdminUsers.login
    })
    .from(schema.euAdminSessions)
    .innerJoin(schema.euAdminUsers, eq(schema.euAdminSessions.userId, schema.euAdminUsers.id))
    .where(eq(schema.euAdminSessions.id, sessionId))
    .limit(1);

  if (rows.length === 0) return null;
  const s = rows[0];
  if (new Date(s.expiresAt) < new Date()) {
    await db.delete(schema.euAdminSessions).where(eq(schema.euAdminSessions.id, sessionId));
    return null;
  }
  return { userId: s.userId, login: s.login };
}

export async function deleteSession(sessionId: string) {
  await db.delete(schema.euAdminSessions).where(eq(schema.euAdminSessions.id, sessionId));
}

export function getSessionCookie(cookies: { get: (name: string) => string | undefined }) {
  return cookies.get(SESSION_COOKIE);
}

export function setSessionCookie(
  cookies: { set: (name: string, value: string, opts: Record<string, unknown>) => void },
  sessionId: string
) {
  cookies.set(SESSION_COOKIE, sessionId, {
    path: '/admin',
    httpOnly: true,
    sameSite: 'lax',
    secure: false, // localhost dev; на проде nginx делает https → поменять
    maxAge: SESSION_DAYS * 86400
  });
}

export function clearSessionCookie(
  cookies: { set: (name: string, value: string, opts: Record<string, unknown>) => void }
) {
  cookies.set(SESSION_COOKIE, '', { path: '/admin', httpOnly: true, maxAge: 0 });
}

// ── Bootstrap админа ───────────────────────────────────────────

export async function ensureAdminExists() {
  const existing = await db
    .select({ id: schema.euAdminUsers.id })
    .from(schema.euAdminUsers)
    .limit(1);
  if (existing.length > 0) return;

  const id = randomBytes(12).toString('hex');
  const hash = await hashPassword('admin123');
  await db.insert(schema.euAdminUsers).values({
    id,
    login: 'tima',
    passwordHash: hash
  });
  console.log('[auth] bootstrap admin created: login=tima, password=admin123 — ПОМЕНЯЙ!');
}
