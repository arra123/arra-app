/**
 * Подключение к bd2 — общая PostgreSQL Тимы (5.42.100.180), префикс
 * наших таблиц `g_*`. Чужие префиксы (`b_*`, `l_*`, `_d`, `_s`) НЕ трогать.
 *
 * ВАЖНО: ленивая инициализация. process.env заполняется либо через PM2
 * на проде, либо через dotenv в dev (Vite сам не пробрасывает).
 */
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import 'dotenv/config';
import * as schema from './schema';

let _db: ReturnType<typeof drizzle> | null = null;

function getDb() {
  if (_db) return _db;

  const url = process.env.DATABASE_URL;
  if (!url) {
    throw new Error('DATABASE_URL не задан в .env');
  }

  const client = postgres(url, {
    max: 10,
    idle_timeout: 30,
    connect_timeout: 10,
    prepare: false
  });

  _db = drizzle(client, { schema });
  return _db;
}

// Proxy-объект: при обращении к любому методу вызывается getDb()
export const db = new Proxy({} as ReturnType<typeof drizzle>, {
  get(_target, prop) {
    return (getDb() as any)[prop];
  }
});

export { schema };
