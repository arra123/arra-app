/**
 * Схема БД GRAFLAB EU · префикс eu_*
 *
 * Общая БД bd2 на сервере 5.42.100.180 — её делят несколько проектов
 * Тимы (Sklad, Sotrudniki, KnowledgeBase, GRAFLAB RU). У каждого свой префикс,
 * мы — `eu_`. Чужие таблицы НЕ трогать.
 */
import { pgTable, serial, varchar, text, integer, boolean, timestamp, pgEnum } from 'drizzle-orm/pg-core';

// ── Категории товаров ──────────────────────────────────────────
export const euCategories = pgTable('eu_categories', {
  id: serial('id').primaryKey(),
  slug: varchar('slug', { length: 64 }).notNull().unique(),
  name: varchar('name', { length: 128 }).notNull(),
  nameSr: varchar('name_sr', { length: 128 }),
  sortOrder: integer('sort_order').notNull().default(0)
});

// ── Товары ─────────────────────────────────────────────────────
export const euProducts = pgTable('eu_products', {
  id: serial('id').primaryKey(),
  article: varchar('article', { length: 32 }).notNull().unique(),
  slug: varchar('slug', { length: 128 }).notNull().unique(),
  name: varchar('name', { length: 256 }).notNull(),
  nameSr: varchar('name_sr', { length: 256 }),
  description: text('description'),
  categoryId: integer('category_id').references(() => euCategories.id),
  priceRub: integer('price_rub').notNull(),
  priceOldRub: integer('price_old_rub'),
  imageUrl: text('image_url').notNull(),
  imageUrlPreview: text('image_url_preview'),
  rating: integer('rating'),
  reviewsCount: integer('reviews_count').notNull().default(0),
  inStock: boolean('in_stock').notNull().default(true),
  active: boolean('active').notNull().default(true),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow()
});

// ── Покупатели ─────────────────────────────────────────────────
export const euCustomers = pgTable('eu_customers', {
  id: serial('id').primaryKey(),
  phone: varchar('phone', { length: 32 }).notNull().unique(),
  name: varchar('name', { length: 128 }),
  email: varchar('email', { length: 256 }),
  referralCode: varchar('referral_code', { length: 16 }).unique(),
  referredBy: integer('referred_by').references((): any => euCustomers.id),
  bonusBalance: integer('bonus_balance').notNull().default(0),
  createdAt: timestamp('created_at').notNull().defaultNow()
});

// ── Сессии покупателей (авторизация по SMS) ───────────────────
export const euCustomerSessions = pgTable('eu_customer_sessions', {
  id: varchar('id', { length: 64 }).primaryKey(),
  customerId: integer('customer_id').notNull().references(() => euCustomers.id, { onDelete: 'cascade' }),
  expiresAt: timestamp('expires_at', { withTimezone: true, mode: 'date' }).notNull()
});

// ── SMS-коды для входа ────────────────────────────────────────
export const euSmsCodes = pgTable('eu_sms_codes', {
  id: serial('id').primaryKey(),
  phone: varchar('phone', { length: 32 }).notNull(),
  code: varchar('code', { length: 6 }).notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true, mode: 'date' }).notNull(),
  used: boolean('used').notNull().default(false),
  createdAt: timestamp('created_at').notNull().defaultNow()
});

// ── Заказы ─────────────────────────────────────────────────────
export const orderStatusEnum = pgEnum('eu_order_status', [
  'new',
  'paid',
  'packed',
  'shipped',
  'delivered',
  'cancelled'
]);

export const euOrders = pgTable('eu_orders', {
  id: serial('id').primaryKey(),
  number: varchar('number', { length: 32 }).notNull().unique(),
  customerId: integer('customer_id').references(() => euCustomers.id),
  status: orderStatusEnum('status').notNull().default('new'),
  totalRub: integer('total_rub').notNull(),
  deliveryAddress: text('delivery_address'),
  deliveryMethod: varchar('delivery_method', { length: 32 }),
  paymentMethod: varchar('payment_method', { length: 32 }),
  comment: text('comment'),
  createdAt: timestamp('created_at').notNull().defaultNow()
});

export const euOrderItems = pgTable('eu_order_items', {
  id: serial('id').primaryKey(),
  orderId: integer('order_id').notNull().references(() => euOrders.id, { onDelete: 'cascade' }),
  productId: integer('product_id').notNull().references(() => euProducts.id),
  quantity: integer('quantity').notNull(),
  priceRub: integer('price_rub').notNull()
});

// ── Админы ─────────────────────────────────────────────────────
export const euAdminUsers = pgTable('eu_admin_users', {
  id: varchar('id', { length: 32 }).primaryKey(),
  login: varchar('login', { length: 64 }).notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow()
});

export const euAdminSessions = pgTable('eu_admin_sessions', {
  id: varchar('id', { length: 64 }).primaryKey(),
  userId: varchar('user_id', { length: 32 }).notNull().references(() => euAdminUsers.id, { onDelete: 'cascade' }),
  expiresAt: timestamp('expires_at', { withTimezone: true, mode: 'date' }).notNull()
});
