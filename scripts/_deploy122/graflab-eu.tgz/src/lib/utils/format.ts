/** Format price in EUR: 1860 (cents) → «€18.60» */
export function formatPrice(cents: number | null | undefined): string {
  if (cents == null) return '';
  const euros = cents / 100;
  return '€' + euros.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** Format price without currency prefix: 1860 → «18.60» (for inputs). */
export function centsToEuros(cents: number | null | undefined): string {
  if (cents == null) return '';
  return (cents / 100).toFixed(2);
}

/** Parse user-entered euro amount ("18.60", "18,60", "18") to cents (1860). */
export function eurosToCents(input: string | null | undefined): number {
  if (!input) return 0;
  const normalized = input.replace(/\s/g, '').replace(',', '.');
  const n = parseFloat(normalized);
  if (isNaN(n) || n < 0) return 0;
  return Math.round(n * 100);
}

/** Discount percent from old price. «−65%». null if not worth showing. */
export function discountPercent(price: number, priceOld: number | null | undefined): string | null {
  if (!priceOld || priceOld <= price) return null;
  const pct = Math.round(((priceOld - price) / priceOld) * 100);
  if (pct < 5) return null;
  return '−' + pct + '%';
}

/** Rating stored in tenths: 50 → «5.0», 47 → «4.7». */
export function formatRating(tenths: number | null | undefined): string | null {
  if (tenths == null) return null;
  return (tenths / 10).toFixed(1);
}

/** Pluralization for EN: 1 review / 2+ reviews. */
export function plural(n: number, forms: [string, string, string]): string {
  return n === 1 ? forms[0] : forms[1];
}

export function reviewsLabel(count: number, forms: [string, string, string] = ['review', 'reviews', 'reviews']): string {
  return count + ' ' + plural(count, forms);
}
