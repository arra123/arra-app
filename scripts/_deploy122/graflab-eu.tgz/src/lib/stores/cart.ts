/**
 * Корзина. Хранится в localStorage, синхронизируется через writable.
 * На сервере (SSR) корзина пустая, гидрируется на клиенте после mount.
 *
 * Структура: Map<productId, { qty }>. Цены не храним — пересчёт идёт
 * по актуальным данным товаров на странице корзины (если цена изменилась
 * между сессиями, пользователь увидит актуальную).
 */
import { writable } from 'svelte/store';
import { browser } from '$app/environment';

export type CartLine = { productId: number; qty: number };
export type CartState = { lines: CartLine[] };

const KEY = 'graflab-eu.cart.v1';

function load(): CartState {
  if (!browser) return { lines: [] };
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { lines: [] };
    const parsed = JSON.parse(raw) as CartState;
    if (!parsed || !Array.isArray(parsed.lines)) return { lines: [] };
    return parsed;
  } catch {
    return { lines: [] };
  }
}

function save(state: CartState) {
  if (!browser) return;
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* quota / private mode — игнорируем */
  }
}

const _cart = writable<CartState>(load());

if (browser) {
  _cart.subscribe(save);
}

export const cart = {
  subscribe: _cart.subscribe,

  add(productId: number) {
    _cart.update((s) => {
      const line = s.lines.find((l) => l.productId === productId);
      if (line) line.qty += 1;
      else s.lines.push({ productId, qty: 1 });
      return { lines: [...s.lines] };
    });
  },

  remove(productId: number) {
    _cart.update((s) => {
      const line = s.lines.find((l) => l.productId === productId);
      if (!line) return s;
      line.qty -= 1;
      if (line.qty <= 0) {
        return { lines: s.lines.filter((l) => l.productId !== productId) };
      }
      return { lines: [...s.lines] };
    });
  },

  clear() {
    _cart.set({ lines: [] });
  },

  removeLine(productId: number) {
    _cart.update((s) => ({ lines: s.lines.filter((l) => l.productId !== productId) }));
  },

  /** Сколько штук конкретного товара в корзине (или 0). */
  qtyOf(state: CartState, productId: number): number {
    return state.lines.find((l) => l.productId === productId)?.qty ?? 0;
  },

  /** Сумма всех позиций в штуках (для badge). */
  totalCount(state: CartState): number {
    return state.lines.reduce((sum, l) => sum + l.qty, 0);
  }
};
