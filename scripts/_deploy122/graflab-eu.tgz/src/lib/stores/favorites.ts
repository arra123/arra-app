/**
 * Избранное. localStorage, аналогично корзине.
 */
import { writable } from 'svelte/store';
import { browser } from '$app/environment';

const KEY = 'graflab-eu.favs.v1';

function load(): Set<number> {
  if (!browser) return new Set();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

function save(ids: Set<number>) {
  if (!browser) return;
  try {
    localStorage.setItem(KEY, JSON.stringify([...ids]));
  } catch {}
}

const _favs = writable<Set<number>>(load());
if (browser) _favs.subscribe(save);

export const favorites = {
  subscribe: _favs.subscribe,
  toggle(id: number) {
    _favs.update((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  },
  has(state: Set<number>, id: number): boolean {
    return state.has(id);
  },
  count(state: Set<number>): number {
    return state.size;
  }
};
