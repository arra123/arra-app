// Service worker — живёт в фоне, не зависит от popup.
// Popup шлёт сообщение → background открывает вкладку, ждёт загрузки,
// заполняет форму. Popup может закрыться — background продолжит.

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "openAndFill") {
    handleOpenAndFill(msg);
  }
  return true;
});

async function handleOpenAndFill({ url, login, pass, clearSession, loginUrl }) {
  const tab = await chrome.tabs.create({ url });

  if (clearSession && loginUrl) {
    // Другой пользователь: открыть сайт → очистить токены → редирект на /login → заполнить
    await waitForTab(tab.id);
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: clearTokens,
      args: [loginUrl]
    }).catch(() => {});

    // Ждём загрузки страницы логина после редиректа
    await waitForTab(tab.id);
    await injectFill(tab.id, login, pass);
  } else {
    // Свой аккаунт или простой заход — ждём загрузки и заполняем
    await waitForTab(tab.id);
    await injectFill(tab.id, login, pass);
  }
}

function waitForTab(tabId) {
  return new Promise(resolve => {
    chrome.tabs.onUpdated.addListener(function fn(tid, info) {
      if (tid === tabId && info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(fn);
        resolve();
      }
    });
  });
}

async function injectFill(tabId, login, pass) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: fillAndSubmit,
      args: [login, pass]
    });
  } catch (e) {
    console.warn("inject failed:", e);
  }
}

// === Функции, выполняемые В КОНТЕКСТЕ СТРАНИЦЫ ===

function clearTokens(loginUrl) {
  for (let i = localStorage.length - 1; i >= 0; i--) {
    const k = localStorage.key(i);
    if (k && /token|auth|session/i.test(k)) localStorage.removeItem(k);
  }
  window.location.href = loginUrl;
}

function fillAndSubmit(login, pass) {
  let n = 0;
  function go() {
    const inputs = document.querySelectorAll("input");
    let lf = null, pf = null;

    for (const inp of inputs) {
      const t = (inp.type || "").toLowerCase();
      const s = ((inp.name || "") + (inp.id || "") + (inp.placeholder || "")).toLowerCase();

      if (t === "password" || s.includes("pass") || s.includes("парол")) {
        pf = inp;
      } else if (["text", "email", ""].includes(t) &&
        (s.includes("login") || s.includes("email") || s.includes("user") ||
         s.includes("логин") || s.includes("почта") || s.includes("имя") ||
         s.includes("фамил"))) {
        lf = inp;
      }
    }

    // Fallback: первый text = логин, первый password = пароль
    if (!lf) lf = document.querySelector('input[type="text"], input[type="email"], input:not([type])');
    if (!pf) pf = document.querySelector('input[type="password"]');

    if (lf && pf) {
      sv(lf, login);
      sv(pf, pass);
      setTimeout(() => {
        const btn = document.querySelector(
          'button[type="submit"], input[type="submit"], ' +
          'form button:not([type="button"]):not([class*="close"]):not([class*="cancel"])'
        );
        if (btn) btn.click();
      }, 400);
    } else if (++n < 40) {
      setTimeout(go, 300);
    }
  }

  function sv(el, v) {
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), "value")?.set;
    if (setter) setter.call(el, v);
    else el.value = v;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  go();
}
