const CONFIG_URL = "http://5.42.116.235/graflab-hub/config.json";

const ICONS = {
  sklad: '<svg viewBox="0 0 24 24" fill="none"><rect x="4" y="12" width="3" height="8" rx="1" fill="#fff"/><rect x="10" y="8" width="3" height="12" rx="1" fill="#fff"/><rect x="16" y="4" width="3" height="16" rx="1" fill="#fff"/></svg>',
  hr: '<svg viewBox="0 0 24 24" fill="#fff"><circle cx="12" cy="8" r="3.5"/><path d="M5.5 21c0-3.6 2.9-6.5 6.5-6.5s6.5 2.9 6.5 6.5"/></svg>',
  wiki: '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M21 3c0 9-5 15-13 15-3 0-5-1-5-1s2-9 8-13c4-2.6 10-1 10-1z"/><path d="M3 21c1-5 4-10 9-13"/></svg>',
  msg: '<svg viewBox="0 0 24 24" fill="#fff"><path d="M12 3C6.5 3 2 6.6 2 11c0 2.5 1.4 4.7 3.6 6.2L4.5 21l4.2-2.1c1 .3 2.1.4 3.3.4 5.5 0 10-3.6 10-8s-4.5-8.3-10-8.3z"/></svg>',
  custom: '<svg viewBox="0 0 24 24" fill="none" stroke="#888" stroke-width="1.5" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/></svg>',
};

const FALLBACK_SITES = [
  { name: "GRAсклад",    desc: "Управление складом",  url: "http://147.45.97.155/sklad",        cls: "sklad", loginPath: "/login" },
  { name: "Сотрудники",  desc: "HR-портал",           url: "http://147.45.97.155/sotrudniki",    cls: "hr",    loginPath: "/login" },
  { name: "База знаний", desc: "Wiki GRAFLAB",        url: "http://147.45.97.155/knowledgeBase", cls: "wiki",  loginPath: "/login" },
  { name: "Мессенджер",  desc: "Корпоративный чат",   url: "https://bem-community.ru/messenger", cls: "msg",   loginPath: "/login" },
];

let SITES = [...FALLBACK_SITES];
let selectedIdx = 0, defaultIdx = 0;
let customSites = [];

// === STORAGE (with fallback if chrome.storage unavailable) ===
async function loadPrefs() {
  if (!chrome?.storage?.local) { console.warn("chrome.storage not available"); return; }
  return new Promise(r => {
    chrome.storage.local.get(["defaultUser", "customSites"], d => {
      defaultIdx = d.defaultUser ?? 0;
      selectedIdx = defaultIdx;
      customSites = d.customSites || [];
      r();
    });
  });
}
function savePrefs() {
  if (!chrome?.storage?.local) return;
  chrome.storage.local.set({ defaultUser: defaultIdx, customSites });
}

// === REMOTE CONFIG ===
async function loadRemoteConfig() {
  try {
    const c = new AbortController();
    setTimeout(() => c.abort(), 4000);
    const r = await fetch(CONFIG_URL, { signal: c.signal, cache: "no-store" });
    if (!r.ok) throw 0;
    const cfg = await r.json();
    if (cfg.sites?.length) {
      SITES = cfg.sites;
      if (chrome?.storage?.local) chrome.storage.local.set({ cachedSites: cfg.sites });
    }
  } catch {
    if (chrome?.storage?.local) {
      const d = await new Promise(r => chrome.storage.local.get(["cachedSites"], r));
      if (d.cachedSites?.length) SITES = d.cachedSites;
    }
  }
}

// === RENDER ===
function renderUserSelect() {
  const sel = document.getElementById("userSelect");
  if (!sel) return;
  sel.innerHTML = "";
  const depts = {};
  ALL_USERS.forEach((u, i) => { (depts[u.dept] ??= []).push({ ...u, idx: i }); });
  for (const [dept, members] of Object.entries(depts)) {
    const g = document.createElement("optgroup"); g.label = dept;
    for (const m of members) {
      const o = document.createElement("option");
      o.value = m.idx;
      o.textContent = `${m.name} — ${m.role}`;
      if (m.idx === selectedIdx) o.selected = true;
      g.appendChild(o);
    }
    sel.appendChild(g);
  }
  sel.onchange = () => { selectedIdx = parseInt(sel.value); updateDefault(); };
}

function renderCards() {
  const main = document.getElementById("cards");
  if (!main) return;
  main.innerHTML = "";
  SITES.forEach((site, i) => {
    main.appendChild(makeCard(site, `a-${i}`, false));
    checkStatus(site.url, `a-${i}`);
  });
}

function renderCustom() {
  const el = document.getElementById("customCards");
  const label = document.getElementById("customLabel");
  if (!el || !label) return;
  el.innerHTML = "";
  label.style.display = customSites.length ? "" : "none";
  customSites.forEach((site, i) => {
    const card = makeCard(site, `c-${i}`, true);
    const del = document.createElement("button");
    del.className = "btn-del-card"; del.textContent = "×"; del.title = "Удалить";
    del.onclick = e => { e.stopPropagation(); customSites.splice(i, 1); savePrefs(); renderCustom(); };
    card.querySelector(".card-right").prepend(del);
    el.appendChild(card);
    checkStatus(site.url, `c-${i}`);
  });
}

function makeCard(site, sid, isCustom) {
  const a = document.createElement("a");
  a.className = "card"; a.href = "#";
  a.onclick = e => { e.preventDefault(); openSite(site); };
  const cls = site.cls || "custom";
  const icon = ICONS[cls] || ICONS.custom;
  a.innerHTML = `
    <div class="card-icon ${cls}">${icon}</div>
    <div class="card-body">
      <div class="card-name">${site.name}</div>
      <div class="card-desc">${site.desc || site.url}</div>
    </div>
    <div class="card-right">
      <div class="card-status checking" id="status-${sid}"></div>
    </div>`;
  return a;
}

function updateDefault() {
  const chk = document.getElementById("chkDefault");
  if (chk) chk.checked = selectedIdx === defaultIdx;
  const ft = document.getElementById("footerDefault");
  if (ft) ft.textContent = `По умолч.: ${ALL_USERS[defaultIdx]?.name || "—"}`;
}

// === OPEN + AUTOFILL ===
// Вся тяжёлая работа (создание вкладки, ожидание загрузки, инжект скрипта)
// делается в background.js — он живёт в фоне и не умирает при закрытии popup.

async function openSite(site) {
  const user = ALL_USERS[selectedIdx];
  const isDefault = selectedIdx === defaultIdx;
  const lp = site.loginPath || "/login";

  // Кастомный сайт со своими кредами
  if (site.customLogin && site.customPass) {
    chrome.runtime.sendMessage({
      action: "openAndFill",
      url: site.url,
      login: site.customLogin,
      pass: site.customPass,
    });
    return;
  }

  if (!user) {
    chrome.runtime.sendMessage({ action: "openAndFill", url: site.url, login: "", pass: "" });
    return;
  }

  if (isDefault) {
    // Свой аккаунт — просто открыть и заполнить если есть форма логина
    chrome.runtime.sendMessage({
      action: "openAndFill",
      url: site.url,
      login: user.login,
      pass: user.pass,
    });
  } else {
    // Другой пользователь — очистить сессию, потом логин
    chrome.runtime.sendMessage({
      action: "openAndFill",
      url: site.url,
      login: user.login,
      pass: user.pass,
      clearSession: true,
      loginUrl: site.url + lp,
    });
  }
}

// === STATUS ===
async function checkStatus(url, id) {
  const dot = document.getElementById(`status-${id}`);
  if (!dot) return;
  try {
    const c = new AbortController(); setTimeout(() => c.abort(), 5000);
    await fetch(url, { mode: "no-cors", signal: c.signal });
    dot.className = "card-status online";
  } catch { dot.className = "card-status offline"; }
}

// === INIT ===
document.addEventListener("DOMContentLoaded", async () => {
  await Promise.all([loadPrefs(), loadRemoteConfig()]);
  renderUserSelect();
  renderCards();
  renderCustom();
  updateDefault();

  const chk = document.getElementById("chkDefault");
  if (chk) chk.addEventListener("change", e => {
    if (e.target.checked) { defaultIdx = selectedIdx; savePrefs(); updateDefault(); }
  });

  const addUserMode = document.getElementById("addUserMode");
  const addLogin = document.getElementById("addLogin");
  const addPass = document.getElementById("addPass");
  if (addUserMode && addLogin && addPass) {
    addLogin.style.display = "none";
    addPass.style.display = "none";
    addUserMode.onchange = () => {
      const show = addUserMode.value === "custom";
      addLogin.style.display = show ? "" : "none";
      addPass.style.display = show ? "" : "none";
    };
  }

  const btnAdd = document.getElementById("btnAddSite");
  if (btnAdd) btnAdd.onclick = () => {
    const form = document.getElementById("addForm");
    if (form) form.classList.toggle("hidden");
  };

  const btnSave = document.getElementById("btnSaveSite");
  if (btnSave) btnSave.onclick = () => {
    const name = document.getElementById("addName")?.value.trim();
    let url = document.getElementById("addUrl")?.value.trim();
    if (!name || !url) return;
    if (!url.startsWith("http")) url = "https://" + url;
    const mode = addUserMode?.value || "none";
    const site = { name, url, desc: url, cls: "custom", loginPath: "/login" };
    if (mode === "custom") {
      site.customLogin = addLogin?.value.trim() || "";
      site.customPass = addPass?.value || "";
    }
    customSites.push(site);
    savePrefs(); renderCustom();
    if (document.getElementById("addName")) document.getElementById("addName").value = "";
    if (document.getElementById("addUrl")) document.getElementById("addUrl").value = "";
    if (addLogin) addLogin.value = "";
    if (addPass) addPass.value = "";
    const form = document.getElementById("addForm");
    if (form) form.classList.add("hidden");
  };
});
