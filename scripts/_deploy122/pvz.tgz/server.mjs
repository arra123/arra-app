// pvz · http-сервер. Native node:http + pg. Запуск: npm start → http://localhost:3001
import 'dotenv/config';
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import pg from 'pg';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3001;
const ROOT = __dirname;
const SITE = join(ROOT, 'site');

const { Pool } = pg;
const pool = new Pool({
  host: process.env.PGHOST,
  port: Number(process.env.PGPORT),
  database: process.env.PGDATABASE,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  ssl: false,
  max: 5,
});

const MIME = {
  '.html':'text/html;charset=utf-8', '.js':'application/javascript;charset=utf-8',
  '.mjs':'application/javascript;charset=utf-8', '.css':'text/css;charset=utf-8',
  '.json':'application/json;charset=utf-8', '.svg':'image/svg+xml',
  '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.webp':'image/webp',
  '.gif':'image/gif', '.ico':'image/x-icon', '.woff2':'font/woff2',
};
const send = (res, code, body, headers={}) => {
  res.writeHead(code, { 'Access-Control-Allow-Origin':'*', ...headers });
  res.end(body);
};
const sendJSON = (res, code, obj) => send(res, code, JSON.stringify(obj, null, 2), { 'Content-Type':'application/json;charset=utf-8' });
const sendNotFound = (res, msg='Not found') => sendJSON(res, 404, { error: msg });

async function readBody(req) {
  const chunks = [];
  for await (const c of req) chunks.push(c);
  if (!chunks.length) return null;
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return null; }
}

async function serveStatic(req, res, p) {
  // /static/<rel> → ROOT/<rel>
  if (p.startsWith('/static/')) {
    const rel = decodeURIComponent(p.slice('/static/'.length));
    if (rel.includes('..')) return sendNotFound(res);
    const abs = join(ROOT, rel);
    try {
      const st = await stat(abs);
      if (!st.isFile()) return false;
      const buf = await readFile(abs);
      send(res, 200, buf, { 'Content-Type': MIME[extname(abs)] || 'application/octet-stream' });
      return true;
    } catch { return false; }
  }
  // /  → site/index.html
  // /<file>.html → site/<file>.html
  const file = p === '/' ? '/index.html' : p;
  const abs = join(SITE, file);
  try {
    const st = await stat(abs);
    if (!st.isFile()) return false;
    const buf = await readFile(abs);
    send(res, 200, buf, {
      'Content-Type': MIME[extname(abs)] || 'application/octet-stream',
      'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
      'Pragma': 'no-cache',
      'Expires': '0',
    });
    return true;
  } catch { return false; }
}

// ───── API ─────
async function apiHealth(req, res) {
  sendJSON(res, 200, { ok: true, ts: new Date().toISOString(), service: 'pvz' });
}

async function apiCities(req, res) {
  const r = await pool.query('select id, name, region, population, lat, lon from m_cities order by population desc nulls last, name');
  sendJSON(res, 200, r.rows);
}

async function apiRentals(req, res) {
  const url = new URL(req.url, 'http://x');
  const district = url.searchParams.get('district');
  const okrug    = url.searchParams.get('okrug');
  const minM2    = url.searchParams.get('min_area');
  const maxM2    = url.searchParams.get('max_area');
  const maxRub   = url.searchParams.get('max_price');
  const minRub   = url.searchParams.get('min_price');
  const onlyLiked = url.searchParams.get('liked') === '1';
  const onlyMismatch = url.searchParams.get('mismatch') === '1';
  const floor    = url.searchParams.get('floor');
  const search   = url.searchParams.get('search');
  const w = [`r.status = 'active'`]; const a = [];
  // По умолчанию (если не запрошены mismatch явно) исключаем объявления, у которых
  // district по координатам НЕ совпал с сохранённым — они доступны только во вкладке «Не тот район».
  if (!onlyMismatch) w.push(`coalesce(r.district_mismatch, false) = false`);
  if (district) { a.push(district); w.push(`coalesce(r.district_geo, r.district) = $${a.length}`); }
  if (okrug)    { a.push(okrug);    w.push(`coalesce(r.okrug_geo, r.okrug) = $${a.length}`); }
  if (minM2)    { a.push(+minM2);   w.push(`r.area_m2 >= $${a.length}`); }
  if (maxM2)    { a.push(+maxM2);   w.push(`r.area_m2 <= $${a.length}`); }
  if (minRub)   { a.push(+minRub);  w.push(`r.price_rub >= $${a.length}`); }
  if (maxRub)   { a.push(+maxRub);  w.push(`r.price_rub <= $${a.length}`); }
  if (floor)    { a.push(+floor);   w.push(`r.floor_no = $${a.length}`); }
  if (search) {
    a.push('%' + search.toLowerCase() + '%');
    w.push(`(lower(r.address) like $${a.length} or lower(r.description) like $${a.length} or lower(r.title) like $${a.length} or r.metro::text ilike $${a.length})`);
  }
  // ?liked=1: активные лайки + история (бывшие лайки) — UI разделит по полю r.liked
  if (onlyLiked) { w.push(`r.liked_at is not null`); }
  if (onlyMismatch) { w.push(`r.district_mismatch = true`); }
  const where = 'where ' + w.join(' and ');
  const order = onlyLiked ? 'order by liked_at desc nulls last' : 'order by price_per_m2 nulls last, price_rub nulls last';

  // Дедуп: для каждой группы dedup_key выбираем «представителя» (с максимальным числом фото и наименьшей ценой за м²),
  // а в массив sources собираем все объявления группы.
  // Объявления без dedup_key (например, без координат) идут как одиночки.
  const sql = `
    with filtered as (
      select r.*, ct.name as city_name
      from m_rentals r
      left join m_cities ct on ct.id = r.city_id
      ${where}
    ),
    ranked as (
      select f.*,
        row_number() over (
          partition by coalesce(f.dedup_key, 'solo-' || f.id::text)
          order by
            case when f.liked then 0 else 1 end,
            jsonb_array_length(coalesce(f.photos,'[]'::jsonb)) desc,
            f.price_per_m2 nulls last,
            f.id
        ) as rn,
        count(*) over (partition by coalesce(f.dedup_key,'solo-'||f.id::text)) as group_size
      from filtered f
    ),
    groups as (
      select coalesce(dedup_key, 'solo-' || id::text) as gkey,
             jsonb_agg(jsonb_build_object(
               'id', id, 'source', source, 'url', url, 'price_rub', price_rub,
               'area_m2', area_m2, 'source_id', source_id
             ) order by source) as sources_all,
             bool_or(liked) as any_liked
      from filtered
      group by 1
    )
    select r.id, r.source, r.source_id, r.title, r.address, r.city_id, r.lat, r.lon,
           r.area_m2, r.price_rub, r.price_per_m2, r.url,
           r.photos, r.description, r.floor_no, r.floors_total,
           coalesce(r.district_geo, r.district) as district,
           coalesce(r.okrug_geo, r.okrug) as okrug,
           r.metro, r.agent_name, r.property_type,
           r.added_at, r.features, r.fetched_at, r.liked, r.liked_at,
           r.city_name, r.dedup_key,
           r.group_size,
           r.wb_unserved_people, r.wb_all_people, r.wb_zone_type, r.wb_subsidy_type,
           r.wb_tariff_pct, r.wb_profit_rub, r.wb_reward_rub, r.wb_can_open,
           r.wb_min_area, r.wb_predicted_turnover, r.wb_tariff_condition, r.wb_enriched_at,
           r.wb_subsidy_size, r.wb_subsidy_text, r.wb_turnover_first, r.wb_turnover_max,
           r.pvz_count_1km, r.pvz_avg_rating::float as pvz_avg_rating, r.pvz_enriched_at,
           (select coalesce(jsonb_object_agg(source, n) filter (where source is not null), '{}'::jsonb)
            from (
              select p.source, count(*)::int as n from m_points p
              where p.lat is not null and p.lon is not null
                and p.lat::float between r.lat::float - 0.012 and r.lat::float + 0.012
                and p.lon::float between r.lon::float - 0.020 and r.lon::float + 0.020
                and 6371000 * 2 * asin(sqrt(
                      power(sin(radians((r.lat::float - p.lat::float)/2)), 2)
                      + cos(radians(r.lat::float)) * cos(radians(p.lat::float))
                      * power(sin(radians((r.lon::float - p.lon::float)/2)), 2)
                    )) <= 1000
              group by p.source
            ) t) as pvz_by_source,
           r.comment, r.comment_at,
           r.district_geo, r.okrug_geo, r.district_mismatch, r.geocheck_at,
           g.sources_all,
           g.any_liked
    from ranked r
    join groups g on g.gkey = coalesce(r.dedup_key, 'solo-' || r.id::text)
    where r.rn = 1
    ${order}
    limit 1000
  `;
  const result = await pool.query(sql, a);
  sendJSON(res, 200, result.rows);
}

async function apiToggleLike(req, res) {
  const m = req.url.match(/\/api\/rentals\/(\d+)\/like/);
  if (!m) return sendNotFound(res);
  const id = +m[1];
  // При лайке — обновляем liked_at; при анлайке — оставляем (нужно для истории).
  const r = await pool.query(`
    update m_rentals
    set liked = not coalesce(liked, false),
        liked_at = case when not coalesce(liked, false) then now() else liked_at end
    where id = $1
    returning id, liked, liked_at
  `, [id]);
  if (!r.rows.length) return sendNotFound(res);
  sendJSON(res, 200, r.rows[0]);
}

async function apiSources(_req, res) {
  const r = await pool.query(`
    select source, count(*)::int as count
    from m_rentals where status='active'
    group by source order by count desc
  `);
  sendJSON(res, 200, r.rows);
}

async function apiDistricts(_req, res) {
  const r = await pool.query(`
    with eff as (
      select coalesce(district_geo, district) as district,
             coalesce(okrug_geo, okrug) as okrug,
             price_rub, area_m2, price_per_m2
      from m_rentals
      where status='active' and coalesce(district_mismatch, false) = false
    )
    select district, okrug,
           count(*)::int as count,
           min(price_rub)::int as min_rent, max(price_rub)::int as max_rent,
           round(avg(price_rub))::int as avg_rent,
           min(area_m2)::int as min_area, max(area_m2)::int as max_area,
           round(avg(price_per_m2))::int as avg_ppm
    from eff
    where district is not null
    group by district, okrug
    order by count desc
  `);
  sendJSON(res, 200, r.rows);
}

// ПВЗ в радиусе вокруг конкретного rental (через haversine из m_points)
async function apiNearbyPvz(req, res) {
  const m = req.url.match(/\/api\/rentals\/(\d+)\/nearby-pvz/);
  if (!m) return sendNotFound(res);
  const rid = +m[1];
  const url = new URL(req.url, 'http://x');
  const radius = Math.min(5000, +(url.searchParams.get('radius_m') || 1000));

  const { rows } = await pool.query(`
    with r as (
      select lat::float as lat, lon::float as lon
      from m_rentals where id = $1 and lat is not null
    )
    select p.id, p.source, p.name, p.address,
           p.lat::float as lat, p.lon::float as lon,
           p.ya_rating::float as ya_rating, p.ya_reviews,
           p.ya_url, p.ya_org_id,
           round(
             6371000 * 2 * asin(sqrt(
               power(sin(radians((r.lat - p.lat::float)/2)), 2) +
               cos(radians(r.lat)) * cos(radians(p.lat::float)) *
               power(sin(radians((r.lon - p.lon::float)/2)), 2)
             ))::numeric, 0
           )::int as distance_m
    from m_points p, r
    where p.lat is not null and p.lon is not null
      and p.lat::float between r.lat - 0.02 and r.lat + 0.02
      and p.lon::float between r.lon - 0.025 and r.lon + 0.025
    having round(
             6371000 * 2 * asin(sqrt(
               power(sin(radians((r.lat - p.lat::float)/2)), 2) +
               cos(radians(r.lat)) * cos(radians(p.lat::float)) *
               power(sin(radians((r.lon - p.lon::float)/2)), 2)
             ))::numeric, 0
           ) <= $2
    order by distance_m asc
    limit 50
  `, [rid, radius]).catch(async () => {
    // fallback: SQL без HAVING (некоторые версии PG не любят такую конструкцию без group by)
    return pool.query(`
      with r as (select lat::float as lat, lon::float as lon from m_rentals where id = $1 and lat is not null),
      ranked as (
        select p.id, p.source, p.name, p.address,
               p.lat::float as lat, p.lon::float as lon,
               p.ya_rating::float as ya_rating, p.ya_reviews,
               p.ya_url, p.ya_org_id,
               6371000 * 2 * asin(sqrt(
                 power(sin(radians((r.lat - p.lat::float)/2)), 2) +
                 cos(radians(r.lat)) * cos(radians(p.lat::float)) *
                 power(sin(radians((r.lon - p.lon::float)/2)), 2)
               )) as dist_m
        from m_points p, r
        where p.lat is not null and p.lon is not null
          and p.lat::float between r.lat - 0.02 and r.lat + 0.02
          and p.lon::float between r.lon - 0.025 and r.lon + 0.025
      )
      select id, source, name, address, lat, lon, ya_rating, ya_reviews, ya_url, ya_org_id,
             round(dist_m::numeric, 0)::int as distance_m
      from ranked where dist_m <= $2 order by dist_m limit 50
    `, [rid, radius]);
  });

  const items = rows;
  const ratings = items.map(x => x.ya_rating).filter(x => typeof x === 'number' && x > 0);
  const avg = ratings.length ? +(ratings.reduce((a,b)=>a+b,0) / ratings.length).toFixed(2) : null;
  const bySource = items.reduce((m, x) => (m[x.source] = (m[x.source]||0)+1, m), {});
  sendJSON(res, 200, { count: items.length, avg_rating: avg, by_source: bySource, items });
}

async function apiSetComment(req, res) {
  const m = req.url.match(/\/api\/rentals\/(\d+)\/comment/);
  if (!m) return sendNotFound(res);
  const id = +m[1];
  const body = await readBody(req);
  const text = (body && typeof body.comment === 'string') ? body.comment.trim() : '';
  const r = await pool.query(`
    update m_rentals
    set comment = nullif($2, ''),
        comment_at = case when nullif($2, '') is not null then now() else null end
    where id = $1
    returning id, comment, comment_at
  `, [id, text]);
  if (!r.rows.length) return sendNotFound(res);
  sendJSON(res, 200, r.rows[0]);
}

// Все ПВЗ из m_points с фильтром по source и bbox.
// Используется для слоёв «WB / Ozon / Авито…» на карте.
async function apiPvzPoints(req, res) {
  const url = new URL(req.url, 'http://x');
  const source = url.searchParams.get('source');
  const bbox = url.searchParams.get('bbox'); // "latMin,lonMin,latMax,lonMax"
  const w = [`p.ya_org_id is not null`]; const a = [];
  if (source && source !== 'all') { a.push(source); w.push(`p.source = $${a.length}`); }
  if (bbox) {
    const [latMin, lonMin, latMax, lonMax] = bbox.split(',').map(Number);
    if ([latMin,lonMin,latMax,lonMax].every(Number.isFinite)) {
      a.push(latMin, lonMin, latMax, lonMax);
      const i = a.length;
      w.push(`p.lat::float between $${i-3} and $${i-1} and p.lon::float between $${i-2} and $${i}`);
    }
  }
  const r = await pool.query(`
    select p.id, p.source, p.name, p.address,
           p.lat::float as lat, p.lon::float as lon,
           p.ya_rating::float as ya_rating, p.ya_reviews, p.ya_url, p.ya_org_id
    from m_points p
    where ${w.join(' and ')}
    limit 5000
  `, a);
  sendJSON(res, 200, r.rows);
}

async function apiMismatchStats(_req, res) {
  const r = await pool.query(`
    select
      (select count(*)::int from m_rentals where status='active' and lat is not null) as total_with_coords,
      (select count(*)::int from m_rentals where status='active' and geocheck_at is not null) as checked,
      (select count(*)::int from m_rentals where status='active' and district_mismatch = true) as mismatch
  `);
  sendJSON(res, 200, r.rows[0] || {});
}

// Принять реально вычисленный район (district_geo) как новый district
async function apiAcceptGeoDistrict(req, res) {
  const m = req.url.match(/\/api\/rentals\/(\d+)\/accept-geo/);
  if (!m) return sendNotFound(res);
  const id = +m[1];
  const r = await pool.query(`
    update m_rentals
    set district = coalesce(district_geo, district),
        okrug = coalesce(okrug_geo, okrug),
        district_mismatch = false
    where id = $1
    returning id, district, okrug
  `, [id]);
  if (!r.rows.length) return sendNotFound(res);
  sendJSON(res, 200, r.rows[0]);
}

async function apiKpis(_req, res) {
  const r = await pool.query(`
    select
      (select count(*) from m_rentals where status='active') as rentals_total,
      (select count(distinct district) from m_rentals where district is not null) as districts,
      (select round(avg(price_rub))::int from m_rentals where status='active' and price_rub is not null) as avg_rent,
      (select round(avg(price_per_m2))::int from m_rentals where status='active' and price_per_m2 is not null) as avg_ppm,
      (select max(fetched_at) from m_rentals) as last_scan
  `);
  sendJSON(res, 200, r.rows[0] || {});
}

// ───── ROUTER ─────
async function router(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const p = url.pathname;
  const m = req.method;

  if (m === 'OPTIONS') return send(res, 204, '', { 'Access-Control-Allow-Methods':'GET,POST,PATCH,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers':'Content-Type' });

  try {
    if (p === '/api/health')      return apiHealth(req, res);
    if (p === '/api/kpis')        return apiKpis(req, res);
    if (p === '/api/cities')      return apiCities(req, res);
    if (p === '/api/rentals')     return apiRentals(req, res);
    if (p === '/api/districts')   return apiDistricts(req, res);
    if (p === '/api/sources')     return apiSources(req, res);
    if (p.match(/^\/api\/rentals\/\d+\/like$/) && m === 'POST') return apiToggleLike(req, res);
    if (p.match(/^\/api\/rentals\/\d+\/comment$/) && m === 'POST') return apiSetComment(req, res);
    if (p.match(/^\/api\/rentals\/\d+\/nearby-pvz$/) && m === 'GET') return apiNearbyPvz(req, res);
    if (p.match(/^\/api\/rentals\/\d+\/accept-geo$/) && m === 'POST') return apiAcceptGeoDistrict(req, res);
    if (p === '/api/mismatch-stats') return apiMismatchStats(req, res);
    if (p === '/api/pvz') return apiPvzPoints(req, res);

    const ok = await serveStatic(req, res, p);
    if (!ok) sendNotFound(res, `${m} ${p}`);
  } catch (e) {
    console.error('500', e);
    sendJSON(res, 500, { error: String(e.message || e) });
  }
}

const server = createServer(router);
server.listen(PORT, () => {
  console.log(`\n  pvz — http://localhost:${PORT}`);
  console.log(`  / → site/index.html`);
  console.log(`  /api/* → API`);
  console.log(`\n  CTRL+C для остановки.\n`);
});

process.on('SIGINT', async () => {
  console.log('\nshutting down...');
  await pool.end();
  server.close(() => process.exit(0));
});
