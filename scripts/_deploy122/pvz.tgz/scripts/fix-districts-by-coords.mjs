// Гео-проверка района/округа по координатам через OSM Nominatim.
// Заполняет m_rentals.district_geo / okrug_geo / district_mismatch / geocheck_at.
// Не перезаписывает r.district — только сравнивает и помечает.
// Запуск: node --env-file=.env scripts/fix-districts-by-coords.mjs [--limit N] [--force]
import 'dotenv/config';
import pg from 'pg';

const args = process.argv.slice(2);
const LIMIT = +(args[args.indexOf('--limit')+1] || 0) || 5000;
const FORCE = args.includes('--force'); // перепроверить даже если geocheck_at уже есть
const STALE_DAYS = 60;
const DELAY_MS = 1100; // Nominatim требует ≤1 req/sec
const UA = 'pvz-research/1.0 (jamieskipper305@gmail.com)';

const sleep = ms => new Promise(r => setTimeout(r, ms));

const OKRUG_RE = [
  [/центральн/i, 'ЦАО'], [/северо-западн|сзао/i, 'СЗАО'], [/северо-восточн|свао/i, 'СВАО'],
  [/юго-восточн|ювао/i, 'ЮВАО'], [/юго-западн|юзао/i, 'ЮЗАО'],
  [/западн/i, 'ЗАО'], [/восточн/i, 'ВАО'],
  [/северн/i, 'САО'], [/южн/i, 'ЮАО'],
  [/зеленоград/i, 'ЗелАО'], [/новомосковск/i, 'НАО'], [/троицк/i, 'ТАО'],
];
function normOkrug(s) {
  if (!s) return null;
  for (const [re, code] of OKRUG_RE) if (re.test(s)) return code;
  return null;
}
// Очистка названия района: «район Нагатино-Садовники» → «Нагатино-Садовники»
function cleanDistrict(s) {
  if (!s) return null;
  return s.replace(/^район\s+/i,'').replace(/\s+район$/i,'').trim() || null;
}

async function reverse(lat, lon, zoom=16) {
  const u = new URL('https://nominatim.openstreetmap.org/reverse');
  u.searchParams.set('lat', String(lat));
  u.searchParams.set('lon', String(lon));
  u.searchParams.set('format', 'json');
  u.searchParams.set('addressdetails', '1');
  u.searchParams.set('zoom', String(zoom));
  u.searchParams.set('accept-language', 'ru');
  const r = await fetch(u, { headers: { 'User-Agent': UA, 'Accept-Language':'ru' } });
  if (!r.ok) throw new Error(`Nominatim ${r.status}`);
  return r.json();
}

function pickDistrict(addr) {
  if (!addr) return { district: null, okrug: null };
  // В Москве районы обычно подписаны как "район XXX" — ищем такие в первую очередь
  const candidates = [addr.suburb, addr.quarter, addr.borough, addr.neighbourhood, addr.city_district];
  let district = null;
  for (const c of candidates) {
    if (c && /^район\s+/i.test(c)) { district = c; break; }
  }
  if (!district) {
    // fallback — берём первый непустой, считая что это микрорайон, не район
    district = candidates.find(c => c) || null;
  }
  return {
    district: cleanDistrict(district),
    okrug: normOkrug(addr.city_district || addr.borough || ''),
  };
}

const { Pool } = pg;
const pool = new Pool({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});

async function main() {
  const filter = FORCE
    ? `lat is not null and lon is not null and status='active'`
    : `lat is not null and lon is not null and status='active'
       and (geocheck_at is null or geocheck_at < now() - interval '${STALE_DAYS} days')`;
  const { rows } = await pool.query(
    `select id, lat::float as lat, lon::float as lon, district as old_d, address from m_rentals where ${filter} order by id limit $1`,
    [LIMIT]
  );

  console.log(`пройду ${rows.length} объявлений (~${Math.ceil(rows.length*DELAY_MS/60000)} мин)`);
  let okN=0, errN=0, mismatch=0;

  for (const r of rows) {
    try {
      let j = await reverse(r.lat, r.lon, 16);
      let { district: dGeo, okrug: oGeo } = pickDistrict(j.address);

      // Если на zoom=16 не нашли «район XXX» — пробуем zoom=15 для перепроверки
      if (!dGeo || !/[А-ЯЁа-яё]/.test(dGeo)) {
        await sleep(DELAY_MS);
        j = await reverse(r.lat, r.lon, 15);
        const p2 = pickDistrict(j.address);
        if (p2.district) dGeo = p2.district;
        if (p2.okrug && !oGeo) oGeo = p2.okrug;
      }

      // Сравнение: тот же район? Игнорируем регистр, ё/е, разные пробелы/тире.
      const norm = s => (s||'').toLowerCase().replace(/ё/g,'е').replace(/[\s\-—]+/g,' ').trim();
      const isMismatch = dGeo && r.old_d && norm(dGeo) !== norm(r.old_d);

      await pool.query(`
        update m_rentals
        set district_geo = $2, okrug_geo = $3,
            district_mismatch = $4, geocheck_at = now()
        where id = $1
      `, [r.id, dGeo, oGeo, !!isMismatch]);

      if (isMismatch) {
        mismatch++;
        if (mismatch <= 30 || mismatch % 50 === 0) {
          console.log(`  ✗ #${r.id}  ${(r.address||'').slice(0,40)}  было «${r.old_d}» → реально «${dGeo}»`);
        }
      }
      okN++;
      if (okN % 50 === 0) console.log(`  ${okN}/${rows.length}  mismatches=${mismatch}`);
    } catch (e) {
      errN++;
      console.error(`✗ #${r.id}: ${e.message}`);
      if (e.message.includes('429')) await sleep(5000);
    }
    await sleep(DELAY_MS);
  }

  console.log(`\n✓ обработано: ${okN}  ошибок: ${errN}  несовпадений: ${mismatch}`);
  await pool.end();
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
