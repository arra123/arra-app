// Парсер 5 районов ЗАО на Avito.
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

// Avito district ID для ЗАО (из URL после применения фильтра)
const districts = [
  { name:'Кунцево',          id: 660 },
  { name:'Можайский',        id: 654 },
  { name:'Крылатское',       id: 657 },
  { name:'Фили-Давыдково',   id: 671 },
  { name:'Ново-Переделкино', id: 668 },
];

// общий шаблон URL: ASgBAgECAUSwCNRW = «коммерческая недвижимость / снять»,
// f=...AUW2ExZ7ImZyb20iOjEwMCwidG8iOm51bGx9 = площадь от 100 м²
const baseUrl = 'https://www.avito.ru/moskva/kommercheskaya_nedvizhimost/sdam-ASgBAgICAUSwCNRW';
const baseFilter = 'f=ASgBAgECAUSwCNRWAUW2ExZ7ImZyb20iOjEwMCwidG8iOm51bGx9&localPriority=0';

for (const d of districts) {
  const url = `${baseUrl}?district=${d.id}&${baseFilter}`;
  console.log(`\n========== ${d.name} (district=${d.id}) ==========`);
  const r = spawnSync('node', [
    'scripts/scan-avito-rent.mjs',
    '--district', d.name,
    '--pages', '5',
    '--delay', '1500',
    '--minarea', '100',
    '--maxarea', '300',
    '--floor', '1',
    '--url', url,
  ], { cwd: ROOT, stdio: 'inherit' });
  if (r.status !== 0) console.warn(`  ! ${d.name}: exit ${r.status}`);
}

console.log('\n=== готово ===');
