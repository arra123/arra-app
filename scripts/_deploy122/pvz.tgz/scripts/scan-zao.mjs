// Парсер 5 районов ЗАО Москвы через CIAN.
// Запуск: node scripts/scan-zao.mjs

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

// Полигоны (bbox) каждого района — в формате CIAN: "lon_lat,lon_lat,lon_lat,lon_lat,lon_lat" (замкнут)
const districts = [
  { name:'Крылатское',       bbox:[37.365415, 55.744825, 37.464544, 55.777277] },
  { name:'Кунцево',          bbox:[37.398,    55.715,    37.475,    55.755   ] },
  { name:'Можайский',        bbox:[37.395,    55.69,     37.515,    55.74    ] },
  { name:'Ново-Переделкино', bbox:[37.300,    55.620,    37.395,    55.665   ] },
  { name:'Фили-Давыдково',   bbox:[37.450,    55.720,    37.515,    55.755   ] },
];

const baseQs = new URLSearchParams({
  currency: '2',
  deal_type: 'rent',
  engine_version: '2',
  maxarea: '300', minarea: '100',
  minprice: '150000', maxprice: '1500000',
  offer_type: 'offices',
});
// типы: офис(1), стрит-ритейл(5), торговая площадь(7), своб. назначения(11)
['1','5','7','11'].forEach((t,i) => baseQs.append(`office_type[${i}]`, t));

function buildUrl(district) {
  const [w, s, e, n] = district.bbox;
  const poly = `${w}_${s},${w}_${n},${e}_${n},${e}_${s},${w}_${s}`;
  const qs = new URLSearchParams(baseQs);
  qs.set('in_polygon[1]', poly);
  qs.set('polygon_name[1]', `район ${district.name}`);
  return `https://www.cian.ru/cat.php?${qs}`;
}

for (const d of districts) {
  const url = buildUrl(d);
  console.log(`\n========== ${d.name} ==========`);
  const r = spawnSync('node', [
    'scripts/scan-cian-rent.mjs',
    '--city', 'Москва',
    '--pages', '8',
    '--delay', '1500',
    '--url', url,
  ], { cwd: ROOT, stdio: 'inherit' });
  if (r.status !== 0) console.warn(`  ! ${d.name}: exit ${r.status}`);
}

console.log('\n=== готово ===');
