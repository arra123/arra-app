// Парсер коммерческой аренды с CIAN.
// Для каждого города из m_cities с region='Москва'/'Московская область'
// тянет страницы поиска и пишет объявления в m_rentals.
//
// Запуск:
//   node scripts/scan-cian-rent.mjs --city Москва [--pages 5] [--type free]
//   node scripts/scan-cian-rent.mjs --all
//
// Параметры URL CIAN:
//   region=1     — Москва
//   region=4593  — Московская область
//   deal_type=rent
//   engine_version=2
//   offer_type=offices  (офисы) | offer_type=offices&type=4 (свободного назначения) | offer_type=offices&type=2 (стрит)

import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));

// ── CLI ────────────────────────────────────────────────────────────────
const argv = process.argv.slice(2);
const arg  = (k, def=null) => { const i = argv.indexOf(k); return i >= 0 && argv[i+1] ? argv[i+1] : def; };
const flag = (k) => argv.includes(k);

const cityName = arg('--city');
const pages    = +(arg('--pages', '5'));   // сколько страниц парсить (28 объявлений на стр)
const propType = arg('--type', 'free,street'); // free / office / street, можно через запятую
const customUrl = arg('--url');                 // готовый URL CIAN с фильтрами
const doAll    = flag('--all');
const delayMs  = +(arg('--delay', '700'));
const minArea  = +(arg('--minarea', '100')); // м² от
const maxArea  = +(arg('--maxarea', '500')); // м² до
const floor    = arg('--floor', '1');         // конкретный этаж (или null=любой)
const maxPrice = +(arg('--maxprice', '0'));   // максимум ₽/мес (0=без лимита)
const bbox     = arg('--bbox');                // "west,south,east,north" — фильтр координат
const addrFilt = arg('--addr');                // подстрока в адресе (после парсинга)

// тип помещения → CIAN type. Можно несколько через запятую
const TYPE_CODES = { office: 1, street: 2, free: 4 };
const typeCodes = propType === 'all' ? Object.values(TYPE_CODES)
  : (propType.split(',').map(t => TYPE_CODES[t.trim()]).filter(Boolean));

// CIAN region id для города
const CIAN_REGIONS = {
  'Москва':              1,
  'Балашиха':            4612,
  'Подольск':            4684,
  'Химки':               4724,
  'Мытищи':              4663,
  'Королёв':             4632,
  'Люберцы':             4654,
  'Красногорск':         4634,
  'Электросталь':        4742,
  'Одинцово':            4677,
  'Серпухов':            4710,
};

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'ru-RU,ru;q=0.9',
};

// ── DB ─────────────────────────────────────────────────────────────────
const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();
await c.query(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));

// ── helpers ────────────────────────────────────────────────────────────
const sleep = ms => new Promise(r => setTimeout(r, ms));

function extractResults(html) {
  // Находим JSON-блок "results":{...} с балансировкой скобок и JSON-строк
  const marker = '"results":{"avgPriceInformer"';
  const i = html.indexOf(marker);
  if (i < 0) return null;
  const s = i + html.slice(i).indexOf('{');
  let depth = 0, end = s, inStr = false, esc = false;
  for (let j = s; j < html.length; j++) {
    const ch = html[j];
    if (inStr) {
      if (esc) { esc = false; continue; }
      if (ch === '\\') { esc = true; continue; }
      if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') { inStr = true; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') { depth--; if (depth === 0) { end = j + 1; break; } }
  }
  try { return JSON.parse(html.slice(s, end)); } catch { return null; }
}

async function fetchPage(regionId, page) {
  let url;
  if (customUrl) {
    // используем готовый URL юзера, добавляя пагинацию
    const u = new URL(customUrl);
    u.searchParams.set('p', page);
    url = u.toString();
  } else {
    const params = new URLSearchParams({
      deal_type: 'rent',
      engine_version: '2',
      offer_type: 'offices',
      region: regionId,
      p: page,
    });
    typeCodes.forEach((t, i) => params.append(`office_type[${i}]`, t));
    if (typeCodes.length === 1) params.set('type', typeCodes[0]);
    if (minArea) params.set('minarea', minArea);
    if (maxArea) params.set('maxarea', maxArea);
    if (floor)   { params.set('minfloorn', floor); params.set('maxfloorn', floor); }
    if (maxPrice) params.set('maxprice', maxPrice);
    if (bbox) {
      const [w, s, e, n] = bbox.split(',').map(Number);
      params.set('in_polygon[1]', `${s} ${w},${s} ${e},${n} ${e},${n} ${w},${s} ${w}`);
    }
    url = `https://www.cian.ru/cat.php?${params}`;
  }
  const r = await fetch(url, { headers: HEADERS });
  if (!r.ok) throw new Error(`CIAN ${r.status}`);
  const html = await r.text();
  const data = extractResults(html);
  if (!data) throw new Error('results not found in HTML');
  let offers = data.offers || [];
  if (addrFilt) {
    const f = addrFilt.toLowerCase();
    offers = offers.filter(o => {
      const a = (o.geo?.userInput || '') + ' ' + (o.geo?.address||[]).map(x=>x.fullName).join(' ');
      return a.toLowerCase().includes(f);
    });
  }
  return offers;
}

function priceMonthly(bt, area) {
  // CIAN: priceType in ('all','squareMeter'), paymentPeriod in ('monthly','annual')
  if (!bt) return { price: null, ppm: null };
  const p = +bt.priceRur || 0;
  const pt = bt.priceType, pp = bt.paymentPeriod;
  let price = null, ppm = null;
  if (pt === 'all') {
    // priceRur — итоговая аренда в указанный период
    price = pp === 'annual' ? Math.round(p / 12) : p;
    if (area) ppm = +(price / area).toFixed(2);
  } else if (pt === 'squareMeter' && area) {
    // priceRur — ₽/м² в указанный период
    const perMonth = pp === 'annual' ? p / 12 : p;
    price = Math.round(perMonth * area);
    ppm = +perMonth.toFixed(2);
  } else if (area) {
    price = p;
    ppm = +(p / area).toFixed(2);
  } else {
    price = p;
  }
  return { price, ppm };
}

async function upsertOffer(cityId, offer) {
  const id  = String(offer.id);
  const lat = offer.geo?.coordinates?.lat;
  const lon = offer.geo?.coordinates?.lng;
  if (!lat || !lon) return false;
  const area  = +(offer.totalArea) || null;
  const { price, ppm } = priceMonthly(offer.bargainTerms, area);
  const addr  = offer.geo?.userInput || (offer.geo?.address || []).map(a => a.fullName).join(', ') || null;
  const title = String(offer.title || offer.formattedFullInfo || addr || '').slice(0, 250);

  // дополнительные поля из raw
  const photos = (offer.photos || []).map(p => p.fullUrl || p.miniUrl).filter(Boolean);
  const description = String(offer.description || '').slice(0, 5000);
  const floor = offer.floorNumber ?? null;
  const floorsTotal = offer.building?.floorsCount ?? null;
  const addrArr = offer.geo?.address || [];
  const district = addrArr.find(a => a.type === 'raion' || /район/i.test(a.name||''))?.name?.replace(/^район\s+/i,'').replace(/\s+район$/i,'') || null;
  const okrug = addrArr.find(a => a.type === 'okrug' || /(ЗАО|САО|СВАО|ЮЗАО|ЮВАО|ЮАО|ВАО|СЗАО|ЦАО|ТАО|НАО)/.test(a.name))?.name || null;
  const metro = (offer.geo?.undergrounds || []).map(m => ({ name:m.name, minutes:m.time, type:m.transportType||'walk', line:m.lineColor }));
  const agentName = offer.user?.agencyName || (offer.user?.isAgent ? 'агент' : null);
  const agentId = String(offer.userId || '');
  const propertyType = offer.category || null;
  const addedAt = offer.addedTimestamp ? new Date(offer.addedTimestamp*1000).toISOString() : null;
  const features = offer.featuresInfo || {};

  await c.query(`
    insert into m_rentals(source, source_id, title, address, city_id, lat, lon, area_m2, price_rub, price_per_m2, url, status, raw,
                          photos, description, floor_no, floors_total, district, okrug, metro,
                          agent_name, agent_id, property_type, added_at, features)
    values('cian', $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'active', $11::jsonb,
           $12::jsonb, $13, $14, $15, $16, $17, $18::jsonb, $19, $20, $21, $22, $23::jsonb)
    on conflict (source, source_id) do update set
      title=excluded.title, address=excluded.address, area_m2=excluded.area_m2,
      price_rub=excluded.price_rub, price_per_m2=excluded.price_per_m2,
      url=excluded.url, status='active', raw=excluded.raw, fetched_at=now(),
      photos=excluded.photos, description=excluded.description,
      floor_no=excluded.floor_no, floors_total=excluded.floors_total,
      district=excluded.district, okrug=excluded.okrug, metro=excluded.metro,
      agent_name=excluded.agent_name, agent_id=excluded.agent_id,
      property_type=excluded.property_type, added_at=excluded.added_at, features=excluded.features
  `, [id, title, addr, cityId, lat, lon, area, price, ppm, offer.fullUrl, JSON.stringify(offer),
      JSON.stringify(photos), description, floor, floorsTotal, district, okrug, JSON.stringify(metro),
      agentName, agentId, propertyType, addedAt, JSON.stringify(features)]);
  return true;
}

// ── основной цикл ──────────────────────────────────────────────────────
async function scanCity(city) {
  const regionId = CIAN_REGIONS[city.name];
  if (!regionId) { console.log(`✗ ${city.name}: region не задан`); return; }
  console.log(`\n→ ${city.name} · CIAN region=${regionId} · type=${propType} · ${pages} стр.`);
  const t0 = Date.now();
  let saved = 0, errors = 0;
  for (let p = 1; p <= pages; p++) {
    try {
      const offers = await fetchPage(regionId, p);
      let okPage = 0;
      for (const o of offers) if (await upsertOffer(city.id, o)) okPage++;
      saved += okPage;
      console.log(`  стр.${p}: ${offers.length} офферов · ${okPage} с координатами`);
    } catch (e) {
      errors++;
      console.warn(`  стр.${p}: ошибка — ${e.message}`);
    }
    await sleep(delayMs);
  }
  await c.query(`
    insert into m_imports_log(source_kind, city_id, inserted, failed, duration_ms)
    values('cian-rent', $1, $2, $3, $4)
  `, [city.id, saved, errors, Date.now()-t0]);
  console.log(`  ✓ ${city.name}: сохранено ${saved}`);
}

let cities;
if (doAll) ({ rows: cities } = await c.query('select id, name from m_cities order by population desc nulls last'));
else if (cityName) ({ rows: cities } = await c.query('select id, name from m_cities where name=$1', [cityName]));
else { console.log('Использование: --city Москва [--pages 3] [--type free|office|street] | --all'); process.exit(1); }

if (!cities.length) { console.error('Город не найден'); process.exit(1); }

for (const city of cities) await scanCity(city);

await c.end();
console.log('\nготово.');
