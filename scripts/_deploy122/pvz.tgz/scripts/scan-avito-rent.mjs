// Парсер Avito коммерческой аренды.
// Прямой fetch HTML каталога — Avito SSR содержит "items":[{...50 объявлений...}]
// с полным набором полей: координаты, цена, описание, метро, фото.
//
// Запуск:
//   node scripts/scan-avito-rent.mjs --url "<avito-url>" [--pages 5] [--bbox w,s,e,n] [--floor 1] [--district Кунцево]
//
// Без playwright и капчи — просто curl-style fetch. Если 403/CAPTCHA вернётся, скрипт сообщит.

import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const arg = (k, def=null) => { const i=argv.indexOf(k); return i>=0 && argv[i+1] ? argv[i+1] : def; };

const customUrl = arg('--url');
const cityName  = arg('--city', 'Москва');
const pages     = +(arg('--pages', '5'));
const minArea   = +(arg('--minarea', '0'));
const maxArea   = +(arg('--maxarea', '0'));
const floor     = arg('--floor', '');         // ожидаемый этаж (фильтр на клиенте через description)
const maxPrice  = +(arg('--maxprice', '0'));
const bbox      = arg('--bbox');
const districtName = arg('--district');       // имя района для записи в m_rentals.district
const delayMs   = +(arg('--delay', '1500'));

if (!customUrl) {
  console.error('Нужен --url с готовым URL Avito (с фильтрами)');
  process.exit(1);
}

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
  'Accept-Language': 'ru-RU,ru;q=0.9',
};

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();
await c.query(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));

const sleep = ms => new Promise(r => setTimeout(r, ms));

// извлечение items[] из SSR HTML с балансировкой скобок
function extractItems(html) {
  const idx = html.indexOf('"items":[{');
  if (idx < 0) return [];
  const s = idx + html.slice(idx).indexOf('[');
  let depth = 0, end = s, inStr = false, esc = false;
  for (let j = s; j < html.length; j++) {
    const ch = html[j];
    if (inStr) {
      if (esc) { esc = false; continue; }
      if (ch === '\\') { esc = true; continue; }
      if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') { inStr = true; continue; }
    if (ch === '[') depth++;
    else if (ch === ']') { depth--; if (depth === 0) { end = j + 1; break; } }
  }
  try { return JSON.parse(html.slice(s, end)); } catch { return []; }
}

async function fetchPage(url) {
  const r = await fetch(url, { headers: HEADERS });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const html = await r.text();
  if (html.includes('Доступ ограничен') || html.includes('Captcha</title>') || html.includes('captcha-container')) {
    throw new Error('CAPTCHA / blocked');
  }
  return html;
}

// поля из item для записи в m_rentals
function extractAreaFromTitle(title, description) {
  const text = (title || '') + ' ' + (description || '');
  const m = text.match(/(\d+(?:[.,]\d+)?)\s*(?:кв\.?\s*м|м[²2])/i);
  return m ? +m[1].replace(',', '.') : null;
}

function extractFloor(title, description) {
  const text = (title || '') + ' ' + (description || '');
  // 1/5 эт, 1 этаж из 5, на 1 этаже
  const m = text.match(/(\d+)\s*\/\s*\d+\s*эта/i)
         || text.match(/(\d+)\s*эта[жз]\s*из\s*\d+/i)
         || text.match(/на\s+(\d+)[-\s]?(?:ом|ой|м)?\s*эта[жз]/i)
         || text.match(/(\d+)\s*[-\s]?(?:ой|й|ом)?\s*эта[жз]/i);
  return m ? +m[1] : null;
}

async function upsert(cityId, item) {
  const lat = item.coords?.lat ? +item.coords.lat : null;
  const lon = item.coords?.lng ? +item.coords.lng : null;
  if (!lat || !lon) return { ok:false, reason:'no coords' };

  // фильтры
  if (bbox) {
    const [w, s, e, n] = bbox.split(',').map(Number);
    if (lat < s || lat > n || lon < w || lon > e) return { ok:false, reason:'bbox' };
  }

  const area = extractAreaFromTitle(item.title, item.description);
  if (minArea && (!area || area < minArea)) return { ok:false, reason:'area<' };
  if (maxArea && area && area > maxArea)    return { ok:false, reason:'area>' };

  const fl = extractFloor(item.title, item.description);
  if (floor && fl != null && +floor !== fl) return { ok:false, reason:'floor' };

  // Цена: priceDetailed.value может быть либо общая (₽/мес), либо ставка (₽/м²/мес)
  // Avito пишет в postfix именно "в месяц" / "в месяц за м²" / "в год за м²"
  // normalizedPrice — это ВСЕГДА справочное приведение (не учитывать!)
  const pd = item.priceDetailed || {};
  const rawValue = +pd.value || 0;
  const postfix = String(pd.postfix || '').toLowerCase();
  const isPerM2  = /за\s*м[²2]/.test(postfix);
  const isAnnual = /в\s*год/.test(postfix);
  let price = rawValue;
  if (rawValue > 0) {
    if (isPerM2 && area) price = Math.round(rawValue * area);
    if (isAnnual) price = Math.round(price / 12);
  } else {
    price = null;
  }
  if (maxPrice && price && price > maxPrice) return { ok:false, reason:'price>' };

  const ppm = (price && area) ? +(price / area).toFixed(2) : null;
  const addr = item.coords?.address_user || item.location?.namePrepositional || item.location?.name || null;
  const title = String(item.title || '').slice(0, 250);
  const url = 'https://www.avito.ru' + (item.urlPath || '').split('?')[0];
  const photos = (item.images || []).map(img => {
    if (typeof img === 'string') return img;
    // Avito ключи: 208 / 236 / 318 / 416 / 432 / 472 / 636 / 864 — берём самый большой
    const keys = Object.keys(img).filter(k => /^\d+x\d+$/.test(k))
      .sort((a,b) => (+a.split('x')[0]) - (+b.split('x')[0]));
    const biggestKey = keys[keys.length - 1];
    return biggestKey ? img[biggestKey] : Object.values(img)[0];
  }).filter(Boolean).slice(0, 12);
  const desc = String(item.description || '').slice(0, 5000);

  const propertyType = item.category?.slug || null;
  const id = String(item.id);

  await c.query(`
    insert into m_rentals(source, source_id, title, address, city_id, lat, lon, area_m2, price_rub, price_per_m2, url, status, raw,
                          photos, description, floor_no, district, property_type)
    values('avito', $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'active', $11::jsonb,
           $12::jsonb, $13, $14, $15, $16)
    on conflict (source, source_id) do update set
      title=excluded.title, address=excluded.address, area_m2=excluded.area_m2,
      price_rub=excluded.price_rub, price_per_m2=excluded.price_per_m2,
      url=excluded.url, status='active', raw=excluded.raw, fetched_at=now(),
      photos=excluded.photos, description=excluded.description,
      floor_no=excluded.floor_no, district=excluded.district, property_type=excluded.property_type
  `, [
    id, title, addr, cityId, lat, lon, area, price, ppm, url, JSON.stringify(item),
    JSON.stringify(photos), desc, fl, districtName, propertyType,
  ]);
  return { ok:true };
}

const { rows: cities } = await c.query('select id from m_cities where name=$1', [cityName]);
if (!cities.length) { console.error('Город не найден'); process.exit(1); }
const cityId = cities[0].id;

console.log(`→ Avito · ${cityName} · ${districtName||'-'} · фильтры: bbox=${bbox||'-'} area=${minArea}-${maxArea||'∞'} floor=${floor||'-'}`);

let saved = 0, fetched = 0, skipped = 0;
const reasons = {};
const t0 = Date.now();

for (let p = 1; p <= pages; p++) {
  const url = p === 1 ? customUrl : `${customUrl}${customUrl.includes('?') ? '&' : '?'}p=${p}`;
  let items;
  try {
    const html = await fetchPage(url);
    items = extractItems(html);
  } catch (e) {
    console.warn(`  стр.${p}: ${e.message}`);
    break;
  }
  if (!items.length) {
    console.warn(`  стр.${p}: 0 items в SSR (возможно конец)`);
    break;
  }
  let pageSaved = 0;
  for (const it of items) {
    const r = await upsert(cityId, it);
    if (r.ok) { pageSaved++; saved++; }
    else { skipped++; reasons[r.reason] = (reasons[r.reason]||0)+1; }
  }
  fetched += items.length;
  console.log(`  стр.${p}: ${items.length} офферов, ${pageSaved} прошли фильтры`);
  await sleep(delayMs);
}

console.log(`\n✓ Avito ${districtName||cityName}: saved=${saved}/${fetched}, skipped=${skipped}`);
console.log('  skip reasons:', reasons);

await c.query(
  `insert into m_imports_log(source_kind, city_id, inserted, duration_ms) values('avito-rent', $1, $2, $3)`,
  [cityId, saved, Date.now()-t0]
);
await c.end();
