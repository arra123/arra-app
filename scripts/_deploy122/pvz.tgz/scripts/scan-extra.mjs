// СЗАО Москвы + ближнее Подмосковье (Красногорск, Одинцово, Реутов).
// Парсим CIAN с теми же фильтрами что в scan-zao.mjs.
// Запуск: node scripts/scan-extra.mjs

import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

// СЗАО Москвы — крупные жилые массивы. Фокус: высокая застройка.
const moscowSzao = [
  { name:'Митино',                 bbox:[37.305, 55.835, 37.405, 55.880] },
  { name:'Строгино',               bbox:[37.355, 55.775, 37.425, 55.815] },
  { name:'Хорошёво-Мнёвники',      bbox:[37.420, 55.755, 37.510, 55.795] },
  { name:'Северное Тушино',        bbox:[37.395, 55.840, 37.470, 55.880] },
  { name:'Южное Тушино',           bbox:[37.420, 55.820, 37.475, 55.855] },
  { name:'Покровское-Стрешнево',   bbox:[37.420, 55.800, 37.475, 55.835] },
  { name:'Щукино',                 bbox:[37.450, 55.790, 37.510, 55.820] },
  { name:'Куркино',                bbox:[37.370, 55.870, 37.435, 55.905] },
];

// Ближнее Подмосковье (≤30 км от центра МСК, крупные ЖК).
// Используем CIAN region id вместо полигона.
const moRegions = [
  { name:'Красногорск (Павшинская пойма)', region:4634, bbox:[37.290, 55.770, 37.380, 55.840] },
  { name:'Одинцово',                       region:4677, bbox:[37.220, 55.640, 37.345, 55.715] },
  { name:'Реутов',                         region:4685, bbox:[37.835, 55.750, 37.880, 55.785] },
  { name:'Химки (ближняя часть)',          region:4724, bbox:[37.400, 55.870, 37.510, 55.920] },
  { name:'Долгопрудный',                   region:4642, bbox:[37.470, 55.920, 37.580, 55.965] },
  { name:'Мытищи',                         region:4663, bbox:[37.690, 55.880, 37.790, 55.960] },
  { name:'Балашиха (ближняя часть)',       region:4612, bbox:[37.840, 55.770, 37.970, 55.830] },
  { name:'Котельники',                     region:4799, bbox:[37.840, 55.640, 37.910, 55.685] },
  { name:'Видное',                         region:4736, bbox:[37.665, 55.530, 37.755, 55.580] },
  { name:'Лыткарино',                      region:4651, bbox:[37.870, 55.555, 37.960, 55.605] },
];

const baseQs = new URLSearchParams({
  currency:'2', deal_type:'rent', engine_version:'2',
  maxarea:'300', minarea:'100',
  minprice:'150000', maxprice:'1500000',
  offer_type:'offices',
});
['1','5','7','11'].forEach((t,i) => baseQs.append(`office_type[${i}]`, t));

function buildPolyUrl(bbox) {
  const [w, s, e, n] = bbox;
  const poly = `${w}_${s},${w}_${n},${e}_${n},${e}_${s},${w}_${s}`;
  const qs = new URLSearchParams(baseQs);
  qs.set('region', '1');
  qs.set('in_polygon[1]', poly);
  qs.set('polygon_name[1]', 'район');
  return `https://www.cian.ru/cat.php?${qs}`;
}
function buildRegionUrl(region) {
  const qs = new URLSearchParams(baseQs);
  qs.set('region', String(region));
  return `https://www.cian.ru/cat.php?${qs}`;
}

function run(name, url) {
  console.log(`\n========== ${name} ==========`);
  console.log('  url:', url.slice(0, 120) + '…');
  const r = spawnSync('node', [
    'scripts/scan-cian-rent.mjs',
    '--city', 'Москва',
    '--pages', '8',
    '--delay', '1500',
    '--url', url,
  ], { cwd: ROOT, stdio: 'inherit' });
  if (r.status !== 0) console.warn(`  ! ${name}: exit ${r.status}`);
}

// СЗАО — через полигон Москвы
for (const d of moscowSzao) {
  run(d.name, buildPolyUrl(d.bbox));
}
// МО — через region id (полигон у CIAN не работает для МО)
for (const m of moRegions) {
  run(m.name, buildRegionUrl(m.region));
}

console.log('\n=== готово ===');
