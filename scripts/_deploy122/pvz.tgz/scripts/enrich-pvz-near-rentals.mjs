// Обогащает m_points данными о ПВЗ в радиусе 1км вокруг каждого rental.
// Источник: Yandex Search API for Organizations (search-maps.yandex.ru).
// Запуск: node --env-file=.env scripts/enrich-pvz-near-rentals.mjs [--limit 100] [--force]
import 'dotenv/config';
import pg from 'pg';

const KEY = process.env.YA_SEARCH_API_KEY;
if (!KEY) { console.error('нет YA_SEARCH_API_KEY в .env'); process.exit(1); }

const args = process.argv.slice(2);
const LIMIT = +(args[args.indexOf('--limit')+1] || 0) || 200;
const FORCE = args.includes('--force');
const RADIUS_M = 1000;
const STALE_DAYS = 30;
const REQ_DELAY_MS = 250;

const SOURCE_RE = [
  [/wildberries|вайлдбер|\bwb\b/i, 'wb'],
  [/ozon|озон/i, 'ozon'],
  [/сдэк|\bcdek\b|\bsdek\b/i, 'sdek'],
  [/яндекс[^a-zа-я]*маркет/i, 'ya_market'],
  [/яндекс[^a-zа-я]*достав/i, 'ya_delivery'],
  [/5\s*post|5\s*пост/i, '5post'],
  [/boxberry|боксберри/i, 'boxberry'],
  [/\bpek\b|\bпэк\b/i, 'pek'],
  [/dpd/i, 'dpd'],
  [/halva|халва/i, 'halva'],
  [/сбер.*логист/i, 'sber_logistics'],
];
function detectSource(name='', cats=[]) {
  const hay = (name + ' ' + cats.join(' ')).toLowerCase();
  for (const [re, src] of SOURCE_RE) if (re.test(hay)) return src;
  return 'other';
}

// Haversine в метрах
function distM(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = d => d * Math.PI / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
  return R * 2 * Math.asin(Math.sqrt(a));
}

async function searchPvz(lon, lat) {
  const u = new URL('https://search-maps.yandex.ru/v1/');
  u.searchParams.set('text', 'пункт выдачи');
  u.searchParams.set('ll', `${lon},${lat}`);
  u.searchParams.set('spn', '0.024,0.018'); // ~1.4км × 1км в Москве
  u.searchParams.set('type', 'biz');
  u.searchParams.set('results', '50');
  u.searchParams.set('lang', 'ru_RU');
  u.searchParams.set('apikey', KEY);
  const r = await fetch(u, { headers: { 'User-Agent':'Mozilla/5.0' }});
  if (!r.ok) throw new Error(`Я.Поиск ${r.status}: ${(await r.text()).slice(0,200)}`);
  return r.json();
}

const { Pool } = pg;
const pool = new Pool({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function main() {
  const where = FORCE
    ? `r.lat is not null and r.lon is not null and r.status='active'`
    : `r.lat is not null and r.lon is not null and r.status='active'
       and (r.pvz_enriched_at is null or r.pvz_enriched_at < now() - interval '${STALE_DAYS} days')`;

  const { rows: rentals } = await pool.query(`
    select id, lat::float as lat, lon::float as lon, address
    from m_rentals r
    where ${where}
    order by r.id
    limit $1
  `, [LIMIT]);

  console.log(`пройду ${rentals.length} объявлений (radius=${RADIUS_M}м)`);
  let okN = 0, errN = 0, totalNew = 0;

  for (const r of rentals) {
    try {
      const j = await searchPvz(r.lon, r.lat);
      const features = (j.features || []);
      let near = []; // в радиусе RADIUS_M

      for (const f of features) {
        const cm = f.properties?.CompanyMetaData;
        if (!cm) continue;
        const [plon, plat] = f.geometry?.coordinates || [];
        if (!plat || !plon) continue;
        const d = distM(r.lat, r.lon, plat, plon);
        if (d > RADIUS_M) continue;

        const cats = (cm.Categories || []).map(c => c.name);
        const src = detectSource(cm.name, cats);
        const rating = f.properties?.businessRating?.score ?? null;
        const reviews = f.properties?.businessRating?.ratings ?? null;

        // upsert в m_points по ya_org_id
        await pool.query(`
          insert into m_points (source, source_id, name, address, lat, lon, ya_org_id,
                                ya_rating, ya_reviews, ya_url, categories, ya_enriched_at, raw, fetched_at)
          values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,now(),$12::jsonb,now())
          on conflict (ya_org_id) where ya_org_id is not null do update set
            name = excluded.name, address = excluded.address,
            lat = excluded.lat, lon = excluded.lon,
            ya_rating = excluded.ya_rating, ya_reviews = excluded.ya_reviews,
            ya_url = excluded.ya_url, categories = excluded.categories,
            source = excluded.source, ya_enriched_at = now(), raw = excluded.raw
        `, [
          src, cm.id || null, cm.name || null, cm.address || null, plat, plon, cm.id || null,
          rating, reviews, cm.url || null,
          JSON.stringify(cats),
          JSON.stringify({ properties: f.properties }),
        ]);

        near.push({ rating });
      }

      const ratings = near.map(n => n.rating).filter(x => typeof x === 'number');
      const avg = ratings.length ? ratings.reduce((a,b)=>a+b,0)/ratings.length : null;

      await pool.query(`
        update m_rentals
        set pvz_enriched_at = now(),
            pvz_count_1km   = $2,
            pvz_avg_rating  = $3
        where id = $1
      `, [r.id, near.length, avg ? avg.toFixed(2) : null]);

      totalNew += near.length;
      okN++;
      if (okN % 10 === 0) console.log(`  ${okN}/${rentals.length}  found=${totalNew}`);
    } catch (e) {
      errN++;
      console.error(`✗ rental#${r.id}: ${e.message}`);
      if (e.message.includes('403')) { console.error('останавливаюсь — ключ не работает'); break; }
    }
    await sleep(REQ_DELAY_MS);
  }

  console.log(`\n✓ обработано: ${okN}  ошибок: ${errN}  ПВЗ найдено суммарно: ${totalNew}`);
  await pool.end();
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
