// Обогащение m_rentals данными WB по точным координатам каждого объявления.
// Дёргает 3 публичных endpoint pvz-map-backend.wildberries.ru:
//   /api/v1/population/uncovered-by-point  → не покрыто людей
//   /api/v1/map/check-point                → зона/тариф/прибыль
//   /api/v1/turnover-predict               → предсказание оборота
//
// Запуск:
//   node scripts/enrich-wb.mjs            — все необогащённые
//   node scripts/enrich-wb.mjs --refresh  — все, перезаписать
//   node scripts/enrich-wb.mjs --limit 50

import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const arg = (k, def=null) => { const i=argv.indexOf(k); return i>=0 && argv[i+1] ? argv[i+1] : def; };
const flag = (k) => argv.includes(k);

const refresh = flag('--refresh');
const limit   = +(arg('--limit', '0'));
const delayMs = +(arg('--delay', '180'));
const concurrency = +(arg('--concurrency', '4'));

const API = 'https://pvz-map-backend.wildberries.ru';
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36',
  'Accept': 'application/json',
  'Origin': 'https://map.wb.ru', 'Referer': 'https://map.wb.ru/',
};
// дефолты RU из /api/v1/map/configs (для check-point расчётов)
const RU = { turnover: 6_000_000, rent: 50_000, salary: 70_000, other_expensive: 10_000 };

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();
await c.query(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function fetchJson(url, retries = 3) {
  for (let i=0; i<retries; i++) {
    try {
      const r = await fetch(url, { headers: HEADERS });
      if (!r.ok) {
        if (r.status === 429 || r.status >= 500) { await sleep(1000*(i+1)); continue; }
        return { error: `HTTP ${r.status}` };
      }
      return await r.json();
    } catch (e) { if (i === retries-1) return { error: String(e.message||e) }; await sleep(500*(i+1)); }
  }
}

async function enrich(rental) {
  const { id, lat, lon, area_m2 } = rental;
  if (!lat || !lon) return { ok:false, reason:'no coords' };
  const area = +area_m2 > 0 ? Math.min(Math.round(+area_m2), 200) : 50;

  // 1) population/uncovered-by-point
  const pop = await fetchJson(`${API}/api/v1/population/uncovered-by-point?longitude=${lon}&latitude=${lat}`);
  if (pop?.error) return { ok:false, reason: 'pop:'+pop.error };

  // 2) check-point
  const cpQs = new URLSearchParams({
    'point.longitude': lon, 'point.latitude': lat, area,
    turnover: RU.turnover, rent: RU.rent, salary: RU.salary, other_expensive: RU.other_expensive,
  });
  const cp = await fetchJson(`${API}/api/v1/map/check-point?${cpQs}`);

  // 3) turnover-predict
  const tpQs = new URLSearchParams({ 'point.longitude': lon, 'point.latitude': lat, area });
  const tp = await fetchJson(`${API}/api/v1/turnover-predict?${tpQs}`);

  const pi = cp?.point_info || {};
  const arr = tp?.turnover_year_prediction;
  const predicted = Array.isArray(arr) && arr.length
    ? Math.round(arr.reduce((a,b)=>a+(+b||0),0)/arr.length) : null;
  const turnoverFirst = Array.isArray(arr) && arr.length ? Math.round(+arr[0]) : null;
  const turnoverMax = Array.isArray(arr) && arr.length ? Math.round(Math.max(...arr.map(x => +x || 0))) : null;

  // Subsidy / Гарантированный доход
  const subsidiesArr = Array.isArray(pi.subsidies_info) ? pi.subsidies_info : [];
  const subsidyMain = pi.subsidy_info || subsidiesArr[0] || null;
  const subsidySize = subsidyMain?.subsidy_size != null ? +subsidyMain.subsidy_size : null;
  const subsidyText = subsidyMain?.subsidy_type_description || null;

  await c.query(`
    update m_rentals set
      wb_unserved_people    = $1,
      wb_all_people         = $2,
      wb_zone_type          = $3,
      wb_subsidy_type       = $4,
      wb_tariff_pct         = $5,
      wb_profit_rub         = $6,
      wb_reward_rub         = $7,
      wb_can_open           = $8,
      wb_min_area           = $9,
      wb_predicted_turnover = $10,
      wb_tariff_condition   = $11,
      wb_subsidy_size       = $12,
      wb_subsidy_text       = $13,
      wb_turnover_first     = $14,
      wb_turnover_max       = $15,
      wb_enriched_at        = now()
    where id = $16
  `, [
    +pop.unserved_people_count || 0,
    +pop.all_people_count || 0,
    pi.zone_info?.text_code || null,
    pi.subsidy_info?.text_code || subsidyMain?.subsidy_text_code || null,
    pi.tariff_info?.total_tariff ?? null,
    pi.tariff_info?.profit ?? null,
    pi.tariff_info?.reward ?? null,
    cp?.can_open ?? null,
    pi.area_info?.min_area ?? null,
    predicted,
    pi.tariff_info?.tariff_condition || null,
    subsidySize,
    subsidyText,
    turnoverFirst,
    turnoverMax,
    id,
  ]);
  return { ok:true };
}

const where = refresh
  ? 'where lat is not null and lon is not null'
  : 'where wb_enriched_at is null and lat is not null and lon is not null';
const lim = limit ? `limit ${limit}` : '';
const { rows } = await c.query(`select id, lat, lon, area_m2 from m_rentals ${where} order by id ${lim}`);

console.log(`→ обогащаю ${rows.length} объявлений (concurrency=${concurrency}, delay=${delayMs}ms)…`);

let ok=0, err=0, processed=0;
const t0 = Date.now();

async function worker(queue) {
  while (queue.length) {
    const r = queue.shift();
    const res = await enrich(r);
    if (res.ok) ok++; else err++;
    processed++;
    if (processed % 10 === 0 || processed === rows.length) {
      process.stdout.write(`\r  [${processed}/${rows.length}] ok=${ok} err=${err} (${((Date.now()-t0)/1000).toFixed(0)}с)`);
    }
    await sleep(delayMs);
  }
}

const queue = [...rows];
const workers = Array.from({ length: Math.min(concurrency, queue.length) }, () => worker(queue));
await Promise.all(workers);

console.log('');

const stats = await c.query(`
  select count(*) filter (where wb_enriched_at is not null) as enriched,
         count(*) filter (where wb_can_open=true) as can_open,
         count(*) filter (where wb_zone_type='priority_zone') as priority,
         count(*) filter (where wb_zone_type='green_zone') as green,
         count(*) filter (where wb_zone_type='red_zone') as red,
         max((wb_profit_rub - price_rub)::int) as best_net
  from m_rentals
`);
console.log('\n', stats.rows[0]);
await c.end();
console.log('готово.');
