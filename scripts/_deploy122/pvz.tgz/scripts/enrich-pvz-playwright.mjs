// Скрапим ПВЗ + рейтинги Я.Карт через playwright (без API ключа).
// Запуск: node --env-file=.env scripts/enrich-pvz-playwright.mjs [--limit N] [--force] [--concurrency 3]
import 'dotenv/config';
import pg from 'pg';
import pw from 'playwright-core';

const args = process.argv.slice(2);
const arg = (k, def) => { const i = args.indexOf(k); return i >= 0 && i+1 < args.length ? args[i+1] : def; };
const LIMIT = +(arg('--limit', '50'));
const CONCURRENCY = +(arg('--concurrency', '3'));
const FORCE = args.includes('--force');
const STALE_DAYS = 30;
const RADIUS_M = 1000;

const SOURCE_RE = [
  // Wildberries / Ozon — отдельный класс «постамат», когда явно автомат
  [/wildberries|вайлдбер/i, 'wb'],
  [/ozon|озон/i, 'ozon'],
  [/сдэк|cdek|sdek/i, 'sdek'],
  [/яндекс[^a-zа-я]*маркет/i, 'ya_market'],
  [/яндекс[^a-zа-я]*достав/i, 'ya_delivery'],
  [/5\s*post|5\s*пост/i, '5post'],
  [/boxberry|боксберри/i, 'boxberry'],
  [/\bpek\b|\bпэк\b/i, 'pek'],
  [/dpd/i, 'dpd'],
  [/халва|halva/i, 'halva'],
  [/сбер.*логист/i, 'sber_logistics'],
  [/pickpoint|пикпоинт/i, 'pickpoint'],
  [/постамат|postamat/i, 'postamat'],
];
const detectSource = (name='', cat='') => {
  const hay = (name + ' ' + cat).toLowerCase();
  for (const [re, s] of SOURCE_RE) if (re.test(hay)) return s;
  return 'other';
};
const parseRate = s => {
  if (!s) return null;
  const m = s.replace(',', '.').match(/(\d+(?:\.\d+)?)/);
  return m ? +m[1] : null;
};
const parseReviews = s => {
  if (!s) return null;
  const m = s.match(/(\d+)/);
  return m ? +m[0] : null;
};
const distM = (lat1, lon1, lat2, lon2) => {
  const R = 6371000, toRad = d => d * Math.PI / 180;
  const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
  return R * 2 * Math.asin(Math.sqrt(a));
};

const { Pool } = pg;
const pool = new Pool({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});

async function searchPvzByQuery(page, lat, lon, query) {
  const url = `https://yandex.ru/maps/?ll=${lon},${lat}&z=16&text=${encodeURIComponent(query)}`;
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 });
  await page.waitForTimeout(1500);
  // Прокручиваем sidebar чтобы догрузить все snippet-ы (yandex использует виртуализацию)
  await page.evaluate(async () => {
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    // Найдём контейнер списка результатов
    const candidates = [
      ...document.querySelectorAll('[class*="search-list-view"]'),
      ...document.querySelectorAll('[class*="scroll__container"]'),
      ...document.querySelectorAll('[class*="sidebar"] [class*="scroll"]'),
    ];
    const scroller = candidates.find(el => el.scrollHeight > el.clientHeight + 50);
    if (!scroller) return;
    let prev = 0, same = 0;
    for (let i = 0; i < 8; i++) {
      scroller.scrollTop = scroller.scrollHeight;
      await sleep(350);
      const cur = document.querySelectorAll('li[class*="search-snippet-view"]').length;
      if (cur === prev) { same++; if (same >= 2) break; } else same = 0;
      prev = cur;
    }
  });
  await page.waitForTimeout(500);
  const items = await page.evaluate(() => {
    const cards = [...document.querySelectorAll('li[class*="search-snippet-view"]')];
    return cards.map(el => {
      const name = el.querySelector('[class*="search-business-snippet-view__title"]')?.textContent?.trim();
      const addr = el.querySelector('[class*="search-business-snippet-view__address"]')?.textContent?.trim();
      const cat  = el.querySelector('[class*="search-business-snippet-view__category"]')?.textContent?.trim();
      const reviews = el.querySelector('[class*="business-rating-amount-view"]')?.textContent?.trim();
      const link = el.querySelector('a[href*="/maps/org/"]')?.href;
      return { name, addr, cat, reviews, link };
    }).filter(x => x.name && x.link);
  });
  return items;
}

// Поиск по нескольким брендовым запросам — Я.Карты по «пункт выдачи»
// возвращают далеко не все WB/Ozon, нужны отдельные запросы.
async function searchPvzNear(page, lat, lon) {
  const queries = ['wildberries пвз', 'ozon пвз', 'яндекс маркет пвз', 'пункт выдачи', 'постамат', 'pickpoint'];
  const all = [];
  for (const q of queries) {
    try {
      const items = await searchPvzByQuery(page, lat, lon, q);
      all.push(...items);
    } catch (e) { /* skip */ }
  }
  // Дедуп по link
  const seen = new Set();
  return all.filter(i => { if (seen.has(i.link)) return false; seen.add(i.link); return true; });
}

async function enrichOrgPage(page, link) {
  await page.goto(link, { waitUntil: 'domcontentloaded', timeout: 15000 });
  await page.waitForTimeout(800);
  const finalUrl = page.url();
  const m = finalUrl.match(/[?&]ll=([\d.]+)(?:%2C|,)([\d.]+)/);
  const lon = m ? +m[1] : null;
  const lat = m ? +m[2] : null;
  const data = await page.evaluate(() => {
    const rate = document.querySelector('[class*="business-rating-badge-view__rating-text"], span[itemprop="ratingValue"]')?.textContent?.trim();
    const reviews = document.querySelector('[class*="business-rating-amount-view"]')?.textContent?.trim();
    const cat  = document.querySelector('[class*="orgpage-categories"] a')?.textContent?.trim();
    const name = document.querySelector('h1[class*="orgpage-header-view__header"], h1')?.textContent?.trim();
    const addr = document.querySelector('a[class*="business-contacts-view__address-link"], [class*="orgpage-header-view__address"]')?.textContent?.trim();
    return { rate, reviews, cat, name, addr };
  });
  return { lat, lon, ...data };
}

async function processRental(browser, r) {
  const page = await browser.newPage({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    locale: 'ru-RU',
  });
  let pvzList = [];
  try {
    const list = await searchPvzNear(page, r.lat, r.lon);
    // Берём первые 30 — в радиусе 1км больше обычно не бывает
    for (const it of list.slice(0, 30)) {
      try {
        const det = await enrichOrgPage(page, it.link);
        if (!det.lat || !det.lon) continue;
        const d = distM(r.lat, r.lon, det.lat, det.lon);
        if (d > RADIUS_M) continue;
        const orgIdMatch = it.link.match(/\/(\d+)\/?$/);
        pvzList.push({
          ya_org_id: orgIdMatch ? orgIdMatch[1] : null,
          ya_url: it.link.split('?')[0],
          name: det.name || it.name,
          address: det.addr || it.addr,
          category: det.cat || it.cat,
          source: detectSource(det.name || it.name, det.cat || it.cat),
          ya_rating: parseRate(det.rate),
          ya_reviews: parseReviews(det.reviews || it.reviews),
          lat: det.lat, lon: det.lon,
          distance_m: Math.round(d),
        });
      } catch (e) { /* пропускаем сбойную карточку */ }
    }
    // Upsert в m_points
    for (const p of pvzList) {
      if (!p.ya_org_id) continue;
      await pool.query(`
        insert into m_points (source, source_id, name, address, lat, lon, ya_org_id,
                              ya_rating, ya_reviews, ya_url, categories, ya_enriched_at, fetched_at)
        values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,now(),now())
        on conflict (ya_org_id) where ya_org_id is not null do update set
          name = excluded.name, address = excluded.address,
          lat = excluded.lat, lon = excluded.lon,
          ya_rating = excluded.ya_rating, ya_reviews = excluded.ya_reviews,
          ya_url = excluded.ya_url, categories = excluded.categories,
          source = excluded.source, ya_enriched_at = now()
      `, [
        p.source, p.ya_org_id, p.name, p.address, p.lat, p.lon, p.ya_org_id,
        p.ya_rating, p.ya_reviews, p.ya_url, JSON.stringify([p.category].filter(Boolean)),
      ]);
    }
    const ratings = pvzList.map(x => x.ya_rating).filter(x => typeof x === 'number');
    const avg = ratings.length ? ratings.reduce((a,b)=>a+b,0)/ratings.length : null;
    await pool.query(`
      update m_rentals set pvz_enriched_at = now(), pvz_count_1km = $2, pvz_avg_rating = $3
      where id = $1
    `, [r.id, pvzList.length, avg ? avg.toFixed(2) : null]);
  } finally {
    await page.close();
  }
  return pvzList.length;
}

async function main() {
  // Обрабатываем только те объявления, что реально показываются на вкладке «Аренда»:
  // активные + не mismatch (исключённые из выдачи). Лайкнутые включены.
  const baseWhere = `lat is not null and lon is not null and status='active'
                     and coalesce(district_mismatch, false) = false`;
  const where = FORCE
    ? baseWhere
    : `${baseWhere} and (pvz_enriched_at is null or pvz_enriched_at < now() - interval '${STALE_DAYS} days')`;
  const { rows } = await pool.query(`
    select id, lat::float as lat, lon::float as lon, address
    from m_rentals where ${where}
    order by
      -- ПРИОРИТЕТ: то что юзер реально видит в «Аренде» по дефолту (floor=1, 100–300 м²)
      case when floor_no = 1 and area_m2 between 100 and 300 then 0 else 1 end,
      liked desc nulls last,
      id
    limit $1
  `, [LIMIT]);

  console.log(`Объявлений к обработке: ${rows.length}, concurrency=${CONCURRENCY}`);
  const browser = await pw.chromium.launch({ headless: true });

  let okN = 0, errN = 0, totalPvz = 0;
  // Очередь с параллелизмом
  let idx = 0;
  async function worker(id) {
    while (idx < rows.length) {
      const my = idx++;
      const r = rows[my];
      try {
        const n = await processRental(browser, r);
        totalPvz += n;
        okN++;
        console.log(`  [w${id}] #${r.id}  ${(r.address||'').slice(0,40)}  → ${n} ПВЗ  (${okN}/${rows.length})`);
      } catch (e) {
        errN++;
        console.error(`  ✗ #${r.id}: ${e.message.slice(0,120)}`);
      }
    }
  }
  await Promise.all(Array.from({length: CONCURRENCY}, (_, i) => worker(i+1)));

  console.log(`\n✓ обработано: ${okN}  ошибок: ${errN}  ПВЗ суммарно: ${totalPvz}`);
  await browser.close();
  await pool.end();
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
