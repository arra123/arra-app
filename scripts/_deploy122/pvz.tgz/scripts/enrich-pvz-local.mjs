// Локальное обогащение m_rentals.pvz_count_1km / pvz_avg_rating
// прямо из m_points (без внешнего API). Считает один SQL запрос,
// обновляет всю таблицу за раз.
//
// Запуск: node --env-file=.env scripts/enrich-pvz-local.mjs

import 'dotenv/config';
import pg from 'pg';

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();

console.log('→ считаем pvz_count_1km и pvz_avg_rating для всех rentals…');
const t0 = Date.now();

// На каждое объявление считаем число точек в радиусе 1км и средний рейтинг.
// bbox-предфильтр для скорости (без него планировщик умрёт на 4000 rentals × 12000 points).
const r = await c.query(`
  with stats as (
    select r.id,
      count(p.id)::int as cnt,
      avg(nullif(p.ya_rating,0))::numeric(3,2) as avg_rate
    from m_rentals r
    left join m_points p
      on p.lat is not null and p.lon is not null
     and p.lat::float between r.lat::float - 0.012 and r.lat::float + 0.012
     and p.lon::float between r.lon::float - 0.020 and r.lon::float + 0.020
     and 6371000 * 2 * asin(sqrt(power(sin(radians((r.lat::float - p.lat::float)/2)),2)
       + cos(radians(r.lat::float))*cos(radians(p.lat::float))*power(sin(radians((r.lon::float - p.lon::float)/2)),2))) <= 1000
    where r.status='active' and r.lat is not null and r.lon is not null
    group by r.id
  )
  update m_rentals m
  set pvz_count_1km = s.cnt,
      pvz_avg_rating = s.avg_rate,
      pvz_enriched_at = now()
  from stats s
  where m.id = s.id
  returning m.id
`);
console.log(`✓ обновлено ${r.rowCount} rentals за ${Date.now()-t0}ms`);

// Сводка
const sum = await c.query(`
  select
    count(*) filter (where pvz_count_1km is not null)::int as enriched,
    count(*) filter (where pvz_count_1km = 0)::int as zero,
    avg(pvz_count_1km)::numeric(6,2) as avg_count,
    max(pvz_count_1km) as max_count
  from m_rentals where status='active'
`);
console.log('сводка:', sum.rows[0]);

await c.end();
