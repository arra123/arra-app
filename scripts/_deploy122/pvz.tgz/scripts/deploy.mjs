// Deploy на 5.42.102.133 через программный SSH (ssh2 npm).
// Запуск: node scripts/deploy.mjs

import { Client } from 'ssh2';
import { readFileSync, statSync, createReadStream } from 'node:fs';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

const HOST = '193.233.136.213';
const USER = 'root';
const PASS = '4DWdXbMLr375';
const APP_DIR = '/opt/pvz';
const APP_PORT = 3001;

console.log('[1/6] упаковка проекта…');
const TAR = join(ROOT, '.pvz-deploy.tar.gz');
execSync(
  `tar --force-local --exclude=node_modules --exclude=.env --exclude=.git --exclude=.wb-state --exclude=.av-state.json --exclude=.av-debug.html --exclude=.av-detail-debug.html -czf ".pvz-deploy.tar.gz" CLAUDE.md README.md package.json package-lock.json server.mjs db scripts site notes`,
  { cwd: ROOT, stdio: 'inherit' }
);
console.log('  tarball size:', (statSync(TAR).size / 1024).toFixed(0), 'KB');

const conn = new Client();

function run(cmd, label) {
  return new Promise((resolve, reject) => {
    if (label) console.log(label);
    conn.exec(cmd, (err, stream) => {
      if (err) return reject(err);
      let stdout = '', stderr = '';
      stream.on('data', d => { stdout += d; process.stdout.write(d); });
      stream.stderr.on('data', d => { stderr += d; process.stderr.write(d); });
      stream.on('close', (code) => {
        if (code !== 0) reject(new Error(`exit ${code}: ${stderr}`));
        else resolve(stdout);
      });
    });
  });
}

function sftpUpload(local, remote) {
  return new Promise((resolve, reject) => {
    conn.sftp((err, sftp) => {
      if (err) return reject(err);
      const total = statSync(local).size;
      let uploaded = 0;
      const ws = sftp.createWriteStream(remote);
      const rs = createReadStream(local);
      rs.on('data', c => {
        uploaded += c.length;
        process.stdout.write(`\r  uploaded ${(uploaded/1024).toFixed(0)}/${(total/1024).toFixed(0)} KB`);
      });
      ws.on('close', () => { console.log(''); resolve(); });
      ws.on('error', reject);
      rs.pipe(ws);
    });
  });
}

conn.on('ready', async () => {
  try {
    console.log('[2/6] копирую tarball на сервер…');
    await sftpUpload(TAR, '/tmp/pvz-deploy.tar.gz');

    console.log('[3/6] копирую .env…');
    await sftpUpload(join(ROOT, '.env'), '/tmp/pvz.env');

    console.log('[4/6] установка/обновление Node 24…');
    await run(`if ! command -v node >/dev/null || [ "$(node -v | cut -d. -f1 | tr -d 'v')" -lt 24 ]; then curl -fsSL https://deb.nodesource.com/setup_24.x | bash - && apt-get install -y nodejs; else node --version; fi`);

    console.log('[5/6] разворачиваю…');
    await run(`
      mkdir -p ${APP_DIR} && cd ${APP_DIR} &&
      tar xzf /tmp/pvz-deploy.tar.gz &&
      mv -f /tmp/pvz.env ${APP_DIR}/.env && chmod 600 ${APP_DIR}/.env &&
      npm install --omit=dev --no-fund --no-audit
    `);

    console.log('[6/6] systemd unit + restart…');
    await run(`cat > /etc/systemd/system/pvz.service <<'UNIT'
[Unit]
Description=PVZ
After=network.target

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/.env
ExecStart=/usr/bin/node ${APP_DIR}/server.mjs
Restart=always
RestartSec=5
StandardOutput=append:/var/log/pvz.log
StandardError=append:/var/log/pvz.log

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload && systemctl enable pvz && systemctl restart pvz`);

    await new Promise(r => setTimeout(r, 2000));
    console.log('--- статус ---');
    await run(`systemctl status pvz --no-pager | head -10`);
    await run(`curl -s http://localhost:${APP_PORT}/api/health || echo HEALTH_FAIL`);
    await run(`ufw allow ${APP_PORT}/tcp 2>/dev/null; firewall-cmd --permanent --add-port=${APP_PORT}/tcp 2>/dev/null && firewall-cmd --reload 2>/dev/null; iptables -I INPUT -p tcp --dport ${APP_PORT} -j ACCEPT 2>/dev/null; true`);

    console.log('\n✓ deploy готов: http://' + HOST + ':' + APP_PORT);
    conn.end();
  } catch (e) {
    console.error('FAIL:', e.message);
    conn.end();
    process.exit(1);
  }
});
conn.on('error', e => { console.error('SSH error:', e.message); process.exit(1); });

console.log('→ ssh root@' + HOST + '…');
conn.connect({ host: HOST, port: 22, username: USER, password: PASS, readyTimeout: 30000 });
