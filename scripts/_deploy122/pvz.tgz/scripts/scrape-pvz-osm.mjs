// Парсер ПВЗ из OpenStreetMap через Overpass API.
// Дополняет m_points точками, которые Yandex.Maps пропустила.
// Каждый brand=Wildberries|Ozon|... в bbox Москвы+ближнего МО.
//
// Запуск: node --env-file=.env scripts/scrape-pvz-osm.mjs

import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Зона: ≤30 км от центра МСК. bbox по lat/lon.
const BBOX = { south: 55.500, west: 37.130, north: 55.985, east: 37.985 };

// Бренды → source. Регулярки по name/brand/operator.
const BRAND_RULES = [
  { src:'wb',             re:/(wildberries|вайлдбер|вб\b)/i },
  { src:'ozon',           re:/(\bozon\b|озон)/i },
  { src:'ya_market',      re:/(яндекс.*маркет|yandex.*market)/i },
  { src:'5post',          re:/(5\s*post|5\s*пост)/i },
  { src:'sdek',           re:/(сдэк|cdek|sdek)/i },
  { src:'boxberry',       re:/(boxberry|боксберри)/i },
  { src:'pickpoint',      re:/(pickpoint|пикпоинт)/i },
  { src:'halva',          re:/(халва|halva)/i },
  { src:'sber_logistics', re:/(сбер.*логист)/i },
  { src:'dpd',            re:/dpd/i },
  { src:'pek',            re:/(\bпэк\b|\bpek\b)/i },
];
function detect(name='', brand='', operator='') {
  const h = (brand + ' ' + name + ' ' + operator).toLowerCase();
  for (const r of BRAND_RULES) if (r.re.test(h)) return r.src;
  return null;
}

function buildQuery() {
  const { south, west, north, east } = BBOX;
  const bb = `${south},${west},${north},${east}`;
  // Берём всё что выглядит как ПВЗ/постамат/доставка по brand или name. Ноды и точки на way/relation.
  return `[out:json][timeout:90];
(
  node["brand"~"Wildberries|Ozon|Озон|СДЭК|CDEK|Boxberry|5Post|Pickpoint|PickPoint|Яндекс.Маркет|Yandex.Market|Халва|Сбер|DPD|ПЭК|PEK",i](${bb});
  node["name"~"Wildberries|вайлдбер|Ozon|Озон|СДЭК|CDEK|Boxberry|5Post|Pickpoint|Яндекс.Маркет|Халва|Сбер.*Логист|DPD|ПЭК",i](${bb});
  node["amenity"="parcel_locker"](${bb});
  node["shop"="convenience"]["brand"~"Wildberries|Ozon|Яндекс|СДЭК|Boxberry|5Post",i](${bb});
);
out body;`;
}

async function fetchOverpass() {
  const endpoints = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
    'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
  ];
  const q = buildQuery();
  for (const ep of endpoints) {
    // GET-вариант с ?data=… — наиболее совместим
    try {
      const url = ep + '?data=' + encodeURIComponent(q);
      const r = await fetch(url, {
        headers: {
          'User-Agent': 'pvz-research/1.0 (jamieskipper305@gmail.com)',
          'Accept': 'application/json',
        },
      });
      if (!r.ok) { console.warn(`  GET ${ep} → HTTP ${r.status}`); }
      else {
        const j = await r.json();
        console.log(`  GET ${ep}: ${j.elements?.length||0} элементов`);
        return j;
      }
    } catch (e) { console.warn(`  GET ${ep} → ${e.message}`); }
    // POST-вариант для overpass-api.de
    try {
      const r = await fetch(ep, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/plain;charset=utf-8',
          'User-Agent': 'pvz-research/1.0 (jamieskipper305@gmail.com)',
          'Accept': 'application/json',
        },
        body: q,
      });
      if (!r.ok) { console.warn(`  POST ${ep} → HTTP ${r.status}`); continue; }
      const j = await r.json();
      console.log(`  POST ${ep}: ${j.elements?.length||0} элементов`);
      return j;
    } catch (e) { console.warn(`  POST ${ep} → ${e.message}`); }
  }
  throw new Error('все Overpass-endpoint-ы недоступны');
}

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();
await c.query(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));

const { rows: cities } = await c.query(`select id from m_cities where name='Москва' limit 1`);
const cityId = cities[0]?.id;

console.log('→ OSM Overpass запрос…');
const t0 = Date.now();
const json = await fetchOverpass();
const els = (json.elements || []).filter(e => e.type === 'node' && e.lat != null && e.lon != null);
console.log(`получено ${els.length} нод`);

// Преобразуем в точки
let mapped = 0, skipped = 0, byNoSrc = 0;
const items = [];
for (const e of els) {
  const t = e.tags || {};
  const name = t.name || t['name:ru'] || '';
  const brand = t.brand || t['brand:ru'] || '';
  const op = t.operator || '';
  const src = detect(name, brand, op);
  if (!src) { byNoSrc++; continue; }
  // адрес из тегов addr:*
  const addr = [t['addr:street'], t['addr:housenumber']].filter(Boolean).join(', ') || null;
  items.push({
    source: src,
    source_id: 'osm/' + e.id,
    name: name || brand || src,
    address: addr,
    lat: e.lat,
    lon: e.lon,
    raw: { osm: e },
  });
}
console.log(`распознано: ${items.length}, без бренда: ${byNoSrc}`);

// Заливаем всё в temp-таблицу одним батчем, потом дедуп через NOT EXISTS на уровне SQL.
console.log('заливаю в TEMP-таблицу…');
await c.query(`drop table if exists tmp_osm_pts`);
await c.query(`create temp table tmp_osm_pts(
  source text, source_id text, name text, address text,
  lat numeric(10,7), lon numeric(10,7), raw jsonb
)`);
const BATCH = 500;
for (let i = 0; i < items.length; i += BATCH) {
  const chunk = items.slice(i, i + BATCH);
  const vals = []; const ph = [];
  chunk.forEach((it, idx) => {
    const o = idx * 7;
    ph.push(`($${o+1},$${o+2},$${o+3},$${o+4},$${o+5},$${o+6},$${o+7}::jsonb)`);
    vals.push(it.source, it.source_id, it.name, it.address, it.lat, it.lon, JSON.stringify(it.raw));
  });
  await c.query(`insert into tmp_osm_pts(source, source_id, name, address, lat, lon, raw) values ${ph.join(',')}`, vals);
  process.stdout.write(`\r  ${Math.min(i+BATCH, items.length)}/${items.length}`);
}
console.log('');

// SQL-дедуп: вставляем только те, у которых нет m_points того же source в 50м
console.log('дедуп + insert…');
const ins = await c.query(`
  insert into m_points(source, source_id, name, address, city_id, lat, lon, raw)
  select t.source, t.source_id, t.name, t.address, $1, t.lat, t.lon, t.raw
  from tmp_osm_pts t
  where not exists (
    select 1 from m_points p
    where p.source = t.source
      and p.lat::float between t.lat - 0.0006 and t.lat + 0.0006
      and p.lon::float between t.lon - 0.0010 and t.lon + 0.0010
      and 6371000 * 2 * asin(sqrt(power(sin(radians((t.lat - p.lat::float)/2)),2)
        + cos(radians(t.lat))*cos(radians(p.lat::float))*power(sin(radians((t.lon - p.lon::float)/2)),2))) < 50
  )
  on conflict (source, source_id) where source_id is not null do nothing
  returning id
`, [cityId]);
const inserted = ins.rowCount;
const dup = items.length - inserted;

console.log(`\n✓ OSM: вставлено ${inserted}, дубли/пропуск ${dup}, всего ${items.length}, время ${Date.now()-t0}ms`);

// Краткая сводка по source
const sum = await c.query(`
  select source, count(*)::int as n
  from m_points
  where source_id like 'osm/%'
  group by source order by n desc
`);
console.log('OSM-точки в БД:', sum.rows);

await c.end();
