// Grid-скрап ПВЗ по сетке точек bbox ЗАО+СЗАО Москвы.
// Заполняет m_points без привязки к объявлениям, чтобы потом любое объявление
// в радиусе 1км получало ПВЗ из кэша.
// Запуск: node --env-file=.env scripts/scrape-pvz-grid.mjs [--concurrency 3]
import 'dotenv/config';
import pg from 'pg';
import pw from 'playwright-core';

const args = process.argv.slice(2);
const arg = (k, def) => { const i = args.indexOf(k); return i >= 0 && i+1 < args.length ? args[i+1] : def; };
const CONCURRENCY = +(arg('--concurrency', '3'));

// bbox по умолчанию — ЗАО+СЗАО Москвы. Перезаписывается флагами --lat-min/-max и --lon-min/-max.
const BBOX = {
  latMin: +arg('--lat-min', '55.685'),
  latMax: +arg('--lat-max', '55.870'),
  lonMin: +arg('--lon-min', '37.290'),
  lonMax: +arg('--lon-max', '37.580'),
};
// Шаг сетки в градусах (по умолчанию ~1км × ~1км). Для МО можно крупнее.
const STEP_LAT = +arg('--step-lat', '0.009');
const STEP_LON = +arg('--step-lon', '0.016');

const SOURCE_RE = [
  [/wildberries|вайлдбер/i, 'wb'],
  [/ozon|озон/i, 'ozon'],
  [/сдэк|cdek|sdek/i, 'sdek'],
  [/яндекс[^a-zа-я]*маркет/i, 'ya_market'],
  [/яндекс[^a-zа-я]*достав/i, 'ya_delivery'],
  [/5\s*post|5\s*пост/i, '5post'],
  [/boxberry|боксберри/i, 'boxberry'],
  [/\bpek\b|\bпэк\b/i, 'pek'],
  [/dpd/i, 'dpd'],
  [/халва|halva/i, 'halva'],
  [/сбер.*логист/i, 'sber_logistics'],
  [/pickpoint|пикпоинт/i, 'pickpoint'],
  [/постамат|postamat/i, 'postamat'],
];
const detectSource = (n='', c='') => {
  const h = (n + ' ' + c).toLowerCase();
  for (const [re, s] of SOURCE_RE) if (re.test(h)) return s;
  return 'other';
};
const parseRate = s => { if (!s) return null; const m = s.replace(',', '.').match(/(\d+(?:\.\d+)?)/); return m ? +m[1] : null; };
const parseReviews = s => { if (!s) return null; const m = s.match(/(\d+)/); return m ? +m[0] : null; };

const { Pool } = pg;
const pool = new Pool({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false, max: 10,
});

async function searchByQuery(page, lat, lon, q) {
  const url = `https://yandex.ru/maps/?ll=${lon},${lat}&z=16&text=${encodeURIComponent(q)}`;
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 });
  await page.waitForTimeout(1500);
  await page.evaluate(async () => {
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const sc = [...document.querySelectorAll('[class*="search-list-view"], [class*="scroll__container"]')]
      .find(el => el.scrollHeight > el.clientHeight + 50);
    if (!sc) return;
    let prev = 0, same = 0;
    for (let i = 0; i < 25; i++) {
      sc.scrollTop = sc.scrollHeight;
      await sleep(450);
      const cur = document.querySelectorAll('li[class*="search-snippet-view"]').length;
      if (cur === prev) { same++; if (same >= 3) break; } else same = 0;
      prev = cur;
    }
  });
  await page.waitForTimeout(400);
  return page.evaluate(() => {
    return [...document.querySelectorAll('li[class*="search-snippet-view"]')]
      .map(el => ({
        name: el.querySelector('[class*="search-business-snippet-view__title"]')?.textContent?.trim(),
        addr: el.querySelector('[class*="search-business-snippet-view__address"]')?.textContent?.trim(),
        cat:  el.querySelector('[class*="search-business-snippet-view__category"]')?.textContent?.trim(),
        reviews: el.querySelector('[class*="business-rating-amount-view"]')?.textContent?.trim(),
        link: el.querySelector('a[href*="/maps/org/"]')?.href,
      }))
      .filter(x => x.name && x.link);
  });
}

async function searchAround(page, lat, lon) {
  // Чистые имена брендов (без «пвз») часто дают больше snippet'ов в выдаче
  const queries = ['wildberries', 'ozon', 'яндекс маркет', 'пункт выдачи', 'постамат', 'pickpoint', '5post'];
  const all = [];
  for (const q of queries) {
    try { all.push(...await searchByQuery(page, lat, lon, q)); } catch {}
  }
  const seen = new Set();
  return all.filter(i => { if (seen.has(i.link)) return false; seen.add(i.link); return true; });
}

async function enrichOrg(page, link) {
  await page.goto(link, { waitUntil: 'domcontentloaded', timeout: 15000 });
  await page.waitForTimeout(700);
  const finalUrl = page.url();
  const m = finalUrl.match(/[?&]ll=([\d.]+)(?:%2C|,)([\d.]+)/);
  const lon = m ? +m[1] : null, lat = m ? +m[2] : null;
  const data = await page.evaluate(() => ({
    rate: document.querySelector('[class*="business-rating-badge-view__rating-text"], span[itemprop="ratingValue"]')?.textContent?.trim(),
    reviews: document.querySelector('[class*="business-rating-amount-view"]')?.textContent?.trim(),
    cat:  document.querySelector('[class*="orgpage-categories"] a')?.textContent?.trim(),
    name: document.querySelector('h1[class*="orgpage-header-view__header"], h1')?.textContent?.trim(),
    addr: document.querySelector('a[class*="business-contacts-view__address-link"], [class*="orgpage-header-view__address"]')?.textContent?.trim(),
  }));
  return { lat, lon, ...data };
}

async function processCell(browser, cell, alreadySeen) {
  const page = await browser.newPage({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    locale: 'ru-RU',
  });
  let n = 0;
  try {
    const list = await searchAround(page, cell.lat, cell.lon);
    for (const it of list) {
      const orgIdMatch = it.link.match(/\/(\d+)\/?$/);
      const orgId = orgIdMatch ? orgIdMatch[1] : null;
      if (!orgId || alreadySeen.has(orgId)) continue;
      try {
        const det = await enrichOrg(page, it.link);
        if (!det.lat || !det.lon) continue;
        const src = detectSource(det.name || it.name, det.cat || it.cat);
        await pool.query(`
          insert into m_points (source, source_id, name, address, lat, lon, ya_org_id,
                                ya_rating, ya_reviews, ya_url, categories, ya_enriched_at, fetched_at)
          values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,now(),now())
          on conflict (ya_org_id) where ya_org_id is not null do update set
            name = excluded.name, address = excluded.address,
            lat = excluded.lat, lon = excluded.lon,
            ya_rating = excluded.ya_rating, ya_reviews = excluded.ya_reviews,
            ya_url = excluded.ya_url, categories = excluded.categories,
            source = excluded.source, ya_enriched_at = now()
        `, [
          src, orgId, det.name || it.name, det.addr || it.addr, det.lat, det.lon, orgId,
          parseRate(det.rate), parseReviews(det.reviews || it.reviews),
          it.link.split('?')[0],
          JSON.stringify([det.cat || it.cat].filter(Boolean)),
        ]);
        alreadySeen.add(orgId);
        n++;
      } catch {}
    }
  } finally {
    await page.close();
  }
  return n;
}

async function main() {
  const cells = [];
  for (let lat = BBOX.latMin; lat <= BBOX.latMax; lat += STEP_LAT) {
    for (let lon = BBOX.lonMin; lon <= BBOX.lonMax; lon += STEP_LON) {
      cells.push({ lat: +lat.toFixed(5), lon: +lon.toFixed(5) });
    }
  }
  console.log(`Сетка: ${cells.length} точек, шаг ~1км, concurrency=${CONCURRENCY}`);

  // Уже виденные org_id (чтобы не дублировать запросы на одну и ту же организацию)
  const seen = new Set();
  const r0 = await pool.query('select ya_org_id from m_points where ya_org_id is not null');
  for (const row of r0.rows) seen.add(row.ya_org_id);
  console.log(`m_points уже содержит ${seen.size} ПВЗ — будут пропускаться при повторе.`);

  const browser = await pw.chromium.launch({ headless: true });
  let okN = 0, errN = 0, totalNew = 0;
  let idx = 0;
  async function worker(id) {
    while (idx < cells.length) {
      const my = idx++;
      const c = cells[my];
      try {
        const beforeSize = seen.size;
        const found = await processCell(browser, c, seen);
        const newOnes = seen.size - beforeSize;
        totalNew += newOnes;
        okN++;
        if (okN % 5 === 0 || newOnes > 0) {
          console.log(`  [w${id}] (${okN}/${cells.length}) ll=${c.lon},${c.lat}  +${newOnes} новых ПВЗ  всего m_points: ${seen.size}`);
        }
      } catch (e) {
        errN++;
        console.error(`  ✗ [w${id}] ll=${c.lon},${c.lat}: ${e.message.slice(0,100)}`);
      }
    }
  }
  await Promise.all(Array.from({length: CONCURRENCY}, (_, i) => worker(i+1)));

  console.log(`\n✓ обработано ячеек: ${okN}  ошибок: ${errN}  новых ПВЗ: ${totalNew}  итого m_points: ${seen.size}`);
  await browser.close();
  await pool.end();
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
