// Парсер коммерческой аренды с realty.yandex.ru через Playwright headless.
// Запуск: node scripts/scan-yarealty.mjs --pages 5 [--city Москва]

import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const argv = process.argv.slice(2);
const arg = (k, def=null) => { const i=argv.indexOf(k); return i>=0 && argv[i+1] ? argv[i+1] : def; };

const pages = +(arg('--pages', '3'));
const cityName = arg('--city', 'Москва');
const delayMs = +(arg('--delay', '2000'));

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();
await c.query(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));

const sleep = ms => new Promise(r => setTimeout(r, ms));

const { chromium } = await import('playwright');
const browser = await chromium.launch({ headless: true, args: ['--disable-blink-features=AutomationControlled','--no-sandbox'] });
const ctx = await browser.newContext({
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
  locale: 'ru-RU', viewport:{width:1366,height:900},
});
await ctx.addInitScript(() => { Object.defineProperty(navigator,'webdriver',{get:()=>undefined}) });
const page = await ctx.newPage();

const baseURL = 'https://realty.yandex.ru/moskva/snyat/kommercheskaya-nedvizhimost/';
const { rows: cities } = await c.query('select id from m_cities where name=$1', [cityName]);
const cityId = cities[0]?.id;
if (!cityId) { console.error('no city'); process.exit(1); }

console.log(`→ Я.Недвижимость · ${cityName} · ${pages} стр.`);
let saved = 0;
const t0 = Date.now();

for (let p = 1; p <= pages; p++) {
  const url = baseURL + (p > 1 ? `?page=${p}` : '');
  try {
    await page.goto(url, { waitUntil:'domcontentloaded', timeout:30000 });
    await page.waitForSelector('.OffersSerpItem, .OfferSerpItem, [class*="OfferSerp"]', { timeout:8000 }).catch(()=>{});
    await page.waitForTimeout(1500);

    const offers = await page.evaluate(() => {
      const results = [];
      // ищем ссылки на /offer/<id>/ и тащим окружение
      document.querySelectorAll('a[href*="/offer/"]').forEach(a => {
        const m = a.href.match(/\/offer\/(\d+)\//);
        if (!m) return;
        const id = m[1];
        if (results.some(r => r.id === id)) return;
        // ближайший Card-контейнер
        let card = a;
        for (let i=0;i<8;i++){ if (!card.parentElement) break; card = card.parentElement;
          if (card.className && card.className.toString().match(/OffersSerp|OfferCard|OfferSerp|SerpItem/i)) break;
        }
        const text = card.innerText || '';
        // цена
        const priceMatch = text.match(/(\d[\d\s]+)\s*₽\s*\/?\s*(?:в\s*мес|мес)/i) || text.match(/(\d[\d\s]+)\s*₽/);
        const price = priceMatch ? +priceMatch[1].replace(/\s/g,'') : null;
        // площадь
        const areaMatch = text.match(/(\d+(?:[.,]\d+)?)\s*м²/i);
        const area = areaMatch ? +areaMatch[1].replace(',','.') : null;
        // адрес
        const addrEl = card.querySelector('[class*="Address"], [class*="address"]');
        const address = addrEl ? addrEl.innerText.trim() : '';
        // фото
        const img = card.querySelector('img');
        const photo = img ? img.src : null;
        results.push({ id, url:a.href, address, price, area, photo, raw:text.slice(0,500) });
      });
      return results;
    });

    let pageSaved = 0;
    for (const o of offers) {
      if (!o.price || !o.area) continue;
      const ppm = +(o.price/o.area).toFixed(2);
      try {
        await c.query(`
          insert into m_rentals(source, source_id, title, address, city_id, lat, lon, area_m2, price_rub, price_per_m2, url, status, photos, raw)
          values('yandex', $1, $2, $3, $4, NULL, NULL, $5, $6, $7, $8, 'active', $9::jsonb, $10::jsonb)
          on conflict (source, source_id) do update set
            address=excluded.address, area_m2=excluded.area_m2, price_rub=excluded.price_rub,
            price_per_m2=excluded.price_per_m2, url=excluded.url, status='active', fetched_at=now()
        `, [o.id, ('Я.Недвижимость '+o.area+'м²').slice(0,250), o.address, cityId, o.area, o.price, ppm, o.url, JSON.stringify(o.photo?[o.photo]:[]), JSON.stringify(o)]);
        pageSaved++; saved++;
      } catch (e) { /* skip */ }
    }
    console.log(`  стр.${p}: ${offers.length} офферов, ${pageSaved} сохранено`);
    if (offers.length === 0) break;
  } catch (e) {
    console.warn(`  стр.${p}: ${e.message}`);
    break;
  }
  await sleep(delayMs);
}

await browser.close();
await c.query(`insert into m_imports_log(source_kind, city_id, inserted, duration_ms) values('ya-realty', $1, $2, $3)`, [cityId, saved, Date.now()-t0]);
console.log(`✓ Я.Недвижимость: сохранено ${saved}`);
await c.end();
