// Сидер списка городов-миллионников РФ + Москва + СПб.
// node scripts/seed-cities.mjs

import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();
await c.query(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));

// МСК + Подмосковье. Для МО — топ-10 городов-спутников по населению.
const cities = [
  { name:'Москва',          region:'Москва',                population:13104177, lat:55.7558, lon:37.6173 },
  { name:'Балашиха',        region:'Московская область',    population:  527926, lat:55.7969, lon:37.9385 },
  { name:'Подольск',        region:'Московская область',    population:  326812, lat:55.4316, lon:37.5447 },
  { name:'Химки',           region:'Московская область',    population:  257778, lat:55.8970, lon:37.4296 },
  { name:'Мытищи',          region:'Московская область',    population:  247293, lat:55.9118, lon:37.7307 },
  { name:'Королёв',         region:'Московская область',    population:  224497, lat:55.9162, lon:37.8543 },
  { name:'Люберцы',         region:'Московская область',    population:  211252, lat:55.6766, lon:37.8932 },
  { name:'Красногорск',     region:'Московская область',    population:  175743, lat:55.8307, lon:37.3306 },
  { name:'Электросталь',    region:'Московская область',    population:  158197, lat:55.7914, lon:38.4477 },
  { name:'Одинцово',        region:'Московская область',    population:  142203, lat:55.6789, lon:37.2649 },
  { name:'Серпухов',        region:'Московская область',    population:  124720, lat:54.9182, lon:37.4136 },
];

let n = 0;
for (const city of cities) {
  await c.query(`
    insert into m_cities(name, region, population, lat, lon)
    values($1,$2,$3,$4,$5)
    on conflict (name) do update set
      region = excluded.region,
      population = excluded.population,
      lat = excluded.lat,
      lon = excluded.lon
  `, [city.name, city.region, city.population, city.lat, city.lon]);
  n++;
}
console.log(`✓ seeded ${n} городов`);
await c.end();
