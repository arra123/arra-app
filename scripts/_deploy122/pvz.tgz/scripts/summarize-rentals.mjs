// AI-сводки описаний объявлений через OpenAI (через PROXYAPI).
// Запуск: node scripts/summarize-rentals.mjs [--limit 50] [--refresh]

import 'dotenv/config';
import pg from 'pg';

const argv = process.argv.slice(2);
const arg = (k, def=null) => { const i=argv.indexOf(k); return i>=0 && argv[i+1] ? argv[i+1] : def; };
const flag = (k) => argv.includes(k);

const limit   = +(arg('--limit', '500'));
const refresh = flag('--refresh');
const model   = arg('--model', 'gpt-4o-mini');

const API_KEY  = process.env.PROXYAPI_KEY;
const API_BASE = process.env.PROXYAPI_BASE_URL || 'https://api.proxyapi.ru/openai/v1';
if (!API_KEY) { console.error('Нет PROXYAPI_KEY в .env'); process.exit(1); }

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();

const where = refresh ? '' : 'where r.ai_summary is null';
const { rows } = await c.query(`
  select r.id, r.title, r.address, r.area_m2, r.price_rub, r.description, r.property_type
  from m_rentals r
  ${where} ${refresh ? '' : 'and'} ${refresh ? 'where' : ''} r.description is not null and length(r.description) > 50 and r.status='active'
  order by r.id
  limit ${limit}
`);

console.log(`→ AI summarize: ${rows.length} объявлений (model=${model})`);

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function summarize(text) {
  const body = {
    model,
    messages: [
      { role:'system', content: 'Ты помогаешь искать коммерческое помещение под аренду. Сожми описание в 1 короткое предложение (≤120 символов) на русском, оставив ключевое: тип/состояние/особенности входа/преимущества. Без вступлений и общих фраз. Просто факты.' },
      { role:'user', content: text.slice(0, 2500) },
    ],
    max_tokens: 80,
    temperature: 0.2,
  };
  const r = await fetch(`${API_BASE}/chat/completions`, {
    method:'POST',
    headers: { 'Content-Type':'application/json', 'Authorization': 'Bearer ' + API_KEY },
    body: JSON.stringify(body),
  });
  if (!r.ok) { const t = await r.text(); throw new Error(`HTTP ${r.status}: ${t.slice(0,200)}`); }
  const j = await r.json();
  return j.choices?.[0]?.message?.content?.trim() || null;
}

let ok=0, err=0;
const t0 = Date.now();
for (let i=0; i<rows.length; i++) {
  const r = rows[i];
  try {
    const summary = await summarize(r.description);
    if (summary) {
      await c.query(`update m_rentals set ai_summary=$1, ai_summary_at=now() where id=$2`, [summary, r.id]);
      ok++;
    }
  } catch (e) { err++; if (err<=3) console.warn(`  [${r.id}]`, e.message); }
  if ((i+1) % 5 === 0 || i === rows.length-1) {
    process.stdout.write(`\r  [${i+1}/${rows.length}] ok=${ok} err=${err} (${((Date.now()-t0)/1000).toFixed(0)}с)`);
  }
  await sleep(150);
}
console.log('');
console.log(`\n✓ summarized=${ok}, err=${err} за ${((Date.now()-t0)/1000).toFixed(0)}с`);

await c.end();
