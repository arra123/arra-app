-- pvz · схема БД (префикс m_*)
-- Идемпотентно: можно гонять много раз.

-- ============ ГОРОДА (для группировок) ============
create table if not exists m_cities (
  id              serial primary key,
  name            text unique not null,         -- 'Москва'
  region          text,                          -- 'Московская область'
  population      integer,                       -- общее население
  area_km2        numeric(10,2),
  lat             numeric(10,7),
  lon             numeric(10,7),
  created_at      timestamptz default now()
);

-- ============ СУЩЕСТВУЮЩИЕ ПВЗ (на карте WB) ============
create table if not exists m_points (
  id              serial primary key,
  source          text not null default 'wb',   -- 'wb' / 'ozon' / 'ya' / etc.
  source_id       text,                          -- внешний id пункта на платформе
  name            text,                          -- 'Wildberries у метро ...'
  address         text,
  city_id         integer references m_cities(id) on delete set null,
  lat             numeric(10,7) not null,
  lon             numeric(10,7) not null,
  is_partner      boolean,                       -- партнёрский / собственный
  schedule        text,                          -- режим работы
  raw             jsonb,                         -- сырая карточка
  fetched_at      timestamptz default now()
);
create index if not exists ix_m_points_city on m_points(city_id);
create index if not exists ix_m_points_geo on m_points(lat, lon);
create unique index if not exists ux_m_points_src on m_points(source, source_id) where source_id is not null;

-- ============ ОБЪЯВЛЕНИЯ ОБ АРЕНДЕ ============
create table if not exists m_rentals (
  id              serial primary key,
  source          text not null default 'wb',   -- 'wb' / 'cian' / 'avito' / 'manual'
  source_id       text,
  title           text,
  address         text,
  city_id         integer references m_cities(id) on delete set null,
  lat             numeric(10,7),
  lon             numeric(10,7),
  area_m2         numeric(10,2),
  price_rub       numeric(12,2),                 -- ₽/мес
  price_per_m2    numeric(10,2),
  url             text,                          -- ссылка на объявление
  status          text default 'active',         -- 'active' / 'gone' / 'taken'
  raw             jsonb,
  fetched_at      timestamptz default now()
);
create index if not exists ix_m_rentals_city on m_rentals(city_id);
create index if not exists ix_m_rentals_geo on m_rentals(lat, lon);
create unique index if not exists ux_m_rentals_src on m_rentals(source, source_id);

-- ============ ЗОНЫ С КАРТЫ WB (uncovered + zone + tariff) ============
-- Источник: pvz-map-backend.wildberries.ru (см. notes/wb-pvz-api.md)
-- На каждую точку сетки пишем: непокрытое население, тип зоны, субсидия, оборот.
create table if not exists m_zones (
  id                 serial primary key,
  city_id            integer references m_cities(id) on delete cascade,
  lat                numeric(10,7) not null,
  lon                numeric(10,7) not null,

  unserved_people    integer,        -- кол-во людей без ПВЗ в этой точке
  all_people         integer,        -- всего людей в зоне точки
  unserved_ratio     numeric(5,4),   -- unserved / all (0..1)

  zone_type          text,           -- 'green_zone' / 'priority_zone' / 'red_zone' / 'forbidden_area'
  zone_priority_type text,           -- 'hexes_population' / 'workload' / etc.
  subsidy_type       text,           -- 'single_subsidy' / 'double_subsidy' / null
  tariff_pct         numeric(5,2),   -- total_tariff из API (% комиссии WB партнёру)
  profit_rub         numeric(12,2),  -- profit ₽/мес (расчётная прибыль)
  reward_rub         numeric(12,2),  -- reward ₽/мес (выплата от WB)
  min_area           integer,        -- min_area_info — мин. площадь для этой точки
  predicted_turnover numeric(14,2),  -- среднее по turnover_year_prediction

  raw                jsonb,          -- сырые ответы для подстраховки
  fetched_at         timestamptz default now(),
  unique(city_id, lat, lon)
);
create index if not exists ix_m_zones_city     on m_zones(city_id);
create index if not exists ix_m_zones_unserved on m_zones(unserved_people desc);
create index if not exists ix_m_zones_priority on m_zones(zone_type) where zone_type='priority_zone';

-- Дополнительные колонки (idempotent, на старых таблицах)
alter table m_zones add column if not exists profit_rub        numeric(12,2);
alter table m_zones add column if not exists reward_rub        numeric(12,2);
alter table m_zones add column if not exists min_area          integer;
alter table m_zones add column if not exists can_open          boolean;
alter table m_zones add column if not exists tariff_condition  text;     -- "Базовые" / "Гарантированный доход" и т.д.
alter table m_zones add column if not exists base_tariff_pct   numeric(5,2);
alter table m_zones add column if not exists bonus_tariff_pct  numeric(5,2);
alter table m_zones add column if not exists tariffs_count     integer;  -- сколько вариантов тарифов даёт WB для точки
alter table m_zones add column if not exists has_subsidy       boolean;
alter table m_zones add column if not exists has_promotion     boolean;
alter table m_zones add column if not exists description       text;

-- Расширение m_rentals: фото, описание, агент, этаж, район
alter table m_rentals add column if not exists photos          jsonb;        -- массив URL
alter table m_rentals add column if not exists description     text;
alter table m_rentals add column if not exists floor_no        integer;
alter table m_rentals add column if not exists floors_total    integer;
alter table m_rentals add column if not exists district        text;          -- "Кунцево"
alter table m_rentals add column if not exists okrug           text;          -- "ЗАО"
alter table m_rentals add column if not exists metro           jsonb;         -- [{name,minutes,type}]
alter table m_rentals add column if not exists agent_name      text;
alter table m_rentals add column if not exists agent_id        text;
alter table m_rentals add column if not exists phones          jsonb;
alter table m_rentals add column if not exists property_type   text;          -- "Помещение свободного назначения"
alter table m_rentals add column if not exists added_at        timestamptz;   -- когда выложено
alter table m_rentals add column if not exists features        jsonb;         -- "Парковка","Отопление" и т.д.
create index if not exists ix_m_rentals_district on m_rentals(district);
create index if not exists ix_m_rentals_okrug    on m_rentals(okrug);

-- лайки на объявления
alter table m_rentals add column if not exists liked    boolean default false;
alter table m_rentals add column if not exists liked_at timestamptz;
create index if not exists ix_m_rentals_liked on m_rentals(liked) where liked = true;

-- комментарии пользователя к объявлениям
alter table m_rentals add column if not exists comment    text;
alter table m_rentals add column if not exists comment_at timestamptz;

-- AI-сводка описания (1-2 предложения)
alter table m_rentals add column if not exists ai_summary text;
alter table m_rentals add column if not exists ai_summary_at timestamptz;

-- WB enrichment: данные с pvz-map-backend.wildberries.ru для каждой точки
alter table m_rentals add column if not exists wb_unserved_people    integer;
alter table m_rentals add column if not exists wb_all_people         integer;
alter table m_rentals add column if not exists wb_zone_type          text;
alter table m_rentals add column if not exists wb_subsidy_type       text;
alter table m_rentals add column if not exists wb_tariff_pct         numeric(5,2);
alter table m_rentals add column if not exists wb_profit_rub         numeric(12,2);
alter table m_rentals add column if not exists wb_reward_rub         numeric(12,2);
alter table m_rentals add column if not exists wb_can_open           boolean;
alter table m_rentals add column if not exists wb_min_area           integer;
alter table m_rentals add column if not exists wb_predicted_turnover numeric(14,2);
alter table m_rentals add column if not exists wb_tariff_condition   text;
alter table m_rentals add column if not exists wb_enriched_at        timestamptz;
alter table m_rentals add column if not exists wb_subsidy_size       numeric(12,2);   -- ₽ гарантированного дохода
alter table m_rentals add column if not exists wb_subsidy_text       text;            -- "Повышенный ГД" / "ГД 6 мес"
alter table m_rentals add column if not exists wb_turnover_first     numeric(14,2);   -- оборот в 1-й месяц
alter table m_rentals add column if not exists wb_turnover_avg       numeric(14,2);   -- среднее за 11 мес (то же что predicted_turnover)
alter table m_rentals add column if not exists wb_turnover_max       numeric(14,2);   -- лучший месяц
create index if not exists ix_m_rentals_wb_profit on m_rentals(wb_profit_rub desc nulls last);
create index if not exists ix_m_rentals_wb_zone on m_rentals(wb_zone_type) where wb_zone_type='priority_zone';

-- Дедуп: ключ группы (одно физическое помещение, опубликованное на разных площадках)
-- Формула: round(lat*1000) || '/' || round(lon*1000) || '/' || round(area/5)
alter table m_rentals add column if not exists dedup_key text;
create index if not exists ix_m_rentals_dedup on m_rentals(dedup_key) where dedup_key is not null;

-- Триггер автоматически вычисляет dedup_key при insert/update
create or replace function m_rentals_set_dedup_key() returns trigger as $$
begin
  if new.lat is not null and new.lon is not null then
    new.dedup_key := round(new.lat * 1000)::text || '/' ||
                     round(new.lon * 1000)::text || '/' ||
                     round(coalesce(new.area_m2, 0) / 5)::text;
  end if;
  return new;
end;
$$ language plpgsql;
drop trigger if exists trg_m_rentals_dedup on m_rentals;
create trigger trg_m_rentals_dedup
  before insert or update of lat, lon, area_m2 on m_rentals
  for each row execute function m_rentals_set_dedup_key();

-- ============ ОБОГАЩЕНИЕ ПВЗ ДАННЫМИ Я.КАРТ ============
-- Источник: Yandex Search API for Organizations (search-maps.yandex.ru)
alter table m_points add column if not exists ya_rating       numeric(3,2);
alter table m_points add column if not exists ya_reviews      integer;
alter table m_points add column if not exists ya_org_id       text;
alter table m_points add column if not exists ya_url          text;
alter table m_points add column if not exists categories      jsonb;
alter table m_points add column if not exists ya_enriched_at  timestamptz;
create unique index if not exists ux_m_points_ya_org on m_points(ya_org_id) where ya_org_id is not null;
create index if not exists ix_m_points_ya_rating on m_points(ya_rating desc nulls last);

-- В m_rentals — отметка когда искали ПВЗ рядом + кеш кол-ва в радиусе 1км
alter table m_rentals add column if not exists pvz_enriched_at timestamptz;
alter table m_rentals add column if not exists pvz_count_1km   integer;
alter table m_rentals add column if not exists pvz_avg_rating  numeric(3,2);

-- Гео-проверка района по координатам (источник: OSM Nominatim)
-- district_geo  — реальный район по lat/lon
-- okrug_geo     — реальный округ
-- district_mismatch — true если сохранённый district ≠ district_geo
alter table m_rentals add column if not exists district_geo      text;
alter table m_rentals add column if not exists okrug_geo         text;
alter table m_rentals add column if not exists district_mismatch boolean;
alter table m_rentals add column if not exists geocheck_at       timestamptz;
create index if not exists ix_m_rentals_mismatch on m_rentals(district_mismatch) where district_mismatch = true;

-- ============ КАНДИДАТЫ-ЛОКАЦИИ (результат скоринга) ============
create table if not exists m_candidates (
  id              serial primary key,
  rental_id       integer references m_rentals(id) on delete cascade,
  city_id         integer references m_cities(id) on delete set null,
  score           numeric(6,2),                  -- общий скор 0..100
  pvz_density_score   numeric(6,2),              -- мало ПВЗ → высокий скор
  population_score    numeric(6,2),              -- много людей → высокий скор
  price_score         numeric(6,2),              -- адекватная цена → высокий скор
  pvz_within_500m     integer,                   -- сколько ПВЗ в радиусе 500м
  population_500m     integer,                   -- сколько людей в радиусе 500м
  status              text default 'new',        -- new / reviewing / contacting / opened / rejected
  notes               text,
  computed_at         timestamptz default now()
);
create index if not exists ix_m_cand_score on m_candidates(score desc);
create index if not exists ix_m_cand_status on m_candidates(status);

-- ============ ИСТОЧНИКИ / ЗАДАЧИ ПАРСЕРОВ ============
create table if not exists m_data_sources (
  id              serial primary key,
  kind            text not null,                 -- 'wb-pvz' / 'wb-rent' / 'cian' / 'rosstat' / etc.
  city_id         integer references m_cities(id) on delete set null,
  status          text default 'idle',           -- 'idle' / 'running' / 'error'
  last_run_at     timestamptz,
  next_run_at     timestamptz,
  count           integer default 0,             -- сколько записей подтянули
  error           text,
  config          jsonb default '{}'::jsonb
);

-- ============ ЛОГ ИМПОРТОВ ============
create table if not exists m_imports_log (
  id              serial primary key,
  source_kind     text,
  city_id         integer,
  inserted        integer,
  updated         integer,
  failed          integer,
  duration_ms     integer,
  started_at      timestamptz default now(),
  finished_at     timestamptz,
  error           text
);
