// cards · GRAflab — локальный http-сервер.
// Без новых зависимостей: только встроенный node:http + pg + openai (уже стоят).
// Запуск: npm start  →  http://localhost:3000

import 'dotenv/config';
import { createServer } from 'node:http';
import { readFile, stat, readdir } from 'node:fs/promises';
import { extname, join, normalize, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import pg from 'pg';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const SITE = join(ROOT, 'site');

const { Pool } = pg;
const pool = new Pool({
  host: process.env.PGHOST,
  port: Number(process.env.PGPORT),
  database: process.env.PGDATABASE,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  ssl: false,
  max: 5,
});

// ─────────── helpers ───────────
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'text/javascript; charset=utf-8',
  '.mjs':  'text/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg':  'image/svg+xml',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif':  'image/gif',
  '.ico':  'image/x-icon',
  '.txt':  'text/plain; charset=utf-8',
};

function send(res, status, body, extraHeaders = {}) {
  const headers = {
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    ...extraHeaders,
  };
  res.writeHead(status, headers);
  res.end(body);
}
function sendJSON(res, status, obj) {
  send(res, status, JSON.stringify(obj, null, 2), { 'Content-Type': 'application/json; charset=utf-8' });
}
function sendNotFound(res, msg = 'Not Found') {
  sendJSON(res, 404, { error: msg });
}

async function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve(null);
      try { resolve(JSON.parse(raw)); } catch { resolve(raw); }
    });
    req.on('error', reject);
  });
}

// безопасное соединение пути (защита от .. вверх)
function safePath(base, p) {
  const decoded = decodeURIComponent(p).replace(/^\/+/, '');
  const target = normalize(join(base, decoded));
  // важно: проверка с разделителем, иначе `cards2` пройдёт как `cards`
  if (target !== base && !target.startsWith(base + sep)) return null;
  return target;
}

// для пользовательских path в API: разрешаем только префиксы карточки/ или output/
function isAllowedUserPath(p) {
  if (typeof p !== 'string' || !p) return false;
  if (p.includes('..') || /^[\\/]/.test(p) || /^[a-z]:/i.test(p)) return false;
  return /^(карточки|output)[\\/]/i.test(p);
}

// ─────────── статика (site/, output/, карточки/) ───────────
async function tryServeFile(res, path) {
  try {
    const s = await stat(path);
    if (s.isDirectory()) return false;
    const ext = extname(path).toLowerCase();
    const data = await readFile(path);
    send(res, 200, data, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    return true;
  } catch { return false; }
}

async function serveStatic(req, res, urlPath) {
  // /static/* → файлы из ROOT (output/, карточки/, site/)
  if (urlPath.startsWith('/static/')) {
    const path = safePath(ROOT, urlPath.slice('/static/'.length));
    if (!path) return sendNotFound(res, 'Bad path');
    const ok = await tryServeFile(res, path);
    if (!ok) sendNotFound(res, 'File not found');
    return true;
  }
  // / → site/index.html
  if (urlPath === '/' || urlPath === '') {
    return await tryServeFile(res, join(SITE, 'index.html'));
  }
  // /components → components.html
  if (urlPath === '/components' || urlPath === '/components/') {
    return await tryServeFile(res, join(SITE, 'components.html'));
  }
  // прочее — пробуем найти в site/
  const path = safePath(SITE, urlPath);
  if (!path) return false;
  return await tryServeFile(res, path);
}

// ─────────── api ───────────
async function apiCategories(_req, res) {
  const r = await pool.query('select * from c_categories order by id');
  sendJSON(res, 200, r.rows);
}
async function apiPalettes(_req, res) {
  const r = await pool.query('select * from c_palettes order by id');
  sendJSON(res, 200, r.rows);
}
async function apiSlideTemplates(_req, res) {
  const r = await pool.query('select * from c_slide_templates order by slide_kind');
  sendJSON(res, 200, r.rows);
}

async function apiSkus(_req, res) {
  const r = await pool.query(`
    select s.*, p.code as palette_code, p.hex_main, p.hex_accent, c.name_ru as category_name
    from c_skus s
    left join c_palettes p on p.id = s.palette_id
    left join c_categories c on c.id = s.category_id
    order by s.created_at desc, s.id
  `);
  sendJSON(res, 200, r.rows);
}

// Список товаров из WB-кабинета — для пикера в генерации.
async function apiWbProductsList(req, res) {
  const url = new URL(req.url, 'http://x');
  const q = (url.searchParams.get('q') || '').trim().toLowerCase();
  const params = [];
  let where = '';
  if (q) {
    params.push('%' + q + '%');
    where = `where lower(coalesce(title,'')) like $1
              or lower(coalesce(vendor_code,'')) like $1
              or lower(coalesce(brand,'')) like $1
              or lower(coalesce(subject_name,'')) like $1
              or cast(nm_id as text) like $1`;
  }
  const r = await pool.query(`
    select nm_id, account, vendor_code, title, brand, subject_name, photo_count,
           coalesce(jsonb_array_length(case when jsonb_typeof(composition)='array' then composition else '[]'::jsonb end), 0) as composition_n,
           coalesce(jsonb_array_length(case when jsonb_typeof(benefits)='array' then benefits else '[]'::jsonb end), 0) as benefits_n,
           (description is not null and length(description)>10) as has_description
    from c_wb_products
    ${where}
    order by wb_updated_at desc nulls last, nm_id desc
    limit 300
  `, params);
  sendJSON(res, 200, r.rows);
}

// Полный товар из WB-кабинета.
async function apiWbProductById(_req, res, nmId) {
  const r = await pool.query(`
    select nm_id, account, vendor_code, title, brand, description, subject_id, subject_name,
           photo_count, characteristics, sizes, dimensions, tags,
           tech_card, composition, usage_text, benefits
    from c_wb_products where nm_id = $1
  `, [+nmId]);
  if (!r.rows.length) return sendNotFound(res, 'WB product not found');
  sendJSON(res, 200, r.rows[0]);
}

async function apiSkuById(_req, res, id) {
  const isNum = /^\d+$/.test(String(id));
  const r = await pool.query(`
    select s.*, p.code as palette_code, p.hex_main, p.hex_accent, c.name_ru as category_name
    from c_skus s
    left join c_palettes p on p.id = s.palette_id
    left join c_categories c on c.id = s.category_id
    where ${isNum ? 's.id=$1' : 's.sku=$1'}
    limit 1
  `, [isNum ? Number(id) : id]);
  if (!r.rows.length) return sendNotFound(res, 'SKU not found');

  // подгружаем последние генерации по этому sku
  const gens = await pool.query(`
    select g.*, p.name as prompt_name, p.version as prompt_version
    from c_generations g
    left join c_prompts p on p.id = g.prompt_id
    where g.sku_id = $1
    order by g.created_at desc
    limit 20
  `, [r.rows[0].id]);

  // привязки промптов к слайдам этого SKU
  const links = await pool.query(`
    select ssp.slide_kind, p.id as prompt_id, p.name, p.version, p.status, t.title as slide_title
    from c_sku_slide_prompt ssp
    join c_prompts p on p.id = ssp.prompt_id
    join c_slide_templates t on t.slide_kind = ssp.slide_kind
    where ssp.sku_id = $1
    order by ssp.slide_kind
  `, [r.rows[0].id]);

  sendJSON(res, 200, { ...r.rows[0], generations: gens.rows, slide_prompts: links.rows });
}

async function apiPrompts(req, res) {
  const url = new URL(req.url, `http://x`);
  const slide = url.searchParams.get('slide_kind');
  const cat = url.searchParams.get('category');
  const status = url.searchParams.get('status');
  const params = [];
  let where = 'where 1=1';
  if (slide) { params.push(Number(slide)); where += ` and slide_kind=$${params.length}`; }
  if (cat)   { params.push(cat);            where += ` and category_id=$${params.length}`; }
  if (status){ params.push(status);         where += ` and status=$${params.length}`; }

  const r = await pool.query(`
    select p.*, c.name_ru as category_name,
      (select count(*)::int from c_generations g where g.prompt_id=p.id) as runs,
      (select count(*)::int from c_generations g where g.prompt_id=p.id and g.status='success') as runs_success
    from c_prompts p
    left join c_categories c on c.id = p.category_id
    ${where}
    order by p.updated_at desc
  `, params);

  // вычисляем approval rate
  for (const row of r.rows) {
    row.approval_rate = row.runs > 0 ? Math.round(100 * row.runs_success / row.runs) : null;
  }
  sendJSON(res, 200, r.rows);
}

async function apiPromptById(_req, res, id) {
  const r = await pool.query(`
    select p.*, c.name_ru as category_name
    from c_prompts p
    left join c_categories c on c.id = p.category_id
    where p.id=$1
  `, [id]);
  if (!r.rows.length) return sendNotFound(res, 'Prompt not found');

  const gens = await pool.query(`
    select g.*, s.sku, s.name_ru as sku_name
    from c_generations g
    left join c_skus s on s.id = g.sku_id
    where g.prompt_id = $1
    order by g.created_at desc
    limit 30
  `, [id]);

  sendJSON(res, 200, { ...r.rows[0], history: gens.rows });
}

async function apiCreatePrompt(req, res) {
  const body = await readBody(req);
  if (!body || !body.name || !body.slide_kind || !body.body) {
    return sendJSON(res, 400, { error: 'name, slide_kind, body required' });
  }
  const r = await pool.query(`
    insert into c_prompts(name,slide_kind,category_id,version,status,body,endpoint,size,quality,ref_image_path,postproc_recipe,notes)
    values($1,$2,$3,coalesce($4,1),coalesce($5,'draft'),$6,coalesce($7,'images.edit'),coalesce($8,'1024x1536'),coalesce($9,'medium'),$10,$11,$12)
    returning *
  `, [body.name, body.slide_kind, body.category_id || null, body.version, body.status, body.body, body.endpoint, body.size, body.quality, body.ref_image_path || null, body.postproc_recipe || null, body.notes || null]);
  sendJSON(res, 201, r.rows[0]);
}

async function apiUpdatePrompt(req, res, id) {
  const body = await readBody(req);
  if (!body) return sendJSON(res, 400, { error: 'body required' });
  const fields = [];
  const params = [];
  for (const k of ['name','slide_kind','category_id','version','status','body','endpoint','size','quality','ref_image_path','postproc_recipe','notes']) {
    if (k in body) { params.push(body[k]); fields.push(`${k}=$${params.length}`); }
  }
  if (!fields.length) return sendJSON(res, 400, { error: 'no fields' });
  fields.push(`updated_at=now()`);
  params.push(id);
  const r = await pool.query(`update c_prompts set ${fields.join(', ')} where id=$${params.length} returning *`, params);
  if (!r.rows.length) return sendNotFound(res, 'Prompt not found');
  sendJSON(res, 200, r.rows[0]);
}

async function apiGenerations(req, res) {
  const url = new URL(req.url, `http://x`);
  const limit = Math.min(Number(url.searchParams.get('limit')) || 50, 500);
  const r = await pool.query(`
    select g.*, s.sku, s.name_ru as sku_name, p.name as prompt_name, p.version as prompt_version
    from c_generations g
    left join c_skus s on s.id = g.sku_id
    left join c_prompts p on p.id = g.prompt_id
    order by g.created_at desc
    limit $1
  `, [limit]);
  sendJSON(res, 200, r.rows);
}

async function apiAnalytics(_req, res) {
  // KPI сводка для дашборда / аналитики
  const r = await pool.query(`
    with totals as (
      select count(*)::int as total, count(*) filter (where status='success')::int as ok,
             coalesce(sum(cost_rub),0)::numeric as cost,
             coalesce(avg(duration_ms) filter (where duration_ms is not null),0)::int as avg_ms
      from c_generations
    )
    select
      (select count(*)::int from c_skus) as skus,
      (select count(*)::int from c_prompts) as prompts,
      (select count(*)::int from c_prompts where status='live') as prompts_live,
      (select total from totals) as gens_total,
      (select ok from totals) as gens_success,
      (select cost from totals) as cost_rub,
      (select avg_ms from totals) as avg_duration_ms
  `);
  // breakdown по категориям
  const cat = await pool.query(`
    select c.id, c.name_ru,
      count(g.id)::int as runs,
      count(g.id) filter (where g.status='success')::int as ok
    from c_categories c
    left join c_skus s on s.category_id = c.id
    left join c_generations g on g.sku_id = s.id
    group by c.id, c.name_ru
    order by runs desc
  `);
  for (const row of cat.rows) {
    row.approval_rate = row.runs > 0 ? Math.round(100 * row.ok / row.runs) : null;
  }
  sendJSON(res, 200, { ...r.rows[0], by_category: cat.rows });
}

// плоский список (для модалки выбора банки и совместимости)
async function apiLibraryFiles(req, res) {
  const url = new URL(req.url, `http://x`);
  const folder = url.searchParams.get('folder') || 'all';
  const out = [];
  async function walk(dir, rel) {
    let entries;
    try { entries = await readdir(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const abs = join(dir, e.name);
      const r = (rel ? rel + '/' : '') + e.name;
      if (e.isDirectory()) {
        if (e.name === 'node_modules' || e.name === '.git') continue;
        await walk(abs, r);
      } else {
        const ext = extname(e.name).toLowerCase();
        if (!['.png','.jpg','.jpeg','.webp','.gif','.psd','.xlsx','.pdf'].includes(ext)) continue;
        let size = 0; let mtime = null;
        try { const st = await stat(abs); size = st.size; mtime = st.mtime.toISOString(); } catch {}
        out.push({ name: e.name, path: r.split(sep).join('/'), ext, size, mtime, url: '/static/' + encodeURI(r.split(sep).join('/')) });
      }
    }
  }
  if (folder === 'cards' || folder === 'all') await walk(join(ROOT, 'карточки'), 'карточки');
  if (folder === 'output' || folder === 'all') await walk(join(ROOT, 'output'), 'output');
  out.sort((a, b) => (b.mtime || '').localeCompare(a.mtime || ''));
  sendJSON(res, 200, out); // без лимита
}

// ─────────── CANON / BLACKLIST / RATINGS ───────────
async function apiCanon(_req, res) {
  const r = await pool.query(`
    select slide_kind, title, description, must_have, must_avoid, soft_options, character_hint, has_jar, has_person
    from c_slide_templates
    order by slide_kind
  `);
  sendJSON(res, 200, r.rows);
}
async function apiBlacklist(_req, res) {
  const r = await pool.query('select * from c_blacklist order by scope, word');
  sendJSON(res, 200, r.rows);
}
async function apiRateGeneration(req, res, gen_id) {
  const b = await readBody(req);
  if (!b || ![-1, 1].includes(b.rating)) return sendJSON(res, 400, { error: 'rating must be -1 or 1' });
  const r = await pool.query(
    'insert into c_ratings(generation_id, rating, note) values($1,$2,$3) returning *',
    [gen_id, b.rating, b.note || null]
  );
  sendJSON(res, 200, r.rows[0]);
}
async function apiRatings(_req, res) {
  const r = await pool.query(`
    select r.*, g.slide_kind, g.cost_rub, g.status, g.output_path, p.name as prompt_name, s.sku
    from c_ratings r
    left join c_generations g on g.id = r.generation_id
    left join c_prompts p on p.id = g.prompt_id
    left join c_skus s on s.id = g.sku_id
    order by r.created_at desc
    limit 100
  `);
  sendJSON(res, 200, r.rows);
}

// ─────────── PROJECTS ───────────
async function apiProjectsList(_req, res) {
  const r = await pool.query(`
    select p.id, p.name, p.sku_id, p.palette_id, p.custom_color, p.jar_path,
           p.ref_paths, p.current_slide, p.brief, p.thumbnail_url, p.updated_at,
           s.sku as sku_code, s.name_ru as sku_name,
           pal.code as palette_code, pal.hex_main, pal.hex_accent
    from c_projects p
    left join c_skus s on s.id = p.sku_id
    left join c_palettes pal on pal.id = p.palette_id
    order by p.updated_at desc
  `);
  sendJSON(res, 200, r.rows);
}
async function apiProjectGet(_req, res, id) {
  const r = await pool.query('select * from c_projects where id=$1', [id]);
  if (!r.rows.length) return sendNotFound(res, 'project not found');
  sendJSON(res, 200, r.rows[0]);
}
async function apiProjectCreate(req, res) {
  const b = await readBody(req) || {};
  const r = await pool.query(`
    insert into c_projects(name, sku_id, palette_id, custom_color, jar_path, ref_paths, layers_json, current_slide, brief)
    values($1,$2,$3,$4,$5,$6,$7,$8,$9)
    returning *
  `, [
    b.name || 'Новый проект',
    b.sku_id || null,
    b.palette_id || null,
    b.custom_color || null,
    b.jar_path || null,
    b.ref_paths || [],
    b.layers_json || {},
    b.current_slide || 1,
    b.brief || null,
  ]);
  sendJSON(res, 201, r.rows[0]);
}
async function apiProjectUpdate(req, res, id) {
  const b = await readBody(req) || {};
  const fields = [];
  const params = [];
  for (const k of ['name','sku_id','palette_id','custom_color','jar_path','ref_paths','layers_json','current_slide','brief','thumbnail_url']) {
    if (k in b) {
      params.push(b[k]);
      fields.push(`${k}=$${params.length}`);
    }
  }
  if (!fields.length) return sendJSON(res, 400, { error: 'no fields' });
  fields.push('updated_at=now()');
  params.push(id);
  const r = await pool.query(`update c_projects set ${fields.join(', ')} where id=$${params.length} returning *`, params);
  if (!r.rows.length) return sendNotFound(res, 'project not found');
  sendJSON(res, 200, r.rows[0]);
}
async function apiProjectDelete(_req, res, id) {
  const r = await pool.query('delete from c_projects where id=$1 returning id', [id]);
  if (!r.rows.length) return sendNotFound(res, 'project not found');
  sendJSON(res, 200, { ok: true });
}

// загрузка картинок (multipart) → сохраняем в карточки/<folder>/
async function apiLibraryUpload(req, res) {
  const ct = req.headers['content-type'] || '';
  const m = ct.match(/boundary=(.+)$/);
  if (!m) return sendJSON(res, 400, { error: 'no boundary' });
  const boundary = '--' + m[1];

  const chunks = [];
  for await (const c of req) chunks.push(c);
  const buf = Buffer.concat(chunks);

  // примитивный парсер multipart
  const parts = [];
  let folder = 'карточки/Загруженное';
  let i = 0;
  while (i < buf.length) {
    const bIdx = buf.indexOf(boundary, i);
    if (bIdx < 0) break;
    const headEnd = buf.indexOf('\r\n\r\n', bIdx);
    if (headEnd < 0) break;
    const head = buf.slice(bIdx, headEnd).toString('utf8');
    const nextB = buf.indexOf(boundary, headEnd + 4);
    if (nextB < 0) break;
    const body = buf.slice(headEnd + 4, nextB - 2); // -2 = \r\n перед boundary
    const nameMatch = head.match(/name="([^"]+)"/);
    const fnameMatch = head.match(/filename="([^"]*)"/);
    if (nameMatch) {
      const name = nameMatch[1];
      if (name === 'folder') folder = body.toString('utf8') || folder;
      else if (fnameMatch && fnameMatch[1]) parts.push({ name: fnameMatch[1], data: body });
    }
    i = nextB;
  }

  if (!parts.length) return sendJSON(res, 400, { error: 'no files' });

  // Защита от path traversal: разрешаем только префиксы карточки/ или output/, без ..
  const cleanFolder = String(folder).replace(/\\/g, '/').replace(/^\/+/, '').replace(/\.+/g, '.');
  if (!isAllowedUserPath(cleanFolder + '/')) {
    return sendJSON(res, 400, { error: 'folder must be inside карточки/ or output/' });
  }
  const targetDir = safePath(ROOT, cleanFolder);
  if (!targetDir) return sendJSON(res, 400, { error: 'invalid folder' });

  const { mkdir, writeFile } = await import('node:fs/promises');
  await mkdir(targetDir, { recursive: true });
  const saved = [];
  for (const p of parts) {
    const safe = p.name.replace(/[\\/:*?"<>|]/g, '_');
    await writeFile(join(targetDir, safe), p.data);
    saved.push(cleanFolder + '/' + safe);
  }
  sendJSON(res, 200, { ok: true, saved });
}

// детальная инфа по одному файлу: запись из c_library_assets + фолдер-мета + связанная генерация
async function apiLibraryAsset(req, res) {
  const url = new URL(req.url, 'http://x');
  const path = url.searchParams.get('path');
  if (!path) return sendJSON(res, 400, { error: 'path required' });

  // запись о файле + размеры с диска
  const fr = await pool.query(`
    select id, path, file_name, folder, type, product_code, slide_kind, palette_cat, dominant_hex, size_w, size_h, byte_size, mtime, notes, rating
    from c_library_assets where path=$1
  `, [path]);
  let file = fr.rows[0] || null;
  if (!file) {
    // не сканировано — отдадим минимум с диска
    try {
      const st = await stat(join(ROOT, path));
      file = {
        path, file_name: path.split('/').pop(), folder: path.split('/').slice(0, -1).join('/'),
        type: null, product_code: null, slide_kind: null, palette_cat: null, dominant_hex: null,
        size_w: null, size_h: null, byte_size: st.size, mtime: st.mtime.toISOString(), notes: null,
      };
    } catch { return sendJSON(res, 404, { error: 'not found' }); }
  }

  // folder-meta (для wb-папок и переименований)
  // полный путь до папки (без имени файла) — из path
  const fullFolder = path.split('/').slice(0, -1).join('/');
  let folderMeta = null;
  try {
    const fm = await pool.query('select * from c_folder_meta where folder=$1', [fullFolder]);
    folderMeta = fm.rows[0] || null;
  } catch {}
  // если в папке есть _meta.json (от parse-wb) — подмерджим
  try {
    const metaPath = join(ROOT, fullFolder, '_meta.json');
    const raw = await readFile(metaPath, 'utf8');
    const j = JSON.parse(raw);
    folderMeta = {
      folder: fullFolder,
      source: folderMeta?.source || (j.nm ? 'wb' : null),
      source_id: folderMeta?.source_id || j.nm || null,
      brand: folderMeta?.brand || j.brand || null,
      display_name: folderMeta?.display_name || j.name || null,
      source_url: folderMeta?.source_url || j.source_url || null,
      pics_total: folderMeta?.pics_total || j.downloaded || j.pics || null,
    };
  } catch {}

  // карточка из нашего WB-кабинета — по nm_id из folder_meta
  let wbProduct = null;
  if (folderMeta?.source_id && /^wb_cabinet_/.test(folderMeta.source || '')) {
    try {
      const wp = await pool.query(`
        select nm_id, account, vendor_code, title, brand, description, subject_id, subject_name,
               photo_count, characteristics, sizes, dimensions, tags, wb_created_at, wb_updated_at, fetched_at,
               tech_card, composition, usage_text, benefits, sklad_folder, cost_price
        from c_wb_products where nm_id = $1
      `, [+folderMeta.source_id]);
      wbProduct = wp.rows[0] || null;
    } catch {}
  }

  // связанная генерация — по output_path = path
  let generation = null;
  try {
    const gr = await pool.query(`
      select id, sku_id, slide_kind, prompt_id, prompt_snapshot, ref_image_path, output_path,
             status, error, cost_rub, tokens, duration_ms, created_at
      from c_generations
      where output_path = $1 or output_path = $2
      order by created_at desc limit 1
    `, [path, '/' + path]);
    generation = gr.rows[0] || null;
  } catch {}

  sendJSON(res, 200, { file, folder_meta: folderMeta, generation, wb_product: wbProduct });
}

// patch benefits/usage_text у c_wb_products
async function apiSetWbProduct(req, res) {
  const b = await readBody(req);
  if (!b?.nm_id) return sendJSON(res, 400, { error: 'nm_id required' });
  const sets = []; const args = [];
  if (b.benefits !== undefined) { args.push(JSON.stringify(b.benefits || [])); sets.push(`benefits = $${args.length}::jsonb`); }
  if (b.usage_text !== undefined) { args.push(b.usage_text || null); sets.push(`usage_text = $${args.length}`); }
  if (!sets.length) return sendJSON(res, 400, { error: 'nothing to update' });
  args.push(+b.nm_id);
  const r = await pool.query(`update c_wb_products set ${sets.join(', ')} where nm_id = $${args.length}`, args);
  sendJSON(res, 200, { ok: r.rowCount > 0 });
}

// upsert описания и оценки файла (notes + rating: -1/0/+1)
async function apiSetAssetMeta(req, res) {
  const b = await readBody(req);
  if (!b?.path) return sendJSON(res, 400, { error: 'path required' });
  if (!isAllowedUserPath(b.path)) return sendJSON(res, 400, { error: 'path must be inside карточки/ or output/' });
  const fields = [];
  const values = [];
  let i = 1;
  if (b.notes !== undefined) { fields.push(`notes = $${i++}`); values.push(b.notes || null); }
  if (b.rating !== undefined) { fields.push(`rating = $${i++}`); values.push(b.rating == null ? null : Math.max(-1, Math.min(1, +b.rating))); }
  if (!fields.length) return sendJSON(res, 400, { error: 'nothing to update' });
  values.push(b.path);
  const r = await pool.query(`update c_library_assets set ${fields.join(', ')} where path = $${i}`, values);
  if (!r.rowCount) {
    // запись не сканировалась — создадим минимальную
    try {
      const st = await stat(join(ROOT, b.path));
      await pool.query(`
        insert into c_library_assets(path, file_name, folder, type, byte_size, mtime, notes, rating)
        values($1,$2,$3,'card',$4,$5,$6,$7)
        on conflict (path) do update set notes=excluded.notes, rating=excluded.rating
      `, [b.path, b.path.split('/').pop(), b.path.split('/').slice(0,-1).join('/'), st.size, st.mtime, b.notes||null, b.rating==null?null:+b.rating]);
    } catch (e) {
      return sendJSON(res, 404, { error: 'asset not found and could not stat' });
    }
  }
  sendJSON(res, 200, { ok: true });
}

// upsert метаданных папки (название/артикул/бренд — для wb-папок и переименований)
async function apiSetFolderMeta(req, res) {
  const b = await readBody(req);
  if (!b?.folder) return sendJSON(res, 400, { error: 'folder required' });
  // создадим таблицу лениво
  await pool.query(`
    create table if not exists c_folder_meta (
      folder        text primary key,
      display_name  text,
      full_name     text,
      source        text,
      source_id     text,
      brand         text,
      source_url    text,
      pics_total    integer,
      notes         text,
      updated_at    timestamptz default now()
    )
  `);
  await pool.query(`alter table c_folder_meta add column if not exists full_name text`);
  await pool.query(`
    insert into c_folder_meta(folder, display_name, full_name, source, source_id, brand, source_url, pics_total, notes, updated_at)
    values($1,$2,$3,$4,$5,$6,$7,$8,$9, now())
    on conflict (folder) do update set
      display_name = coalesce(excluded.display_name, c_folder_meta.display_name),
      full_name    = coalesce(excluded.full_name, c_folder_meta.full_name),
      source       = coalesce(excluded.source, c_folder_meta.source),
      source_id    = coalesce(excluded.source_id, c_folder_meta.source_id),
      brand        = coalesce(excluded.brand, c_folder_meta.brand),
      source_url   = coalesce(excluded.source_url, c_folder_meta.source_url),
      pics_total   = coalesce(excluded.pics_total, c_folder_meta.pics_total),
      notes        = coalesce(excluded.notes, c_folder_meta.notes),
      updated_at   = now()
  `, [b.folder, b.display_name||null, b.full_name||null, b.source||null, b.source_id||null, b.brand||null, b.source_url||null, b.pics_total||null, b.notes||null]);
  sendJSON(res, 200, { ok: true });
}

// перезапуск scan-library.mjs из UI
async function apiLibraryRescan(_req, res) {
  try {
    const { spawn } = await import('node:child_process');
    const child = spawn(process.execPath, [join(ROOT, 'scripts', 'scan-library.mjs')], {
      cwd: ROOT,
      env: process.env,
      stdio: ['ignore','pipe','pipe'],
    });
    let log = '';
    child.stdout.on('data', d => log += d.toString());
    child.stderr.on('data', d => log += d.toString());
    await new Promise((resolve, reject) => {
      child.on('exit', code => code === 0 ? resolve() : reject(new Error(`scan exited ${code}\n${log.slice(-1500)}`)));
      child.on('error', reject);
    });
    sendJSON(res, 200, { ok: true, log: log.split('\n').slice(-20).join('\n') });
  } catch (e) {
    sendJSON(res, 500, { ok: false, error: e.message });
  }
}

// удаление файла из библиотеки
async function apiLibraryDelete(req, res) {
  const b = await readBody(req);
  const path = b?.path;
  if (!path) return sendJSON(res, 400, { error: 'bad path' });
  if (!isAllowedUserPath(path)) return sendJSON(res, 400, { error: 'only карточки/ or output/' });
  const safe = safePath(ROOT, path);
  if (!safe) return sendJSON(res, 400, { error: 'path traversal blocked' });
  const { unlink } = await import('node:fs/promises');
  try {
    await unlink(safe);
    sendJSON(res, 200, { ok: true });
  } catch (e) {
    sendJSON(res, 500, { ok: false, error: e.message });
  }
}

// удаление фона (через @imgly/background-removal — ставится отдельно если нужно)
// поиск дубликатов в output/ — сначала по size (быстро), потом sha1 только для подозрительных
async function apiFindDuplicates(_req, res) {
  const { readFile, readdir, stat } = await import('node:fs/promises');
  const crypto = await import('node:crypto');
  const dir = join(ROOT, 'output');
  let entries = [];
  try { entries = await readdir(dir); } catch { return sendJSON(res, 200, { groups: [] }); }

  // 1) собираем metadata без чтения содержимого
  const meta = [];
  for (const name of entries) {
    if (!/\.(png|jpe?g|webp)$/i.test(name)) continue;
    if (/_raw\./i.test(name)) continue;     // raw — не считаем
    try {
      const p = join(dir, name);
      const st = await stat(p);
      if (!st.isFile()) continue;
      meta.push({ name, path: 'output/' + name, size: st.size, mtime: st.mtime, abs: p });
    } catch {}
  }

  // 2) группируем по size
  const bySize = new Map();
  for (const m of meta) {
    if (!bySize.has(m.size)) bySize.set(m.size, []);
    bySize.get(m.size).push(m);
  }

  // 3) sha1 только в группах ≥2 файлов с одинаковым размером
  const byHash = new Map();
  for (const [, files] of bySize.entries()) {
    if (files.length < 2) continue;
    for (const f of files) {
      try {
        const buf = await readFile(f.abs);
        const h = crypto.createHash('sha1').update(buf).digest('hex');
        if (!byHash.has(h)) byHash.set(h, []);
        byHash.get(h).push({ name: f.name, path: f.path, size: f.size, mtime: f.mtime });
      } catch {}
    }
  }

  const groups = [];
  for (const [h, files] of byHash.entries()) {
    if (files.length > 1) {
      files.sort((a, b) => a.mtime - b.mtime);
      groups.push({ hash: h, files });
    }
  }
  sendJSON(res, 200, { groups, total_dupes: groups.reduce((s, g) => s + g.files.length - 1, 0) });
}

async function apiRemoveBg(req, res) {
  const b = await readBody(req);
  const inPath = b?.path;
  if (!inPath) return sendJSON(res, 400, { error: 'path required' });
  if (!isAllowedUserPath(inPath)) return sendJSON(res, 400, { error: 'path must be inside карточки/ or output/' });
  try {
    const { readFile, writeFile } = await import('node:fs/promises');
    const buf = await readFile(join(ROOT, inPath));
    let out;
    let note = '';
    try {
      // Нормальное AI-вырезание через @imgly/background-removal-node
      const mod = await import('@imgly/background-removal-node');
      const removeBackground = mod.removeBackground || mod.default?.removeBackground || mod.default;
      const blob = await removeBackground(buf, { output: { format: 'image/png' } });
      // blob → buffer
      const ab = await blob.arrayBuffer();
      out = Buffer.from(ab);
    } catch (aiErr) {
      // fallback на sharp.trim() (простой случай — белый фон)
      console.warn('imgly remove-bg failed, fallback to trim:', aiErr.message);
      const sharp = (await import('sharp')).default;
      out = await sharp(buf).trim({ background: '#ffffff', threshold: 30 }).png().toBuffer();
      note = 'fallback: trim по белому фону (AI-модель недоступна)';
    }
    const outPath = inPath.replace(/(\.[^.]+)$/, '_nobg.png');
    await writeFile(join(ROOT, outPath), out);
    const resp = { ok: true, path: outPath, url: '/static/' + outPath };
    if (note) resp.note = note;
    sendJSON(res, 200, resp);
  } catch (e) {
    sendJSON(res, 500, { error: e.message });
  }
}

// пересборка только композитинга (без нового OpenAI вызова) — используется когда правишь слои уже сгенерённой карточки
async function apiRecompose(req, res) {
  const b = await readBody(req);
  const { generation_id, layers = [], jar_path = null, target_size = null } = b || {};
  if (!generation_id) return sendJSON(res, 400, { error: 'generation_id required' });
  const r = await pool.query('select * from c_generations where id=$1', [generation_id]);
  if (!r.rows.length) return sendJSON(res, 404, { error: 'gen not found' });
  const g = r.rows[0];
  // ищем raw файл рядом с output_path
  let baseFile = null;
  try {
    const { stat } = await import('node:fs/promises');
    const candidate = g.output_path?.replace(/\.png$/, '_raw.png');
    if (candidate) {
      try { await stat(join(ROOT, candidate)); baseFile = candidate; } catch {}
    }
    if (!baseFile && g.output_path) baseFile = g.output_path;
  } catch {}
  if (!baseFile) return sendJSON(res, 400, { error: 'no base file to recompose from' });

  try {
    const { compose } = await import('./lib/compose.mjs');
    const { writeFile, readFile } = await import('node:fs/promises');
    const baseBuf = await readFile(join(ROOT, baseFile));
    const finalBuf = await compose(baseBuf, {
      targetSize: target_size || '1024x1536',
      jarPath: jar_path,
      layers,
      rootDir: ROOT,
    });
    const ts = Date.now();
    const newName = `output/recompose_${generation_id}_${ts}.png`;
    await writeFile(join(ROOT, newName), finalBuf);
    sendJSON(res, 200, { ok: true, output_path: newName, output_url: '/static/' + newName });
  } catch (e) {
    sendJSON(res, 500, { error: e.message });
  }
}

// каталог библиотеки с тегами (для UI Библиотеки и пресетов)
async function apiAssets(req, res) {
  const url = new URL(req.url, `http://x`);
  const filters = [];
  const params = [];
  for (const k of ['type','product_code','slide_kind','palette_cat']) {
    const v = url.searchParams.get(k);
    if (v) { params.push(k === 'slide_kind' ? +v : v); filters.push(`${k}=$${params.length}`); }
  }
  const where = filters.length ? 'where ' + filters.join(' and ') : '';
  const r = await pool.query(`
    select id, path, file_name, folder, type, product_code, slide_kind, palette_cat, dominant_hex, size_w, size_h, byte_size, notes,
           '/static/' || path as url
    from c_library_assets ${where}
    order by product_code nulls last, slide_kind nulls last, file_name
    limit 500
  `, params);
  // facets для UI
  const facets = await pool.query(`
    select 'type' as kind, type as val, count(*)::int as n from c_library_assets group by type
    union all
    select 'product', product_code, count(*)::int from c_library_assets where product_code is not null group by product_code
    union all
    select 'slide', slide_kind::text, count(*)::int from c_library_assets where slide_kind is not null group by slide_kind
    union all
    select 'palette', palette_cat, count(*)::int from c_library_assets where palette_cat is not null group by palette_cat
  `);
  sendJSON(res, 200, { items: r.rows, facets: facets.rows });
}

// дерево по папкам (для UI Библиотеки)
async function apiLibraryTree(_req, res) {
  // 1) тэги из БД одним запросом — мап по path
  const tagRows = await pool.query(`
    select path, type, product_code, slide_kind, palette_cat, dominant_hex, size_w, size_h, byte_size, notes, rating
    from c_library_assets
  `);
  const tagsByPath = new Map();
  for (const r of tagRows.rows) tagsByPath.set(r.path, r);

  // 1a) folder-meta (если таблица есть — для красивых названий и WB-данных)
  let folderMetaByName = new Map();
  try {
    const fm = await pool.query('select * from c_folder_meta');
    for (const r of fm.rows) folderMetaByName.set(r.folder, r);
  } catch {}

  // 2) обход папок
  const tree = []; // [{folder:"карточки/бенфо новый лучшая", files:[...]}]
  async function walk(dir, rel, currentFolder) {
    let entries;
    try { entries = await readdir(dir, { withFileTypes: true }); } catch { return; }
    const folderFiles = [];
    for (const e of entries) {
      const abs = join(dir, e.name);
      const r = (rel ? rel + '/' : '') + e.name;
      if (e.isDirectory()) {
        if (e.name === 'node_modules' || e.name === '.git') continue;
        await walk(abs, r, r.split(sep).join('/'));
      } else {
        const ext = extname(e.name).toLowerCase();
        if (!['.png','.jpg','.jpeg','.webp','.gif','.psd','.xlsx','.pdf'].includes(ext)) continue;
        let size = 0; let mtime = null;
        try { const st = await stat(abs); size = st.size; mtime = st.mtime.toISOString(); } catch {}
        const path = r.split(sep).join('/');
        const tags = tagsByPath.get(path) || {};
        folderFiles.push({
          name: e.name,
          path, ext, size, mtime,
          url: '/static/' + encodeURI(path),
          // тэги из c_library_assets
          type: tags.type || null,
          product_code: tags.product_code || null,
          slide_kind: tags.slide_kind || null,
          palette_cat: tags.palette_cat || null,
          dominant_hex: tags.dominant_hex || null,
          notes: tags.notes || null,
          rating: tags.rating || null,
        });
      }
    }
    if (folderFiles.length) {
      folderFiles.sort((a,b) => a.name.localeCompare(b.name));
      const folderName = currentFolder || rel;
      // подгружаем _meta.json + c_folder_meta
      let meta = folderMetaByName.get(folderName) || null;
      try {
        const raw = await readFile(join(dir, '_meta.json'), 'utf8');
        const j = JSON.parse(raw);
        meta = {
          folder: folderName,
          source: meta?.source || (j.nm ? 'wb' : null),
          source_id: meta?.source_id || j.nm || null,
          brand: meta?.brand || j.brand || null,
          display_name: meta?.display_name || j.name || null,
          full_name: meta?.full_name || j.title || null,
          source_url: meta?.source_url || j.source_url || null,
          pics_total: meta?.pics_total || j.downloaded || j.pics || null,
        };
      } catch {}
      // помечаем что нужно подмерджить wb_product (один запрос batch'ем после walk)
      tree.push({ folder: folderName, files: folderFiles, meta });
    }
  }
  // корень карточек тоже
  await walk(join(ROOT, 'карточки'), 'карточки', 'карточки');
  await walk(join(ROOT, 'output'), 'output', 'output');

  // batch: подгружаем wb_products одним запросом для всех wb_cabinet_* папок
  const nmIds = tree
    .filter(t => t.meta?.source && /^wb_cabinet_/.test(t.meta.source) && t.meta.source_id)
    .map(t => +t.meta.source_id)
    .filter(Number.isFinite);
  if (nmIds.length) {
    try {
      const wpRes = await pool.query(
        'select nm_id, title, description, subject_name, brand, vendor_code from c_wb_products where nm_id = ANY($1::bigint[])',
        [nmIds],
      );
      const byNm = new Map(wpRes.rows.map(r => [String(r.nm_id), r]));
      for (const t of tree) {
        if (t.meta?.source && /^wb_cabinet_/.test(t.meta.source) && t.meta.source_id) {
          const wp = byNm.get(String(t.meta.source_id));
          if (wp) {
            t.meta.full_name    = t.meta.full_name || wp.title || null;
            t.meta.brand        = t.meta.brand || wp.brand || null;
            t.meta.subject_name = wp.subject_name || null;
            t.meta.vendor_code  = wp.vendor_code || null;
            if (wp.description) {
              t.meta.description_short = wp.description.slice(0, 240) + (wp.description.length > 240 ? '…' : '');
            }
          }
        }
      }
    } catch (e) { console.warn('wb-products batch failed', e.message); }
  }

  tree.sort((a,b) => a.folder.localeCompare(b.folder));
  sendJSON(res, 200, tree);
}

// Тянет факты о товаре из c_wb_products / c_skus и собирает компактный блок.
// Возвращает { factsBlock, themed } — themed это короткий хинт по тематическим образам для AI.
async function buildProductFacts({ wb_nm_id, sku_id }) {
  let wb = null, sku = null;
  if (wb_nm_id) {
    try {
      const r = await pool.query(`
        select nm_id, vendor_code, title, brand, description, subject_name,
               characteristics, composition, benefits, usage_text
        from c_wb_products where nm_id = $1
      `, [+wb_nm_id]);
      wb = r.rows[0] || null;
    } catch {}
  }
  if (sku_id) {
    try {
      const r = await pool.query(`
        select s.*, c.name_ru as category_name, p.code as palette_code
        from c_skus s
        left join c_categories c on c.id = s.category_id
        left join c_palettes p on p.id = s.palette_id
        where s.id = $1
      `, [+sku_id]);
      sku = r.rows[0] || null;
    } catch {}
  }
  if (!wb && !sku) return { factsBlock: '', themed: '' };

  const out = [];
  const title = wb?.title || sku?.name_ru || '';
  if (title) out.push(`  · Название: ${title}`);
  const cat = sku?.category_name || wb?.subject_name || '';
  if (cat) out.push(`  · Категория: ${cat}`);
  const brand = wb?.brand || 'GraFLab';
  if (brand) out.push(`  · Бренд: ${brand}`);

  // состав: либо из jsonb composition (массив объектов с name/dose), либо из active_subst
  const compItems = [];
  if (Array.isArray(wb?.composition)) {
    for (const c of wb.composition.slice(0, 6)) {
      if (typeof c === 'string') compItems.push(c);
      else if (c?.name) compItems.push([c.name, c.dose, c.unit].filter(Boolean).join(' '));
    }
  }
  if (!compItems.length && sku?.active_subst) compItems.push(sku.active_subst + (sku.dose_mg ? ` ${sku.dose_mg} мг` : ''));
  if (compItems.length) out.push(`  · Активные вещества: ${compItems.join(', ')}`);

  // польза
  const benefits = [];
  if (Array.isArray(wb?.benefits)) {
    for (const b of wb.benefits.slice(0, 5)) {
      if (typeof b === 'string') benefits.push(b);
      else if (b?.text || b?.title) benefits.push(b.text || b.title);
    }
  }
  if (benefits.length) out.push(`  · Польза: ${benefits.join('; ')}`);

  // тематические образы — для AI: какие визуальные подсказки уместны
  const lt = (title + ' ' + (compItems.join(' ')) + ' ' + (cat || '')).toLowerCase();
  const themed = [];
  if (/ежовик|hericium|гриб/u.test(lt))           themed.push('гриб ежовик гребенчатый (мягкий силуэт), нейроны');
  if (/гинкго|ginkgo/u.test(lt))                   themed.push('лист гинкго-билоба, нейронные связи');
  if (/мака|maca/u.test(lt))                       themed.push('корень мака, тёплые тона энергии');
  if (/глицин|glycine/u.test(lt))                  themed.push('спокойствие, мягкие волны, ночной фон');
  if (/йохимбин|yohimbine/u.test(lt))              themed.push('активная энергия, тёплый оранжевый');
  if (/берберин|berberine/u.test(lt))              themed.push('жёлтый-золотой пигмент, корень барбариса');
  if (/магний|magnesium|треонат|threonate/u.test(lt)) themed.push('кристаллы магния, фиолетовая глубина');
  if (/asta|астаксантин|astaxanthin/u.test(lt))    themed.push('красный астаксантин, морские капли');
  if (/коллаген|collagen/u.test(lt))               themed.push('гладкая кожа, спираль коллагена');
  if (/q10|coq10|коэнзим/u.test(lt))               themed.push('энергия клетки, золотое сияние');
  if (/витамин\s*d|vitamin\s*d/u.test(lt))         themed.push('солнце, тёплый золотой свет');
  if (/нмн|nmn|никотинамид/u.test(lt))             themed.push('молекулы NAD+, longevity, серебристо-холодный');
  if (/ресвератрол|resveratrol/u.test(lt))         themed.push('виноград, рубиновые акценты');
  if (/псиллиум|psyllium|клетчат/u.test(lt))       themed.push('злаки, природные волокна, охра');
  if (/серрапептаз|serrapeptase|наттокиназ/u.test(lt)) themed.push('кровоток, чистые сосуды, прохладный синий');
  if (/бенфо|benfo|тиамин/u.test(lt))              themed.push('нейросеть мозга, deep blue + cyan glow');

  let factsBlock = '';
  if (out.length) {
    factsBlock = '=== ДАННЫЕ ТОВАРА (используй как смысловой контекст, НЕ копируй текст в картинку) ===\n' + out.join('\n');
  }
  return { factsBlock, themed: themed.join('; ') };
}

// Глубокая сборка промпта: brief пользователя ПЕРВЫМ, потом ограничения. Канон применяется ТОЛЬКО когда уместно.
async function buildDeepPrompt(slide_kind, userPromptText, options = {}) {
  const canon = await pool.query('select * from c_slide_templates where slide_kind=$1', [slide_kind]);
  const c = canon.rows[0];
  const black = await pool.query("select word, alternative from c_blacklist where scope='global'");
  const banned = black.rows.map(r => r.word).join(', ');

  const userBrief = String(userPromptText || '').trim();
  const briefLow = userBrief.toLowerCase();
  // флаг `u` нужен чтобы кириллица матчилась при `i`
  const isMinimal = /(минимализм|без декор|без частиц|нейтральн|чистый фон|пустой фон|без украшен|без объектов)/iu.test(briefLow);
  const productFacts = await buildProductFacts({ wb_nm_id: options.wb_nm_id, sku_id: options.sku_id });
  const userHasContent = options.hasTextLayers || options.hasImageLayers || userBrief.length > 20 || !!productFacts.factsBlock;

  // Эффекты для слайдов с банкой (1/2/6) — по дефолту glow включён, остальное от пользователя
  const slidesWithJar = [1, 2, 6];
  const isJarSlide = slidesWithJar.includes(+slide_kind);
  const effFx = { ...(options.canon_opts || {}) };
  if (options.hasJar && isJarSlide) {
    if (effFx.pedestal === undefined && effFx.glow === undefined) effFx.glow = true;
  }
  const layoutMode = options.layout_mode || 'approx';

  const lines = [];

  // 1. КОРОТКИЙ КОНТЕКСТ
  lines.push(`Создай ФОН-композицию для карточки товара (БАД GRAflab, маркетплейс WB), слайд ${slide_kind} «${c?.title || 'card'}».`);
  lines.push(`Размер: портрет 1086×1449 (или близкий к нему).`);
  lines.push('');

  // 1.5 ФАКТЫ ТОВАРА — для смыслового контекста
  if (productFacts.factsBlock) {
    lines.push(productFacts.factsBlock);
    if (productFacts.themed) {
      lines.push(`  · Тематические образы (можно подмешать в фон, очень аккуратно): ${productFacts.themed}`);
    }
    lines.push('');
  }

  // 1.7 ПАЛИТРА — отдельный жёсткий блок если задана
  if (options.palette) {
    const p = options.palette;
    lines.push('=== ПАЛИТРА (СТРОГО, БЕЗ ДРУГИХ ОТТЕНКОВ) ===');
    lines.push(`  · Доминирующий цвет: ${p.hex_main}`);
    if (p.hex_accent) lines.push(`  · Акцентный цвет: ${p.hex_accent}`);
    lines.push(`  · НЕ используй цвета вне этой палитры. Не рисуй оранжевый, если палитра холодная. Не рисуй синий, если палитра тёплая.`);
    lines.push(`  · Тёмные участки получай как глубокий оттенок доминирующего, не как чёрный.`);
    lines.push('');
  }

  // 2. ГЛАВНЫЕ ТРЕБОВАНИЯ — ПОЛЬЗОВАТЕЛЬСКИЕ ИДУТ ПЕРВЫМИ
  if (userBrief) {
    lines.push('=== ГЛАВНЫЕ ТРЕБОВАНИЯ ПОЛЬЗОВАТЕЛЯ (СТРОГО СОБЛЮДАЙ, ПЕРЕБИВАЕТ ВСЁ ОСТАЛЬНОЕ) ===');
    lines.push(userBrief);
    lines.push('');
  }

  // 3. ЖЁСТКИЕ ЗАПРЕТЫ ПРИ КОМПОЗИТИНГЕ
  if (options.composeMode) {
    if (options.hasJar) {
      const jp = options.jar_pos;
      const wantsPedestal = effFx.pedestal === true;
      lines.push('КРИТИЧНО — про банку:');
      lines.push('  · НЕ рисуй банку. Совсем не рисуй.');
      if (!wantsPedestal) {
        lines.push('  · НЕ рисуй постамент / пьедестал / диск / полку / отражение под банкой.');
      } else {
        lines.push('  · Банка появится на постаменте — впиши под банку круглый постамент (диск/подиум) с тенью и лёгкой подсветкой, аккуратно вписанный в композицию.');
      }
      if (jp) {
        lines.push(`  · Место под банку: центр в X≈${Math.round(jp.x)}%, Y≈${Math.round(jp.y)}%, ширина ≈${Math.round(jp.w)}% холста. Оставь там чистый фон без декора и текстов; композицию строй ВОКРУГ этого места.`);
      } else {
        lines.push('  · На месте банки (центр, ~55% Y) оставь чистый фон. Банку и её тень наложим программно поверх.');
      }
      if (effFx.glow) lines.push('  · Под зоной банки добавь мягкое свечение/halo — гало радиус ~50% от ширины банки, цвет — акцентный из палитры.');
      if (effFx.particles) lines.push('  · Добавь тонкие летящие частицы/искры по краям композиции (не перекрывая зону банки).');
    }
    if (options.hasTextLayers || options.hasImageLayers) {
      lines.push('  · НЕ рисуй текстовые блоки и UI-элементы — мы наложим точно поверх. Оставь композиционно свободные зоны.');
    } else {
      // Нет текстовых слоёв вообще — запретить любые буквы, иначе AI выдумывает «Данила» и пр.
      lines.push('  · НИКАКИХ букв, надписей, слов, цифр, лого в кадре. Только визуальный фон. Если хочется текст — он будет добавлен позже.');
    }
    lines.push('');

    // Per-layer lock: фиксированные слои упоминаем отдельно
    const layers = options.layers || [];
    const fixed = layers.filter(L => L.lock === 'pos' || L.lock === 'full');
    const free  = layers.filter(L => !L.lock || L.lock === 'free');
    if (fixed.length) {
      lines.push('Фиксированные элементы (СОБЛЮДАЙ ИХ ПОЗИЦИЮ ОБЯЗАТЕЛЬНО):');
      for (const L of fixed) {
        const desc = L.type === 'text'
          ? `текст «${(L.content || '').slice(0, 40)}»`
          : (L.type === 'draw' ? 'нарисованный штрих' : `картинка ${(L.content || '').slice(0, 40)}`);
        const rot = +L.rot || 0;
        const rotPart = rot ? `, повёрнут на ${rot}°` : '';
        const at = `X≈${Math.round(L.x)}% Y≈${Math.round(L.y)}% (шир.${Math.round(L.w)}%${rotPart})`;
        if (L.lock === 'full') {
          lines.push(`  · 🔒 ${desc} — этот объект ЗАФИКСИРОВАН целиком: НЕ ПЕРЕРИСОВЫВАЙ его, оставь точно ${at}. Композицию строй ВОКРУГ.`);
        } else {
          lines.push(`  · 📍 ${desc} — позиция ЗАФИКСИРОВАНА в ${at}. Содержимое можешь стилизовать, место не трогай.`);
        }
      }
      lines.push('');
    }
    if (free.length) {
      lines.push('Свободные элементы (можно сдвигать, наклонять, перерисовывать):');
      for (const L of free) {
        const desc = L.type === 'text'
          ? `текст «${(L.content || '').slice(0, 40)}»`
          : `картинка ${(L.content || '').slice(0, 40)}`;
        lines.push(`  · ${desc} — желательная позиция X≈${Math.round(L.x)}% Y≈${Math.round(L.y)}%, можно отклониться.`);
      }
      lines.push('');
    }
  }

  // 4. РАСКЛАДКА — ТОЛЬКО если есть контент И пользователь НЕ просил минимализм
  if (!isMinimal && userHasContent && c?.layout?.length) {
    const filtered = c.layout.filter(z => {
      const zoneText = (z.zone + ' ' + (z.note || '')).toLowerCase();
      if (options.hasJar && /банка|постамент|пьедестал/iu.test(zoneText)) return false;
      if (isMinimal && /декор|glow|частиц|тематич/iu.test(zoneText)) return false;
      return true;
    });
    if (filtered.length) {
      const headline = layoutMode === 'strict'
        ? 'РАСПОЛОЖЕНИЕ ЗОН (СОБЛЮДАЙ ТОЧНО):'
        : 'Желательное расположение зон (можно слегка двигать, но композицию сохрани):';
      lines.push(headline);
      for (const z of filtered) {
        if (z.w === 0 && z.h === 0) {
          lines.push(`  · ${z.zone} — ${z.note}`);
        } else {
          lines.push(`  · ${z.zone}: X=${z.x}% Y=${z.y}% (шир.${z.w}% выс.${z.h}%) — ${z.note}`);
        }
      }
      lines.push('');
    }
  }

  // 5. ХАРД-ПРАВИЛА (всегда)
  lines.push('Жёсткие правила:');
  lines.push('  · реальная кириллица, НИКАКИХ псевдо-русских глифов (только если есть текстовые слои)');
  if (banned) lines.push(`  · запрещённые слова: ${banned}`);
  lines.push('  · никаких медицинских утверждений');
  lines.push('  · премиум спокойный тон, мягкое студийное освещение');
  lines.push('  · композиция чистая, без визуального шума и случайных мелких объектов');

  // 5.5 КРЕАТИВНОСТЬ — интонация
  const cr = +options.creativity;
  if (cr === 0) {
    lines.push('');
    lines.push('Режим работы: СТРОГИЙ. Делай предсказуемо: проверенные композиции, спокойные оттенки, минимум декора. Без неожиданных решений. Это карточка маркетплейса, не арт.');
  } else if (cr === 2) {
    lines.push('');
    lines.push('Режим работы: СВОБОДНЫЙ. Можешь экспериментировать с композицией, светом, фактурой. Цель — чтобы карточка цепляла глаз. Палитру и факты товара не нарушай, остальное — твой выбор.');
  } else {
    lines.push('');
    lines.push('Режим работы: БАЛАНС. Следуй правилам, но не бойся придать характер: интересный свет, неожиданный ракурс декора, фактура. Главное — товар должен читаться сразу.');
  }

  // 6. ХИНТ ПО СТИЛЮ из канона — если нет ни brief, ни товара
  if (!userBrief && !productFacts.factsBlock && c?.must_have?.length) {
    lines.push('');
    lines.push('Стандарт для этого слайда (применять если нет уточнений пользователя):');
    for (const x of c.must_have.slice(0, 3)) lines.push('  · ' + x);
  }

  // 7. ФИРМЕННЫЙ СТИЛЬ GRAflab — тёплый напоминатель в конце (если у юзера не задан конкретный стиль через preset)
  const briefHasPreset = /\[пресет:/i.test(userBrief);
  const briefHasMinimal = /минимализм/iu.test(briefLow);
  if (!briefHasPreset && !briefHasMinimal) {
    lines.push('');
    lines.push('Фирменный стиль GRAflab (если нет прямых противоречий):');
    lines.push('  · фон тёмный, насыщенный, в палитре (тёмно-зелёный/синий/глубокий)');
    lines.push('  · маркеры тезисов — золотые круглые точки •, не флэт-иконки');
    lines.push('  · дозировки выделены крупно в контрастной плашке (например, чип «3500 мг»)');
    lines.push('  · фото моделей живые, lifestyle, в полупрофиль — если есть в композиции');
    lines.push('  · типографика UPPERCASE для заголовков, sans-serif, без декоративных шрифтов');
  }

  return lines.join('\n');
}

// Собрать полный промпт без вызова OpenAI (для предпросмотра в UI)
async function apiBuildPrompt(req, res) {
  const body = await readBody(req) || {};
  const { slide_kind = 1, prompt_text = '', layers = [], jar_path = null, jar_pos = null, canon_opts = {}, wb_nm_id = null, sku_id = null, palette = null, layout_mode = 'approx', creativity = 1 } = body;
  const hasTextLayers = layers.some(l => l.type === 'text');
  const hasImageLayers = layers.some(l => l.type === 'image');
  const hasJar = !!jar_path;
  const deepPrompt = await buildDeepPrompt(slide_kind, prompt_text, {
    composeMode: true, hasJar, hasTextLayers, hasImageLayers, jar_pos, canon_opts, wb_nm_id, sku_id, palette, layout_mode, layers, creativity,
  });
  sendJSON(res, 200, { prompt: deepPrompt });
}

// Запустить генерацию (реальный вызов OpenAI + серверный композитинг)
async function apiGenerate(req, res) {
  const body = await readBody(req);
  if (!body) return sendJSON(res, 400, { error: 'body required' });

  const { sku_id, slide_kind, prompt_id, prompt_text, dry_run = false, layers = [], jar_path: jarPathInput = null, jar_pos = null, canon_opts = {}, wb_nm_id = null, palette = null, layout_mode = 'approx', creativity = 1 } = body;
  let jar_path = jarPathInput;
  if (!slide_kind) return sendJSON(res, 400, { error: 'slide_kind required' });
  if (!prompt_id && !prompt_text) return sendJSON(res, 400, { error: 'prompt_id or prompt_text required' });

  let sku = { jar_master_path: null };
  if (sku_id) {
    const skuR = await pool.query('select * from c_skus where id=$1', [sku_id]);
    if (skuR.rows.length) sku = skuR.rows[0];
  }
  // если эталон банки не передан, но товар имеет мастер-банку — подставляем
  if (!jar_path && sku?.jar_master_path) jar_path = sku.jar_master_path;

  let prompt;
  if (prompt_id) {
    const promptR = await pool.query('select * from c_prompts where id=$1', [prompt_id]);
    if (!promptR.rows.length) return sendJSON(res, 400, { error: 'prompt not found' });
    prompt = promptR.rows[0];
  } else {
    const refPath = body.ref_image_path || null;
    prompt = {
      body: prompt_text,
      endpoint: refPath ? 'images.edit' : 'images.generate',
      size: body.size || '1024x1536',
      quality: body.quality || 'medium',
      ref_image_path: refPath,
    };
  }

  // Глубокая сборка финального промпта (канон + brand + blacklist + user)
  const hasTextLayers = layers.some(l => l.type === 'text');
  const hasImageLayers = layers.some(l => l.type === 'image');
  const hasJar = !!jar_path;
  const deepPrompt = await buildDeepPrompt(slide_kind, prompt.body, {
    composeMode: true, hasJar, hasTextLayers, hasImageLayers, jar_pos, canon_opts, wb_nm_id, sku_id, palette, layout_mode, layers, creativity,
  });

  const startedAt = Date.now();
  const ins = await pool.query(`
    insert into c_generations(sku_id,slide_kind,prompt_id,prompt_snapshot,ref_image_path,status,is_dry_run)
    values($1,$2,$3,$4,$5,'queued',$6)
    returning id
  `, [sku_id || null, slide_kind, prompt_id || null, deepPrompt, prompt.ref_image_path, dry_run]);
  const genId = ins.rows[0].id;

  if (dry_run) {
    await pool.query(`update c_generations set status='success', cost_rub=0, tokens=0, duration_ms=$1, error='dry_run' where id=$2`, [Date.now() - startedAt, genId]);
    return sendJSON(res, 200, { ok: true, generation_id: genId, dry_run: true, deep_prompt: deepPrompt });
  }

  try {
    const { OpenAI } = await import('openai');
    const { writeFile, mkdir } = await import('node:fs/promises');
    const { compose } = await import('./lib/compose.mjs');
    const client = new OpenAI({ apiKey: process.env.PROXYAPI_KEY, baseURL: process.env.PROXYAPI_BASE_URL });

    let result;
    if (prompt.endpoint === 'images.edit' && prompt.ref_image_path) {
      const refBuf = await readFile(join(ROOT, prompt.ref_image_path));
      result = await client.images.edit({
        model: 'gpt-image-2',
        image: new File([refBuf], 'ref.png', { type: 'image/png' }),
        prompt: deepPrompt,
        size: prompt.size || '1024x1536',
        quality: prompt.quality || 'medium',
        n: 1,
      });
    } else {
      result = await client.images.generate({
        model: 'gpt-image-2',
        prompt: deepPrompt,
        size: prompt.size || '1024x1536',
        quality: prompt.quality || 'medium',
        n: 1,
      });
    }

    const tokens = result.usage?.total_tokens || 0;
    const costRub = +(tokens * 0.0017).toFixed(2);

    if (!result.data?.[0]?.b64_json) {
      await pool.query(`update c_generations set status='failed', error=$1 where id=$2`, ['no image returned', genId]);
      return sendJSON(res, 500, { ok: false, generation_id: genId, error: 'no image returned' });
    }

    await mkdir(join(ROOT, 'output'), { recursive: true });
    const ts = Date.now();
    const rawName = `gen_${genId}_${ts}_raw.png`;
    const finalName = `gen_${genId}_${ts}.png`;
    const rawPath = `output/${rawName}`;
    const finalPath = `output/${finalName}`;

    // Сохраняем сырой ответ от OpenAI
    const aiBuf = Buffer.from(result.data[0].b64_json, 'base64');
    await writeFile(join(ROOT, rawPath), aiBuf);

    // Композитинг: накладываем банку и слои поверх
    let finalBuf;
    try {
      finalBuf = await compose(aiBuf, {
        targetSize: prompt.size || '1024x1536',
        jarPath: jar_path,
        jarPos: jar_pos,
        layers: layers,
        rootDir: ROOT,
      });
    } catch (e) {
      console.warn('compose failed, fallback to raw:', e.message);
      finalBuf = aiBuf;
    }
    await writeFile(join(ROOT, finalPath), finalBuf);

    const duration = Date.now() - startedAt;
    await pool.query(`
      update c_generations
      set status='success', output_path=$1, cost_rub=$2, tokens=$3, duration_ms=$4
      where id=$5
    `, [finalPath, costRub, tokens, duration, genId]);

    sendJSON(res, 200, {
      ok: true, generation_id: genId,
      output_path: finalPath,
      output_url: '/static/' + finalPath,
      raw_url: '/static/' + rawPath,
      cost_rub: costRub, tokens, duration_ms: duration,
      deep_prompt: deepPrompt,
    });
  } catch (e) {
    await pool.query(`update c_generations set status='failed', error=$1, duration_ms=$2 where id=$3`, [String(e.message || e), Date.now() - startedAt, genId]);
    sendJSON(res, 500, { ok: false, generation_id: genId, error: String(e.message || e) });
  }
}

// ─────────── router ───────────
async function router(req, res) {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const m = req.method;

  try {
    // API
    if (p === '/api/health')          return sendJSON(res, 200, { ok: true, ts: new Date().toISOString() });
    if (p === '/api/categories')       return await apiCategories(req, res);
    if (p === '/api/palettes')         return await apiPalettes(req, res);
    if (p === '/api/slide-templates')  return await apiSlideTemplates(req, res);
    if (p === '/api/skus')             return await apiSkus(req, res);
    let mm = p.match(/^\/api\/skus\/([^/]+)$/);
    if (mm)                            return await apiSkuById(req, res, mm[1]);
    if (p === '/api/wb-products')      return await apiWbProductsList(req, res);
    mm = p.match(/^\/api\/wb-products\/(\d+)$/);
    if (mm)                            return await apiWbProductById(req, res, mm[1]);

    if (p === '/api/prompts'  && m === 'GET')  return await apiPrompts(req, res);
    if (p === '/api/prompts'  && m === 'POST') return await apiCreatePrompt(req, res);
    mm = p.match(/^\/api\/prompts\/(\d+)$/);
    if (mm && m === 'GET')             return await apiPromptById(req, res, mm[1]);
    if (mm && (m === 'PATCH' || m === 'PUT')) return await apiUpdatePrompt(req, res, mm[1]);

    if (p === '/api/generations')      return await apiGenerations(req, res);
    if (p === '/api/analytics')        return await apiAnalytics(req, res);
    if (p === '/api/library/files')    return await apiLibraryFiles(req, res);
    if (p === '/api/library/tree')     return await apiLibraryTree(req, res);
    if (p === '/api/library/assets')   return await apiAssets(req, res);
    if (p === '/api/library/upload' && m === 'POST') return await apiLibraryUpload(req, res);
    if (p === '/api/library/delete' && m === 'POST') return await apiLibraryDelete(req, res);
    if (p === '/api/library/remove-bg' && m === 'POST') return await apiRemoveBg(req, res);
    if (p === '/api/library/duplicates' && m === 'GET')  return await apiFindDuplicates(req, res);
    if (p === '/api/library/rescan' && m === 'POST') return await apiLibraryRescan(req, res);
    if (p === '/api/library/asset' && m === 'GET')  return await apiLibraryAsset(req, res);
    if (p === '/api/library/asset' && (m === 'POST' || m === 'PATCH')) return await apiSetAssetMeta(req, res);
    if (p === '/api/library/folder-meta' && (m === 'POST' || m === 'PATCH')) return await apiSetFolderMeta(req, res);
    if (p === '/api/wb/product' && (m === 'POST' || m === 'PATCH')) return await apiSetWbProduct(req, res);
    if (p === '/api/recompose' && m === 'POST')       return await apiRecompose(req, res);
    if (p === '/api/build-prompt' && m === 'POST')    return await apiBuildPrompt(req, res);

    if (p === '/api/canon')           return await apiCanon(req, res);
    if (p === '/api/blacklist')       return await apiBlacklist(req, res);
    if (p === '/api/ratings')         return await apiRatings(req, res);
    mm = p.match(/^\/api\/generations\/(\d+)\/rate$/);
    if (mm && m === 'POST')           return await apiRateGeneration(req, res, mm[1]);

    if (p === '/api/projects' && m === 'GET')  return await apiProjectsList(req, res);
    if (p === '/api/projects' && m === 'POST') return await apiProjectCreate(req, res);
    mm = p.match(/^\/api\/projects\/(\d+)$/);
    if (mm && m === 'GET')    return await apiProjectGet(req, res, mm[1]);
    if (mm && (m === 'PATCH' || m === 'PUT')) return await apiProjectUpdate(req, res, mm[1]);
    if (mm && m === 'DELETE') return await apiProjectDelete(req, res, mm[1]);
    if (p === '/api/generate' && m === 'POST') return await apiGenerate(req, res);

    // OPTIONS для CORS
    if (m === 'OPTIONS') {
      return send(res, 204, '', {
        'Access-Control-Allow-Methods': 'GET,POST,PATCH,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      });
    }

    // Статика
    const ok = await serveStatic(req, res, p);
    if (!ok) sendNotFound(res, `${m} ${p}`);
  } catch (e) {
    console.error('500', e);
    sendJSON(res, 500, { error: String(e.message || e) });
  }
}

const server = createServer(router);
server.listen(PORT, () => {
  console.log(`\n  cards · GRAflab — http://localhost:${PORT}`);
  console.log(`  / → site/index.html`);
  console.log(`  /components → лаборатория компонентов`);
  console.log(`  /static/карточки/* → эталоны`);
  console.log(`  /api/* → API`);
  console.log(`\n  CTRL+C для остановки.\n`);
});

// graceful shutdown
process.on('SIGINT', async () => {
  console.log('\nshutting down...');
  await pool.end();
  server.close(() => process.exit(0));
});
