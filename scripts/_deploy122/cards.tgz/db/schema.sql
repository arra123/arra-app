-- cards · GRAflab — схема БД (префикс c_*)
-- Идемпотентно: можно гонять много раз, ничего не сломается.

-- ============ КАТЕГОРИИ ============
create table if not exists c_categories (
  id           text primary key,                   -- 'cognitive', 'energy', 'cardio', ...
  name_ru      text not null,
  description  text,
  created_at   timestamptz not null default now()
);

-- ============ ПАЛИТРЫ ============
create table if not exists c_palettes (
  id              serial primary key,
  code            text unique not null,            -- 'cognitive', 'energy', 'cardio'
  category_id     text references c_categories(id),
  hex_main        text not null,                   -- '#1e3a8a'
  hex_accent      text not null,                   -- '#4a96d4'
  bg_object       text,                            -- 'glowing brain neural network'
  mood            text,                            -- 'tech, сосредоточенный'
  palette_words   text,                            -- 'deep navy + cyan glow'
  is_starter      boolean not null default true,
  created_at      timestamptz not null default now()
);

-- ============ SKU (артикулы) ============
create table if not exists c_skus (
  id              serial primary key,
  sku             text unique not null,            -- 'BENFO_60'
  name_ru         text not null,                   -- 'Бенфотиамин 60'
  name_en         text,                            -- 'BENFOTIAMINE'
  category_id     text references c_categories(id),
  palette_id      integer references c_palettes(id),
  jar_master_path text,                             -- 'карточки/бенфо новый лучшая/банка.png'
  active_subst    text,
  dose_mg         integer,
  capsules        integer,
  status          text not null default 'data_collecting', -- new/data_collecting/data_ready/draft/approved/exported/error
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ============ ЭТАЛОННЫЕ БАНКИ (master PNG) ============
create table if not exists c_brand_jars (
  id           serial primary key,
  sku_id       integer references c_skus(id) on delete cascade,
  png_path     text not null,
  alpha_ok     boolean default false,                  -- прозрачный фон есть
  source       text,                                    -- 'manual', 'remove-bg', 'photographer'
  created_at   timestamptz not null default now()
);

-- ============ КАНОНИЧЕСКИЕ ШАБЛОНЫ 6 СЛАЙДОВ ============
create table if not exists c_slide_templates (
  id            serial primary key,
  slide_kind    integer not null,                  -- 1..6
  title         text not null,                     -- 'HERO', 'СОСТАВ И ДОЗИРОВКА', ...
  description   text,                              -- что обязательно, что мягко
  prompt_body   text,                              -- базовый шаблон с {{vars}}
  hard_rules    text[],                            -- jar/no-jar, no-pedestal, real-cyrillic ...
  has_jar       boolean default false,             -- 1, 2, 6 → true; 3, 4, 5 → false
  has_person    boolean default false,             -- 3, 4 → true
  unique(slide_kind)
);

-- ============ ПРОМПТЫ (наша рабочая база) ============
create table if not exists c_prompts (
  id              serial primary key,
  name            text not null,                   -- 'test22', 'состав-нейтрал', 'memory-focus'
  slide_kind      integer not null,                -- 1..6 — для какого слайда
  category_id     text references c_categories(id),
  version         integer not null default 1,
  status          text not null default 'draft',  -- draft / live / deprecated
  body            text not null,                   -- сам промпт (с переменными)
  endpoint        text default 'images.edit',     -- 'images.edit' / 'images.generate'
  size            text default '1024x1536',
  quality         text default 'medium',
  ref_image_path  text,                            -- эталон-картинка (например slide 1)
  postproc_recipe text,                            -- 'crop top=85,bottom=86 → upscale 1080x1440'
  notes           text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ============ ЛОГ ГЕНЕРАЦИЙ (история всех попыток) ============
create table if not exists c_generations (
  id              serial primary key,
  sku_id          integer references c_skus(id),
  slide_kind      integer,                         -- 1..6
  prompt_id       integer references c_prompts(id),
  prompt_snapshot text,                            -- полный текст промпта на момент запуска
  ref_image_path  text,
  output_path     text,                            -- 'output/test12_final.png'
  status          text not null,                   -- 'queued' / 'running' / 'success' / 'failed'
  error           text,
  cost_rub        numeric(10,2),                   -- ~6.0 за medium quality
  tokens          integer,
  duration_ms     integer,
  is_dry_run      boolean default false,
  created_by      text default 'tima',
  created_at      timestamptz not null default now()
);

-- ============ СВЯЗЬ SKU ↔ ПРОМПТ ДЛЯ СЛАЙДА (какой промпт используется по умолчанию) ============
create table if not exists c_sku_slide_prompt (
  sku_id      integer references c_skus(id) on delete cascade,
  slide_kind  integer not null,
  prompt_id   integer references c_prompts(id),
  primary key (sku_id, slide_kind)
);

-- ============ ЗАПРЕЩЁННЫЕ СЛОВА (по WB и категорийным правилам) ============
create table if not exists c_blacklist (
  id           serial primary key,
  word         text not null,
  reason       text,
  scope        text not null default 'global',  -- global / category-id
  alternative  text
);
create unique index if not exists ux_c_blacklist_word_scope on c_blacklist(word, scope);

-- расширяем slide_templates деталями для канона
alter table c_slide_templates add column if not exists must_have text[] default '{}';
alter table c_slide_templates add column if not exists must_avoid text[] default '{}';
alter table c_slide_templates add column if not exists soft_options text[] default '{}';
alter table c_slide_templates add column if not exists character_hint text;
alter table c_slide_templates add column if not exists layout jsonb default '[]'::jsonb;

-- ============ ОЦЕНКИ ГЕНЕРАЦИЙ (для обучения) ============
create table if not exists c_ratings (
  id           serial primary key,
  generation_id integer references c_generations(id) on delete cascade,
  rating       smallint check (rating in (-1, 1)),  -- -1 плохо, +1 хорошо
  note         text,
  created_by   text default 'tima',
  created_at   timestamptz not null default now()
);
create index if not exists ix_c_ratings_gen on c_ratings(generation_id);

-- ============ ПРОЕКТЫ (генерация без обязательного товара) ============
create table if not exists c_projects (
  id              serial primary key,
  name            text not null,
  sku_id          integer references c_skus(id),
  palette_id      integer references c_palettes(id),
  custom_color    text,
  jar_path        text,
  ref_paths       text[] default '{}',
  layers_json     jsonb default '{}'::jsonb,
  current_slide   integer default 1,
  brief           text,                     -- доп описание от пользователя для AI
  thumbnail_url   text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists ix_c_projects_updated on c_projects(updated_at desc);

-- привязка промптов к проектам (после создания c_projects)
alter table c_prompts add column if not exists project_id integer references c_projects(id) on delete set null;

-- ============ КАТАЛОГ БИБЛИОТЕКИ (теги к каждому файлу) ============
create table if not exists c_library_assets (
  id              serial primary key,
  path            text unique not null,            -- 'карточки/бенфо новый лучшая/бенфо новый1.png'
  file_name       text not null,
  folder          text not null,
  type            text not null default 'card',    -- 'card' / 'jar' / 'reference' / 'archive' / 'product-photo'
  product_code    text,                             -- 'benfo' / 'asta' / 'lumbro' / 'nmn' / 'psyllium' / 'resveratrol' / 'serrapeptase'
  slide_kind      integer,                          -- 1..6 если определимо
  palette_cat     text,                             -- 'cognitive' / 'energy' / 'cardio' / 'detox' / 'beauty' / 'immunity' / 'longevity' / 'vision'
  dominant_hex    text,                             -- '#1e3a8a'
  style_tag       text,                             -- 'premium' / 'minimal' / 'editorial' / 'wellness' / 'sport' / 'tech-cognitive' (опц., вручную)
  size_w          integer,
  size_h          integer,
  byte_size       integer,
  mtime           timestamptz,
  notes           text,
  rating          smallint,                         -- ручная оценка 1..5 если поставим
  created_at      timestamptz not null default now()
);
create index if not exists ix_c_lib_product on c_library_assets(product_code);
create index if not exists ix_c_lib_type on c_library_assets(type);
create index if not exists ix_c_lib_slide on c_library_assets(slide_kind);
create index if not exists ix_c_lib_palette on c_library_assets(palette_cat);

-- ============ ИНДЕКСЫ ============
create index if not exists ix_c_skus_category on c_skus(category_id);
create index if not exists ix_c_prompts_slide on c_prompts(slide_kind);
create index if not exists ix_c_prompts_cat on c_prompts(category_id);
create index if not exists ix_c_generations_sku on c_generations(sku_id);
create index if not exists ix_c_generations_created on c_generations(created_at desc);
