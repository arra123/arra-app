"""
Тест 4: бенфо слайд 2 V2 с правильным промптом.
Реф: Игорев слайд 2 бенфо (без банки, список во всю ширину).
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

# теперь референс — сам слайд 2 бенфо (без банки, во всю ширину)
REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый2.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\benfo_slide2_v2_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\benfo_slide2_v2_final.png")

prompt = """Generate a product card slide in EXACTLY the same style and composition as this reference,
but for a DIFFERENT product variation.

ABSOLUTELY KEEP IDENTICAL:
- Layout: ingredient list spans FULL WIDTH of the slide. NO product jar on this slide.
- Color palette: deep saturated blue background with light cyan glow, soft particles,
  glowing brain neural network on the background.
- Typography: same fonts, same weights as in the reference.
- Visual style of icon-circles on the left of each ingredient row.
- The 3 small badges at the bottom.

CONTENT TO RENDER (slide title and ingredients):

Title (large, bold, dark navy):  Бенфотиамин
Subtitle (smaller):  СОСТАВ И ДОЗИРОВКА
Tiny caption:  В 1 КАПСУЛЕ

Vertical full-width list of 5 ingredient rows. Each row:
   [round blue icon on the left] [ingredient name in CAPS, dark navy] ........ [right-aligned dose: NNN мг]

Rows in this order:
  1. БЕНФОТИАМИН — 350 мг (icon: shield)
  2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг (icon: molecule)
  3. БЕРБЕРИН — 20 мг (icon: leaf)
  4. МАГНИЙ ГЛИЦИНАТ — 100 мг (icon: "Mg" letter mark)
  5. АЦЕТИЛ-L-КАРНИТИН — 100 мг (icon: capsule)

Bottom row: three small badge plates side by side:
   [star icon]  ОТБОРНЫЕ ИНГРЕДИЕНТЫ
   [capsule icon]  60 КАПСУЛ
   [crown icon]  ПРЕМИАЛЬНОЕ КАЧЕСТВО

CRITICAL RULES (do not break):
- NO PRODUCT JAR on this slide. Anywhere. The ingredient list takes the entire central area.
- All Cyrillic text must be readable, NO garbled or fake-Cyrillic characters.
- No medical claims (no "лечит", no "против болезни", no diagnoses).
- Aspect: portrait, ratio close to 1086x1449.
"""

print("calling images.edit (benfo slide 2 v2, no jar, full width)...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=prompt,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))

img = Image.open(OUT_RAW)
print(f"raw size: {img.size}")
img.resize((1086, 1449), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"final saved: {OUT_FINAL}")
