// Заливает запреты слов и обогащает slide_templates деталями из SLIDE-CANON.md
import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();

// 1) Накатим schema (на случай если новые таблицы ещё нет)
const schema = readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
await c.query(schema);
console.log('schema OK');

// 2) Запреты
const blacklist = [
  // глобальные (запрещены по WB во всех категориях БАДов)
  ['лечит',         'WB запрещает медицинские утверждения',     'global', 'способствует'],
  ['излечивает',    'медицинское утверждение',                  'global', 'поддерживает'],
  ['омолаживает',   'медицинское утверждение',                  'global', 'способствует обновлению'],
  ['исцеляет',      'медицинское утверждение',                  'global', 'поддерживает'],
  ['против болезни','упоминание заболеваний запрещено',         'global', 'для активного образа жизни'],
  ['диагноз',       'упоминание заболеваний запрещено',         'global', null],
  ['гарантия результата','недопустимое обещание',                'global', 'способствует'],
  ['восстанавливает','медицинское утверждение',                 'global', 'поддерживает'],
  ['100%',          'недопустимое категоричное утверждение',    'global', 'высокий процент'],
  ['чудо',          'размытое маркетинговое слово',             'global', null],

  // категорийные
  ['память',        'для cognitive — заменить на «фокус» / «концентрация» / «ясность ума»', 'cognitive', 'фокус'],
  ['воспаление',    'для cardio с серрапептазой — нельзя',       'cardio',    'микроциркуляция'],
  ['кишечник',      'для digestive с псиллиумом — мягче',        'digestive', 'комфорт пищеварения'],
  ['токсины',       'для detox — заменить на «обновление»',      'detox',     'обновление клеток'],
];
await c.query("delete from c_blacklist");
for (const [w, r, scope, alt] of blacklist) {
  await c.query("insert into c_blacklist(word, reason, scope, alternative) values($1,$2,$3,$4)", [w, r, scope, alt]);
}
console.log(`  ${blacklist.length} blacklist words`);

// 3) Обогащаем slide_templates
const canon = [
  [1, 'HERO', {
    must_have: [
      'Заголовок продукта (UPPERCASE) — позиция и размер консистентны на всех слайдах',
      'Подзаголовок — одно главное обещание (1 строка)',
      '3-4 плитки преимуществ или компонентов (иконка + 1-2 строки)',
      'Банка GRAFLAB — на постаменте с тенью и свечением',
      'Фон с тематическим объектом + glow + частицы',
    ],
    must_avoid: [
      'Менять форму, цвет или текст банки',
      'Дозировки на этом слайде (только на slide 2)',
      'Псевдо-кириллица в тексте',
    ],
    soft_options: [
      'Верхняя «плашка с компонентами» (АСТАКСАНТИН + Q10 + PQQ + MCT) — есть/нет',
      'Положение плиток — слева или сверху',
      'Надпись «Будь здоров!» над банкой — есть/нет',
    ],
    character_hint: null,
  }],
  [2, 'СОСТАВ И ДОЗИРОВКА', {
    must_have: [
      'Заголовок: «СОСТАВ И ДОЗИРОВКА» / «СОСТАВ КОМПЛЕКСА»',
      'Подзаголовок: «В 1 КАПСУЛЕ» или «N мощных компонентов»',
      'Список компонентов: иконка + название + дозировка (мг)',
      '«мг» справа от числа на той же baseline',
      '3 нижних бейджа: «ОТБОРНЫЕ ИНГРЕДИЕНТЫ / 60 КАПСУЛ / ПРЕМИАЛЬНОЕ КАЧЕСТВО»',
    ],
    must_avoid: [
      'Банка, если компонентов 5+ (тогда список во всю ширину)',
      'Постамент / disc / shadow ring внизу',
      '«мг» на новой строке или через тире',
      'Псевдо-кириллица',
    ],
    soft_options: [
      'Банка справа если компонентов 3-4',
      'Дозировки могут быть без цифр («оптимальная дозировка»)',
    ],
    character_hint: null,
  }],
  [3, 'ВЫГОДЫ A + ЧЕЛОВЕК', {
    must_have: [
      'Заголовок «ПРЕИМУЩЕСТВА ДЛЯ X»',
      '3-4 плитки преимуществ',
      'Крупный персонаж A (фото-реалистичный)',
    ],
    must_avoid: [
      'Банка',
      'Плитки, наложенные на персонажа',
    ],
    soft_options: [
      'Положение плиток — слева/справа от персонажа',
      'Нижняя плашка-CTA',
    ],
    character_hint: 'energy/antiox → спортсменка-девушка; cognitive → офисный мужчина за ноутбуком; cardio → активный мужчина на улице; longevity → расслабленная женщина с книгой',
  }],
  [4, 'ВЫГОДЫ B + ЧЕЛОВЕК', {
    must_have: [
      'Заголовок (другой ракурс выгод, без повторов слайда 3)',
      '3-4 плитки (не дублируют 3-й слайд)',
      'Персонаж B противоположный персонажу A',
    ],
    must_avoid: [
      'Банка',
      'Повторение текста плиток со слайда 3',
      'Тот же типаж персонажа что на слайде 3',
    ],
    soft_options: [
      'Если на 3 был мужчина → на 4 женщина',
      'Если на 3 «активность» → на 4 «спокойствие»',
    ],
    character_hint: 'противоположный пол + другое настроение от персонажа на слайде 3',
  }],
  [5, 'ПРЕИМУЩЕСТВА КОМПЛЕКСА', {
    must_have: [
      'Заголовок «ПОЧЕМУ ВЫБИРАЮТ X» / «ПРЕИМУЩЕСТВА КОМПЛЕКСА»',
      '4-6 плиток в сетке 2×2 или 2×3 — самый плотный по тексту слайд',
    ],
    must_avoid: [
      'Банка (полностью)',
      'Люди / персонажи',
      'Постамент / shadow ring',
    ],
    soft_options: [
      'Декор — молекулы или капсулы фоном',
      'Нижний бейдж со списком ключевых слов',
    ],
    character_hint: null,
  }],
  [6, 'ДЛЯ КОГО / КАЧЕСТВО', {
    must_have: [
      'Заголовок «ДЛЯ КОГО ЭТОТ КОМПЛЕКС»',
      '4-6 категорий целевой аудитории (иконка + 1-2 строки «ДЛЯ ...»)',
      'Блок про качество: «ВЫСОКИЕ СТАНДАРТЫ / СТРОГИЙ КОНТРОЛЬ / ПРЕМИАЛЬНОЕ СЫРЬЁ»',
    ],
    must_avoid: [
      'Большая банка по центру',
      'Псевдо-кириллица',
    ],
    soft_options: [
      'Маленькая или средняя банка в углу',
      'Картинка лаборатории/производства как фон или плашка',
    ],
    character_hint: null,
  }],
];

for (const [kind, _t, d] of canon) {
  await c.query(
    `update c_slide_templates set must_have=$1, must_avoid=$2, soft_options=$3, character_hint=$4 where slide_kind=$5`,
    [d.must_have, d.must_avoid, d.soft_options, d.character_hint, kind]
  );
}
console.log(`  ${canon.length} canon details enriched`);

// 4) Несколько примеров оценок для существующих generations (чтобы UI было что показывать)
await c.query("delete from c_ratings");
const gens = await c.query("select id, status from c_generations order by id");
let rated = 0;
for (const g of gens.rows.slice(0, 8)) {
  const rating = g.status === 'success' ? 1 : -1;
  const note = g.status === 'success' ? 'хорошо легло, оставляем' : 'провал — пересборка';
  await c.query("insert into c_ratings(generation_id, rating, note) values($1,$2,$3)", [g.id, rating, note]);
  rated++;
}
console.log(`  ${rated} ratings`);

await c.end();
console.log('done');
