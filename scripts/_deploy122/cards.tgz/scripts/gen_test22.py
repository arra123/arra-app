"""
Тест #22: НИКАКОГО crop, НИКАКОГО padding.
Raw 1024×1536 (2:3) → resize до 1080×1620 (2:3, такой же формат как у Игоря на бенфо).
Никаких боковых полос, никаких обрезок верха/низа.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test22_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test22_final.png")

PROMPT = """The attached image is slide 1 of a product card series. Generate slide 2 of the SAME series.

=== BRAND CANVAS (must match slide 1 — same brain background, same title style/case/position, blue family palette only, no yellow/gold/orange, hexagonal glass-morphism icons) ===

Title position: SAME small top margin as on slide 1 (~80-100px from top edge).
Side margins: SAME small left/right margins as slide 1 (~50-60px from left/right edges).
The brain neural network in the upper-right corner — same position, same size as slide 1.

=== LAYOUT MAP for the 1024×1536 canvas ===

  Y=0..100    EMPTY blue background (top margin matching slide 1)
  Y=100..180   "БЕНФОТИАМИН" UPPERCASE title (large bold dark navy)
  Y=190..240   "СОСТАВ И ДОЗИРОВКА" subtitle (smaller, blue)
  Y=250..255   solid blue divider line (~80px wide, 4px tall, NO gradient, NO gold)
  Y=265..295   "В 1 КАПСУЛЕ" tiny grey caption
  Y=350..450   row 1: [shield] БЕНФОТИАМИН .... 350 мг
  Y=470..570   row 2: [molecule with 3 atoms and bonds] АЛЬФА-ЛИПОЕВАЯ КИСЛОТА .... 100 мг
  Y=590..690   row 3: [leaf] БЕРБЕРИН .... 20 мг
  Y=710..810   row 4: [Mg-ring] МАГНИЙ ГЛИЦИНАТ .... 100 мг
  Y=830..930   row 5: [brain] АЦЕТИЛ-L-КАРНИТИН .... 100 мг
  Y=1280..1430   bottom 3 plates: [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО
  Y=1430..1536   bottom margin matching slide 1

X-axis: content fills ~90% of width (left margin ~50px, right margin ~50px). Content extends close to the left/right edges, NOT centered with big gutters.

Each ingredient row layout: [hex icon, ~80px tall] [name CAPS, navy bold] ........ [dose: large number + small "мг" RIGHT of it on the SAME baseline].

Icons:
   1. БЕНФОТИАМИН — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — molecular structure: 3 atoms with visible bonds (like a triangle of 3 connected circles)
   3. БЕРБЕРИН — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — brain outline

Bottom plates: [icon] + 2-line text. Light-blue or light-gray separators between plates. NO yellow/gold.

=== FORBIDDEN ===
- NO product jar, NO pedestal, NO shadow ring.
- NO horizontal light streaks between rows.
- NO yellow/gold/orange anywhere.
- NO medical claims.
- NO garbled / pseudo Cyrillic.

Portrait, premium calm cognitive-tech mood.
"""

print("test #22: NO crop NO padding - just resize 1024x1536 -> 1080x1620 (2:3 like Igor)...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
# никакого crop, никакого padding — просто resize до 1080×1620 (2:3)
img_final = img.resize((1080, 1620), Image.LANCZOS)
img_final.save(OUT_FINAL, "PNG")
print(f"final: {img_final.size} (2:3 ratio)")
print(f"saved: {OUT_FINAL}")
