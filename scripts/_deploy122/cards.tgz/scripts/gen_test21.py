"""
Тест #21: фикс косяка #20 — вместо solid-color padding делаем EDGE-EXTEND
(растяжку крайних пикселей по бокам). Будет seamless, без видимых полос.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test21_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test21_final.png")

PROMPT = """The attached image is slide 1 of a product card series. Generate slide 2 of the SAME series.

=== BRAND CANVAS (must match slide 1 — same brain background, same title style/case/position, blue family palette only, no yellow/gold/orange, hexagonal glass-morphism icons) ===

Title position: SAME small top margin as on slide 1 (~80px from top edge).

=== LAYOUT MAP for the 1024×1536 canvas ===

  Y=0..80    EMPTY blue background (small top margin, like slide 1)
  Y=80..160   "БЕНФОТИАМИН" UPPERCASE title
  Y=170..220   "СОСТАВ И ДОЗИРОВКА" subtitle
  Y=230..235   solid blue divider line (~80px wide, 4px tall)
  Y=245..275   "В 1 КАПСУЛЕ" tiny grey caption
  Y=320..420   row 1: [shield] БЕНФОТИАМИН .... 350 мг
  Y=440..540   row 2: [molecule with 3 atoms and bonds] АЛЬФА-ЛИПОЕВАЯ КИСЛОТА .... 100 мг
  Y=560..660   row 3: [leaf] БЕРБЕРИН .... 20 мг
  Y=680..780   row 4: [Mg-ring] МАГНИЙ ГЛИЦИНАТ .... 100 мг
  Y=800..900   row 5: [brain] АЦЕТИЛ-L-КАРНИТИН .... 100 мг
  Y=1380..1500   bottom 3 plates: [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО
  Y=1500..1536   tiny bottom margin

Each ingredient row layout: [hex icon, ~80px tall] [name CAPS, navy bold] ........ [dose: large number + small "мг" RIGHT of it on the SAME baseline].

Icons:
   1. БЕНФОТИАМИН — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — molecular structure: 3 atoms with visible bonds
   3. БЕРБЕРИН — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — brain outline

Bottom plates: [icon] + 2-line text. Light-blue or light-gray separators. NO yellow/gold.

=== FORBIDDEN ===
- NO product jar, NO pedestal, NO shadow ring.
- NO horizontal light streaks between rows.
- NO yellow/gold/orange.
- NO medical claims.
- NO garbled / pseudo Cyrillic.

Portrait, premium calm cognitive-tech mood.
"""

print("test #21: edge-extend padding (no solid stripes)...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW).convert("RGB")
W, H = img.size  # 1024, 1536
target_w, target_h = 1152, 1536  # 3:4
pad_left = (target_w - W) // 2     # 64
pad_right = target_w - W - pad_left  # 64

# EDGE-EXTEND: берём крайние столбцы (по 8px) и растягиваем
# Берём не 1 пиксель а 8 — даст более плавный блёр на padding'е
edge_w = 8
left_strip = img.crop((0, 0, edge_w, H))
right_strip = img.crop((W - edge_w, 0, W, H))

left_pad = left_strip.resize((pad_left, H), Image.LANCZOS)
right_pad = right_strip.resize((pad_right, H), Image.LANCZOS)

img_padded = Image.new("RGB", (target_w, target_h), (0, 0, 0))
img_padded.paste(left_pad, (0, 0))
img_padded.paste(img, (pad_left, 0))
img_padded.paste(right_pad, (pad_left + W, 0))

img_final = img_padded.resize((1080, 1440), Image.LANCZOS)
img_final.save(OUT_FINAL, "PNG")
print(f"padded: {img_padded.size} (edge-extend), final: {img_final.size}")
print(f"saved: {OUT_FINAL}")
