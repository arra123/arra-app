"""
Тест #5: ref = бенфо slide 1 (для палитры/стиля/банки),
промпт = детальное описание slide 2 + наши правила и предотвращение известных косяков.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test05_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test05_final.png")

# === ПРОМПТ ТЕСТА #5 (записан 1:1 в EXPERIMENTS.md) ===
PROMPT = """The attached image is SLIDE 1 of a product card for "Бенфотиамин" by GRAFLAB.

Use it as a STYLE REFERENCE only. Match its:
- color palette (deep saturated navy-blue background with light cyan glow, soft particles, glowing brain neural network on background)
- typography (same fonts, same weights)
- icon language (thin-line round icons with soft inner shadow, NOT thick filled circles)
- premium-marketplace look and feel
- the exact GRAFLAB BENFOTIAMINE jar (form, label, text, proportions) — DO NOT redraw it differently

NOW generate SLIDE 2 of the same product card. Slide 2 is "Состав и дозировка".

LAYOUT for slide 2:
- Top-left: large bold dark-navy title "Бенфотиамин"
- Below the title: smaller bold blue subtitle "СОСТАВ И ДОЗИРОВКА"
- Below subtitle: tiny caption "В 1 КАПСУЛЕ"
- Top-right corner: glowing brain neural network silhouette (same as slide 1, half-faded, decorative)
- Center: vertical list of 5 ingredient ROWS, full slide width.
  Each row has a subtle blue-glass plate background (rounded corners, very soft).
  Inside each row, left-to-right:
    [thin-line round icon, small] [ingredient NAME in CAPS, dark-navy bold] ...flexible space... [DOSE in a small pill-shaped blue gradient capsule, with the number large bold and "мг" SMALLER and PLACED RIGHT NEXT TO the number on the SAME LINE — never below]
- Bottom of slide: three small horizontal badge plates side by side, separated by a tiny dot —
    [star icon] ОТБОРНЫЕ ИНГРЕДИЕНТЫ
    [capsule icon] 60 КАПСУЛ
    [crown icon] ПРЕМИАЛЬНОЕ КАЧЕСТВО

The 5 ingredients in this exact order:
  1. БЕНФОТИАМИН — 350 мг — icon: shield outline
  2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — icon: molecule outline
  3. БЕРБЕРИН — 20 мг — icon: leaf outline
  4. МАГНИЙ ГЛИЦИНАТ — 100 мг — icon: "Mg" lettermark in a thin ring
  5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — icon: capsule outline

HARD RULES (do not break — this is critical):
1. NO PRODUCT JAR anywhere on this slide. The list takes the full width. The jar belongs to slides 1 and 6 only, NOT to slide 2.
2. The jar shape and label that you saw in the reference must NEVER appear on this slide.
3. All Cyrillic letters must be REAL Cyrillic — no fake / pseudo-Cyrillic glyphs, no garbled text, no «Eyge ggopop» style nonsense. Every word must be readable as proper Russian.
4. The dose unit "мг" sits to the RIGHT of the number on the SAME baseline. Never under the number, never on a new line, never with a separating dash.
5. Icons must be THIN-LINE outlines (1-2 px stroke), inside a soft round plate. NOT thick solid fills.
6. No medical claims. No words like "лечит", "омолаживает", "против болезни", диагнозы.
7. The result MUST be portrait orientation, aspect close to 1086×1449.
8. Plenty of breathing room between rows — the slide should feel airy and premium, not cramped.

Mood: premium, calm, technological, trustworthy. Like a high-end pharma brand for cognitive health.
"""
# === КОНЕЦ ПРОМПТА ===

print("test #5: edit with slide 1 as ref, prompt describes slide 2...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
print(f"raw size: {img.size}")
img.resize((1086, 1449), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"final saved: {OUT_FINAL}")
