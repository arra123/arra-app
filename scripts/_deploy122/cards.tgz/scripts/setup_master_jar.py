"""
Никакой генерации. Берём готовую банку Игоря (с прозрачным фоном) и кладём как мастер-эталон.
+ доп.версия на зелёном фоне — для случаев, когда Игорь захочет вернуться к его старому воркфлоу.
"""
from PIL import Image
import pathlib, shutil

SRC = pathlib.Path(r"C:\Claude\Work\cards\карточки\банка asta1 прозрачн.png")
OUT_DIR = pathlib.Path(r"C:\Claude\Work\cards\output\masters")
OUT_DIR.mkdir(parents=True, exist_ok=True)

# 1. Эталон с прозрачным фоном (как есть, ничего не меняем)
master_transparent = OUT_DIR / "jar_asta_plus_master.png"
shutil.copy2(SRC, master_transparent)
print(f"эталон (transparent): {master_transparent}")

# 2. Версия на зелёном фоне — для ручного workflow
img = Image.open(SRC).convert("RGBA")
green = Image.new("RGBA", img.size, (0, 177, 64, 255))   # chroma green #00B140
composite = Image.alpha_composite(green, img)
master_green = OUT_DIR / "jar_asta_plus_on_green.png"
composite.convert("RGB").save(master_green, "PNG")
print(f"эталон (green bg): {master_green}")

print(f"\nразмер: {img.size[0]}×{img.size[1]} px")
print("это и есть НАШ эталон. Никакая генерация его больше не трогает.")
