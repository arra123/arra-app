"""
Тест #9: добавляю safe-margin сверху и снизу в промпте + симметричный crop меньше.
Цель: заголовок и бейджи целые.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test09_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test09_final.png")

PROMPT = """The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

Match slide 1 exactly: same color palette (light cyan-blue background with glowing brain neural network), same fonts, same hexagonal glass-morphism icon plates with thin gold/light edge, same atmosphere.

Slide 2 content:
- Title (Sentence case, NOT uppercase): "Бенфотиамин"
- Subtitle (smaller, blue): "СОСТАВ И ДОЗИРОВКА"
- Caption (small grey): "В 1 КАПСУЛЕ"
- 5 ingredient ROWS, each is a horizontal glass-morphism plate (rounded corners, soft inner highlight, hexagonal icon on the left). Layout per row: [hex icon] [INGREDIENT NAME, dark navy bold caps] ........ [DOSE: number large bold + "мг" smaller, both on the SAME LINE, "мг" RIGHT of the number]
- Icons (must match by meaning, do not invent):
   1. БЕНФОТИАМИН — 350 мг — icon: shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — icon: thin molecule outline
   3. БЕРБЕРИН — 20 мг — icon: leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — icon: "Mg" lettermark inside a thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — icon: brain outline
- Bottom row: 3 small horizontal plates side by side (NOT round medallions).
  Each plate: subtle white glow background, rounded corners, small icon on the left + 2-line text on the right.
  Plates contents:
    [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ
    [capsule] 60 КАПСУЛ
    [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО
  Separators: short thin gold horizontal LINES (no dots).

CRITICAL SAFE MARGINS (this is critical for layout):
- Leave at LEAST 100 pixels of clear background ABOVE the title — title must not touch the top edge.
- Leave at LEAST 100 pixels of clear background BELOW the bottom badges — badges must not touch the bottom edge.

OTHER HARD RULES:
- NO product jar anywhere on this slide.
- NO pedestal, NO platform, NO disc, NO shadow ring.
- "мг" is to the RIGHT of the number on the SAME baseline.
- All Cyrillic must be REAL Cyrillic — no garbled glyphs.
- No medical claims.
- Portrait orientation, premium calm tech mood.
"""

print("test #9: safe margins top+bottom in prompt, symmetric crop...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))

# Симметричный crop по 85px сверху и снизу (как изначально, но теперь модель в курсе про margins)
img = Image.open(OUT_RAW)
W, H = img.size
top_crop = 85
bottom_crop = 86  # 85+86=171
img_cropped = img.crop((0, top_crop, W, H - bottom_crop))
print(f"crop: top={top_crop}, bottom={bottom_crop}, result={img_cropped.size}")
assert img_cropped.size == (1024, 1365), f"unexpected size {img_cropped.size}"
img_final = img_cropped.resize((1080, 1440), Image.LANCZOS)
img_final.save(OUT_FINAL, "PNG")
print(f"final: {img_final.size}")
print(f"saved: {OUT_FINAL}")
