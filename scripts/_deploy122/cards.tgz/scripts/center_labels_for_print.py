"""
center_labels_for_print.py — берёт PDF-этикетки (FBS / маркировки) и
помещает каждую по центру листа A4 с заданным полем от края.

Зачем: Pantum (и многие другие лазерники) имеют непечатаемую кромку 3-5 мм.
Этикетка 60x60 mm обычно сохранена в углу страницы → QR режется. Скрипт
делает "сдвиг" — кладёт исходную страницу по центру A4 → можно печатать
с обычными настройками без масштабирования и драйверных приседаний.

Usage:
    python center_labels_for_print.py --input-dir ../../helper --pattern "*.pdf"
    python center_labels_for_print.py --input-dir path --output combined.pdf
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import fitz  # PyMuPDF

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

A4_W_PT = 595.276  # A4 в пунктах (1 pt = 1/72 inch)
A4_H_PT = 841.890


def center_pdf(input_path: Path, output_doc: fitz.Document, margin_mm: float = 8.0) -> int:
    src = fitz.open(input_path)
    pages_added = 0
    margin_pt = margin_mm * 72.0 / 25.4

    for page in src:
        page_rect = page.rect
        sw, sh = page_rect.width, page_rect.height

        usable_w = A4_W_PT - 2 * margin_pt
        usable_h = A4_H_PT - 2 * margin_pt
        scale = min(usable_w / sw, usable_h / sh, 1.0)
        target_w = sw * scale
        target_h = sh * scale

        x = (A4_W_PT - target_w) / 2
        y = (A4_H_PT - target_h) / 2
        target_rect = fitz.Rect(x, y, x + target_w, y + target_h)

        new_page = output_doc.new_page(width=A4_W_PT, height=A4_H_PT)
        new_page.show_pdf_page(target_rect, src, page.number)
        pages_added += 1

    src.close()
    return pages_added


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input-dir", required=True, type=Path)
    p.add_argument("--pattern", default="*.pdf")
    p.add_argument("--output", type=Path, default=None,
                   help="итоговый PDF (по умолчанию: <dir>/labels_to_print.pdf)")
    p.add_argument("--margin-mm", type=float, default=8.0)
    args = p.parse_args()

    files = sorted(args.input_dir.glob(args.pattern))
    files = [f for f in files if "_centered" not in f.name and "labels_to_print" not in f.name]

    if not files:
        print(f"PDF не найдено в {args.input_dir} по шаблону {args.pattern}", file=sys.stderr)
        sys.exit(1)

    output = args.output or (args.input_dir / "labels_to_print.pdf")
    print(f"найдено PDF: {len(files)}, поле {args.margin_mm} мм")

    out_doc = fitz.open()
    total_pages = 0
    for f in files:
        n = center_pdf(f, out_doc, margin_mm=args.margin_mm)
        print(f"  + {f.name} ({n} стр.)")
        total_pages += n

    out_doc.save(output)
    out_doc.close()
    print(f"\nготово: {output} ({total_pages} стр.)")


if __name__ == "__main__":
    main()
