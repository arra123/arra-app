// Заливает layout-зоны (где что располагается на карточке) для всех 6 канонических слайдов.
// Зоны в % от карточки (X — горизонталь, Y — вертикаль). x/y — центр зоны.
import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
const __dirname = dirname(fileURLToPath(import.meta.url));

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();
// schema (для добавления колонки layout если нет)
await c.query(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));

const layouts = {
  1: [
    { zone:'заголовок продукта',  x:50, y:12, w:90, h:14, note:'UPPERCASE, крупный bold sans, тёмный' },
    { zone:'подзаголовок-обещание', x:50, y:24, w:80, h:6, note:'1 строка, меньше заголовка' },
    { zone:'плитки преимуществ',  x:22, y:55, w:34, h:55, note:'3-4 плитки колонкой слева: иконка + headline + 1-line caption' },
    { zone:'банка GRAFLAB',        x:72, y:55, w:42, h:60, note:'front-centered на постаменте с тенью и свечением' },
    { zone:'фон',                  x:50, y:50, w:100, h:100, note:'согласно стилю выбранному пользователем; если минимализм — без декора' },
  ],
  2: [
    { zone:'заголовок продукта',   x:50, y:8,  w:90, h:8,  note:'UPPERCASE — та же позиция/размер что на слайде 1' },
    { zone:'подзаголовок «СОСТАВ И ДОЗИРОВКА»', x:50, y:16, w:70, h:5, note:'меньшим bold, синий/брендовый' },
    { zone:'caption «В 1 КАПСУЛЕ»', x:50, y:21, w:30, h:3, note:'мелкий серый, под подзаголовком' },
    { zone:'разделитель',           x:50, y:24, w:14, h:0.6, note:'тонкая золото-синяя градиент-линия 100×6px' },
    { zone:'список ингредиентов',   x:50, y:55, w:88, h:55, note:'5 строк glass-morphism: hex-icon | NAME caps bold | dose pill «N мг» (мг СПРАВА от числа на одной baseline)' },
    { zone:'нижние бейджи качества', x:50, y:92, w:90, h:6, note:'3 горизонтальных плашки разделённые тонкой золотой линией' },
    { zone:'НЕТ банки (если 5+ компонентов)', x:0, y:0, w:0, h:0, note:'если компонентов 5+ — банки нет, список во всю ширину' },
  ],
  3: [
    { zone:'заголовок «ПРЕИМУЩЕСТВА ДЛЯ X»', x:50, y:10, w:90, h:9, note:'UPPERCASE bold, та же позиция что 1/2' },
    { zone:'персонаж A (фото)',     x:25, y:60, w:42, h:75, note:'фото-реалистичный человек, full или 3/4 length, согласно character_hint' },
    { zone:'плитки преимуществ',    x:75, y:55, w:42, h:60, note:'3-4 плитки колонкой справа от персонажа (или наоборот)' },
    { zone:'нижняя CTA-плашка',     x:50, y:93, w:80, h:5, note:'опционально, например «КОМПЛЕКСНАЯ ПОДДЕРЖКА»' },
    { zone:'НЕТ банки',             x:0, y:0, w:0, h:0, note:'банки на этом слайде НЕТ' },
  ],
  4: [
    { zone:'заголовок (другой ракурс)', x:50, y:10, w:90, h:9, note:'UPPERCASE; формулировка отличается от слайда 3' },
    { zone:'персонаж B (фото)',         x:75, y:60, w:42, h:75, note:'противоположный пол/настроение от персонажа A' },
    { zone:'плитки (НЕ повторяют слайд 3)', x:25, y:55, w:42, h:60, note:'другие выгоды нежели на 3-м' },
    { zone:'НЕТ банки',                  x:0, y:0, w:0, h:0, note:'банки на этом слайде НЕТ' },
  ],
  5: [
    { zone:'заголовок «ПОЧЕМУ ВЫБИРАЮТ X»', x:50, y:10, w:90, h:9, note:'UPPERCASE bold' },
    { zone:'сетка плиток 2×3',           x:50, y:55, w:90, h:75, note:'2×3 (или 2×2): крупная иконка + bold headline + 1-line caption' },
    { zone:'нижний keyword-бейдж',       x:50, y:94, w:80, h:4, note:'опционально: «ЭНЕРГИЯ • ЗАЩИТА • ФОКУС»' },
    { zone:'НЕТ людей и НЕТ банки',      x:0, y:0, w:0, h:0, note:'это самый плотный текстом слайд — без отвлечений' },
  ],
  6: [
    { zone:'заголовок «ДЛЯ КОГО»',       x:50, y:10, w:90, h:9, note:'UPPERCASE bold' },
    { zone:'сетка аудитории 2×3',        x:30, y:50, w:55, h:65, note:'4-6 карточек «ДЛЯ ...» — иконка + 1-2 строки' },
    { zone:'банка (опционально)',         x:80, y:60, w:30, h:50, note:'маленькая или средняя в углу' },
    { zone:'блок качества',               x:50, y:90, w:80, h:8, note:'3 строки: ВЫСОКИЕ СТАНДАРТЫ / СТРОГИЙ КОНТРОЛЬ / ПРЕМИАЛЬНОЕ СЫРЬЁ' },
    { zone:'фон — намёк на лабораторию',  x:50, y:50, w:100, h:100, note:'subtle blurred lab/production hint' },
  ],
};

let updated = 0;
for (const [k, layout] of Object.entries(layouts)) {
  const r = await c.query(
    'update c_slide_templates set layout=$1::jsonb where slide_kind=$2',
    [JSON.stringify(layout), +k]
  );
  if (r.rowCount) updated++;
}
console.log(`updated ${updated}/${Object.keys(layouts).length} slide layouts`);
await c.end();
