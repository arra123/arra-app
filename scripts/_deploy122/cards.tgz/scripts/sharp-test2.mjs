import sharp from 'sharp';
import { writeFile } from 'node:fs/promises';

const text = 'АСТАКСАНТИН АБВ';

async function tryOne(label, opts) {
  try {
    const buf = await sharp({ text: opts }).png().toBuffer();
    await writeFile(`C:/Claude/Work/cards/output/font2-${label}.png`, buf);
    const meta = await sharp(buf).metadata();
    console.log(label, 'OK', meta.width + 'x' + meta.height);
  } catch (e) { console.log(label, 'ERR', e.message); }
}

await tryOne('A-arialBold-asArial',  { text, font: 'Arial 48',      fontfile: 'C:/Windows/Fonts/arialbd.ttf', width: 800, dpi: 72, rgba: true });
await tryOne('B-arialBold-asArialBold', { text, font: 'Arial Bold 48', fontfile: 'C:/Windows/Fonts/arialbd.ttf', width: 800, dpi: 72, rgba: true });
await tryOne('C-markup-bold', { text: '<span foreground="#ffffff" weight="bold">'+text+'</span>', font: 'Arial 48', fontfile: 'C:/Windows/Fonts/arialbd.ttf', width: 800, dpi: 72, rgba: true });
await tryOne('D-markup-color', { text: '<span foreground="#ffd86b">'+text+'</span>', font: 'Arial 48', fontfile: 'C:/Windows/Fonts/arial.ttf', width: 800, dpi: 72, rgba: true });
