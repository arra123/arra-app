import 'dotenv/config';
import pg from 'pg';
const { Client } = pg;
const c = new Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();

const fixes = [
  ['BENFO_60',          'карточки/бенфо новый лучшая/бенфо новый1.png'],
  ['ASTA_PLUS_60',      'карточки/аста2/1.png'],
  ['LUMBRO_NATTO_SERRA','карточки/любмро/1.png'],
  ['NMN_250',           'карточки/nmn new/комплекс1.png'],
  ['PSYLLIUM_180',      'карточки/псиллиум/псиллиум1.png'],
  ['RESVERATROL_60',    'карточки/ресветарол готовый/123.png'],
  ['SERRAP_60',         'карточки/серрапептаза готовый/серрапептаза1.png'],
];
for (const [sku, path] of fixes) {
  const r = await c.query('update c_skus set jar_master_path=$1 where sku=$2 returning sku', [path, sku]);
  console.log(r.rows.length ? `  ${sku} → ${path}` : `  SKIP ${sku}`);
}
await c.end();
console.log('done');
