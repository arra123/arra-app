"""
Тест #6: минимальный промпт + ref slide 1.
Цель: пусть модель сама держит стиль (меньше моих навязываний).
Размер финала: 1080×1440 (3:4, WB-стандарт). Без искажений.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test06_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test06_final.png")

# === ПРОМПТ ТЕСТА #6 — минимальный ===
PROMPT = """The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

Match slide 1 exactly: same color palette, same fonts, same icon look, same brand jar style and proportions, same plate/glass-card style, same atmosphere, same level of detail.

Slide 2 content:
- Title: Бенфотиамин
- Subtitle: СОСТАВ И ДОЗИРОВКА
- Caption: В 1 КАПСУЛЕ
- 5 ingredient rows: name + dose
   1. БЕНФОТИАМИН — 350 мг
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг
   3. БЕРБЕРИН — 20 мг
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг
- Bottom 3 small badges: ОТБОРНЫЕ ИНГРЕДИЕНТЫ • 60 КАПСУЛ • ПРЕМИАЛЬНОЕ КАЧЕСТВО

Hard rules:
- NO product jar on this slide.
- "мг" sits right after the number on the same line.
- Real Cyrillic letters, not garbled.
- Portrait orientation.
"""
# === КОНЕЦ ===

print("test #6: minimal prompt + slide 1 ref...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))

# Постпроцесс: 1024x1536 → center-crop до 1024x1365 (3:4) → upscale до 1080x1440
img = Image.open(OUT_RAW)
print(f"raw size: {img.size}")

W, H = img.size              # 1024, 1536
target_h = int(W * 4 / 3)    # 1365
top = (H - target_h) // 2    # 85
img_cropped = img.crop((0, top, W, top + target_h))
img_final = img_cropped.resize((1080, 1440), Image.LANCZOS)
img_final.save(OUT_FINAL, "PNG")
print(f"cropped: {img_cropped.size}")
print(f"final saved: {OUT_FINAL}  size: {img_final.size}")
