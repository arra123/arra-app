"""
Тест #8: уменьшаем bottom-crop до 60px, чтобы не резать бейджи.
В промпте просим «extra bottom margin under badges» чтобы модель не клеила их вплотную к низу.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test08_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test08_final.png")

PROMPT = """The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

Match slide 1 exactly: same color palette (light cyan-blue background with glowing brain neural network), same fonts, same hexagonal glass-morphism icon plates with thin gold/light edge, same atmosphere.

Slide 2 content:
- Title (Sentence case, NOT uppercase): "Бенфотиамин"
- Subtitle (smaller, blue): "СОСТАВ И ДОЗИРОВКА"
- Caption (small grey): "В 1 КАПСУЛЕ"
- 5 ingredient ROWS, each is a horizontal glass-morphism plate (rounded corners, soft inner highlight, hexagonal icon on the left). Layout per row: [hex icon] [INGREDIENT NAME, dark navy bold caps] ........ [DOSE: number large bold + "мг" smaller, both on the SAME LINE, "мг" RIGHT of the number]
- Icons (must match by meaning, do not invent):
   1. БЕНФОТИАМИН — 350 мг — icon: shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — icon: thin molecule outline
   3. БЕРБЕРИН — 20 мг — icon: leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — icon: "Mg" lettermark inside a thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — icon: brain outline
- Bottom row of slide: 3 small horizontal plates side by side (NOT round medallions).
  Each plate: subtle white glow background, rounded corners, small icon on the left + 2-line text on the right.
  Plates contents (icon + text):
    [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ
    [capsule] 60 КАПСУЛ
    [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО
  Separators between plates: short thin gold horizontal LINES (no dots).
  IMPORTANT: leave generous bottom margin — at least 100px clear space BELOW these badges.

CRITICAL RULES (do not break):
- NO product jar anywhere on this slide.
- NO pedestal, NO platform, NO disc, NO shadow ring at the bottom of the slide.
- The title at the top must be FULLY VISIBLE — do not crop it.
- The bottom badges row must be FULLY VISIBLE — both lines of text in each badge readable, with at least 100px clear margin below.
- "мг" is to the RIGHT of the number on the SAME baseline.
- All Cyrillic must be REAL Cyrillic — no garbled or fake-Cyrillic glyphs.
- No medical claims.
- Portrait orientation, premium calm tech mood.
"""

print("test #8: smaller bottom-crop (60px), explicit bottom margin in prompt...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))

# Уменьшенный bottom-crop: 60px вместо 171
img = Image.open(OUT_RAW)
W, H = img.size  # 1024, 1536
# Хотим 4:3 ratio = 1024×1365, надо отрезать 171px. Но из этих 171
# отрежем только 60 снизу, а 111 сверху (минимум, чтобы заголовок не потерять — он сверху-слева)
# Стоп, нет. Если отрежем 60 снизу — итог 1024×1476, не 3:4. Надо ровно 1024×1365.
# Стратегия: оставляем модели запас сверху (там фон) — режем 130 сверху + 41 снизу.
# Это сохраняет бейджи целыми (низ режется минимально), а сверху обрезается фон над заголовком.
top_crop = 130
bottom_crop = 171 - top_crop  # = 41
img_cropped = img.crop((0, top_crop, W, H - bottom_crop))
print(f"crop: top={top_crop}, bottom={bottom_crop}, result={img_cropped.size}")
assert img_cropped.size == (1024, 1365), f"unexpected size {img_cropped.size}"
img_final = img_cropped.resize((1080, 1440), Image.LANCZOS)
img_final.save(OUT_FINAL, "PNG")
print(f"final: {img_final.size}")
print(f"saved: {OUT_FINAL}")
