"""
Тест end-to-end pipeline: фон через gpt-image-2 + композит банки + текстовые слои.
Цель: главный слайд ASTA PLUS как у Игоря (для сравнения).
"""
import os, time, base64, pathlib, sys
from openai import OpenAI
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")

client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

OUT_DIR = pathlib.Path(r"C:\Claude\Work\cards\output")
JAR_MASTER = pathlib.Path(r"C:\Claude\Work\cards\output\masters\jar_asta_plus_master.png")
W, H = 1086, 1449

# 1) ФОН — берём промпт из чата Игоря (сообщение 108, вариант 1)
bg_prompt = """bright premium orange gradient background, warm sunlight glow,
soft light streaks and energy particles, dynamic motion lines flowing left to right,
hexagonal molecular structures faintly glowing in the background,
clean minimalistic composition for marketplace product card,
strong contrast, modern advertising style,
left side slightly more detailed with soft glowing elements and warm orange tones,
right-center area clean and reserved for product placement,
warm energetic mood, premium look, cinematic depth,
no text, no objects, no product, no people, no labels"""

print("[1/3] генерим фон через gpt-image-2 (medium, 1024x1536)...")
t0 = time.time()
result = client.images.generate(
    model="gpt-image-2",
    prompt=bg_prompt,
    size="1024x1536",
    quality="medium",
    n=1,
)
print(f"      готово за {time.time()-t0:.1f}s")
print(f"      usage: {result.usage}")

bg_b64 = result.data[0].b64_json
bg_path = OUT_DIR / "slide1_bg_raw.png"
bg_path.write_bytes(base64.b64decode(bg_b64))

# resize до нашего размера 1086x1449
bg = Image.open(bg_path).convert("RGBA").resize((W, H), Image.LANCZOS)

# 2) КОМПОЗИТ БАНКИ
print("[2/3] композитим банку...")
jar = Image.open(JAR_MASTER).convert("RGBA")
# хотим чтобы банка занимала ~50% высоты слайда, по центру правой половины
target_h = int(H * 0.55)
ratio = target_h / jar.height
target_w = int(jar.width * ratio)
jar_resized = jar.resize((target_w, target_h), Image.LANCZOS)
# позиция: правая половина, центр по вертикали с лёгким смещением вниз
jar_x = int(W * 0.95) - target_w
jar_y = int(H * 0.40)
slide = bg.copy()
slide.alpha_composite(jar_resized, (jar_x, jar_y))

# 3) ТЕКСТОВЫЕ СЛОИ
print("[3/3] накладываем тексты и плитки...")
draw = ImageDraw.Draw(slide)

def font(size, bold=True):
    p = r"C:\Windows\Fonts\segoeuib.ttf" if bold else r"C:\Windows\Fonts\segoeui.ttf"
    return ImageFont.truetype(p, size)

def font_black(size):
    # импакт-подобный для главного заголовка
    for f in [r"C:\Windows\Fonts\impact.ttf", r"C:\Windows\Fonts\segoeuib.ttf"]:
        if pathlib.Path(f).exists():
            return ImageFont.truetype(f, size)
    return font(size, True)

# 3.1 — верхняя плашка «АСТАКСАНТИН + Q10 + PQQ + MCT»
top_y = 35
top_text = "АСТАКСАНТИН  +  Q10  +  PQQ  +  MCT"
ft_top = font(34, True)
tw, th = draw.textbbox((0,0), top_text, font=ft_top)[2:]
plate_w = tw + 80
plate_h = th + 36
plate_x = (W - plate_w) // 2
draw.rounded_rectangle((plate_x, top_y, plate_x+plate_w, top_y+plate_h), 30,
                       fill=(200, 30, 30, 255))
draw.text((plate_x + 40, top_y + 14), top_text, font=ft_top, fill=(255,255,255))

# 3.2 — главный заголовок «АСТАКСАНТИН»
ft_main = font_black(160)
title = "АСТАКСАНТИН"
tw, th = draw.textbbox((0,0), title, font=ft_main)[2:]
title_x = (W - tw) // 2
title_y = 130
# обводка для контраста
for dx in (-3,-2,2,3):
    for dy in (-3,-2,2,3):
        draw.text((title_x+dx, title_y+dy), title, font=ft_main, fill=(80,20,0))
draw.text((title_x, title_y), title, font=ft_main, fill=(255,255,255))

# 3.3 — подзаголовок
ft_sub = font(48, True)
sub = "АНТИОКСИДАНТНАЯ ЗАЩИТА"
tw, th = draw.textbbox((0,0), sub, font=ft_sub)[2:]
sub_x = (W - tw) // 2
sub_y = title_y + 175
draw.text((sub_x+2, sub_y+2), sub, font=ft_sub, fill=(80,20,0))
draw.text((sub_x, sub_y), sub, font=ft_sub, fill=(255,255,255))

# 3.4 — три плитки слева (Q10 / PQQ / MCT)
tiles = [
    ("Q10",  "поддержка\nклеточной энергии", (255, 110, 50)),
    ("PQQ",  "ясность ума\nи концентрация",  (180, 100, 220)),
    ("MCT",  "быстрый\nисточник энергии",    (255, 180, 60)),
]
tile_x = 30
tile_y_start = sub_y + 100
tile_w = 380
tile_h = 130
gap = 20
ft_tile_title = font(40, True)
ft_tile_desc  = font(22, True)

for i, (k, desc, color) in enumerate(tiles):
    y = tile_y_start + i * (tile_h + gap)
    # тень
    draw.rounded_rectangle((tile_x+4, y+5, tile_x+tile_w+4, y+tile_h+5), 18,
                           fill=(0,0,0,80))
    # карточка
    draw.rounded_rectangle((tile_x, y, tile_x+tile_w, y+tile_h), 18,
                           fill=(255,255,255,255), outline=(40,30,20), width=3)
    # цветной кружок-иконка слева
    cx, cy = tile_x + 55, y + tile_h//2
    draw.ellipse((cx-35, cy-35, cx+35, cy+35), fill=color, outline=(40,30,20), width=2)
    # заголовок плитки
    draw.text((tile_x + 110, y + 18), k, font=ft_tile_title, fill=(40, 30, 20))
    # описание
    draw.text((tile_x + 110, y + 70), desc, font=ft_tile_desc, fill=(90, 70, 60))

# 3.5 — нижний бейдж «60 капсул»
ft_caps = font(36, True)
caps_text = "60 КАПСУЛ"
tw, th = draw.textbbox((0,0), caps_text, font=ft_caps)[2:]
caps_w = tw + 60
caps_h = th + 20
caps_x = 30
caps_y = H - caps_h - 35
draw.rounded_rectangle((caps_x, caps_y, caps_x+caps_w, caps_y+caps_h), 24,
                       fill=(40,30,20,230))
draw.text((caps_x + 30, caps_y + 8), caps_text, font=ft_caps, fill=(255, 200, 100))

# Сохранить
out = OUT_DIR / "slide1_test.png"
slide.convert("RGB").save(out, "PNG")
print(f"\nГОТОВО: {out}")
