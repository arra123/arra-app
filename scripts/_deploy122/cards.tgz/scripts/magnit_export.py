"""
magnit_export.py — обработка xlsx-шаблона Магнит-Маркета.

Магнит-Маркет принимает максимум 10 ссылок на фото в одной ячейке (через `;`),
но при интеграции с Озоном попадаются товары с 11+ фото. Если их обрезать —
теряем контент. Если заменить пустой строкой — Магнит ругается.

Решение: лишние фото скачиваем, склеиваем в коллаж (2x2 / 2x3 / 3x3),
загружаем коллаж в S3 (twcstorage.ru/sprav/magnit/) и подставляем ссылку
на коллаж как 10-ю позицию.

Usage:
    python magnit_export.py --input data/ke_template.xlsx
    python magnit_export.py --input data/ke_template.xlsx --output data/ke_template_fixed.xlsx
    python magnit_export.py --input ... --dry-run         # ничего не качать, только отчёт
    python magnit_export.py --input ... --no-upload       # коллажи делать локально, без S3
"""

from __future__ import annotations

import argparse
import io
import sys
import time
from pathlib import Path
from typing import Optional

import boto3
import requests
from openpyxl import load_workbook
from PIL import Image

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

S3_ENDPOINT = "https://s3.twcstorage.ru"
S3_BUCKET = "sprav"
S3_PREFIX = "magnit"
S3_REGION = "ru-1"
S3_ACCESS_KEY = "FY03FKZ1LH5KO8FKK39Z"
S3_SECRET_KEY = "vCBksnVsm0E8qHuY7mxJ4nZV3bVg6BvLt4UJ13DT"

PHOTO_COL_NAME = "Ссылки на фото"
ARTICLE_COL_CANDIDATES = ("SKU id продавца", "Артикул", "Артикул товара", "Внутренний код", "SKU", "ID")
SHEET_NAME = "Товары"

MAX_PHOTOS = 10
COLLAGE_SIZE = 1200
COLLAGE_BG = (255, 255, 255)
HTTP_TIMEOUT = 30
HTTP_RETRIES = 2


def find_column(ws, header_name: str) -> Optional[int]:
    """Ищем номер колонки по заголовку в первой строке (1-based)."""
    for col_idx, cell in enumerate(ws[1], start=1):
        if cell.value and str(cell.value).strip() == header_name:
            return col_idx
    return None


def find_article_column(ws) -> Optional[int]:
    for name in ARTICLE_COL_CANDIDATES:
        col = find_column(ws, name)
        if col:
            return col
    return None


def split_urls(cell_value) -> list[str]:
    if not cell_value:
        return []
    raw = str(cell_value)
    parts = [p.strip() for p in raw.split(";")]
    return [p for p in parts if p]


def download_image(url: str) -> Optional[Image.Image]:
    for attempt in range(HTTP_RETRIES + 1):
        try:
            r = requests.get(url, timeout=HTTP_TIMEOUT)
            r.raise_for_status()
            img = Image.open(io.BytesIO(r.content)).convert("RGB")
            return img
        except Exception as e:
            if attempt == HTTP_RETRIES:
                print(f"    ! не скачалось {url}: {e}", file=sys.stderr)
                return None
            time.sleep(1)
    return None


def build_collage(images: list[Image.Image], canvas_size: int = COLLAGE_SIZE) -> Image.Image:
    """Склейка в квадратную сетку. 1→1x1, 2→1x2, 3-4→2x2, 5-6→2x3, 7-9→3x3, 10+→4x4."""
    n = len(images)
    if n <= 1:
        cols, rows = 1, 1
    elif n == 2:
        cols, rows = 2, 1
    elif n <= 4:
        cols, rows = 2, 2
    elif n <= 6:
        cols, rows = 3, 2
    elif n <= 9:
        cols, rows = 3, 3
    else:
        cols, rows = 4, 4

    cell_w = canvas_size // cols
    cell_h = canvas_size // rows
    canvas = Image.new("RGB", (cell_w * cols, cell_h * rows), COLLAGE_BG)

    for idx, img in enumerate(images[: cols * rows]):
        thumb = img.copy()
        thumb.thumbnail((cell_w, cell_h), Image.LANCZOS)
        x = (idx % cols) * cell_w + (cell_w - thumb.width) // 2
        y = (idx // cols) * cell_h + (cell_h - thumb.height) // 2
        canvas.paste(thumb, (x, y))

    return canvas


def upload_to_s3(s3_client, key: str, image: Image.Image) -> str:
    buf = io.BytesIO()
    image.save(buf, format="JPEG", quality=88, optimize=True)
    buf.seek(0)
    s3_client.put_object(
        Bucket=S3_BUCKET,
        Key=key,
        Body=buf.getvalue(),
        ContentType="image/jpeg",
        ACL="public-read",
    )
    return f"{S3_ENDPOINT}/{S3_BUCKET}/{key}"


def make_s3_client():
    return boto3.client(
        "s3",
        endpoint_url=S3_ENDPOINT,
        region_name=S3_REGION,
        aws_access_key_id=S3_ACCESS_KEY,
        aws_secret_access_key=S3_SECRET_KEY,
    )


def process(
    input_path: Path,
    output_path: Path,
    dry_run: bool = False,
    no_upload: bool = False,
) -> None:
    print(f"open {input_path}")
    wb = load_workbook(input_path)

    if SHEET_NAME not in wb.sheetnames:
        print(f"Лист '{SHEET_NAME}' не найден. Доступные: {wb.sheetnames}", file=sys.stderr)
        sys.exit(1)
    ws = wb[SHEET_NAME]

    photo_col = find_column(ws, PHOTO_COL_NAME)
    if not photo_col:
        print(f"Колонка '{PHOTO_COL_NAME}' не найдена в листе '{SHEET_NAME}'", file=sys.stderr)
        sys.exit(1)
    article_col = find_article_column(ws)
    print(f"sheet='{SHEET_NAME}' photo_col={photo_col} article_col={article_col or 'нет — буду брать row_idx'}")

    s3_client = None
    if not no_upload and not dry_run:
        s3_client = make_s3_client()

    local_dir = output_path.parent / "collages"
    if no_upload:
        local_dir.mkdir(parents=True, exist_ok=True)

    stats = {"rows": 0, "ok": 0, "fixed": 0, "empty": 0, "fail": 0}

    for row_idx in range(2, ws.max_row + 1):
        cell = ws.cell(row=row_idx, column=photo_col)
        urls = split_urls(cell.value)

        if not urls:
            stats["empty"] += 1
            continue

        stats["rows"] += 1

        if len(urls) <= MAX_PHOTOS:
            stats["ok"] += 1
            continue

        article = None
        if article_col:
            article = ws.cell(row=row_idx, column=article_col).value
        article_safe = str(article).strip() if article else f"row{row_idx}"
        article_safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in article_safe)

        keep = urls[: MAX_PHOTOS - 1]
        extras = urls[MAX_PHOTOS - 1 :]
        print(f"[row {row_idx}] {article_safe}: {len(urls)} фото → keep {len(keep)} + collage {len(extras)}")

        if dry_run:
            stats["fixed"] += 1
            continue

        images: list[Image.Image] = []
        for u in extras:
            img = download_image(u)
            if img:
                images.append(img)

        if not images:
            print(f"    ! ни одно фото не скачалось — оставляю первые 10")
            cell.value = ";".join(urls[:MAX_PHOTOS])
            stats["fail"] += 1
            continue

        collage = build_collage(images)
        collage_url: str

        if no_upload:
            local_path = local_dir / f"{article_safe}_collage.jpg"
            collage.save(local_path, format="JPEG", quality=88, optimize=True)
            collage_url = f"file://{local_path.resolve()}"
            print(f"    saved local: {local_path}")
        else:
            key = f"{S3_PREFIX}/{article_safe}_collage.jpg"
            collage_url = upload_to_s3(s3_client, key, collage)
            print(f"    uploaded: {collage_url}")

        new_urls = keep + [collage_url]
        cell.value = ";".join(new_urls)
        stats["fixed"] += 1

    if not dry_run:
        wb.save(output_path)
        print(f"saved → {output_path}")

    print()
    print("===== отчёт =====")
    print(f"строк с фото:     {stats['rows']}")
    print(f"норм (≤10):       {stats['ok']}")
    print(f"исправлено (>10): {stats['fixed']}")
    print(f"пусто:            {stats['empty']}")
    print(f"проблем:          {stats['fail']}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True, type=Path)
    p.add_argument("--output", type=Path, default=None)
    p.add_argument("--dry-run", action="store_true", help="только отчёт, ничего не менять")
    p.add_argument("--no-upload", action="store_true", help="коллажи сохранять локально, без S3")
    args = p.parse_args()

    if not args.input.exists():
        print(f"файл не найден: {args.input}", file=sys.stderr)
        sys.exit(1)

    output = args.output or args.input.with_name(args.input.stem + "_fixed" + args.input.suffix)
    process(args.input, output, dry_run=args.dry_run, no_upload=args.no_upload)


if __name__ == "__main__":
    main()
