// Парсер карточки Wildberries по nm-id (артикулу).
// Использование: node scripts/parse-wb.mjs 927416199
// Скачивает все слайды (big webp) в карточки/wb_<nm>/, опц. сразу запускает scan-library.

import { mkdir, writeFile, access } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

const nm = process.argv[2];
if (!nm || !/^\d+$/.test(nm)) {
  console.error('Usage: node scripts/parse-wb.mjs <nm-id>');
  process.exit(1);
}

console.log(`\n=== WB parse · nm=${nm} ===`);

// 1) Опционально пробуем JSON detail API (несколько endpoints), если не выйдет — ничего страшного
let pics = null, name = '', brand = '';
const detailUrls = [
  `https://card.wb.ru/cards/v2/detail?appType=1&curr=rub&dest=-1257786&nm=${nm}`,
  `https://card.wb.ru/cards/v1/detail?appType=1&curr=rub&dest=-1257786&nm=${nm}`,
  `https://card.wb.ru/cards/detail?appType=1&curr=rub&dest=-1257786&nm=${nm}`,
];
for (const url of detailUrls) {
  try {
    const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' } });
    if (!r.ok) continue;
    const ct = r.headers.get('content-type') || '';
    if (!ct.includes('json')) continue;
    const j = await r.json();
    const p = j?.data?.products?.[0];
    if (p) { pics = p.pics; name = p.name || ''; brand = p.brand || ''; console.log(`detail OK: pics=${pics}, ${brand} · ${name}`); break; }
  } catch {}
}
if (pics == null) console.log(`detail API недоступен — будем брутфорсом до первого 404`);

// 2) Подбираем basket номер (диапазоны WB меняются; вычисляем + бэкапом перебор)
const vol = Math.floor(+nm / 100000);
const part = Math.floor(+nm / 1000);

function basketByVol(v) {
  // актуальная карта на 2024-2026 (из открытого WB JS)
  const ranges = [
    [143,1],[287,2],[431,3],[719,4],[1007,5],[1061,6],[1115,7],[1169,8],[1313,9],[1601,10],
    [1655,11],[1919,12],[2045,13],[2189,14],[2405,15],[2621,16],[2837,17],[3053,18],[3269,19],[3485,20],
    [3701,21],[3917,22],[4133,23],[4349,24],[4565,25],[4781,26],[4997,27],[5213,28],[5429,29],[5645,30],
    [5861,31],[6077,32],[6293,33],[6509,34],[6725,35],[6941,36],[7157,37],[7373,38],[7589,39],[7805,40],
    [8021,41],[8237,42],[8453,43],[8669,44],[8885,45],[9101,46],[9317,47],[9533,48],[9749,49],[9965,50],
    [10181,51],[10397,52],[10613,53],[10829,54],[11045,55],
  ];
  for (const [hi, b] of ranges) if (v <= hi) return b;
  return 60;
}

const guessedBasket = basketByVol(vol);
// упорядоченный список: сначала ближайшие, потом 1..70
const candidates = [guessedBasket];
for (let d = 1; d <= 6; d++) candidates.push(guessedBasket + d, guessedBasket - d);
for (let i = 1; i <= 70; i++) if (!candidates.includes(i)) candidates.push(i);

const HOSTS = ['wbbasket.ru', 'wb.ru'];

async function checkBasket(b, host) {
  const url = `https://basket-${String(b).padStart(2,'0')}.${host}/vol${vol}/part${part}/${nm}/images/big/1.webp`;
  try {
    const r = await fetch(url, { method: 'HEAD' });
    return r.ok;
  } catch { return false; }
}

let basket = null;
let chosenHost = null;
outer:
for (const host of HOSTS) {
  for (const b of candidates) {
    if (b < 1 || b > 70) continue;
    process.stdout.write(`  basket-${String(b).padStart(2,'0')}.${host} ... `);
    if (await checkBasket(b, host)) { basket = b; chosenHost = host; console.log('OK'); break outer; }
    console.log('miss');
    if (process.env.QUICK === '1' && b > guessedBasket + 6) break;  // быстрая остановка для теста
  }
}
if (!basket) { console.error('basket не найден — попробуй вручную'); process.exit(4); }
const bb = String(basket).padStart(2, '0');

// 3) Скачиваем все слайды
const folderName = `wb_${nm}`;
const targetDir = join(ROOT, 'карточки', folderName);
await mkdir(targetDir, { recursive: true });

console.log(`\nfolder: карточки/${folderName}/`);

async function fetchWithTimeout(url, ms = 8000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), ms);
  try { return await fetch(url, { signal: ctl.signal }); }
  finally { clearTimeout(timer); }
}

const limit = pics || 30;
let okCount = 0, missCount = 0;
for (let i = 1; i <= limit; i++) {
  const url = `https://basket-${bb}.${chosenHost}/vol${vol}/part${part}/${nm}/images/big/${i}.webp`;
  process.stdout.write(`  ${String(i).padStart(2)}/${limit} ... `);
  try {
    const r = await fetchWithTimeout(url, 8000);
    if (!r.ok) {
      console.log(`HTTP ${r.status}`);
      missCount++;
      if (pics == null && missCount >= 2) { console.log('  → 2 подряд 404, останавливаюсь'); break; }
      continue;
    }
    missCount = 0;
    const buf = Buffer.from(await r.arrayBuffer());
    const outName = `${String(i).padStart(2,'0')}.webp`;
    await writeFile(join(targetDir, outName), buf);
    console.log(`saved ${(buf.length/1024).toFixed(0)} KB`);
    okCount++;
  } catch (e) {
    console.log('timeout/err: ' + e.message);
    missCount++;
    if (pics == null && missCount >= 3) break;
  }
}

// 4) Сохраняем мета
await writeFile(join(targetDir, '_meta.json'), JSON.stringify({
  nm, name, brand, pics, basket: bb, downloaded: okCount,
  source_url: `https://www.wildberries.ru/catalog/${nm}/detail.aspx`,
  created_at: new Date().toISOString(),
}, null, 2), 'utf8');

console.log(`\n=== ИТОГО ===`);
console.log(`скачано: ${okCount} / ${pics}`);
console.log(`папка:   карточки/${folderName}/`);
console.log(`\nЗапусти: node scripts/scan-library.mjs — чтобы перетегировать.`);
