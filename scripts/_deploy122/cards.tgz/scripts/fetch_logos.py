"""
fetch_logos.py — массовая загрузка иконок приложений из Apple App Store
для проекта bem-box (постаматы / локеры).

Берёт список запросов, ищет через iTunes Search API, скачивает иконку
512x512 с CDN Apple. Результат — папка PNG-файлов + manifest.json.
"""

from __future__ import annotations

import json
import re
import sys
import urllib.parse
from pathlib import Path

import requests

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

OUT_DIR = Path("C:/Claude/helper/logos")

# Категории и запросы. slug = имя файла без расширения.
# slug, query, must_match (один из этих токенов должен быть в trackName/bundleId/seller)
GROUPS = {
    "Маркетплейсы": [
        ("ymarket", "yandex market", ["яндекс маркет", "yandex market"]),
        ("ozon", "ozon", ["ozon"]),
        ("wildberries", "wildberries", ["wildberries", "wildberry"]),
        ("magnit-market", "магнит маркет", ["магнит маркет", "magnit"]),
        ("megamarket", "мегамаркет", ["мегамаркет", "megamarket", "sbermegamarket"]),
        ("aliexpress", "aliexpress", ["aliexpress"]),
    ],
    "Курьерские службы": [
        ("cdek", "сдэк", ["сдэк", "cdek"]),
        ("boxberry", "boxberry", ["boxberry"]),
        ("pochta-rossii", "почта россии", ["почта россии", "russian post"]),
        ("dpd", "dpd доставка", ["dpd"]),
        ("dellin", "деловые линии", ["деловые линии", "dellin"]),
        ("5post", "5post", ["5post"]),
        ("pickpoint", "pickpoint", ["pickpoint"]),
        ("yandex-delivery", "яндекс доставка", ["яндекс доставка", "yandex delivery"]),
        ("yandex-go", "яндекс go", ["яндекс go", "yandex go"]),
        ("dostavista", "достависта", ["достависта", "dostavista"]),
    ],
    "Карты и навигация": [
        ("2gis", "2gis", ["2gis", "2гис"]),
        ("yandex-maps", "яндекс карты", ["яндекс карты", "yandex maps"]),
    ],
    "Платежи и банки": [
        ("yandex-pay", "яндекс пэй", ["яндекс пэй", "yandex pay"]),
        ("tbank", "т-банк", ["т-банк", "t-bank", "tinkoff"]),
        ("sber", "сбербанк", ["сбер", "sber"]),
        ("alfa", "альфа банк россия", ["альфа", "alfa-bank", "alfabank"]),
        ("vtb", "втб", ["втб", "vtb"]),
    ],
    "CRM и учёт": [
        ("amocrm", "amocrm", ["amocrm", "амо"]),
        ("bitrix24", "bitrix24", ["bitrix"]),
        ("1c", "1с предприятие", ["1с", "1c"]),
    ],
    "Мессенджеры и соцсети": [
        ("telegram", "telegram", ["telegram"]),
        ("vk", "вконтакте", ["вконтакте", "vkontakte", "vk.com"]),
        ("whatsapp", "whatsapp", ["whatsapp"]),
        ("max", "max мессенджер", ["max"]),
    ],
}


def search_app(query: str, must_match: list[str], country: str = "ru") -> dict | None:
    """Берём первый результат, в trackName/bundleId которого есть хоть одно из must_match."""
    url = f"https://itunes.apple.com/search?term={urllib.parse.quote(query)}&entity=software&country={country}&limit=15"
    try:
        r = requests.get(url, timeout=20)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        print(f"  ! search fail: {e}")
        return None

    results = data.get("results", [])
    if not results:
        return None

    must_match_lc = [m.lower() for m in must_match]
    for app in results:
        haystack = (
            (app.get("trackName") or "")
            + " "
            + (app.get("bundleId") or "")
            + " "
            + (app.get("sellerName") or "")
        ).lower()
        if any(m in haystack for m in must_match_lc):
            return app
    return None


def safe_filename(slug: str) -> str:
    return re.sub(r"[^a-z0-9_-]", "-", slug.lower())


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    manifest: dict[str, list[dict]] = {}
    not_found: list[str] = []

    for group, items in GROUPS.items():
        print(f"\n=== {group} ===")
        manifest[group] = []
        for slug, query, must_match in items:
            print(f"[{slug}] поиск: {query}")
            app = search_app(query, must_match)
            if not app:
                print(f"  ! не найдено (нет совпадения с {must_match})")
                not_found.append(f"{group}/{slug}")
                continue

            icon_url = app.get("artworkUrl512") or app.get("artworkUrl100")
            if not icon_url:
                print("  ! нет artwork")
                not_found.append(f"{group}/{slug}")
                continue

            file_path = OUT_DIR / f"{safe_filename(slug)}.png"
            try:
                ir = requests.get(icon_url, timeout=30)
                ir.raise_for_status()
                file_path.write_bytes(ir.content)
                print(f"  + {app.get('trackName')} → {file_path.name} ({len(ir.content)//1024} КБ)")
                manifest[group].append({
                    "slug": slug,
                    "name": app.get("trackName"),
                    "file": file_path.name,
                    "store_url": app.get("trackViewUrl"),
                })
            except Exception as e:
                print(f"  ! download fail: {e}")
                not_found.append(f"{group}/{slug}")

    (OUT_DIR / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(f"\n=== итог ===")
    print(f"скачано: {sum(len(v) for v in manifest.values())} иконок")
    print(f"не найдено: {len(not_found)}")
    if not_found:
        for nf in not_found:
            print(f"  - {nf}")
    print(f"\nфайлы: {OUT_DIR}")


if __name__ == "__main__":
    main()
