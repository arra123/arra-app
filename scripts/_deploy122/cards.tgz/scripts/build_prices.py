import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule

SRC = '1777032414137-30701843 (1).xlsx'
OUT = 'output/Цены_GRAFLAB_OZON.xlsx'

df = pd.read_excel(SRC, sheet_name=0, header=5)
df = df[['Артикул товара', 'Наименование товара', 'OZON SKU ID', 'Стоимость товара', 'Дата оформления заказа', 'Количество возвращаемых товаров']].copy()
df.columns = ['Артикул', 'Наименование', 'SKU OZON', 'Цена', 'Дата заказа', 'Кол-во']
df['Цена'] = pd.to_numeric(df['Цена'], errors='coerce')
df['Кол-во'] = pd.to_numeric(df['Кол-во'], errors='coerce').fillna(1).astype(int)

# -- aggregations --
by_sku = df.groupby(['Артикул', 'Наименование'], dropna=False).agg(
    Кол_во_возвратов=('Цена', 'count'),
    Мин_цена=('Цена', 'min'),
    Макс_цена=('Цена', 'max'),
    Средняя_цена=('Цена', 'mean'),
    Сумма=('Цена', 'sum'),
).reset_index()
by_sku = by_sku.sort_values('Кол_во_возвратов', ascending=False).reset_index(drop=True)

uniq_prices = df.drop_duplicates(subset=['Артикул'])[['Артикул', 'Наименование', 'SKU OZON', 'Цена']].sort_values('Артикул').reset_index(drop=True)

top_expensive = df.drop_duplicates(subset=['Артикул'])[['Артикул', 'Наименование', 'Цена']].sort_values('Цена', ascending=False).reset_index(drop=True)

full = df.sort_values(['Дата заказа'], ascending=False).reset_index(drop=True)

# ============== Build workbook ==============
wb = Workbook()

FONT = 'Calibri'
THIN = Side(border_style='thin', color='D0D0D0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
HEADER_FILL = PatternFill('solid', start_color='2C5F2E')
HEADER_FONT = Font(name=FONT, bold=True, color='FFFFFF', size=11)
TITLE_FONT = Font(name=FONT, bold=True, size=16, color='1A1A1A')
SUBTITLE_FONT = Font(name=FONT, italic=True, size=10, color='666666')
ZEBRA_FILL = PatternFill('solid', start_color='F7F7F5')
TOTAL_FILL = PatternFill('solid', start_color='E5602A')
TOTAL_FONT = Font(name=FONT, bold=True, color='FFFFFF', size=11)
CARD_FILL = PatternFill('solid', start_color='FAFAF8')

def style_header(row, sheet, ncols):
    for c in range(1, ncols + 1):
        cell = sheet.cell(row=row, column=c)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = BORDER
    sheet.row_dimensions[row].height = 32

def style_body(sheet, first_row, last_row, ncols, money_cols=(), center_cols=()):
    for r in range(first_row, last_row + 1):
        fill = ZEBRA_FILL if (r - first_row) % 2 == 1 else None
        for c in range(1, ncols + 1):
            cell = sheet.cell(row=r, column=c)
            cell.font = Font(name=FONT, size=11)
            cell.border = BORDER
            if fill:
                cell.fill = fill
            if c in money_cols:
                cell.number_format = '# ##0 ₽;[Red]-# ##0 ₽;-'
                cell.alignment = Alignment(horizontal='right', vertical='center')
            elif c in center_cols:
                cell.alignment = Alignment(horizontal='center', vertical='center')
            else:
                cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)

def set_widths(sheet, widths):
    for i, w in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(i)].width = w

# ============================
# Sheet 1: Сводка
# ============================
ws = wb.active
ws.title = 'Сводка'

ws['A1'] = 'GRAFLAB — анализ цен (возвраты OZON)'
ws['A1'].font = TITLE_FONT
ws.merge_cells('A1:D1')

ws['A2'] = 'Источник: выгрузка возвратов OZON, отчёт от 24.04.2026'
ws['A2'].font = SUBTITLE_FONT
ws.merge_cells('A2:D2')

ws['A4'] = 'Показатель'
ws['B4'] = 'Значение'
style_header(4, ws, 2)

kpi_rows = [
    ('Всего возвращённых позиций',       len(df),                      '0'),
    ('Уникальных артикулов',             df['Артикул'].nunique(),      '0'),
    ('Общая сумма возвратов',            float(df['Цена'].sum()),      '# ##0 ₽'),
    ('Средняя цена позиции',             float(df['Цена'].mean()),     '# ##0 ₽'),
    ('Медианная цена позиции',           float(df['Цена'].median()),   '# ##0 ₽'),
    ('Минимальная цена',                 float(df['Цена'].min()),      '# ##0 ₽'),
    ('Максимальная цена',                float(df['Цена'].max()),      '# ##0 ₽'),
]
start_row = 5
for i, (label, val, fmt) in enumerate(kpi_rows):
    r = start_row + i
    ws.cell(row=r, column=1, value=label).font = Font(name=FONT, size=11)
    ws.cell(row=r, column=1).border = BORDER
    ws.cell(row=r, column=1).alignment = Alignment(horizontal='left', vertical='center')
    c = ws.cell(row=r, column=2, value=val)
    c.font = Font(name=FONT, size=11, bold=True)
    c.number_format = fmt
    c.alignment = Alignment(horizontal='right', vertical='center')
    c.border = BORDER
    if i % 2 == 1:
        ws.cell(row=r, column=1).fill = ZEBRA_FILL
        ws.cell(row=r, column=2).fill = ZEBRA_FILL
    ws.row_dimensions[r].height = 22

ws['A13'] = 'Что в этом файле'
ws['A13'].font = Font(name=FONT, bold=True, size=12)

legend = [
    ('Сводка',            'ключевые показатели и общая сумма'),
    ('Цены по артикулам', 'один артикул = одна строка, цена и название'),
    ('Топ дорогих',       'артикулы отсортированы от самого дорогого'),
    ('Топ возвратов',     'что возвращают чаще всего (с частотой и суммой)'),
    ('Полный список',     'все 396 строк возвратов с датами'),
]
ws.cell(row=14, column=1, value='Лист').font = HEADER_FONT
ws.cell(row=14, column=2, value='Что внутри').font = HEADER_FONT
style_header(14, ws, 2)
for i, (name, desc) in enumerate(legend):
    r = 15 + i
    ws.cell(row=r, column=1, value=name).font = Font(name=FONT, size=11, bold=True)
    ws.cell(row=r, column=2, value=desc).font = Font(name=FONT, size=11)
    for c in (1, 2):
        cell = ws.cell(row=r, column=c)
        cell.border = BORDER
        cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
        if i % 2 == 1:
            cell.fill = ZEBRA_FILL
    ws.row_dimensions[r].height = 22

set_widths(ws, [32, 22])
ws.sheet_view.showGridLines = False

# ============================
# Sheet 2: Цены по артикулам (уникальные)
# ============================
ws2 = wb.create_sheet('Цены по артикулам')
ws2['A1'] = 'Цены товаров по артикулам'
ws2['A1'].font = TITLE_FONT
ws2.merge_cells('A1:D1')
ws2['A2'] = f'Уникальных артикулов: {len(uniq_prices)}'
ws2['A2'].font = SUBTITLE_FONT
ws2.merge_cells('A2:D2')

headers = ['Артикул', 'Наименование', 'SKU OZON', 'Цена']
for i, h in enumerate(headers, 1):
    ws2.cell(row=4, column=i, value=h)
style_header(4, ws2, 4)

for i, row in uniq_prices.iterrows():
    r = 5 + i
    ws2.cell(row=r, column=1, value=row['Артикул'])
    ws2.cell(row=r, column=2, value=row['Наименование'])
    ws2.cell(row=r, column=3, value=str(row['SKU OZON']) if pd.notna(row['SKU OZON']) else '')
    ws2.cell(row=r, column=4, value=float(row['Цена']) if pd.notna(row['Цена']) else None)

last_row = 4 + len(uniq_prices)
style_body(ws2, 5, last_row, 4, money_cols=(4,), center_cols=(1, 3))

set_widths(ws2, [16, 80, 16, 16])
ws2.freeze_panes = 'A5'
ws2.sheet_view.showGridLines = False
ws2.auto_filter.ref = f'A4:D{last_row}'

# ============================
# Sheet 3: Топ дорогих
# ============================
ws3 = wb.create_sheet('Топ дорогих')
ws3['A1'] = 'Товары от самых дорогих к дешёвым'
ws3['A1'].font = TITLE_FONT
ws3.merge_cells('A1:C1')
ws3['A2'] = 'Один артикул = одна строка'
ws3['A2'].font = SUBTITLE_FONT
ws3.merge_cells('A2:C2')

headers = ['Артикул', 'Наименование', 'Цена']
for i, h in enumerate(headers, 1):
    ws3.cell(row=4, column=i, value=h)
style_header(4, ws3, 3)

for i, row in top_expensive.iterrows():
    r = 5 + i
    ws3.cell(row=r, column=1, value=row['Артикул'])
    ws3.cell(row=r, column=2, value=row['Наименование'])
    ws3.cell(row=r, column=3, value=float(row['Цена']) if pd.notna(row['Цена']) else None)

last_row = 4 + len(top_expensive)
style_body(ws3, 5, last_row, 3, money_cols=(3,), center_cols=(1,))

# Color scale on price
rule = ColorScaleRule(start_type='min', start_color='FFF4EC',
                      mid_type='percentile', mid_value=50, mid_color='F5B086',
                      end_type='max', end_color='E5602A')
ws3.conditional_formatting.add(f'C5:C{last_row}', rule)

set_widths(ws3, [16, 80, 16])
ws3.freeze_panes = 'A5'
ws3.sheet_view.showGridLines = False
ws3.auto_filter.ref = f'A4:C{last_row}'

# ============================
# Sheet 4: Топ возвратов
# ============================
ws4 = wb.create_sheet('Топ возвратов')
ws4['A1'] = 'Что возвращают чаще всего'
ws4['A1'].font = TITLE_FONT
ws4.merge_cells('A1:G1')
ws4['A2'] = 'Сгруппировано по артикулу — количество возвратов, диапазон цен, сумма'
ws4['A2'].font = SUBTITLE_FONT
ws4.merge_cells('A2:G2')

headers = ['Артикул', 'Наименование', 'Кол-во возвратов', 'Мин. цена', 'Макс. цена', 'Средняя цена', 'Сумма возвратов']
for i, h in enumerate(headers, 1):
    ws4.cell(row=4, column=i, value=h)
style_header(4, ws4, 7)

for i, row in by_sku.iterrows():
    r = 5 + i
    ws4.cell(row=r, column=1, value=row['Артикул'])
    ws4.cell(row=r, column=2, value=row['Наименование'])
    ws4.cell(row=r, column=3, value=int(row['Кол_во_возвратов']))
    ws4.cell(row=r, column=4, value=float(row['Мин_цена']) if pd.notna(row['Мин_цена']) else None)
    ws4.cell(row=r, column=5, value=float(row['Макс_цена']) if pd.notna(row['Макс_цена']) else None)
    ws4.cell(row=r, column=6, value=float(row['Средняя_цена']) if pd.notna(row['Средняя_цена']) else None)
    ws4.cell(row=r, column=7, value=float(row['Сумма']) if pd.notna(row['Сумма']) else None)

last_row = 4 + len(by_sku)
style_body(ws4, 5, last_row, 7, money_cols=(4, 5, 6, 7), center_cols=(1, 3))

# Totals row
total_row = last_row + 1
ws4.cell(row=total_row, column=1, value='ИТОГО').font = TOTAL_FONT
ws4.cell(row=total_row, column=2, value=f'по {len(by_sku)} артикулам').font = TOTAL_FONT
ws4.cell(row=total_row, column=3, value=f'=SUM(C5:C{last_row})').font = TOTAL_FONT
ws4.cell(row=total_row, column=7, value=f'=SUM(G5:G{last_row})').font = TOTAL_FONT
for c in range(1, 8):
    cell = ws4.cell(row=total_row, column=c)
    cell.fill = TOTAL_FILL
    cell.border = BORDER
    cell.alignment = Alignment(horizontal='center' if c in (1, 3) else ('right' if c == 7 else 'left'), vertical='center')
    if c in (3,):
        cell.number_format = '# ##0'
    if c in (4, 5, 6, 7):
        cell.number_format = '# ##0 ₽'
ws4.row_dimensions[total_row].height = 26

# Color scale on count
rule2 = ColorScaleRule(start_type='min', start_color='E8F0E8',
                       mid_type='percentile', mid_value=50, mid_color='7AB07A',
                       end_type='max', end_color='2C5F2E')
ws4.conditional_formatting.add(f'C5:C{last_row}', rule2)

set_widths(ws4, [16, 60, 14, 14, 14, 14, 18])
ws4.freeze_panes = 'A5'
ws4.sheet_view.showGridLines = False
ws4.auto_filter.ref = f'A4:G{last_row}'

# ============================
# Sheet 5: Полный список
# ============================
ws5 = wb.create_sheet('Полный список')
ws5['A1'] = 'Все возвращённые позиции'
ws5['A1'].font = TITLE_FONT
ws5.merge_cells('A1:F1')
ws5['A2'] = f'{len(full)} строк — по одной на каждый возврат'
ws5['A2'].font = SUBTITLE_FONT
ws5.merge_cells('A2:F2')

headers = ['Артикул', 'Наименование', 'SKU OZON', 'Цена', 'Кол-во', 'Дата заказа']
for i, h in enumerate(headers, 1):
    ws5.cell(row=4, column=i, value=h)
style_header(4, ws5, 6)

for i, row in full.iterrows():
    r = 5 + i
    ws5.cell(row=r, column=1, value=row['Артикул'])
    ws5.cell(row=r, column=2, value=row['Наименование'])
    ws5.cell(row=r, column=3, value=str(row['SKU OZON']) if pd.notna(row['SKU OZON']) else '')
    ws5.cell(row=r, column=4, value=float(row['Цена']) if pd.notna(row['Цена']) else None)
    ws5.cell(row=r, column=5, value=int(row['Кол-во']))
    d = row['Дата заказа']
    if pd.notna(d):
        cell = ws5.cell(row=r, column=6, value=d)
        cell.number_format = 'DD.MM.YYYY'

last_row = 4 + len(full)
style_body(ws5, 5, last_row, 6, money_cols=(4,), center_cols=(1, 3, 5, 6))

# Totals
total_row = last_row + 1
ws5.cell(row=total_row, column=1, value='ИТОГО').font = TOTAL_FONT
ws5.cell(row=total_row, column=2, value=f'{len(full)} позиций').font = TOTAL_FONT
ws5.cell(row=total_row, column=4, value=f'=SUM(D5:D{last_row})').font = TOTAL_FONT
ws5.cell(row=total_row, column=5, value=f'=SUM(E5:E{last_row})').font = TOTAL_FONT
for c in range(1, 7):
    cell = ws5.cell(row=total_row, column=c)
    cell.fill = TOTAL_FILL
    cell.border = BORDER
    cell.alignment = Alignment(horizontal='center' if c in (1, 5) else ('right' if c == 4 else 'left'), vertical='center')
    if c == 4:
        cell.number_format = '# ##0 ₽'
    if c == 5:
        cell.number_format = '# ##0'
ws5.row_dimensions[total_row].height = 26

set_widths(ws5, [16, 70, 16, 14, 10, 16])
ws5.freeze_panes = 'A5'
ws5.sheet_view.showGridLines = False
ws5.auto_filter.ref = f'A4:F{last_row}'

wb.save(OUT)
print('Saved:', OUT)
