// Накатывает schema.sql + сиды (категории, палитры, шаблоны, SKU, реальные промпты из EXPERIMENTS.md, лог).
// Идемпотентно: ON CONFLICT DO NOTHING / DO UPDATE.
import 'dotenv/config';
import pg from 'pg';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const { Client } = pg;

const client = new Client({
  host: process.env.PGHOST,
  port: Number(process.env.PGPORT),
  database: process.env.PGDATABASE,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  ssl: false,
});

await client.connect();

console.log('— accumulating schema...');
const schema = readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
await client.query(schema);
console.log('  schema OK');

// ============ КАТЕГОРИИ ============
const categories = [
  ['cognitive',  'Мозг / фокус',          'Когнитивные функции, память, концентрация'],
  ['energy',     'Энергия / антиоксиданты', 'Антиоксидантная защита, активность, тонус'],
  ['cardio',     'Сосуды / кровоток',      'Микроциркуляция, поддержка сердечно-сосудистой'],
  ['detox',      'Детокс / longevity',     'Очищение, обновление, здоровое старение'],
  ['digestive',  'Пищеварение',            'ЖКТ, мягкая поддержка'],
  ['immunity',   'Иммунитет',              'Защита, витамин D, цинк'],
  ['beauty',     'Красота',                'Кожа, волосы, ногти, коллаген'],
  ['vision',     'Зрение',                 'Глаза, лютеин, антиокс'],
];
for (const [id, name_ru, description] of categories) {
  await client.query(
    'insert into c_categories(id,name_ru,description) values($1,$2,$3) on conflict (id) do update set name_ru=excluded.name_ru, description=excluded.description',
    [id, name_ru, description]
  );
}
console.log(`  ${categories.length} categories`);

// ============ ПАЛИТРЫ ============
const palettes = [
  ['cognitive', 'cognitive', '#1e3a8a', '#4a96d4', 'glowing brain neural network', 'tech, сосредоточенный', 'deep navy-blue + cyan glow'],
  ['energy',    'energy',    '#c2410c', '#f97316', 'molecules + sun particles + glow', 'солнечный, активный', 'warm orange + sunlight'],
  ['cardio',    'cardio',    '#be123c', '#f472b6', 'erythrocytes flow + waves', 'насыщенный, движение', 'red + pink waves'],
  ['detox',     'detox',     '#065f46', '#34d399', 'leaves + drops + clean atmosphere', 'свежесть, обновление', 'fresh green + mint'],
  ['digestive', 'digestive', '#581c87', '#a78bfa', 'soft abstract biology, lavender', 'мягкая забота', 'lavender + violet'],
  ['longevity', 'detox',     '#4c1d95', '#a78bfa', 'gold particles, premium glow',     'премиум, спокойствие', 'deep purple + gold'],
  ['beauty',    'beauty',    '#831843', '#fb7185', 'soft petals, rose gold sparkles',  'нежность, премиум',     'rose gold + pink'],
  ['immunity',  'immunity',  '#92400e', '#facc15', 'sun rays, citrus particles',       'тёплый, защитный',      'amber + sun yellow'],
  ['vision',    'vision',    '#064e3b', '#6ee7b7', 'eye iris pattern, soft glow',      'мягкий, чистый',        'emerald + mint'],
];
for (const [code, category_id, hex_main, hex_accent, bg_object, mood, palette_words] of palettes) {
  await client.query(
    `insert into c_palettes(code,category_id,hex_main,hex_accent,bg_object,mood,palette_words,is_starter)
     values($1,$2,$3,$4,$5,$6,$7,true)
     on conflict (code) do update set
       hex_main=excluded.hex_main, hex_accent=excluded.hex_accent,
       bg_object=excluded.bg_object, mood=excluded.mood, palette_words=excluded.palette_words`,
    [code, category_id, hex_main, hex_accent, bg_object, mood, palette_words]
  );
}
console.log(`  ${palettes.length} palettes`);

// ============ КАНОН 6 СЛАЙДОВ ============
const slideTemplates = [
  [1, 'HERO', 'Заголовок + банка крупно + продающие плитки + компоненты без дозировки',
    'HERO slide for GRAFLAB {{product}}. Palette: {{palette_words}}. Background: {{bg_object}} with soft glow and particles. Hero text: large bold "{{hero_name}}" + subtitle "{{hero_promise}}". Left side: {{N}} rounded white tiles with colored icons. Right-center: GRAFLAB jar on a glowing pedestal (use jar reference). No medical claims. Sharp Cyrillic text.',
    ['NO medical claims', 'Real Cyrillic only', 'Title UPPERCASE', 'Jar must use master PNG, not regenerated'],
    true, false],
  [2, 'СОСТАВ И ДОЗИРОВКА', 'Список ингредиентов с дозами. Банка только если 3-4 компонента.',
    'COMPOSITION slide for GRAFLAB {{product}}. Same palette and background as slide 1. Title: "СОСТАВ И ДОЗИРОВКА", subtitle "В 1 КАПСУЛЕ". List of {{N}} ingredients each row: icon + NAME + dose "NNN мг" right of number. Bottom: 3 small badges. {{if_no_jar: list spans full width}}.',
    ['NO jar (if 5+ components)', 'NO pedestal/platform/disc', '"мг" right of number same line', 'Real Cyrillic', 'Safe margin 100px above title and below badges'],
    false, false],
  [3, 'ВЫГОДЫ A + ЧЕЛОВЕК', 'Преимущества (часть 1) с персонажем A — обычно девушка-спортсменка',
    'BENEFITS A slide for GRAFLAB {{product}}. Same palette as slide 1. Title bold. On {{character_side}}: photo-realistic {{character_a_type}}, full or 3/4 length. Opposite side: {{N}} tiles each icon + 2-line headline + caption. NO JAR.',
    ['NO jar', 'Person photo-realistic', 'Tiles do not overlap with person'],
    false, true],
  [4, 'ВЫГОДЫ B + ЧЕЛОВЕК', 'Преимущества (часть 2) с персонажем B — другого пола / настроения',
    'BENEFITS B slide. Same palette. Different character from slide 3 (opposite gender or mood). Different tiles, no repeats with slide 3.',
    ['NO jar', 'Person opposite to slide 3', 'No repeating tiles from slide 3'],
    false, true],
  [5, 'ПРЕИМУЩЕСТВА КОМПЛЕКСА', 'Самый плотный по тексту. 4-6 плиток в сетке. Без банки и людей.',
    'COMPLEX-ADVANTAGES slide. Title bold. Grid {{rows}}×{{cols}} of rounded tiles each: large icon + bold headline + 1-line caption. Decoration: subtle molecules, no people, no jar.',
    ['NO jar', 'NO people', 'Only tiles + decoration'],
    false, false],
  [6, 'ДЛЯ КОГО / КАЧЕСТВО', 'Целевая аудитория + блок про стандарты GMP. Маленькая банка опционально.',
    'FOR-WHOM slide. Title bold. Grid of {{N}} target-audience cards each: icon + 1-2 line "ДЛЯ ..." headline. Quality block: GMP / премиальное сырьё. Background hint of laboratory/production.',
    ['Real Cyrillic', 'No medical claims', 'Small or medium jar optional'],
    true, false],
];
for (const [slide_kind, title, description, prompt_body, hard_rules, has_jar, has_person] of slideTemplates) {
  await client.query(
    `insert into c_slide_templates(slide_kind,title,description,prompt_body,hard_rules,has_jar,has_person)
     values($1,$2,$3,$4,$5,$6,$7)
     on conflict (slide_kind) do update set
       title=excluded.title, description=excluded.description,
       prompt_body=excluded.prompt_body, hard_rules=excluded.hard_rules,
       has_jar=excluded.has_jar, has_person=excluded.has_person`,
    [slide_kind, title, description, prompt_body, hard_rules, has_jar, has_person]
  );
}
console.log(`  ${slideTemplates.length} slide_templates`);

// ============ SKU ============
const skus = [
  ['BENFO_60',          'Бенфотиамин 60',                    'BENFOTIAMINE',       'cognitive', 'cognitive', 'карточки/бенфо новый лучшая/бенфо новый1.png', 'Бенфотиамин',      350, 60, 'data_ready'],
  ['ASTA_PLUS_60',      'Asta Plus',                          'ASTA PLUS',          'energy',    'energy',    'карточки/аста2/аста1.png',                       'Астаксантин',      20,  60, 'data_ready'],
  ['LUMBRO_NATTO_SERRA', 'Lumbro-Natto-Serra',                'LUMBRO',             'cardio',    'cardio',    'карточки/любмро/банка любмро1.png',              'Серрапептаза + наттокиназа', 0, 60, 'draft'],
  ['NMN_250',           'NMN 250мг',                          'NMN',                'detox',     'longevity', 'карточки/nmn new/nmn1.png',                       'NMN',              250, 60, 'draft'],
  ['PSYLLIUM_180',      'Псиллиум 180',                       'PSYLLIUM',           'digestive', 'digestive', 'карточки/псиллиум/псиллиум1.png',                'Шелуха псиллиума', 0,   180, 'data_collecting'],
  ['RESVERATROL_60',    'Ресвератрол',                        'RESVERATROL',        'energy',    'energy',    'карточки/ресветарол готовый/1.png',              'Транс-ресвератрол', 500, 60, 'data_collecting'],
  ['SERRAP_60',         'Серрапептаза',                       'SERRAPEPTASE',       'cardio',    'cardio',    'карточки/серрапептаза готовый/1.png',            'Серрапептаза',     120000, 60, 'data_collecting'],
];
for (const [sku, name_ru, name_en, category_id, palette_code, jar_path, active_subst, dose_mg, capsules, status] of skus) {
  // Сначала находим palette_id
  const pres = await client.query('select id from c_palettes where code=$1', [palette_code]);
  const palette_id = pres.rows[0]?.id;
  await client.query(
    `insert into c_skus(sku,name_ru,name_en,category_id,palette_id,jar_master_path,active_subst,dose_mg,capsules,status)
     values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     on conflict (sku) do update set
       name_ru=excluded.name_ru, name_en=excluded.name_en, category_id=excluded.category_id,
       palette_id=excluded.palette_id, jar_master_path=excluded.jar_master_path,
       active_subst=excluded.active_subst, dose_mg=excluded.dose_mg, capsules=excluded.capsules,
       status=excluded.status, updated_at=now()`,
    [sku, name_ru, name_en, category_id, palette_id, jar_path, active_subst, dose_mg || null, capsules || null, status]
  );
}
console.log(`  ${skus.length} skus`);

// ============ ПРОМПТЫ (реальные из EXPERIMENTS.md test05..test12) ============
const benfoPromptShort = `The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

Match slide 1 exactly: same palette, fonts, hexagonal glass-morphism icons.

Header (top-left, vertically stacked):
  "БЕНФОТИАМИН"  ← title, ALL UPPERCASE, large dark-navy bold
  "СОСТАВ И ДОЗИРОВКА"  ← subtitle, smaller, blue
  ━━━━━━━━━━ ← MANDATORY: gold-to-blue gradient horizontal LINE, 100px wide, 4-6px tall
  "В 1 КАПСУЛЕ"  ← small grey caption below the line

5 ingredient ROWS, each is a horizontal glass-morphism plate. Each row:
  [hex icon] [NAME caps bold] ........ [DOSE: number large + "мг" smaller, SAME line, мг RIGHT of number]

Icons:
 1. БЕНФОТИАМИН — 350 мг — shield outline
 2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — molecule outline
 3. БЕРБЕРИН — 20 мг — leaf outline
 4. МАГНИЙ ГЛИЦИНАТ — 100 мг — "Mg" lettermark in thin ring
 5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — brain outline

Bottom row: 3 horizontal plates side by side, separators = thin gold lines:
  [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО

CRITICAL SAFE MARGINS: 100px clear background ABOVE title and BELOW badges.

HARD RULES:
- NO product jar, NO pedestal, NO platform, NO disc, NO shadow ring.
- "мг" right of number, same baseline.
- Real Cyrillic only.
- Gold-blue divider IS REQUIRED, render visibly.
- Title ALL UPPERCASE.
- Portrait orientation, premium calm tech mood.`;

const prompts = [
  // name, slide_kind, category, version, status, body, endpoint, size, quality, ref_path, postproc, notes
  ['test22', 1, 'cognitive', 9, 'live',
    'HERO slide for GRAFLAB Бенфотиамин. Palette: deep navy + cyan glow, glowing brain network background. Hero text: "БЕНФОТИАМИН" UPPERCASE + subtitle "БИОДОСТУПНАЯ ФОРМА B1". Right-center: GRAFLAB jar on glowing pedestal. No medical claims, sharp Cyrillic.',
    'images.edit', '1024x1536', 'medium',
    null, null,
    '68% одобрено · 14 запусков · базовый hero для cognitive-серий'],

  ['состав-нейтрал', 2, 'cognitive', 12, 'live',
    benfoPromptShort,
    'images.edit', '1024x1536', 'medium',
    'карточки/бенфо новый лучшая/бенфо новый1.png',
    'crop top=85, bottom=86 → resize 1080x1440 LANCZOS',
    'Финальный рецепт после 12 итераций. Получен в EXPERIMENTS #12.'],

  ['memory-focus', 3, 'cognitive', 2, 'live',
    'BENEFITS A slide for GRAFLAB Бенфотиамин. Palette: deep navy + cyan glow. On left: photo-realistic office worker, focused at laptop, soft cyan rim light. On right: 4 rounded tiles each icon + bold headline + caption. Tiles: ФОКУС / ПАМЯТЬ / ЯСНОСТЬ УМА / РАБОТОСПОСОБНОСТЬ. NO JAR.',
    'images.edit', '1024x1536', 'medium',
    'карточки/бенфо новый лучшая/бенфо новый1.png', null,
    '82% одобрено · 9 запусков'],

  ['омега-benefits', 3, 'cardio', 3, 'live',
    'BENEFITS A slide for GRAFLAB Омега-3. Palette: red + pink waves, blood-flow background. Athletic woman running pose, full body. 4 tiles: СЕРДЦЕ / СОСУДЫ / ТОНУС / ВЫНОСЛИВОСТЬ. NO JAR.',
    'images.edit', '1024x1536', 'medium',
    null, null,
    '82% одобрено · 9 запусков · отлично для cardio'],

  ['детокс-применение', 4, 'detox', 2, 'draft',
    'BENEFITS B slide for GRAFLAB. Palette: fresh green + mint. Calm woman with book, soft natural light. 4 tiles: МЯГКОЕ ОЧИЩЕНИЕ / ОБНОВЛЕНИЕ / БАЛАНС / ЛЁГКОСТЬ. NO JAR.',
    'images.edit', '1024x1536', 'medium',
    null, null,
    'Часто правят — нужно усилить «мягкость» в тоне'],

  ['premium-УТП', 5, 'detox', 1, 'live',
    'COMPLEX-ADVANTAGES slide. Title: "ПОЧЕМУ ВЫБИРАЮТ NMN PREMIUM". Grid 2×3 of rounded tiles each: large icon + bold headline + 1-line caption. Tiles: 250МГ / NIAGEN GMP / 60 ДНЕЙ КУРС / ЧИСТЫЙ СОСТАВ / БЕЗ E-ДОБАВОК / ПРЕМИУМ. Subtle gold particles, no jar, no people.',
    'images.edit', '1024x1536', 'medium',
    null, null,
    '90% одобрено · 5 запусков · работает для longevity'],

  ['коллаген-hero', 1, 'beauty', 4, 'live',
    'HERO slide for GRAFLAB КОЛЛАГЕН. Palette: rose gold + pink. Background: soft petals, sparkles. Hero text: "КОЛЛАГЕН + ВИТАМИН С" + subtitle "КОЖА · ВОЛОСЫ · НОГТИ". GRAFLAB jar right-center on glowing pedestal.',
    'images.edit', '1024x1536', 'medium',
    null, null,
    '75% одобрено · 11 запусков'],

  ['витамин-D-гарантии', 6, 'immunity', 2, 'live',
    'FOR-WHOM slide for GRAFLAB ВИТАМИН D3 5000. Palette: amber + sun yellow. Title: "ДЛЯ КОГО ПОДХОДИТ". Grid of 6 audience cards. Quality block: ВЫСОКИЕ СТАНДАРТЫ / СТРОГИЙ КОНТРОЛЬ / ПРЕМИАЛЬНОЕ СЫРЬЁ. Background hint of lab.',
    'images.edit', '1024x1536', 'medium',
    null, null,
    '80% одобрено · 6 запусков · использовать для всех "ДЛЯ КОГО" слайдов'],

  // черновик
  ['состав-бенфо v10', 2, 'cognitive', 10, 'draft',
    'DRAFT — пробуем убрать ASCII-схему divider, заменить на text-only указание. Цель: посмотреть будет ли модель рисовать divider без ASCII.',
    'images.edit', '1024x1536', 'medium',
    'карточки/бенфо новый лучшая/бенфо новый1.png', null,
    '0 запусков · идея — упростить промпт после v9'],
];

for (const [name, slide_kind, cat, version, status, body, endpoint, size, quality, ref, postproc, notes] of prompts) {
  // Добавляем только если такой name+version не существует
  const r = await client.query('select id from c_prompts where name=$1 and version=$2', [name, version]);
  if (r.rows.length === 0) {
    await client.query(
      `insert into c_prompts(name,slide_kind,category_id,version,status,body,endpoint,size,quality,ref_image_path,postproc_recipe,notes)
       values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
      [name, slide_kind, cat, version, status, body, endpoint, size, quality, ref, postproc, notes]
    );
  }
}
console.log(`  ${prompts.length} prompts (insert if not exists)`);

// ============ ЛОГ ГЕНЕРАЦИЙ (из EXPERIMENTS #1..#12) ============
async function findPromptId(name, version) {
  const r = await client.query('select id from c_prompts where name=$1 and version=$2', [name, version]);
  return r.rows[0]?.id || null;
}
async function findSkuId(sku) {
  const r = await client.query('select id from c_skus where sku=$1', [sku]);
  return r.rows[0]?.id || null;
}

const benfoSkuId = await findSkuId('BENFO_60');
const test22Id = await findPromptId('test22', 9);
const sostavId = await findPromptId('состав-нейтрал', 12);

const generations = [
  // status, slide_kind, prompt_id, ref_image, output, cost, tokens, dur_ms, notes-as-error/null
  ['failed',  1, null,       null,                                             null,                    null, null, null,  'Test #1: AI придумал свою банку, не использовал master PNG. Learning: банку никогда не генерим с нуля.'],
  ['success', 1, null,       'карточки/аста/1.png',                           'output/asta_blue.png',  6.0,  3500, 22000, null],
  ['failed',  2, null,       'карточки/бенфо новый лучшая/бенфо новый1.png',  null,                    null, null, null,  'Test #3: ref был slide 1 → модель повторила композицию (с банкой). Banка наложилась на плитки.'],
  ['success', 2, null,       'карточки/бенфо новый лучшая/бенфо новый2.png',  'output/test04.png',     6.0,  3200, 24000, null],
  ['success', 2, null,       'карточки/бенфо новый лучшая/бенфо новый1.png',  'output/test05.png',     6.0,  3739, 28000, 'Test #5: явно «no jar», слов-описание slide 2. Получили вариацию. Иконки не совсем outline, но норм.'],
  ['success', 2, null,       'карточки/бенфо новый лучшая/бенфо новый1.png',  'output/test06.png',     5.0,  3213, 22000, 'Test #6: минимальный промпт. Постамент-фантом снизу.'],
  ['success', 2, null,       'карточки/бенфо новый лучшая/бенфо новый1.png',  'output/test07.png',     6.0,  3500, 25000, 'Test #7: фикс пьедестала. Бейджи обрезались.'],
  ['failed',  2, null,       'карточки/бенфо новый лучшая/бенфо новый1.png',  null,                    null, null, null,  'Test #8: top_crop=130 срезал заголовок.'],
  ['success', 2, sostavId,   'карточки/бенфо новый лучшая/бенфо новый1.png',  'output/test09_final.png', 6.0, 3400, 23000, 'Test #9: safe-margins в промпте. Заголовок целый, бейджи целые. ✅ РАБОЧИЙ ВАРИАНТ'],
  ['failed',  2, sostavId,   'карточки/бенфо новый лучшая/бенфо новый1.png',  null,                    null, null, null,  'Test #10: divider line не нарисовался без ASCII-схемы.'],
  ['success', 2, sostavId,   'карточки/бенфо новый лучшая/бенфо новый1.png',  'output/test11_final.png', 6.0, 3600, 24000, 'Test #11: agressive ASCII divider — полоска появилась. ✅'],
  ['success', 2, sostavId,   'карточки/бенфо новый лучшая/бенфо новый1.png',  'output/test12_final.png', 6.0, 3500, 23000, 'Test #12: UPPERCASE заголовок. ФИНАЛЬНЫЙ результат. Шаблон для slide 2 cognitive/blue.'],
];

// очистим старый лог чтобы не плодить дубли при повторной накатке
await client.query("delete from c_generations where created_by='seed'");
for (const [status, slide_kind, prompt_id, ref, out, cost, tokens, dur, err] of generations) {
  await client.query(
    `insert into c_generations(sku_id,slide_kind,prompt_id,prompt_snapshot,ref_image_path,output_path,status,error,cost_rub,tokens,duration_ms,is_dry_run,created_by)
     values($1,$2,$3,null,$4,$5,$6,$7,$8,$9,$10,false,'seed')`,
    [benfoSkuId, slide_kind, prompt_id, ref, out, status, err, cost, tokens, dur]
  );
}
console.log(`  ${generations.length} generations (history)`);

// ============ ПРИВЯЗКА SKU → ПРОМПТ ДЛЯ СЛАЙДА ============
const skuPromptMap = [
  ['BENFO_60', 1, 'test22', 9],
  ['BENFO_60', 2, 'состав-нейтрал', 12],
  ['BENFO_60', 3, 'memory-focus', 2],
];
await client.query('delete from c_sku_slide_prompt');
for (const [sku, slide_kind, pname, pver] of skuPromptMap) {
  const sid = await findSkuId(sku);
  const pid = await findPromptId(pname, pver);
  if (sid && pid) {
    await client.query(
      'insert into c_sku_slide_prompt(sku_id, slide_kind, prompt_id) values($1,$2,$3)',
      [sid, slide_kind, pid]
    );
  }
}
console.log(`  ${skuPromptMap.length} sku→prompt mappings`);

// ============ ИТОГ ============
const counts = await client.query(`
  select 'categories' as t, count(*)::int as n from c_categories union all
  select 'palettes', count(*) from c_palettes union all
  select 'skus', count(*) from c_skus union all
  select 'slide_templates', count(*) from c_slide_templates union all
  select 'prompts', count(*) from c_prompts union all
  select 'generations', count(*) from c_generations union all
  select 'sku_slide_prompt', count(*) from c_sku_slide_prompt
`);
console.log('\n=== TOTALS ===');
for (const r of counts.rows) console.log(`  ${r.t.padEnd(20)} ${r.n}`);

await client.end();
console.log('\nDONE');
