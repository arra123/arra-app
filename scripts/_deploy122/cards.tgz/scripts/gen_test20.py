"""
Тест #20: ВСЁ что у модели сохраняем — никакого crop.
Padding синим фоном по бокам: 1024×1536 → 1152×1536 (это уже 3:4) → resize 1080×1440.
Так badges не обрежутся, заголовок не прижмётся — всё что модель отдаёт остаётся.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test20_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test20_final.png")

PROMPT = """The attached image is slide 1 of a product card series. Generate slide 2 of the SAME series.

=== BRAND CANVAS (must match slide 1 — same brain background, same title style/case/position, blue family palette only, no yellow/gold/orange, hexagonal glass-morphism icons) ===

Title position: SAME small top margin as on slide 1 (~80px from top edge).

=== LAYOUT MAP for the 1024×1536 canvas ===

  Y=0..80    EMPTY blue background (small top margin, like slide 1)
  Y=80..160   "БЕНФОТИАМИН" UPPERCASE title (large bold dark navy)
  Y=170..220   "СОСТАВ И ДОЗИРОВКА" subtitle (smaller, blue)
  Y=230..235   solid blue divider line (~80px wide, 4px tall)
  Y=245..275   "В 1 КАПСУЛЕ" tiny grey caption
  Y=320..420   row 1: [shield] БЕНФОТИАМИН .... 350 мг
  Y=440..540   row 2: [molecule with 3 atoms and bonds] АЛЬФА-ЛИПОЕВАЯ КИСЛОТА .... 100 мг
  Y=560..660   row 3: [leaf] БЕРБЕРИН .... 20 мг
  Y=680..780   row 4: [Mg-ring] МАГНИЙ ГЛИЦИНАТ .... 100 мг
  Y=800..900   row 5: [brain] АЦЕТИЛ-L-КАРНИТИН .... 100 мг
  Y=1380..1500   bottom 3 plates: [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО
  Y=1500..1536   tiny bottom margin

Each ingredient row layout: [hex icon, ~80px tall] [name CAPS, navy bold] ........ [dose: large number + small "мг" RIGHT of it on the SAME baseline].

Icons:
   1. БЕНФОТИАМИН — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — molecular structure: 3 atoms connected with visible bonds (NOT a star)
   3. БЕРБЕРИН — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — brain outline

Bottom plates: [icon] + 2-line text. Light-blue or light-gray separators between plates. NO yellow/gold.

=== FORBIDDEN ===
- NO product jar, NO pedestal, NO shadow ring.
- NO horizontal light streaks between rows.
- NO yellow/gold/orange anywhere.
- NO medical claims.
- NO garbled / pseudo Cyrillic.

Portrait, premium calm cognitive-tech mood.
"""

print("test #20: NO CROP - side padding only (1024x1536 -> 1152x1536 -> 1080x1440)...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)

# Padding по бокам: ширина 1024 → 1152 (нужно + 128, по 64 с каждой стороны)
# Цвет фона возьмём с самого края картинки (предположительно синий)
target_w = 1152
target_h = 1536
pad_left = (target_w - img.width) // 2
pad_right = target_w - img.width - pad_left

# Берём цвет фона из левого верхнего пикселя (модель там обычно фон)
bg_color = img.getpixel((10, 10))[:3]  # RGB без alpha
print(f"bg color sampled: {bg_color}")

img_padded = Image.new("RGB", (target_w, target_h), bg_color)
img_padded.paste(img, (pad_left, 0))

# Resize до 1080×1440
img_final = img_padded.resize((1080, 1440), Image.LANCZOS)
img_final.save(OUT_FINAL, "PNG")
print(f"padded: {img_padded.size}, final: {img_final.size}")
print(f"saved: {OUT_FINAL}")
