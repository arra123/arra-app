// Заливает несколько вариантов промптов на каждый slide_kind: строгие, мягкие, минималистичные, премиум.
import 'dotenv/config';
import pg from 'pg';

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();

const variants = [
  // slide 1 HERO — 4 варианта стиля
  { slide_kind:1, name:'hero · strict-grid', category_id:'cognitive', version:1, status:'live',
    body:'HERO slide. Strict 12-col grid, sharp typography (Inter Tight 800), hard edges, no glow excess. Title UPPERCASE top-third, subtitle one line below, 3 tile-buttons left-side. Jar centered front-facing on subtle pedestal.',
    notes:'Строгий академичный стиль. Для премиум-категорий с фокусом на доверии.'},
  { slide_kind:1, name:'hero · soft-glow', category_id:'cognitive', version:1, status:'live',
    body:'HERO slide. Soft atmospheric. Glow particles, gradient mist behind jar. Title large UPPERCASE with backlight halo. 3-4 tiles with soft inner-light icons. Premium calm.',
    notes:'Мягкий эффект свечения для wellness-направлений.'},
  { slide_kind:1, name:'hero · minimal-mono', category_id:'cognitive', version:1, status:'draft',
    body:'HERO minimal. Mono-color background, single big title UPPERCASE, just 2 small accent labels. Jar clean front-facing, no decoration. Pure typography focus.',
    notes:'Минимализм. Для аутентичных линеек.'},
  { slide_kind:1, name:'hero · editorial', category_id:'cognitive', version:1, status:'draft',
    body:'HERO editorial. Magazine-style: large serif accents alongside sans UPPERCASE, asymmetric tile placement, one decorative element (molecule/leaf/wave) extending to edge. Editorial mood.',
    notes:'Редакционный журнальный стиль.'},

  // slide 2 СОСТАВ — 3 варианта
  { slide_kind:2, name:'composition · classic-rows', category_id:'cognitive', version:1, status:'live',
    body:'COMPOSITION slide. Title UPPERCASE top-left + smaller subtitle "СОСТАВ И ДОЗИРОВКА" + caption "В 1 КАПСУЛЕ". Vertical list of 5 ingredient rows: hex-glass icon left + name CAPS + dose pill (number + мг RIGHT same line). 3 horizontal badge plates at bottom.',
    notes:'Классическая раскладка состава. Стандарт.'},
  { slide_kind:2, name:'composition · hero-jar', category_id:'cognitive', version:1, status:'live',
    body:'COMPOSITION with jar. Right side: GRAFLAB jar prominent. Left side: list of 3-4 ingredients (one per line, NAME + dose). Bottom: 2 badges. Use when components ≤ 4.',
    notes:'Когда компонентов мало — банку оставляем на этом слайде.'},
  { slide_kind:2, name:'composition · ingredient-cards', category_id:'cognitive', version:1, status:'draft',
    body:'COMPOSITION cards. Each ingredient = its own card with photo of plant/molecule on top, name CAPS, dose, 1-line action description. Grid 2x2 or 2x3. Premium catalog feel.',
    notes:'Карточки-плитки на каждый ингредиент. Подходит для дорогих линеек.'},

  // slide 3 ВЫГОДЫ A — 3 варианта
  { slide_kind:3, name:'benefits-a · sport-energy', category_id:'energy', version:1, status:'live',
    body:'BENEFITS A. Athletic woman running pose. Right side 4 tiles: ЗАЩИТА / ЭНЕРГИЯ / ФОКУС / РЕСУРС. Photorealistic, golden-hour lighting, dynamic motion blur on background.',
    notes:'Спортивный энергичный сюжет.'},
  { slide_kind:3, name:'benefits-a · office-cognitive', category_id:'cognitive', version:1, status:'live',
    body:'BENEFITS A. Confident office worker at laptop, focused expression, modern workspace bokeh. 4 tiles: КОНЦЕНТРАЦИЯ / ЯСНОСТЬ / РЕАКЦИЯ / СПОКОЙСТВИЕ. Cool blue tones, clean.',
    notes:'Офисный когнитивный сюжет.'},
  { slide_kind:3, name:'benefits-a · lifestyle-calm', category_id:'detox', version:1, status:'draft',
    body:'BENEFITS A. Mature woman in soft natural light, peaceful. 4 tiles: МЯГКОСТЬ / ОБНОВЛЕНИЕ / БАЛАНС / ДОЛГОЛЕТИЕ. Earth tones, slow gentle composition.',
    notes:'Спокойный lifestyle для longevity/детокса.'},

  // slide 5 ПРЕИМУЩЕСТВА — 3 варианта
  { slide_kind:5, name:'advantages · 2x3-tight', category_id:'cognitive', version:1, status:'live',
    body:'ADVANTAGES grid 2x3, tight spacing. Each tile: large icon + bold headline 2-3 words + 1-line caption. Subtle background decoration (molecules far back). NO jar, NO people.',
    notes:'Плотная 2×3 сетка. Стандарт для slide 5.'},
  { slide_kind:5, name:'advantages · 2x2-spacious', category_id:'cognitive', version:1, status:'draft',
    body:'ADVANTAGES grid 2x2, spacious breathing room. Larger tiles, bigger icons, single large bold word per tile + 2-3 line caption.',
    notes:'Просторная 2×2 для меньшего числа УТП.'},
  { slide_kind:5, name:'advantages · numbered-list', category_id:'cognitive', version:1, status:'draft',
    body:'ADVANTAGES numbered. Vertical list 1-6 each with big number on left, headline middle, brief caption. Editorial article feel.',
    notes:'Нумерованный список. Подходит когда нужна последовательность.'},

  // slide 6 ДЛЯ КОГО — 2 варианта
  { slide_kind:6, name:'for-whom · 6-cards', category_id:'cognitive', version:1, status:'live',
    body:'FOR WHOM. 6 audience cards in grid: each has icon + ДЛЯ ... headline. Bottom: quality block 3 lines: ВЫСОКИЕ СТАНДАРТЫ / СТРОГИЙ КОНТРОЛЬ / ПРЕМИАЛЬНОЕ СЫРЬЁ.',
    notes:'6 категорий аудитории + блок качества.'},
  { slide_kind:6, name:'for-whom · single-portrait', category_id:'cognitive', version:1, status:'draft',
    body:'FOR WHOM portrait. Single big "идеальный пользователь" portrait left. Right: 3-4 reasons "почему именно для вас". Bottom: small jar in corner.',
    notes:'Через идеальный пользователь.'},
];

let inserted = 0;
for (const v of variants) {
  // не плодим дубли по name+version
  const r = await c.query('select id from c_prompts where name=$1 and version=$2', [v.name, v.version]);
  if (r.rows.length) continue;
  await c.query(
    `insert into c_prompts(name, slide_kind, category_id, version, status, body, endpoint, size, quality, notes)
     values($1,$2,$3,$4,$5,$6,'images.edit','1024x1536','medium',$7)`,
    [v.name, v.slide_kind, v.category_id, v.version, v.status, v.body, v.notes]
  );
  inserted++;
}

const totalR = await c.query('select count(*)::int as n from c_prompts');
console.log(`+${inserted} variants · total: ${totalR.rows[0].n} prompts`);
await c.end();
