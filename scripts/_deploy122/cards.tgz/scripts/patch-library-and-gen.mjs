// Заменяет секции Генерация и Библиотека на новые версии
import { readFileSync, writeFileSync } from 'node:fs';

const fpath = 'C:/Claude/Work/cards/site/index.html';
let src = readFileSync(fpath, 'utf8');

// ─── ГЕНЕРАЦИЯ ───
{
  const start = src.indexOf('<section class="tab-page active" data-page="generate">');
  const end = src.indexOf('<!-- ─────────── 2. БАЗА ПРОМПТОВ ─────────── -->', start);
  if (start < 0 || end < 0) throw new Error('generate markers');
  const NEW = `<section class="tab-page active" data-page="generate">
  <div class="px-6 py-6 flex flex-col gap-4" style="height:calc(100vh - 0px); min-height:760px">

    <!-- ── TOP BAR: SKU + slide tabs + quality + dry + generate ── -->
    <div class="r-card p-3 relative flex items-center gap-3 flex-wrap">
      <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>

      <div class="flex items-center gap-2">
        <span class="section-cap">товар</span>
        <select id="gen-sku" class="sinput" style="height:34px; min-width:240px"></select>
      </div>

      <div class="w-px h-6" style="background:var(--slate-6)"></div>

      <div class="flex items-center gap-1" id="gen-slide-tabs">
        <!-- 1..6 кнопки слайдов -->
      </div>

      <div class="w-px h-6" style="background:var(--slate-6)"></div>

      <div class="flex items-center gap-2">
        <span class="section-cap">качество</span>
        <div class="flex gap-1" id="gen-quality">
          <button data-q="low" class="ftab" style="padding:6px 10px; font-size:12px">low</button>
          <button data-q="medium" class="ftab active" style="padding:6px 10px; font-size:12px">medium</button>
          <button data-q="high" class="ftab" style="padding:6px 10px; font-size:12px">high</button>
        </div>
      </div>

      <div class="flex items-center gap-2">
        <span class="text-[12px] text-[var(--slate-11)]">dry-run</span>
        <input type="checkbox" id="gen-dry-run" class="sswitch" checked />
      </div>

      <div class="ml-auto flex items-center gap-2">
        <button class="sbtn sbtn-md sbtn-secondary" id="btn-gen-clear-canvas" title="Очистить холст"><i data-lucide="eraser" class="w-3.5 h-3.5"></i></button>
        <button class="sbtn sbtn-md sbtn-secondary" id="btn-gen-test"><i data-lucide="zap" class="w-3.5 h-3.5"></i>Тест 1</button>
        <button class="rbtn-primary" id="btn-gen-fire"><i data-lucide="sparkles" class="w-3.5 h-3.5"></i>Сгенерировать</button>
      </div>
    </div>

    <!-- ── ОСНОВНАЯ РАБОЧАЯ ОБЛАСТЬ: tools | canvas | inspector ── -->
    <div class="grid grid-cols-[240px_1fr_320px] gap-4 flex-1 min-h-0">

      <!-- ── LEFT: инструменты ── -->
      <div class="r-card p-4 relative overflow-y-auto" style="min-height:0">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>

        <div class="section-cap mb-3">добавить</div>
        <div class="grid grid-cols-2 gap-2 mb-5">
          <button class="sbtn sbtn-md sbtn-outline" id="tool-add-text" title="Добавить текст"><i data-lucide="type" class="w-4 h-4"></i>Текст</button>
          <button class="sbtn sbtn-md sbtn-outline" id="tool-add-from-lib" title="Картинка из библиотеки"><i data-lucide="folder-open" class="w-4 h-4"></i>Из либы</button>
          <button class="sbtn sbtn-md sbtn-outline col-span-2" id="tool-upload" title="Загрузить с компьютера">
            <i data-lucide="upload" class="w-4 h-4"></i>Загрузить файл
            <input type="file" id="tool-upload-input" accept="image/*" hidden multiple />
          </button>
        </div>

        <div class="section-cap mb-3">палитра / фон</div>
        <div id="gen-palette-grid" class="grid grid-cols-5 gap-1.5 mb-2"></div>
        <div class="flex items-center gap-2 mb-5">
          <input type="color" id="gen-palette-custom" value="#4a96d4" class="w-8 h-8 rounded cursor-pointer border" style="border-color:var(--slate-6)" />
          <div class="text-[11px] mono text-[var(--slate-10)] flex-1 truncate" id="gen-palette-info">—</div>
        </div>

        <div class="section-cap mb-3">эталон банки</div>
        <div id="gen-jar-mini" class="rounded-lg border overflow-hidden flex items-center justify-center mb-2" style="border-color:var(--slate-6); aspect-ratio:1; background:#0c0c0e">
          <div class="text-[11px] text-[var(--slate-10)]">не выбрана</div>
        </div>
        <button class="sbtn sbtn-sm sbtn-secondary w-full" id="gen-jar-pick"><i data-lucide="image" class="w-3 h-3"></i>выбрать банку</button>
        <div class="text-[10px] text-[var(--slate-10)] mono mt-1 break-all" id="gen-jar-path">—</div>
      </div>

      <!-- ── CENTER: холст ── -->
      <div class="r-card relative flex flex-col" style="min-height:0">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>

        <div class="flex items-center justify-between p-3 border-b" style="border-color:var(--slate-6)">
          <div class="text-[12.5px] text-[var(--slate-11)]" id="gen-canvas-title">холст 1086×1449</div>
          <div class="flex items-center gap-2 text-[11px] text-[var(--slate-10)] mono">
            <span id="gen-zoom-label">100%</span>
            <button class="sbtn sbtn-icon-sm sbtn-ghost" id="gen-zoom-out"><i data-lucide="minus" class="w-3 h-3"></i></button>
            <button class="sbtn sbtn-icon-sm sbtn-ghost" id="gen-zoom-in"><i data-lucide="plus" class="w-3 h-3"></i></button>
          </div>
        </div>

        <div class="flex-1 overflow-auto flex items-center justify-center p-6" id="gen-canvas-viewport" style="background:#06060a; min-height:400px">
          <div id="gen-canvas" tabindex="0" style="position:relative; width:480px; aspect-ratio:1086/1449; background:linear-gradient(135deg,#1e3a8a,#4a96d4); border-radius:18px; overflow:hidden; box-shadow:0 40px 80px -20px rgba(0,0,0,.6); user-select:none">
            <div id="gen-canvas-hint" style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; color:rgba(255,255,255,.55); font-size:12px; pointer-events:none">пустой холст · нажми Текст или Загрузить</div>
          </div>
        </div>
      </div>

      <!-- ── RIGHT: слои + статус + лог ── -->
      <div class="r-card p-4 relative overflow-y-auto flex flex-col gap-4" style="min-height:0">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>

        <div>
          <div class="flex items-center justify-between mb-2">
            <div class="section-cap">слои</div>
            <span class="text-[11px] text-[var(--slate-10)] mono" id="gen-layers-count">0</span>
          </div>
          <div id="gen-layers" class="flex flex-col gap-1">
            <div class="text-[12px] text-[var(--slate-10)] py-2">пусто</div>
          </div>
        </div>

        <div id="gen-inspector" class="flex flex-col gap-2 hidden">
          <div class="section-cap">элемент</div>
          <input class="sinput" id="ins-text" placeholder="текст" />
          <div class="grid grid-cols-2 gap-2">
            <input class="sinput" id="ins-x" placeholder="X %" type="number" min="0" max="100" />
            <input class="sinput" id="ins-y" placeholder="Y %" type="number" min="0" max="100" />
          </div>
          <div class="grid grid-cols-2 gap-2">
            <input class="sinput" id="ins-w" placeholder="W %" type="number" min="5" max="200" />
            <input class="sinput" id="ins-fs" placeholder="size px" type="number" min="8" max="200" />
          </div>
          <div class="flex gap-1" id="ins-align">
            <button class="ftab" data-align="left" style="padding:6px 10px; font-size:11px"><i data-lucide="align-left" class="w-3 h-3"></i></button>
            <button class="ftab" data-align="center" style="padding:6px 10px; font-size:11px"><i data-lucide="align-center" class="w-3 h-3"></i></button>
            <button class="ftab" data-align="right" style="padding:6px 10px; font-size:11px"><i data-lucide="align-right" class="w-3 h-3"></i></button>
          </div>
          <div class="flex gap-2">
            <input type="color" id="ins-color" value="#ffffff" class="w-9 h-9 rounded cursor-pointer border flex-shrink-0" style="border-color:var(--slate-6)" />
            <button class="sbtn sbtn-sm sbtn-destructive flex-1" id="ins-delete"><i data-lucide="trash-2" class="w-3 h-3"></i>удалить слой</button>
          </div>
        </div>

        <div class="mt-auto">
          <div class="section-cap mb-2">лог генерации</div>
          <div id="gen-log" class="text-[11px] mono leading-relaxed max-h-[220px] overflow-y-auto rounded-lg p-3" style="background:#000; border:1px solid var(--slate-6); color:var(--slate-11)">
            <div style="color:var(--slate-10)">— готов к работе —</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Модалка выбора банки/картинки из библиотеки -->
  <div id="jar-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center" style="background:rgba(0,0,0,.7); backdrop-filter:blur(8px)">
    <div class="r-card relative p-6" style="width:92vw; max-width:1100px; max-height:88vh; overflow-y:auto">
      <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-[18px] font-semibold" id="jar-modal-title">Выбери картинку</h3>
        <button class="sbtn sbtn-icon-sm sbtn-ghost" id="jar-modal-close"><i data-lucide="x" class="w-4 h-4"></i></button>
      </div>
      <input class="sinput mb-4" placeholder="Поиск по имени или папке…" id="jar-modal-q" />
      <div id="jar-modal-grid" class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3"></div>
    </div>
  </div>
</section>

`;
  src = src.slice(0, start) + NEW + src.slice(end);
  console.log('GEN section replaced');
}

// ─── БИБЛИОТЕКА ───
{
  const start = src.indexOf('<section class="tab-page" data-page="library">');
  const end = src.indexOf('<!-- ─────────── 4. АНАЛИТИКА', start);
  if (start < 0 || end < 0) throw new Error('library markers');
  const NEW = `<section class="tab-page" data-page="library">
  <div class="max-w-[1320px] mx-auto px-8 py-10">

    <div class="mb-8 flex items-end justify-between flex-wrap gap-4">
      <h1 class="text-[36px] font-semibold tracking-tight">Библиотека</h1>
      <div class="flex items-center gap-2">
        <button class="sbtn sbtn-md sbtn-secondary" id="lib-refresh"><i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>Обновить</button>
        <button class="sbtn sbtn-md sbtn-primary" id="lib-upload-btn"><i data-lucide="upload" class="w-3.5 h-3.5"></i>Загрузить</button>
        <input type="file" id="lib-upload-input" accept="image/*" hidden multiple />
      </div>
    </div>

    <div class="flex items-center gap-3 mb-6 flex-wrap">
      <div class="relative flex-1 max-w-[420px] min-w-[240px]">
        <i data-lucide="search" class="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[var(--slate-10)]"></i>
        <input class="sinput pl-9" placeholder="Поиск по имени файла или папке…" id="lib-q" />
      </div>
      <div class="text-[12px] text-[var(--slate-10)] mono" id="lib-stats">—</div>
    </div>

    <div id="library-tree" class="flex flex-col gap-3">
      <div class="text-[12px] text-[var(--slate-10)]">загрузка…</div>
    </div>
  </div>
</section>

`;
  src = src.slice(0, start) + NEW + src.slice(end);
  console.log('LIBRARY section replaced');
}

writeFileSync(fpath, src, 'utf8');
console.log('done');
