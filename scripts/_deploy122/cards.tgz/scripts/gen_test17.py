"""
Тест #17: финальная комбинация:
  top_crop = 0  (НИКОГДА не резать сверху, иначе заголовок прижмётся)
  bottom_crop = 171  (для 3:4)
  + в промпте safe-zone: badges должны быть на Y=1310-1360 (не ниже),
    тогда после bottom_crop=171 они попадут в видимую часть (Y_visible=0..1365).
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test17_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test17_final.png")

PROMPT = """The attached image is slide 1 of a product card series. Generate slide 2 of the SAME series.

=== BRAND CANVAS (must match slide 1 exactly — brand anchors of the whole 6-slide series) ===
- Background: identical light-cyan blue gradient with the SAME brain neural network silhouette in the SAME position, SAME size, SAME opacity as slide 1.
- Title "БЕНФОТИАМИН" (UPPERCASE): identical X, Y, font, weight, size, dark navy color as on slide 1.
- Color palette: strictly blue family. NO yellow, NO gold, NO orange.
- Hexagonal glass-morphism icon plates: same shape as on slide 1.

=== LAYOUT — SAFE ZONE (CRITICAL FOR LAYOUT) ===
The canvas is 1024×1536. ALL visible content must lie within Y=[150, 1350]:
- Title at Y ≈ 180 (do not push higher).
- Bottom badges row finishes at Y ≤ 1340 (do not push lower — leave at LEAST 200 px clear blue background BELOW the badges).
- This is REQUIRED — content must NOT touch top or bottom edges.

=== SLIDE-2-SPECIFIC CONTENT ===
Header (top-left, below title):
- Subtitle "СОСТАВ И ДОЗИРОВКА" (smaller, blue)
- Solid blue divider line ~80px wide, 3-4px tall (NOT gradient, NOT gold)
- Tiny grey caption "В 1 КАПСУЛЕ"

Body — 5 ingredient rows in horizontal glass-morphism plates. Layout per row:
[hex icon] [name CAPS, navy bold] [dose: large number + small "мг" RIGHT of it on the SAME baseline].
Rows:
   1. БЕНФОТИАМИН — 350 мг — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — molecule outline
   3. БЕРБЕРИН — 20 мг — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — brain outline

Bottom row — 3 horizontal plates (NOT round medallions): [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО.

=== FORBIDDEN ===
- NO product jar, NO pedestal, NO platform, NO shadow ring.
- NO horizontal light streaks between rows.
- NO yellow / gold / orange.
- NO medical claims.
- NO garbled / pseudo Cyrillic letters.

Portrait, premium calm cognitive-tech mood.
"""

print("test #17: top_crop=0 + safe zone Y[150, 1350] + brand canvas...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
# Crop ТОЛЬКО снизу — никогда не трогаем верх
img_cropped = img.crop((0, 0, img.width, img.height - 171))
print(f"crop: top=0, bottom=171, result={img_cropped.size}")
assert img_cropped.size == (1024, 1365), f"unexpected {img_cropped.size}"
img_cropped.resize((1080, 1440), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"saved: {OUT_FINAL}")
