"""
Тест #12: финальный — ВСЁ хорошее из #11 + заголовок КАПСОМ.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test12_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test12_final.png")

PROMPT = """The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

Match slide 1 exactly: same color palette, same fonts, same hexagonal glass-morphism icon plates.

The slide 2 header (top-left, vertically stacked, with VISIBLE spacing between elements):

  ┌─────────────────────
  │  "БЕНФОТИАМИН"               ← title, ALL UPPERCASE, large dark navy bold
  │  "СОСТАВ И ДОЗИРОВКА"        ← subtitle, UPPERCASE, smaller, blue
  │  ━━━━━━━━━━━━━━━━━━           ← MANDATORY: a thick gold-to-blue gradient horizontal LINE
  │                                  about 100px wide, 4-6px tall, clearly visible.
  │  "В 1 КАПСУЛЕ"               ← small grey caption, BELOW the line, left-aligned
  └─────────────────────

5 ingredient ROWS, each is a horizontal glass-morphism plate (rounded corners, soft inner highlight, hexagonal icon on the left). Layout per row: [hex icon] [INGREDIENT NAME, dark navy bold caps] ........ [DOSE: number large bold + "мг" smaller, both on the SAME LINE, "мг" RIGHT of the number].

Icons:
   1. БЕНФОТИАМИН — 350 мг — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — molecule outline
   3. БЕРБЕРИН — 20 мг — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — brain outline

Bottom row: 3 small horizontal plates side by side (NOT round medallions).
Plates: [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО.
Separators: short thin gold horizontal LINES.

CRITICAL SAFE MARGINS:
- At LEAST 100 px clear background ABOVE the title.
- At LEAST 100 px clear background BELOW the bottom badges.

HARD RULES:
- NO product jar, NO pedestal, NO platform, NO disc, NO shadow ring.
- "мг" RIGHT of the number, SAME baseline.
- Real Cyrillic only.
- The gold-blue divider line under "СОСТАВ И ДОЗИРОВКА" is REQUIRED. Render it visibly.
- Title "БЕНФОТИАМИН" must be ALL UPPERCASE LATIN/CYRILLIC LETTERS.
- Portrait orientation, premium calm tech mood.
"""

print("test #12: UPPERCASE title + everything good from #11...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
img_cropped = img.crop((0, 85, img.width, img.height - 86))
img_cropped.resize((1080, 1440), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"saved: {OUT_FINAL}")
