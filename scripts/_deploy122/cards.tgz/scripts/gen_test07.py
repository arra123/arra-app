"""
Тест #7: фиксим косяки test06.
- НЕТ пьедестала внизу (явно)
- Заголовок Sentence Case, не uppercase
- Top crop не делаем — обрезаем ТОЛЬКО снизу (170 px), чтобы не резать заголовок
- Бейджи снизу: разделители — тонкие линии, не точки; subtle white glow под ними
- Иконки указаны явно по смыслу
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test07_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test07_final.png")

PROMPT = """The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

Match slide 1 exactly: same color palette (light cyan-blue background with glowing brain neural network), same fonts, same hexagonal glass-morphism icon plates with thin gold/light edge, same atmosphere.

Slide 2 content:
- Title (Sentence case, NOT uppercase): "Бенфотиамин"
- Subtitle (smaller, blue): "СОСТАВ И ДОЗИРОВКА"
- Caption (small grey): "В 1 КАПСУЛЕ"
- 5 ingredient ROWS, each is a horizontal glass-morphism plate (rounded corners, soft inner highlight, hexagonal icon on the left). Layout per row: [hex icon] [INGREDIENT NAME, dark navy bold caps] ........ [DOSE: number large bold + "мг" smaller, both on the SAME LINE, "мг" RIGHT of the number]
- Icons (must match by meaning, do not invent):
   1. БЕНФОТИАМИН — 350 мг — icon: shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — icon: thin molecule outline
   3. БЕРБЕРИН — 20 мг — icon: leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — icon: "Mg" lettermark inside a thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — icon: brain outline
- Bottom row: 3 small horizontal plates side by side, each with a subtle white glow background and a small icon-medallion + 2-line text. Separators between plates: short thin gold horizontal LINES (NOT dots). Plates:
   ОТБОРНЫЕ ИНГРЕДИЕНТЫ | 60 КАПСУЛ | ПРЕМИАЛЬНОЕ КАЧЕСТВО

CRITICAL RULES (do not break):
- NO product jar anywhere on this slide.
- NO pedestal, NO platform, NO disc, NO shadow ring at the bottom of the slide. The composition is purely a vertical list. The bottom of the slide is the badges row — nothing else.
- The title at the top must be FULLY VISIBLE — do not crop it.
- "мг" is to the RIGHT of the number on the SAME baseline. Never under the number, never via a dash separator.
- All Cyrillic must be REAL Cyrillic — no garbled or fake-Cyrillic glyphs.
- No medical claims (no "лечит", "против болезни", диагнозы).
- Portrait orientation, premium calm tech mood.
"""

print("test #7: explicit fixes (no pedestal, sentence case, lines not dots, fixed icons)...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))

# Постпроцесс: обрезаем ТОЛЬКО снизу (бывший пьедестал), верх оставляем
img = Image.open(OUT_RAW)
W, H = img.size  # 1024, 1536
target_h = int(W * 4 / 3)  # 1365
img_cropped = img.crop((0, 0, W, target_h))  # bottom crop only
img_final = img_cropped.resize((1080, 1440), Image.LANCZOS)
img_final.save(OUT_FINAL, "PNG")
print(f"raw size: {img.size}")
print(f"cropped (bottom only): {img_cropped.size}")
print(f"final: {img_final.size}")
print(f"saved: {OUT_FINAL}")
