import 'dotenv/config';
import pg from 'pg';

const { Client } = pg;

const client = new Client({
  host: process.env.PGHOST,
  port: Number(process.env.PGPORT),
  database: process.env.PGDATABASE,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  ssl: false,
  connectionTimeoutMillis: 8000,
});

try {
  await client.connect();
  const now = await client.query('SELECT NOW() as now, current_database() as db, current_user as user, version() as version');
  console.log('OK', now.rows[0]);

  const tables = await client.query(`
    SELECT table_schema, table_name
    FROM information_schema.tables
    WHERE table_schema NOT IN ('pg_catalog', 'information_schema')
    ORDER BY table_schema, table_name
  `);
  console.log(`\nТаблиц всего: ${tables.rows.length}`);
  for (const r of tables.rows) console.log(`  ${r.table_schema}.${r.table_name}`);

  const cTables = tables.rows.filter(r => r.table_name.startsWith('c_'));
  console.log(`\nНаших c_* таблиц: ${cTables.length}`);
} catch (e) {
  console.error('FAIL', e.message);
  process.exitCode = 1;
} finally {
  await client.end();
}
