"""
Тест #13: фиксим косяки #12.
- Заголовок Sentence case "Бенфотиамин" (как на slide 1) — единый стиль на обоих слайдах
- Полоска синяя, простая (как у Игоря на slide 1) — НЕ gold-blue gradient
- Разделители между бейджами — тонкие серые/синие, БЕЗ жёлтого
- Заголовок в том же положении/размере/шрифте, что на slide 1
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test13_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test13_final.png")

PROMPT = """The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

CRITICAL CONSISTENCY RULE — the title must look IDENTICAL on slide 1 and slide 2 (same location, same size, same font, same color, same case):

  TITLE: "Бенфотиамин"
  - Sentence case (capital Б, rest lowercase) — EXACTLY as on slide 1
  - Same dark navy color
  - Same large bold sans-serif font
  - Same X position (top-left) and same Y position (~80px from the top edge)
  - Same size as on slide 1

Header layout below the title (top-left, vertically stacked):

  ┌─────────────────────
  │  "Бенфотиамин"               ← title (see consistency rule above)
  │  "СОСТАВ И ДОЗИРОВКА"        ← subtitle, UPPERCASE, smaller, blue
  │  ────────                     ← MANDATORY: simple SOLID BLUE line, ~80px wide,
  │                                  3-4px tall, NO gradient, NO gold, NO multicolor.
  │                                  Just a clean blue divider.
  │  "В 1 КАПСУЛЕ"               ← small grey caption, BELOW the line, left-aligned
  └─────────────────────

5 ingredient ROWS, each is a horizontal glass-morphism plate (rounded corners, soft inner highlight, hexagonal icon on the left). Layout per row: [hex icon] [INGREDIENT NAME, dark navy bold caps] ........ [DOSE: number large bold + "мг" smaller, both on the SAME LINE, "мг" RIGHT of the number].

Icons:
   1. БЕНФОТИАМИН — 350 мг — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — molecule outline
   3. БЕРБЕРИН — 20 мг — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — brain outline

Bottom row: 3 small horizontal plates side by side (NOT round medallions).
Each plate: subtle white glow background, rounded corners, small icon on the left + 2-line text on the right.
Plates: [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО.
Separators: short thin LIGHT-GRAY or LIGHT-BLUE horizontal lines. ABSOLUTELY NO YELLOW, NO GOLD, NO ORANGE separators anywhere on this slide. The whole slide is BLUE-only palette.

CRITICAL SAFE MARGINS:
- At LEAST 100 px clear background ABOVE the title.
- At LEAST 100 px clear background BELOW the bottom badges.
- At LEAST 60 px clear margin on left and right sides — content must NOT touch the side edges.

HARD RULES:
- NO product jar, NO pedestal, NO platform, NO disc, NO shadow ring.
- "мг" RIGHT of the number, SAME baseline.
- Real Cyrillic only.
- Title "Бенфотиамин" in Sentence case (NOT uppercase, NOT lowercase) — to match slide 1 exactly.
- The blue divider line under "СОСТАВ И ДОЗИРОВКА" is REQUIRED, but in BLUE only — NO gold/yellow.
- Color palette is strictly BLUE family (navy, royal, cyan, light cyan, white). NO yellow, NO gold, NO orange anywhere.
- Portrait orientation, premium calm tech mood.
"""

print("test #13: fix consistency w/ slide 1 + remove yellow + sentence case...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
img_cropped = img.crop((0, 85, img.width, img.height - 86))
img_cropped.resize((1080, 1440), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"saved: {OUT_FINAL}")
