"""
Тест #15: явная safe-zone для контента.
Просим модель уложить весь контент в Y[160, 1300] of 1536 raw → симметричный crop 85/86 ничего не режет.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test15_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test15_final.png")

PROMPT = """The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

CRITICAL LAYOUT — content safe zone:
The full canvas is 1024 wide × 1536 tall. Place ALL visual content (title, subtitle, divider, ingredient rows, bottom badges) STRICTLY within the central safe zone Y=[160, 1320].
- TOP edge: at least 160 px of empty blue background ABOVE the title.
- BOTTOM edge: at least 220 px of empty blue background BELOW the last bottom badge.
- Side margins: at least 60 px on left and right.

Title: "БЕНФОТИАМИН"
- ALL UPPERCASE
- Same dark navy bold font as on slide 1
- Title position: Y ≈ 180 from top (NOT touching top edge)

Header layout (top-left, vertically stacked, Y starts at ~180):

  ┌─────────────────────
  │  "БЕНФОТИАМИН"               ← UPPERCASE title
  │  "СОСТАВ И ДОЗИРОВКА"        ← subtitle, smaller, blue
  │  ────                         ← short solid blue divider line, ~80px wide, 3-4px tall, NO gradient, NO gold
  │  "В 1 КАПСУЛЕ"               ← small grey caption, BELOW the line
  └─────────────────────

5 ingredient ROWS in the middle band of the slide. Each row is a horizontal glass-morphism plate (rounded corners, hexagonal icon on the left). Layout: [hex icon] [INGREDIENT NAME, dark navy bold caps] [DOSE: number large bold + "мг" smaller, both on the SAME LINE, "мг" RIGHT of the number].

NO horizontal light streaks or sweeps running BETWEEN the rows. Clean uniform blue background.

Icons:
   1. БЕНФОТИАМИН — 350 мг — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — molecule outline
   3. БЕРБЕРИН — 20 мг — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — brain outline

Bottom row of badges, positioned at approximately Y=1240-1310 (NOT touching the bottom edge):
3 small horizontal plates side by side: [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО.
Separators between plates: thin LIGHT-BLUE or LIGHT-GRAY lines. NO YELLOW/GOLD anywhere.

HARD RULES:
- NO product jar, NO pedestal, NO platform, NO disc, NO shadow ring.
- "мг" RIGHT of the number, SAME baseline.
- Real Cyrillic only.
- Color palette is strictly BLUE family. NO yellow/gold/orange.
- Portrait orientation.
"""

print("test #15: explicit safe zone Y[160,1320]...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
# симметричный crop 85+86, все правильно если модель уложилась в safe zone
img_cropped = img.crop((0, 85, img.width, img.height - 86))
print(f"crop: top=85, bottom=86, result={img_cropped.size}")
img_cropped.resize((1080, 1440), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"saved: {OUT_FINAL}")
