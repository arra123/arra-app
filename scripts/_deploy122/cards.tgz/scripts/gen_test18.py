"""
Тест #18: ASCII-схема макета по Y-координатам в промпте.
Модель лучше следует визуальным схемам чем словесному "Y=1340".
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test18_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test18_final.png")

PROMPT = """The attached image is slide 1 of a product card series. Generate slide 2 of the SAME series.

=== BRAND CANVAS (must match slide 1 — same brain background, same title style/case/position, blue family palette only, no yellow/gold/orange, hexagonal glass-morphism icons) ===

=== LAYOUT MAP for the 1024×1536 canvas ===

  Y=0    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Y=0..180   EMPTY blue background (top safe margin)
  Y=180..240   "БЕНФОТИАМИН" UPPERCASE title
  Y=250..290   "СОСТАВ И ДОЗИРОВКА" subtitle
  Y=300..305   solid blue divider line (~80px wide)
  Y=315..345   "В 1 КАПСУЛЕ" tiny caption
  Y=380..480   row 1: [shield] БЕНФОТИАМИН .... 350 мг
  Y=500..600   row 2: [molecule] АЛЬФА-ЛИПОЕВАЯ КИСЛОТА .... 100 мг
  Y=620..720   row 3: [leaf] БЕРБЕРИН .... 20 мг
  Y=740..840   row 4: [Mg-ring] МАГНИЙ ГЛИЦИНАТ .... 100 мг
  Y=860..960   row 5: [brain] АЦЕТИЛ-L-КАРНИТИН .... 100 мг
  Y=1080..1200   bottom 3 plates side by side:
                 [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО
  Y=1200..1536   EMPTY blue background (bottom safe margin — DO NOT place anything here)
  Y=1536 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CRITICAL: nothing is placed below Y=1200. The lower third of the canvas is empty blue background — exactly like the empty top margin. This is the brand grid.

Each ingredient row layout: [hex icon, ~80px tall] [name CAPS, navy bold] ........ [dose: large number + small "мг" RIGHT of it on the SAME baseline].

Each bottom plate: [icon] + 2-line text, light-blue or light-gray separators between plates (NO yellow/gold).

=== FORBIDDEN ===
- NO product jar, NO pedestal, NO shadow ring.
- NO horizontal light streaks between rows.
- NO yellow/gold/orange anywhere.
- NO medical claims.
- NO garbled / pseudo Cyrillic.

Portrait, premium calm cognitive-tech mood.
"""

print("test #18: ASCII Y-coordinate layout map...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
# top=0 (никогда не режем верх), bottom=171 (режем нижний "пустой" margin Y=1200..1536 — там должно быть пусто, всё ок)
img_cropped = img.crop((0, 0, img.width, img.height - 171))
print(f"crop: top=0, bottom=171, result={img_cropped.size}")
img_cropped.resize((1080, 1440), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"saved: {OUT_FINAL}")
