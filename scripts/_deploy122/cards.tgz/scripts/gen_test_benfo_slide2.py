"""
Тест 3: ИгорЕВ слайд 1 бенфо как референс - просим сгенерить слайд 2 (состав).
В постпроцессе resize до 1086x1449 - это наш стандарт, а не 1024x1536.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\benfo_slide2_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\benfo_slide2_final.png")

prompt = """This is slide 1 of a product card for the supplement "Бенфотиамин" by GRAFLAB.

Generate slide 2 of the SAME product card. Keep absolutely identical:
- color palette (deep saturated blue background with light blue glow, soft cyan particles, glowing brain neural network on background)
- typography (same fonts, same weights as in slide 1)
- product jar GRAFLAB BENFOTIAMINE on the right side (DO NOT change the jar shape, proportions, label, or text - keep it pixel-perfect like in slide 1)
- overall composition style (same plates with rounded corners, same icon style)

Content for slide 2 — "Состав и дозировка":

Top header (large, bold, black/dark):
   "Бенфотиамин"
Subtitle below it (smaller, regular):
   "СОСТАВ И ДОЗИРОВКА"
Tiny text under subtitle:
   "В 1 КАПСУЛЕ"

Center: a vertical list of 5 ingredient rows. Each row is a horizontal layout:
   [icon on left] [ingredient name in CAPS] [right-aligned dose: NNN мг]

The 5 ingredients:
1. БЕНФОТИАМИН — 350 мг
2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг
3. БЕРБЕРИН — 20 мг
4. МАГНИЙ ГЛИЦИНАТ — 100 мг
5. АЦЕТИЛ-L-КАРНИТИН — 100 мг

Each ingredient has a circular blue icon to the left (different icon per ingredient: shield, molecule, leaf, "Mg" letter, capsule).

Bottom of slide: three small badge plates side by side:
   "ОТБОРНЫЕ ИНГРЕДИЕНТЫ"   "60 КАПСУЛ"   "ПРЕМИАЛЬНОЕ КАЧЕСТВО"

Aspect: portrait, ~1086x1449 ratio.
All Cyrillic text must be readable, no garbled characters.
"""

print("calling images.edit (benfo slide 2)...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=prompt,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
print(f"raw saved: {OUT_RAW}")

# Resize to our exact target 1086x1449
img = Image.open(OUT_RAW)
print(f"raw size: {img.size}")
target = (1086, 1449)
img_resized = img.resize(target, Image.LANCZOS)
img_resized.save(OUT_FINAL, "PNG")
print(f"final size: {img_resized.size}")
print(f"final saved: {OUT_FINAL}")
