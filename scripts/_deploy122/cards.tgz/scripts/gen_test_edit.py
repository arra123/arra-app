"""
Тест 2: используем images.edit с РЕФЕРЕНСОМ Игоря.
Берём готовый слайд аста2/1.png, просим поменять оранжевую палитру на синюю.
Композиция, банка, иконки, тексты — должны остаться.
"""
import os, time, base64, pathlib
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\аста2\1.png")
OUT = pathlib.Path(r"C:\Claude\Work\cards\output\slide1_edit_blue.png")

prompt = """Сохрани композицию и все элементы этого слайда товара БЕЗ ИЗМЕНЕНИЙ:
- та же банка GRAFLAB ASTA PLUS справа (форма, этикетка, размер — НЕ МЕНЯТЬ)
- те же три плитки слева (Q10, PQQ, MCT) с теми же иллюстрациями (молекула, мозг, капля)
- та же верхняя плашка «АСТАКСАНТИН + Q10 + PQQ + MCT»
- те же заголовки и подзаголовки

ИЗМЕНИ ТОЛЬКО ЦВЕТОВУЮ ПАЛИТРУ:
- фон: вместо оранжевого — глубокий насыщенный синий (deep blue) с лёгким голубым свечением
- верхняя плашка: тёмно-синяя (вместо красно-оранжевой)
- glow и эффекты: голубой/синий свет вместо тёплого оранжевого
- общий мудoid: cool premium technology вместо warm energy

Качество: премиальный маркетплейс, чёткие контуры, читаемый текст.
"""

print("calling images.edit, palette: orange to blue...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=prompt,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"готово за {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT.write_bytes(base64.b64decode(result.data[0].b64_json))
print(f"сохранил: {OUT}")
