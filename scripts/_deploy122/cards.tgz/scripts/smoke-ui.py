"""SMOKE-test UI on Playwright."""
# coding: utf-8
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace', line_buffering=True)
"""Smoke-test UI on Playwright.
Проходит ключевые сценарии: Генерация, Промпты, Библиотека.
Сохраняет скрины и пишет отчёт по найденным багам.
"""
import os, sys, time, json
from playwright.sync_api import sync_playwright

OUT = r'C:\Claude\Work\cards\output\smoke'
os.makedirs(OUT, exist_ok=True)

bugs = []
console_errors = []

def log(msg):
    print(f'[{time.strftime("%H:%M:%S")}] {msg}', flush=True)

def bug(category, desc, severity='med'):
    bugs.append({'category': category, 'severity': severity, 'desc': desc})
    log(f'BUG [{severity}] {category}: {desc}')

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    ctx = browser.new_context(viewport={'width': 1500, 'height': 950})
    page = ctx.new_page()

    page.on('console', lambda m: (
        console_errors.append(m.text) if m.type == 'error' else None,
        log(f'CONSOLE.{m.type}: {m.text}') if m.type in ('error', 'warning') else None
    ))
    page.on('pageerror', lambda e: (console_errors.append(str(e)), log(f'PAGEERROR: {e}')))

    log('1. open root')
    page.goto('http://localhost:3000/', wait_until='networkidle')
    page.wait_for_timeout(1500)
    page.screenshot(path=f'{OUT}/01_root.png', full_page=False)

    # на старте должен быть раздел Генерация
    title = page.locator('h1').first.text_content()
    log(f'   h1 = "{title}"')
    if title and 'Генерация' not in title:
        bug('routing', f'на /index.html заголовок "{title}", ожидался "Генерация"')

    # ── Генерация ──
    log('2. Генерация: проверяю SKU, палитру, добавление текста')
    # palettes должны быть видны
    pal_buttons = page.locator('#gen-palette-grid [data-pal]').all()
    log(f'   palette buttons: {len(pal_buttons)}')
    if len(pal_buttons) == 0:
        bug('gen.palette', 'палитры не загрузились или не отрендерились')

    # клик на 2-ю палитру
    if len(pal_buttons) >= 2:
        pal_buttons[1].click()
        page.wait_for_timeout(300)

    # добавим текст
    log('   click "Текст"')
    page.locator('#tool-add-text').click()
    page.wait_for_timeout(500)
    layers_count = page.locator('#gen-layers-count').text_content()
    log(f'   layers-count after add-text: {layers_count}')
    if layers_count != '1':
        bug('gen.layers', f'после "+ Текст" layers-count = {layers_count}, ожидалось 1')

    # инспектор должен открыться
    inspector_visible = page.locator('#gen-inspector').is_visible()
    log(f'   inspector visible: {inspector_visible}')
    if not inspector_visible:
        bug('gen.inspector', 'инспектор не показался после добавления текста')

    page.screenshot(path=f'{OUT}/02_gen_with_text.png', full_page=False)

    # выбираем эталон банки через модал
    log('3. эталон банки → модал библиотеки')
    page.locator('#jar-pick').click()
    page.wait_for_timeout(800)
    modal_visible = page.locator('#lib-modal').is_visible()
    log(f'   lib modal visible: {modal_visible}')
    if not modal_visible:
        bug('gen.modal', 'модал библиотеки не открылся при клике на «эталон банки»', 'high')

    if modal_visible:
        files_in_modal = page.locator('#lib-modal-grid [data-pick]').all()
        log(f'   files in modal: {len(files_in_modal)}')
        if len(files_in_modal) == 0:
            bug('gen.modal', 'в модале библиотеки 0 файлов', 'high')
        elif len(files_in_modal) > 0:
            page.screenshot(path=f'{OUT}/03_jar_modal.png', full_page=False)
            files_in_modal[0].click()
            page.wait_for_timeout(500)

    jar_path = page.locator('#jar-preview').inner_html()
    log(f'   jar-preview after pick: {jar_path[:120]}...')

    # добавляем референс
    log('4. добавляю reference image')
    page.locator('#ref-add').click()
    page.wait_for_timeout(800)
    if page.locator('#lib-modal').is_visible():
        files = page.locator('#lib-modal-grid [data-pick]').all()
        if files:
            files[1].click() if len(files) > 1 else files[0].click()
            page.wait_for_timeout(500)
    ref_count = len(page.locator('#ref-list [data-ref-rm]').all())
    log(f'   refs added: {ref_count}')
    if ref_count == 0:
        bug('gen.ref', 'референс не добавился после клика в модале')

    page.screenshot(path=f'{OUT}/04_gen_full.png', full_page=False)

    # переключение слайда
    log('5. переключаю на слайд 2')
    page.locator('[data-slide="2"]').click()
    page.wait_for_timeout(300)
    title2 = page.locator('#gen-canvas-title').text_content()
    log(f'   canvas title: {title2}')
    if 'слайд 2' not in (title2 or ''):
        bug('gen.tabs', f'после клика slide=2 title = "{title2}"')

    # переход в Промпт-таб
    log('6. переключаюсь на view "Промпт"')
    page.locator('#view-prompt-btn').click()
    page.wait_for_timeout(400)
    prompt_visible = page.locator('#gen-prompt').is_visible()
    log(f'   prompt textarea visible: {prompt_visible}')
    if not prompt_visible:
        bug('gen.prompt', 'промпт-textarea не показался при переходе во view=prompt')
    prompt_text = page.locator('#gen-prompt').input_value() if prompt_visible else ''
    log(f'   prompt length: {len(prompt_text)}')
    if len(prompt_text) < 100:
        bug('gen.prompt', f'итоговый промпт слишком короткий ({len(prompt_text)} символов)')

    page.screenshot(path=f'{OUT}/05_prompt_tab.png', full_page=False)

    # симуляция
    log('7. жму Симуляция')
    page.locator('#view-canvas-btn').click()
    page.wait_for_timeout(300)
    # smoke НЕ дёргает реальную генерацию (она тратит ~17₽). Делаем dry-run через прямой API:
    log('   skip UI fire to avoid OpenAI charge — calling /api/generate dry_run via fetch')
    res = page.evaluate("""async () => {
      const r = await fetch('/api/generate', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({slide_kind:1, prompt_text:'smoke', dry_run:true})
      });
      return await r.json();
    }""")
    log(f'   dry-run api response: ok={res.get("ok")}')
    # ждём что кнопка перестанет быть disabled (генерация завершилась)
    try:
        page.wait_for_function("!document.getElementById('btn-gen-fire').disabled", timeout=15000)
        log('   button re-enabled — generation finished')
    except:
        bug('gen.button', 'кнопка Сгенерировать не вернулась в активное за 15с', 'high')

    page.wait_for_timeout(500)
    layers_after = page.locator('#gen-layers-count').text_content()
    log(f'   layers-count after simulate: {layers_after}')
    # после симуляции в моём коде если output_url был — он добавляется как слой; в dry-run output_url=null, поэтому слой может не добавиться. Это надо отметить.

    # лог
    log_text = page.locator('#gen-log').inner_text()
    log(f'   gen-log tail:\\n{log_text[-300:]}')

    page.screenshot(path=f'{OUT}/06_after_simulate.png', full_page=False)

    # ── База промптов ──
    log('8. перехожу в Базу промптов')
    page.locator('aside.sidebar [data-go="prompts"]').click()
    page.wait_for_timeout(500)
    page.wait_for_load_state('networkidle')

    # 5 табов
    for v in ['canon', 'black', 'my', 'brand', 'rated']:
        log(f'   tab: {v}')
        page.locator(f'[data-pview="{v}"]').click()
        page.wait_for_timeout(800)
        # проверка что соответствующий блок видим
        target = page.locator(f'#pview-{v}')
        visible = target.is_visible()
        log(f'     #pview-{v} visible: {visible}')
        if not visible:
            bug('prompts.tabs', f'таб «{v}» не показывается')
        page.screenshot(path=f'{OUT}/07_prompts_{v}.png', full_page=False)
        if v == 'canon':
            # должно быть 6 карточек
            cards = page.locator('#pview-canon .r-card').all()
            log(f'     canon cards: {len(cards)}')
            if len(cards) != 6:
                bug('prompts.canon', f'карточек {len(cards)}, ожидалось 6')
        elif v == 'black':
            words = page.locator('#pview-black .badge-r.bounced').all()
            log(f'     blacklist words: {len(words)}')
            if len(words) < 10:
                bug('prompts.black', f'слов {len(words)}, ожидалось ≥10')
        elif v == 'my':
            items = page.locator('#prompts-list [data-prompt]').all()
            log(f'     prompts in list: {len(items)}')
            if len(items) == 0:
                bug('prompts.my', 'промпты не загрузились в список')
        elif v == 'rated':
            items = page.locator('#pview-rated .r-card').all()
            log(f'     ratings: {len(items)}')

    # ── Библиотека ──
    log('9. Библиотека')
    page.locator('aside.sidebar [data-go="library"]').click()
    page.wait_for_timeout(800)
    page.wait_for_load_state('networkidle')
    folders = page.locator('#library-tree details').all()
    log(f'   folders: {len(folders)}')
    if len(folders) < 20:
        bug('library', f'папок видно {len(folders)}, ожидалось ≥20')
    stats = page.locator('#lib-stats').text_content()
    log(f'   stats: {stats}')
    page.screenshot(path=f'{OUT}/08_library.png', full_page=False)

    # ── Аналитика ──
    log('10. Аналитика')
    page.locator('aside.sidebar [data-go="analytics"]').click()
    page.wait_for_timeout(500)
    page.screenshot(path=f'{OUT}/09_analytics.png', full_page=False)

    log('=== ИТОГ ===')
    log(f'console errors: {len(console_errors)}')
    for e in console_errors[:10]:
        log(f'  · {e[:200]}')
    log(f'bugs: {len(bugs)}')
    for b in bugs:
        log(f'  [{b["severity"]}] {b["category"]}: {b["desc"]}')

    with open(f'{OUT}/_report.json', 'w', encoding='utf-8') as f:
        json.dump({'console_errors': console_errors, 'bugs': bugs}, f, ensure_ascii=False, indent=2)

    browser.close()

print('done')
