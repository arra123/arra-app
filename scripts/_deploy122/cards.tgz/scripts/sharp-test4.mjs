import sharp from 'sharp';
import { writeFile } from 'node:fs/promises';

async function tryOne(label, opts) {
  try {
    const txt = await sharp({ text: opts }).png().toBuffer();
    // подложить тёмный фон, чтобы видеть белый/цветной текст
    const bg = await sharp({ create: { width: opts.width, height: 100, channels: 4, background: '#222' }}).png().toBuffer();
    const final = await sharp(bg).composite([{input: txt, gravity: 'center'}]).png().toBuffer();
    await writeFile(`C:/Claude/Work/cards/output/font4-${label}.png`, final);
    console.log(label, 'OK');
  } catch (e) { console.log(label, 'ERR', e.message); }
}

const text = 'АСТАКСАНТИН';
const markup = `<span foreground="#ff5050">${text}</span>`;

await tryOne('A-noFontfile',  { text: markup, font: 'Arial 48', width: 800, dpi: 72, rgba: true });
await tryOne('B-withFontfile', { text: markup, font: 'Arial 48', fontfile: 'C:/Windows/Fonts/arial.ttf', width: 800, dpi: 72, rgba: true });
await tryOne('C-withFontBold', { text: markup, font: 'Arial Bold 48', fontfile: 'C:/Windows/Fonts/arialbd.ttf', width: 800, dpi: 72, rgba: true });
