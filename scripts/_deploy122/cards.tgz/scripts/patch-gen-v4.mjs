// Patch v4: концепция «проект» с сохранением, поле промпта, мульти-референсы, лоадер, ресайз 4 угла
import { readFileSync, writeFileSync } from 'node:fs';

const fpath = 'C:/Claude/Work/cards/site/index.html';
let src = readFileSync(fpath, 'utf8');

// ─── 1) HTML секция Генерация ───
{
  const start = src.indexOf('<section class="tab-page active" data-page="generate">');
  const end = src.indexOf('<!-- ─────────── 2. БАЗА ПРОМПТОВ ─────────── -->', start);
  if (start < 0 || end < 0) throw new Error('generate markers');

  const NEW = `<section class="tab-page active" data-page="generate">
  <div class="px-5 py-4 flex flex-col gap-3" style="height:calc(100vh - 0px); min-height:760px">

    <!-- ── ОДНА ПОЛОСА: проект, слайд, привязка, действия ── -->
    <div class="r-card p-3 relative flex items-center gap-3 flex-wrap">
      <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>

      <select id="proj-pick" class="sinput" style="height:34px; min-width:220px; max-width:320px">
        <option value="new">+ Новый проект</option>
      </select>
      <input id="proj-name" class="sinput" style="height:34px; min-width:200px; max-width:280px" placeholder="Название проекта…" value="Новый проект" />
      <button id="btn-proj-save" class="sbtn sbtn-sm sbtn-secondary" title="Сохранить проект"><i data-lucide="save" class="w-3.5 h-3.5"></i>сохранить</button>
      <button id="btn-proj-delete" class="sbtn sbtn-icon-sm sbtn-ghost" title="Удалить проект" style="color:var(--red-11)"><i data-lucide="trash-2" class="w-3.5 h-3.5"></i></button>

      <div class="w-px h-6" style="background:var(--slate-6)"></div>

      <div class="flex items-center gap-1" id="gen-slide-tabs"></div>

      <div class="w-px h-6" style="background:var(--slate-6)"></div>

      <button id="btn-attach-sku" class="sbtn sbtn-sm sbtn-outline" title="Опционально: привязать к существующему товару">
        <i data-lucide="link" class="w-3 h-3"></i><span id="btn-attach-sku-label">привязать товар</span>
      </button>

      <div class="ml-auto flex items-center gap-2">
        <select id="gen-quality" class="sinput" style="height:34px; width:auto">
          <option value="low">low · 1.6 ₽</option>
          <option value="medium" selected>medium · 17 ₽</option>
          <option value="high">high · 68 ₽</option>
        </select>
        <button class="sbtn sbtn-md sbtn-secondary" id="btn-simulate" title="Симуляция без вызова OpenAI"><i data-lucide="flask-conical" class="w-3.5 h-3.5"></i>симуляция</button>
        <button class="rbtn-primary" id="btn-gen-fire"><i data-lucide="sparkles" class="w-3.5 h-3.5"></i>Сгенерировать</button>
      </div>
    </div>

    <!-- ── РАБОЧАЯ ОБЛАСТЬ ── -->
    <div class="grid grid-cols-[240px_1fr_320px] gap-3 flex-1 min-h-0">

      <!-- LEFT: инструменты + палитра + банка + референсы -->
      <div class="r-card p-4 relative overflow-y-auto flex flex-col gap-4" style="min-height:0">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>

        <div>
          <div class="section-cap mb-2">добавить на холст</div>
          <div class="grid grid-cols-2 gap-2">
            <button class="sbtn sbtn-md sbtn-outline" id="tool-add-text"><i data-lucide="type" class="w-4 h-4"></i>Текст</button>
            <button class="sbtn sbtn-md sbtn-outline" id="tool-add-from-lib"><i data-lucide="folder-open" class="w-4 h-4"></i>Картинка</button>
            <button class="sbtn sbtn-md sbtn-outline col-span-2" id="tool-upload-btn">
              <i data-lucide="upload" class="w-4 h-4"></i>Загрузить файл
              <input type="file" id="tool-upload-input" accept="image/*" hidden multiple />
            </button>
          </div>
        </div>

        <div>
          <div class="section-cap mb-2">палитра / фон</div>
          <div id="gen-palette-grid" class="grid grid-cols-5 gap-1.5 mb-2"></div>
          <div class="flex items-center gap-2">
            <input type="color" id="gen-palette-custom" value="#4a96d4" class="w-8 h-8 rounded cursor-pointer border" style="border-color:var(--slate-6)" />
            <div class="text-[11px] mono text-[var(--slate-10)] flex-1 truncate" id="gen-palette-info">—</div>
          </div>
        </div>

        <div>
          <div class="flex items-center justify-between mb-2">
            <div class="section-cap">эталон банки</div>
            <button id="jar-clear" class="text-[11px] text-[var(--slate-10)] hover:text-[var(--red-11)]" style="background:transparent; border:none; cursor:pointer; display:none" title="убрать">✕</button>
          </div>
          <button id="jar-pick" class="rounded-lg border overflow-hidden flex items-center justify-center w-full hover:border-[var(--slate-7)] transition" style="border-color:var(--slate-6); aspect-ratio:1; background:#0c0c0e; cursor:pointer; padding:0">
            <div id="jar-preview" class="text-[11px] text-[var(--slate-10)] text-center p-3">+ кликни чтобы выбрать</div>
          </button>
        </div>

        <div>
          <div class="flex items-center justify-between mb-2">
            <div class="section-cap">базовые картинки <span class="text-[10px] text-[var(--slate-10)]">(reference)</span></div>
          </div>
          <div id="ref-list" class="flex flex-col gap-2 mb-2"></div>
          <button id="ref-add" class="sbtn sbtn-sm sbtn-secondary w-full"><i data-lucide="plus" class="w-3 h-3"></i>добавить референс</button>
          <p class="text-[10.5px] text-[var(--slate-10)] mt-2 leading-relaxed">если есть — генерация будет image.edit от первой картинки, остальные упомянуты в промпте</p>
        </div>
      </div>

      <!-- CENTER: tabs «Холст / Промпт» -->
      <div class="r-card relative flex flex-col" style="min-height:0">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>

        <div class="flex items-center justify-between p-3 border-b" style="border-color:var(--slate-6)">
          <div class="flex items-center gap-1">
            <button class="ftab active" data-view="canvas" id="view-canvas-btn" style="padding:6px 12px; font-size:12px"><i data-lucide="layout" class="w-3 h-3"></i>Холст</button>
            <button class="ftab" data-view="prompt" id="view-prompt-btn" style="padding:6px 12px; font-size:12px"><i data-lucide="terminal" class="w-3 h-3"></i>Промпт</button>
          </div>
          <div class="flex items-center gap-2 text-[11px] text-[var(--slate-10)] mono">
            <span id="gen-canvas-title">слайд 1 · HERO · 1086×1449</span>
          </div>
          <div class="flex items-center gap-2 text-[11px] text-[var(--slate-10)] mono">
            <button class="sbtn sbtn-icon-sm sbtn-ghost" id="gen-zoom-out"><i data-lucide="minus" class="w-3 h-3"></i></button>
            <span id="gen-zoom-label">100%</span>
            <button class="sbtn sbtn-icon-sm sbtn-ghost" id="gen-zoom-in"><i data-lucide="plus" class="w-3 h-3"></i></button>
          </div>
        </div>

        <!-- canvas view -->
        <div id="view-canvas" class="flex-1 overflow-auto flex items-center justify-center p-6 relative" style="background:#06060a; min-height:400px">
          <div id="gen-canvas" tabindex="0" style="position:relative; width:480px; aspect-ratio:1086/1449; background:linear-gradient(135deg,#1e3a8a,#4a96d4); border-radius:18px; overflow:hidden; box-shadow:0 40px 80px -20px rgba(0,0,0,.6); user-select:none"></div>
          <!-- loading overlay -->
          <div id="gen-loading" class="hidden" style="position:absolute; inset:0; background:rgba(0,0,0,.7); backdrop-filter:blur(4px); display:flex; align-items:center; justify-content:center; flex-direction:column; gap:14px; z-index:20">
            <span class="spinner" style="width:32px; height:32px; border-width:3px; color:var(--accent-purple)"></span>
            <div class="text-[14px] text-slate-12 font-medium" id="gen-loading-text">генерация…</div>
            <div class="text-[12px] text-[var(--slate-11)] mono" id="gen-loading-elapsed">0 сек</div>
          </div>
        </div>

        <!-- prompt view -->
        <div id="view-prompt" class="hidden flex-1 overflow-y-auto p-5 flex flex-col gap-4">
          <div>
            <label class="slabel">Дополнительное описание (для AI)</label>
            <textarea id="gen-brief" class="sinput" placeholder="Расскажи что хочешь увидеть. Например: «фон — туманный лес сверху, банка по центру с подсветкой снизу, текст должен быть в стиле минимализма, без украшений»" style="min-height:90px; resize:vertical; padding:10px 12px"></textarea>
            <div class="shelp">это текст добавится к авто-промпту</div>
          </div>
          <div>
            <div class="flex items-center justify-between mb-2">
              <label class="slabel" style="margin:0">Итоговый промпт (отправится в AI)</label>
              <div class="flex gap-2">
                <button class="sbtn sbtn-sm sbtn-ghost" id="btn-prompt-regen"><i data-lucide="refresh-cw" class="w-3 h-3"></i>пересобрать</button>
                <button class="sbtn sbtn-sm sbtn-ghost" id="btn-prompt-copy"><i data-lucide="copy" class="w-3 h-3"></i>копировать</button>
              </div>
            </div>
            <textarea id="gen-prompt" class="code-mini" style="min-height:300px; width:100%; resize:vertical; outline:none" spellcheck="false"></textarea>
          </div>
        </div>
      </div>

      <!-- RIGHT: слои + inspector + лог -->
      <div class="r-card p-4 relative overflow-y-auto flex flex-col gap-4" style="min-height:0">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>

        <div>
          <div class="flex items-center justify-between mb-2">
            <div class="section-cap">слои</div>
            <span class="text-[11px] text-[var(--slate-10)] mono" id="gen-layers-count">0</span>
          </div>
          <div id="gen-layers" class="flex flex-col gap-1">
            <div class="text-[12px] text-[var(--slate-10)] py-2">пусто · добавь Текст или Картинку</div>
          </div>
        </div>

        <div id="gen-inspector" class="flex flex-col gap-2 hidden" style="border-top:1px solid var(--slate-6); padding-top:14px">
          <div class="flex items-center justify-between">
            <div class="section-cap">элемент</div>
            <div class="flex gap-1">
              <button class="sbtn sbtn-icon-sm sbtn-ghost" id="ins-z-up" title="на передний план"><i data-lucide="chevron-up" class="w-3 h-3"></i></button>
              <button class="sbtn sbtn-icon-sm sbtn-ghost" id="ins-z-down" title="на задний план"><i data-lucide="chevron-down" class="w-3 h-3"></i></button>
            </div>
          </div>
          <textarea class="sinput" id="ins-text" placeholder="текст" style="min-height:60px; resize:vertical; padding:8px 10px"></textarea>
          <div class="grid grid-cols-2 gap-2">
            <label class="text-[11px] text-[var(--slate-10)]">X% <input class="sinput" id="ins-x" type="number" min="0" max="100" /></label>
            <label class="text-[11px] text-[var(--slate-10)]">Y% <input class="sinput" id="ins-y" type="number" min="0" max="100" /></label>
            <label class="text-[11px] text-[var(--slate-10)]">шир.% <input class="sinput" id="ins-w" type="number" min="5" max="200" /></label>
            <label class="text-[11px] text-[var(--slate-10)]">размер <input class="sinput" id="ins-fs" type="number" min="8" max="200" /></label>
          </div>
          <div class="flex gap-1" id="ins-align">
            <button class="ftab" data-align="left" style="padding:6px 10px; font-size:11px"><i data-lucide="align-left" class="w-3 h-3"></i></button>
            <button class="ftab" data-align="center" style="padding:6px 10px; font-size:11px"><i data-lucide="align-center" class="w-3 h-3"></i></button>
            <button class="ftab" data-align="right" style="padding:6px 10px; font-size:11px"><i data-lucide="align-right" class="w-3 h-3"></i></button>
          </div>
          <div class="flex gap-2">
            <input type="color" id="ins-color" value="#ffffff" class="w-9 h-9 rounded cursor-pointer border flex-shrink-0" style="border-color:var(--slate-6)" />
            <button class="sbtn sbtn-sm sbtn-destructive flex-1" id="ins-delete"><i data-lucide="trash-2" class="w-3 h-3"></i>удалить слой</button>
          </div>
        </div>

        <div class="mt-auto">
          <div class="section-cap mb-2">лог</div>
          <div id="gen-log" class="text-[11px] mono leading-relaxed max-h-[200px] overflow-y-auto rounded-lg p-3" style="background:#000; border:1px solid var(--slate-6); color:var(--slate-11)">
            <div style="color:var(--slate-10)">— готов к работе —</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Модалка библиотеки -->
  <div id="lib-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center" style="background:rgba(0,0,0,.7); backdrop-filter:blur(8px)">
    <div class="r-card relative p-6" style="width:92vw; max-width:1100px; max-height:88vh; overflow-y:auto">
      <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-[18px] font-semibold" id="lib-modal-title">Выбери картинку</h3>
        <button class="sbtn sbtn-icon-sm sbtn-ghost" id="lib-modal-close"><i data-lucide="x" class="w-4 h-4"></i></button>
      </div>
      <input class="sinput mb-4" placeholder="Поиск по имени или папке…" id="lib-modal-q" />
      <div id="lib-modal-grid" class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3"></div>
    </div>
  </div>

  <!-- Модалка SKU -->
  <div id="sku-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center" style="background:rgba(0,0,0,.7); backdrop-filter:blur(8px)">
    <div class="r-card relative p-6" style="width:92vw; max-width:560px">
      <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-[18px] font-semibold">Привязать к товару</h3>
        <button class="sbtn sbtn-icon-sm sbtn-ghost" id="sku-modal-close"><i data-lucide="x" class="w-4 h-4"></i></button>
      </div>
      <p class="text-[13px] text-[var(--slate-11)] mb-4">Опционально. Привязка добавит палитру категории, эталон банки и название.</p>
      <div class="flex flex-col gap-1 max-h-[400px] overflow-y-auto" id="sku-modal-list"></div>
      <div class="flex gap-2 mt-4 pt-4" style="border-top:1px solid var(--slate-6)">
        <button class="sbtn sbtn-md sbtn-outline flex-1" id="sku-detach">отвязать товар</button>
      </div>
    </div>
  </div>
</section>

`;
  src = src.slice(0, start) + NEW + src.slice(end);
}

// ─── 2) JS Gen ───
{
  const startMarker = '  // ============ ГЕНЕРАЦИЯ (canvas-композитор · проект) ============';
  const endMarker = '  // ============ BOOT ============';
  const i = src.indexOf(startMarker);
  const j = src.indexOf(endMarker, i);
  if (i < 0 || j < 0) throw new Error('JS markers');

  const NEW = `  // ============ ГЕНЕРАЦИЯ v4 (проекты · промпт · мульти-реф) ============
  const SLIDE_TITLES = ['HERO','СОСТАВ','ВЫГОДЫ A','ВЫГОДЫ B','ПРЕИМУЩЕСТВА','ДЛЯ КОГО'];

  const Gen = {
    skus: [], palettes: [], jarFiles: [], projects: [],
    project_id: null,                     // id из БД (если сохранён)
    project_name: 'Новый проект',
    sku: null,
    palette: null,
    jar_path: null,
    ref_paths: [],                         // массив путей-референсов
    quality: 'medium',
    slide: 1,
    customColor: '#4a96d4',
    layers: [],
    layersBySlide: {1:[],2:[],3:[],4:[],5:[],6:[]},
    selectedId: null,
    zoom: 1,
    view: 'canvas',
    brief: '',
    prompt: '',
    _libMode: 'image-add',                 // 'image-add' | 'jar' | 'ref'

    async init(){
      [this.skus, this.palettes, this.projects] = await Promise.all([
        api('/api/skus'), api('/api/palettes'), api('/api/projects'),
      ]);
      this.renderSlideTabs();
      this.renderPalettes();
      this.renderProjectPicker();
      this.bindControls();
      this.palette = this.palettes.find(p => p.code === 'cognitive') || this.palettes[0];
      this.renderPalettes();
      this.renderCanvas();
      this.renderLayers();
      this.renderJar();
      this.renderRefList();
    },

    renderProjectPicker(){
      const sel = document.getElementById('proj-pick');
      sel.innerHTML = '<option value="new">+ Новый проект</option>' + this.projects.map(p =>
        \`<option value="\${p.id}" \${p.id===this.project_id?'selected':''}>\${esc(p.name)}</option>\`
      ).join('');
    },

    renderSlideTabs(){
      const cont = document.getElementById('gen-slide-tabs');
      cont.innerHTML = SLIDE_TITLES.map((t,i) =>
        \`<button class="ftab \${this.slide===i+1?'active':''}" data-slide="\${i+1}" style="padding:6px 10px; font-size:12px" title="\${esc(t)}">\${i+1}</button>\`
      ).join('');
      cont.querySelectorAll('[data-slide]').forEach(b => b.onclick = () => this.switchSlide(+b.dataset.slide));
    },

    switchSlide(n){
      this.layersBySlide[this.slide] = this.layers;
      this.slide = n;
      this.layers = this.layersBySlide[n] || [];
      this.selectedId = null;
      this.renderSlideTabs();
      this.renderCanvas();
      this.renderLayers();
      this.updateInspector();
      document.getElementById('gen-canvas-title').textContent = \`слайд \${n} · \${SLIDE_TITLES[n-1]} · 1086×1449\`;
    },

    attachSku(sku){
      this.sku = sku;
      const lab = document.getElementById('btn-attach-sku-label');
      if (!sku) { lab.textContent = 'привязать товар'; return; }
      lab.textContent = sku.sku;
      document.getElementById('proj-name').value = sku.name_ru;
      this.project_name = sku.name_ru;
      if (sku.palette_code) this.palette = this.palettes.find(p => p.code === sku.palette_code) || this.palette;
      if (sku.jar_master_path) this.jar_path = sku.jar_master_path;
      if (!this.layersBySlide[1].length) {
        this.layersBySlide[1].push({ id:'auto-title', type:'text', x:50, y:14, w:90, fs:48, content: (sku.name_en || sku.name_ru || '').toUpperCase(), color:'#ffffff', align:'center', weight:700 });
      }
      if (this.slide === 1) this.layers = this.layersBySlide[1];
      this.renderPalettes(); this.renderJar(); this.renderCanvas(); this.renderLayers();
      this.log(\`товар: \${sku.name_ru} (\${sku.sku})\`);
    },

    renderPalettes(){
      const grid = document.getElementById('gen-palette-grid');
      grid.innerHTML = this.palettes.map(p => {
        const active = this.palette?.id === p.id;
        return \`<button data-pal="\${p.code}" title="\${esc(p.code)}" style="aspect-ratio:1; border-radius:6px; background:linear-gradient(135deg, \${p.hex_main}, \${p.hex_accent}); border:\${active?'2px solid #fafafa':'1px solid var(--slate-6)'}; cursor:pointer"></button>\`;
      }).join('');
      grid.querySelectorAll('[data-pal]').forEach(b => b.onclick = () => {
        this.palette = this.palettes.find(p => p.code === b.dataset.pal);
        this.renderPalettes(); this.renderCanvas();
        document.getElementById('gen-palette-info').textContent = \`\${this.palette.code} · \${this.palette.hex_main}\`;
      });
      if (this.palette) document.getElementById('gen-palette-info').textContent = \`\${this.palette.code} · \${this.palette.hex_main}\`;
    },

    renderJar(){
      const prev = document.getElementById('jar-preview');
      const clr = document.getElementById('jar-clear');
      if (!prev) return;
      if (this.jar_path) {
        prev.outerHTML = \`<img id="jar-preview" src="/static/\${encodeURI(this.jar_path)}" style="width:100%; height:100%; object-fit:contain" onerror="this.outerHTML='<div id=jar-preview class=\\\\'text-[11px]\\\\' style=\\\\'color:var(--red-11)\\\\'>не найден</div>'" />\`;
        clr.style.display = '';
      } else {
        prev.outerHTML = '<div id="jar-preview" class="text-[11px] text-[var(--slate-10)] text-center p-3">+ кликни чтобы выбрать</div>';
        clr.style.display = 'none';
      }
    },

    renderRefList(){
      const cont = document.getElementById('ref-list');
      if (!this.ref_paths.length) {
        cont.innerHTML = '<div class="text-[11px] text-[var(--slate-10)] text-center py-2">— нет референсов —</div>';
        return;
      }
      cont.innerHTML = this.ref_paths.map((p, i) => \`
        <div class="flex items-center gap-2 p-2 rounded-lg" style="background:rgba(255,255,255,.02); border:1px solid var(--slate-6)">
          <img src="/static/\${encodeURI(p)}" style="width:36px; height:48px; object-fit:cover; border-radius:4px; flex-shrink:0" />
          <div class="flex-1 min-w-0 text-[10.5px] mono text-[var(--slate-11)] truncate">\${esc(p.replace('карточки/',''))}</div>
          <button data-ref-rm="\${i}" class="text-[var(--slate-10)] hover:text-[var(--red-11)]" style="background:transparent; border:none; cursor:pointer; padding:2px"><i data-lucide="x" class="w-3 h-3"></i></button>
        </div>
      \`).join('');
      cont.querySelectorAll('[data-ref-rm]').forEach(b => b.onclick = () => {
        this.ref_paths.splice(+b.dataset.refRm, 1);
        this.renderRefList(); lucide.createIcons();
      });
      lucide.createIcons();
    },

    renderCanvas(){
      const c = document.getElementById('gen-canvas');
      const palGrad = this.palette
        ? \`linear-gradient(135deg, \${this.palette.hex_main}, \${this.palette.hex_accent})\`
        : \`linear-gradient(135deg, \${this.customColor}, \${this.customColor})\`;
      c.style.background = palGrad;
      c.innerHTML = '';
      if ([1,2,6].includes(this.slide) && this.jar_path) {
        const j = document.createElement('img');
        j.src = '/static/' + encodeURI(this.jar_path);
        j.style.cssText = 'position:absolute; left:50%; top:55%; transform:translate(-50%,-50%); width:60%; pointer-events:none';
        j.draggable = false;
        c.appendChild(j);
      }
      if (!this.layers.length && !([1,2,6].includes(this.slide) && this.jar_path)) {
        const hint = document.createElement('div');
        hint.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.5);font-size:12px;pointer-events:none;text-align:center;padding:20px';
        hint.innerHTML = 'пусто<br/><span style="font-size:10px">слева → Текст / Картинка / Загрузить</span>';
        c.appendChild(hint);
      }
      for (const L of this.layers) this.renderLayer(c, L);
    },

    renderLayer(c, L){
      const el = document.createElement('div');
      el.dataset.lid = L.id;
      const isText = L.type === 'text';
      const sel = this.selectedId === L.id;
      const base = \`position:absolute; left:\${L.x}%; top:\${L.y}%; width:\${L.w}%; transform:translate(-50%,-50%); cursor:move; \${sel ? 'outline:2px dashed #fafafa; outline-offset:2px':''}\`;
      if (isText) {
        el.style.cssText = base + \`; color:\${L.color||'#fff'}; text-align:\${L.align||'center'}; font-size:\${L.fs||32}px; font-weight:\${L.weight||700}; line-height:1.15; text-shadow:0 2px 8px rgba(0,0,0,.4); padding:4px; word-break:break-word; white-space:pre-wrap\`;
        el.textContent = L.content || '';
      } else {
        el.style.cssText = base;
        const img = document.createElement('img');
        img.src = L.content;
        img.style.cssText = 'width:100%; display:block; pointer-events:none';
        img.draggable = false;
        img.onerror = () => { el.innerHTML = '<div style="color:#f47174;font-size:11px;text-align:center">img not found</div>'; };
        el.appendChild(img);
      }
      el.addEventListener('pointerdown', (e) => {
        if (e.target.closest('.layer-handle')) return;
        this.startDrag(e, L);
      });

      // 4 handles по углам
      if (sel) {
        const corners = [
          ['nw', '-6px', '-6px', 'nwse-resize'],
          ['ne', 'auto -6px', '-6px', 'nesw-resize'],
          ['sw', '-6px', 'auto', 'nesw-resize'],
          ['se', 'auto -6px', 'auto -6px', 'nwse-resize'],
        ];
        for (const [pos, lr, tb, cur] of corners) {
          const h = document.createElement('div');
          h.className = 'layer-handle';
          h.dataset.corner = pos;
          let style = 'position:absolute; width:12px; height:12px; background:#fafafa; border-radius:2px; box-shadow:0 0 0 1px rgba(0,0,0,.6); z-index:10; cursor:'+cur+';';
          if (pos==='nw') style += 'left:-6px; top:-6px';
          if (pos==='ne') style += 'right:-6px; top:-6px';
          if (pos==='sw') style += 'left:-6px; bottom:-6px';
          if (pos==='se') style += 'right:-6px; bottom:-6px';
          h.style.cssText = style;
          h.addEventListener('pointerdown', (e) => { e.stopPropagation(); this.startResize(e, L, pos); });
          el.appendChild(h);
        }
      }

      el.addEventListener('click', (e) => { e.stopPropagation(); this.selectLayer(L.id); });
      c.appendChild(el);
    },

    startDrag(e, L){
      e.stopPropagation(); e.preventDefault();
      this.selectLayer(L.id);
      const c = document.getElementById('gen-canvas');
      const rect = c.getBoundingClientRect();
      const startX = e.clientX, startY = e.clientY;
      const oX = L.x, oY = L.y;
      const move = (ev) => {
        const dxp = (ev.clientX - startX) / rect.width * 100;
        const dyp = (ev.clientY - startY) / rect.height * 100;
        L.x = Math.max(0, Math.min(100, oX + dxp));
        L.y = Math.max(0, Math.min(100, oY + dyp));
        this.renderCanvas(); this.updateInspector();
      };
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    },

    startResize(e, L, corner){
      e.stopPropagation(); e.preventDefault();
      const c = document.getElementById('gen-canvas');
      const rect = c.getBoundingClientRect();
      const startX = e.clientX, startY = e.clientY;
      const oW = L.w, oFS = L.fs || 32, oX = L.x, oY = L.y;
      const isText = L.type === 'text';
      const move = (ev) => {
        const dxp = (ev.clientX - startX) / rect.width * 100;
        const dyp = (ev.clientY - startY) / rect.height * 100;
        // se: расширяем вправо-вниз, x/y растёт пропорционально
        // nw: тянем верх-лево
        let dW = 0;
        if (corner === 'se' || corner === 'ne') dW = dxp * 2;
        else dW = -dxp * 2;
        const newW = Math.max(5, Math.min(200, oW + dW));
        L.w = newW;
        if (isText) L.fs = Math.max(8, Math.round(oFS * (newW / oW)));
        this.renderCanvas(); this.updateInspector();
      };
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    },

    addText(){
      const id = 'L'+Date.now();
      this.layers.push({ id, type:'text', x:50, y:50, w:80, fs:32, content:'Новый текст', color:'#ffffff', align:'center', weight:700 });
      this.layersBySlide[this.slide] = this.layers;
      this.selectedId = id;
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
    },
    addImage(url){
      const id = 'L'+Date.now();
      this.layers.push({ id, type:'image', x:50, y:50, w:30, content: url });
      this.layersBySlide[this.slide] = this.layers;
      this.selectedId = id;
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
    },
    selectLayer(id){
      this.selectedId = id;
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
    },
    deleteLayer(id){
      this.layers = this.layers.filter(L => L.id !== id);
      this.layersBySlide[this.slide] = this.layers;
      if (this.selectedId === id) this.selectedId = null;
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
    },
    moveLayer(id, dir){
      const idx = this.layers.findIndex(L => L.id === id);
      if (idx < 0) return;
      const newIdx = dir === 'up' ? Math.min(this.layers.length-1, idx+1) : Math.max(0, idx-1);
      if (newIdx === idx) return;
      const [L] = this.layers.splice(idx, 1);
      this.layers.splice(newIdx, 0, L);
      this.layersBySlide[this.slide] = this.layers;
      this.renderCanvas(); this.renderLayers();
    },

    renderLayers(){
      const cont = document.getElementById('gen-layers');
      const cnt = document.getElementById('gen-layers-count');
      cnt.textContent = this.layers.length;
      if (!this.layers.length) { cont.innerHTML = '<div class="text-[12px] text-[var(--slate-10)] py-2">пусто · добавь Текст или Картинку</div>'; return; }
      cont.innerHTML = this.layers.slice().reverse().map(L => {
        const active = this.selectedId === L.id;
        const ico = L.type === 'text' ? 'type' : 'image';
        const lbl = L.type === 'text' ? (L.content || 'текст').slice(0, 24) : 'картинка';
        return \`<div class="prompt-item \${active?'active':''}" data-lid="\${L.id}" style="display:flex; align-items:center; gap:8px; padding:7px 9px; font-size:12px; cursor:pointer">
          <i data-lucide="\${ico}" class="w-3.5 h-3.5 text-[var(--slate-11)] flex-shrink-0"></i>
          <span class="flex-1 text-left truncate text-slate-12">\${esc(lbl)}</span>
          <button data-del="\${L.id}" class="text-[var(--slate-10)] hover:text-[var(--red-11)] flex-shrink-0" title="удалить" style="background:transparent; border:none; cursor:pointer; padding:2px"><i data-lucide="x" class="w-3 h-3"></i></button>
        </div>\`;
      }).join('');
      cont.querySelectorAll('[data-lid]').forEach(b => b.onclick = (e) => {
        const del = e.target.closest('[data-del]');
        if (del) { this.deleteLayer(del.dataset.del); return; }
        this.selectLayer(b.dataset.lid);
      });
      lucide.createIcons();
    },

    updateInspector(){
      const ins = document.getElementById('gen-inspector');
      const L = this.layers.find(l => l.id === this.selectedId);
      if (!L) { ins.classList.add('hidden'); return; }
      ins.classList.remove('hidden');
      const isText = L.type === 'text';
      document.getElementById('ins-text').value = isText ? (L.content || '') : '';
      document.getElementById('ins-text').disabled = !isText;
      document.getElementById('ins-x').value = Math.round(L.x);
      document.getElementById('ins-y').value = Math.round(L.y);
      document.getElementById('ins-w').value = Math.round(L.w);
      document.getElementById('ins-fs').value = L.fs || 32;
      document.getElementById('ins-fs').disabled = !isText;
      document.getElementById('ins-color').value = L.color || '#ffffff';
      document.querySelectorAll('#ins-align [data-align]').forEach(b => b.classList.toggle('active', b.dataset.align === (L.align || 'center')));
    },

    bindInspector(){
      const upd = (k, val) => {
        const L = this.layers.find(l => l.id === this.selectedId); if (!L) return;
        L[k] = val;
        this.renderCanvas(); this.renderLayers();
      };
      document.getElementById('ins-text').oninput = e => upd('content', e.target.value);
      document.getElementById('ins-x').oninput = e => upd('x', +e.target.value);
      document.getElementById('ins-y').oninput = e => upd('y', +e.target.value);
      document.getElementById('ins-w').oninput = e => upd('w', +e.target.value);
      document.getElementById('ins-fs').oninput = e => upd('fs', +e.target.value);
      document.getElementById('ins-color').oninput = e => upd('color', e.target.value);
      document.querySelectorAll('#ins-align [data-align]').forEach(b => b.onclick = () => upd('align', b.dataset.align));
      document.getElementById('ins-delete').onclick = () => this.selectedId && this.deleteLayer(this.selectedId);
      document.getElementById('ins-z-up').onclick = () => this.selectedId && this.moveLayer(this.selectedId, 'up');
      document.getElementById('ins-z-down').onclick = () => this.selectedId && this.moveLayer(this.selectedId, 'down');
    },

    bindControls(){
      document.getElementById('tool-add-text').onclick = () => this.addText();
      document.getElementById('tool-add-from-lib').onclick = () => this.openLibModal('image-add');
      document.getElementById('tool-upload-btn').onclick = () => document.getElementById('tool-upload-input').click();
      document.getElementById('tool-upload-input').onchange = (e) => {
        for (const f of e.target.files) this.addImage(URL.createObjectURL(f));
      };

      // SKU
      document.getElementById('btn-attach-sku').onclick = () => this.openSkuModal();
      document.getElementById('sku-modal-close').onclick = () => document.getElementById('sku-modal').classList.add('hidden');
      document.getElementById('sku-detach').onclick = () => { this.attachSku(null); document.getElementById('sku-modal').classList.add('hidden'); };
      document.getElementById('sku-modal').onclick = (e) => { if (e.target.id === 'sku-modal') document.getElementById('sku-modal').classList.add('hidden'); };

      // jar
      document.getElementById('jar-pick').onclick = () => this.openLibModal('jar');
      document.getElementById('jar-clear').onclick = (e) => { e.stopPropagation(); this.jar_path = null; this.renderJar(); this.renderCanvas(); };

      // refs
      document.getElementById('ref-add').onclick = () => this.openLibModal('ref');

      // lib modal
      document.getElementById('lib-modal-close').onclick = () => this.closeLibModal();
      document.getElementById('lib-modal').onclick = (e) => { if (e.target.id === 'lib-modal') this.closeLibModal(); };
      document.getElementById('lib-modal-q').oninput = (e) => {
        const q = e.target.value.toLowerCase().trim();
        this.renderLibGrid(this.jarFiles.filter(f => !q || (f.path||'').toLowerCase().includes(q)));
      };

      document.getElementById('gen-quality').onchange = e => { this.quality = e.target.value; };

      // palette custom
      document.getElementById('gen-palette-custom').oninput = e => {
        this.customColor = e.target.value;
        this.palette = null;
        document.querySelectorAll('#gen-palette-grid [data-pal]').forEach(b => b.style.borderColor = 'var(--slate-6)');
        document.getElementById('gen-palette-info').textContent = 'кастом · ' + e.target.value;
        this.renderCanvas();
      };

      // launch
      document.getElementById('btn-gen-fire').onclick = () => this.fire(false);
      document.getElementById('btn-simulate').onclick = () => this.fire(true);

      // zoom
      document.getElementById('gen-zoom-in').onclick = () => this.setZoom(Math.min(2, this.zoom + 0.1));
      document.getElementById('gen-zoom-out').onclick = () => this.setZoom(Math.max(0.4, this.zoom - 0.1));

      // canvas click — снять выделение
      document.getElementById('gen-canvas').onclick = () => { this.selectedId = null; this.renderCanvas(); this.renderLayers(); this.updateInspector(); };

      // project name
      document.getElementById('proj-name').oninput = (e) => { this.project_name = e.target.value; };

      // project picker
      document.getElementById('proj-pick').onchange = (e) => {
        if (e.target.value === 'new') this.newProject();
        else this.loadProject(+e.target.value);
      };

      // save / delete
      document.getElementById('btn-proj-save').onclick = () => this.saveProject();
      document.getElementById('btn-proj-delete').onclick = () => this.deleteProject();

      // view tabs
      document.getElementById('view-canvas-btn').onclick = () => this.switchView('canvas');
      document.getElementById('view-prompt-btn').onclick = () => this.switchView('prompt');

      // brief
      document.getElementById('gen-brief').oninput = (e) => { this.brief = e.target.value; this.composePrompt(true); };
      document.getElementById('btn-prompt-regen').onclick = () => this.composePrompt(true);
      document.getElementById('btn-prompt-copy').onclick = () => {
        navigator.clipboard.writeText(this.prompt);
        this.log('промпт скопирован', 'ok');
      };
      document.getElementById('gen-prompt').oninput = (e) => { this.prompt = e.target.value; };

      this.bindInspector();
    },

    setZoom(z){
      this.zoom = z;
      document.getElementById('gen-canvas').style.width = (480 * z) + 'px';
      document.getElementById('gen-zoom-label').textContent = Math.round(z*100) + '%';
    },

    switchView(v){
      this.view = v;
      document.querySelectorAll('[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === v));
      document.getElementById('view-canvas').classList.toggle('hidden', v !== 'canvas');
      document.getElementById('view-prompt').classList.toggle('hidden', v !== 'prompt');
      if (v === 'prompt') this.composePrompt();
    },

    openSkuModal(){
      const m = document.getElementById('sku-modal');
      m.classList.remove('hidden');
      const list = document.getElementById('sku-modal-list');
      list.innerHTML = this.skus.map(s => {
        const grad = s.hex_main ? \`linear-gradient(135deg, \${s.hex_main}, \${s.hex_accent})\` : 'var(--slate-5)';
        return \`<button class="prompt-item" data-skuid="\${s.id}" style="display:flex; align-items:center; gap:12px; padding:10px 12px; text-align:left; cursor:pointer">
          <span style="width:28px; height:36px; border-radius:6px; background:\${grad}; flex-shrink:0; border:1px solid rgba(255,255,255,.06)"></span>
          <div class="flex-1 min-w-0">
            <div class="text-[13px] font-medium text-slate-12 truncate">\${esc(s.name_ru)}</div>
            <div class="text-[11px] text-[var(--slate-10)] mono truncate">\${esc(s.sku)} · \${esc(s.category_id||'')}</div>
          </div>
        </button>\`;
      }).join('');
      list.querySelectorAll('[data-skuid]').forEach(b => b.onclick = () => {
        const sku = this.skus.find(s => s.id === +b.dataset.skuid);
        this.attachSku(sku);
        document.getElementById('sku-modal').classList.add('hidden');
      });
    },

    async openLibModal(mode){
      this._libMode = mode;
      const titles = { 'image-add':'Картинка для слоя', 'jar':'Эталон банки', 'ref':'Базовая картинка (reference)' };
      document.getElementById('lib-modal-title').textContent = titles[mode];
      document.getElementById('lib-modal').classList.remove('hidden');
      const grid = document.getElementById('lib-modal-grid');
      grid.innerHTML = '<div class="col-span-full text-center text-[12px] text-[var(--slate-10)] py-8">загрузка…</div>';
      if (!this.jarFiles.length) {
        const files = await api('/api/library/files?folder=all');
        this.jarFiles = files.filter(f => ['.png','.jpg','.jpeg','.webp'].includes(f.ext));
      }
      this.renderLibGrid(this.jarFiles);
    },
    closeLibModal(){ document.getElementById('lib-modal').classList.add('hidden'); },
    renderLibGrid(files){
      const grid = document.getElementById('lib-modal-grid');
      if (!files.length) { grid.innerHTML = '<div class="col-span-full text-center text-[12px] text-[var(--slate-10)] py-8">ничего не найдено</div>'; return; }
      grid.innerHTML = files.slice(0, 200).map(f =>
        \`<button class="file-tile" data-pick="\${esc(f.path)}" data-url="\${esc(f.url)}" style="text-align:left; cursor:pointer">
          <div class="file-preview" style="background:#0c0c0e url('\${f.url}') center/contain no-repeat"></div>
          <div class="file-meta">
            <div class="text-[11.5px] font-medium text-slate-12 truncate">\${esc(f.name)}</div>
            <div class="text-[10px] text-[var(--slate-10)] mono truncate">\${esc((f.path||'').replace('карточки/',''))}</div>
          </div>
        </button>\`
      ).join('');
      grid.querySelectorAll('[data-pick]').forEach(el => el.onclick = () => {
        const path = el.dataset.pick;
        const url = el.dataset.url;
        if (this._libMode === 'jar') { this.jar_path = path; this.renderJar(); this.renderCanvas(); this.log('эталон банки: '+path); }
        else if (this._libMode === 'ref') { this.ref_paths.push(path); this.renderRefList(); this.log('+ референс: '+path); }
        else { this.addImage(url); this.log('+ слой картинки: '+path); }
        this.closeLibModal();
      });
    },

    log(msg, kind='info'){
      const el = document.getElementById('gen-log');
      const time = new Date().toLocaleTimeString('ru');
      const color = kind === 'err' ? 'var(--red-11)' : kind === 'ok' ? 'var(--green-11)' : kind === 'warn' ? 'var(--yellow-11)' : 'var(--slate-11)';
      const div = document.createElement('div');
      div.style.color = color;
      div.textContent = \`[\${time}] \${msg}\`;
      el.appendChild(div);
      el.scrollTop = el.scrollHeight;
    },

    composePrompt(updateView=false){
      const tpl = SLIDE_TITLES[this.slide-1];
      const palWords = this.palette
        ? \`\${this.palette.code} palette: \${this.palette.hex_main} → \${this.palette.hex_accent}, \${this.palette.bg_object||''}\`
        : \`custom hex \${this.customColor}\`;
      const elems = this.layers.map(L => {
        if (L.type === 'text') return \`- TEXT "\${L.content}" at \${Math.round(L.x)}%/\${Math.round(L.y)}% (size \${L.fs||32}px, align \${L.align||'center'}, color \${L.color||'#fff'})\`;
        return \`- IMAGE at \${Math.round(L.x)}%/\${Math.round(L.y)}% width \${Math.round(L.w)}% (src: \${L.content})\`;
      }).join('\\n') || '(no layers — use defaults from slide canon)';
      const jar = ([1,2,6].includes(this.slide) && this.jar_path) ? \`\\nGRAFLAB jar reference: /static/\${this.jar_path}, centered ~55% Y\` : '';
      const refs = this.ref_paths.length ? \`\\nReference image(s) for image.edit:\\n\${this.ref_paths.map((p,i) => \`  \${i+1}. /static/\${p}\`).join('\\n')}\\nMatch style/palette/typography from these references exactly.\` : '';
      const briefLine = this.brief.trim() ? \`\\n\\nДОПОЛНИТЕЛЬНО ОТ ПОЛЬЗОВАТЕЛЯ:\\n\${this.brief.trim()}\` : '';
      this.prompt = \`Slide \${this.slide} · \${tpl} · project "\${this.project_name}"\\n\${palWords}\${jar}\${refs}\\n\\nElements on canvas:\\n\${elems}\${briefLine}\\n\\nMatch GRAflab brand canvas: real Cyrillic, no medical claims, premium calm tone, portrait 1086x1449.\`;
      if (updateView) {
        const el = document.getElementById('gen-prompt');
        if (el) el.value = this.prompt;
      }
      return this.prompt;
    },

    showLoader(text){
      const ov = document.getElementById('gen-loading');
      ov.classList.remove('hidden');
      ov.style.display = 'flex';
      document.getElementById('gen-loading-text').textContent = text;
      const elapsed = document.getElementById('gen-loading-elapsed');
      const t0 = Date.now();
      this._loaderTimer = setInterval(() => {
        elapsed.textContent = ((Date.now()-t0)/1000).toFixed(1) + ' сек';
      }, 100);
    },
    hideLoader(){
      clearInterval(this._loaderTimer);
      const ov = document.getElementById('gen-loading');
      ov.classList.add('hidden');
      ov.style.display = 'none';
    },

    async fire(simulate){
      const dryRun = simulate;
      const promptText = this.composePrompt();
      this.log(\`старт · слайд \${this.slide} · \${dryRun?'симуляция':'РЕАЛЬНЫЙ'} · \${this.quality}\`, 'info');
      if (!dryRun) {
        const cost = { low:1.6, medium:17, high:68 }[this.quality];
        if (!confirm(\`Реальная генерация ~\${cost.toFixed(1)} ₽ через ProxyAPI. Продолжить?\`)) { this.log('отменено', 'warn'); return; }
      }
      this.showLoader(dryRun ? 'симуляция…' : 'генерация через OpenAI…');
      try {
        const res = await fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sku_id: this.sku?.id || 1,
            slide_kind: this.slide,
            prompt_text: promptText,
            ref_image_path: this.ref_paths[0] || this.jar_path,
            quality: this.quality,
            dry_run: dryRun,
          }),
        });
        const j = await res.json();
        this.hideLoader();
        if (j.ok) {
          this.log(\`✓ слайд \${this.slide} · gen #\${j.generation_id}\${j.cost_rub?' · '+j.cost_rub+' ₽':''}\`, 'ok');
          if (j.output_url) {
            this.log('файл: ' + j.output_url, 'ok');
            // показать как новый слой автоматически
            this.addImage(j.output_url);
            this.log('добавлен слой с результатом', 'ok');
          } else if (dryRun) {
            this.log('симуляция · реально картинка не создана', 'warn');
          }
        } else {
          this.log('✗ ошибка: ' + (j.error || 'неизвестно'), 'err');
        }
      } catch(e) {
        this.hideLoader();
        this.log('✗ сеть: ' + e.message, 'err');
      }
      loadGenerations();
    },

    // ─── PROJECTS ───
    async newProject(){
      this.project_id = null;
      this.project_name = 'Новый проект';
      this.sku = null; this.palette = this.palettes[0]; this.jar_path = null; this.ref_paths = [];
      this.layers = []; this.layersBySlide = {1:[],2:[],3:[],4:[],5:[],6:[]};
      this.selectedId = null; this.brief = ''; this.prompt = '';
      document.getElementById('proj-name').value = this.project_name;
      document.getElementById('proj-pick').value = 'new';
      document.getElementById('btn-attach-sku-label').textContent = 'привязать товар';
      document.getElementById('gen-brief').value = '';
      this.renderPalettes(); this.renderJar(); this.renderRefList();
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
      this.log('новый проект', 'info');
    },

    async loadProject(id){
      const p = await api('/api/projects/' + id);
      this.project_id = p.id;
      this.project_name = p.name;
      document.getElementById('proj-name').value = p.name;
      this.palette = p.palette_id ? this.palettes.find(x => x.id === p.palette_id) : null;
      this.customColor = p.custom_color || '#4a96d4';
      this.jar_path = p.jar_path || null;
      this.ref_paths = p.ref_paths || [];
      this.brief = p.brief || '';
      document.getElementById('gen-brief').value = this.brief;
      this.layersBySlide = p.layers_json && Object.keys(p.layers_json).length ? p.layers_json : {1:[],2:[],3:[],4:[],5:[],6:[]};
      for (let k=1; k<=6; k++) this.layersBySlide[k] = this.layersBySlide[k] || [];
      this.slide = p.current_slide || 1;
      this.layers = this.layersBySlide[this.slide];
      this.selectedId = null;
      if (p.sku_id) this.sku = this.skus.find(s => s.id === p.sku_id) || null;
      else this.sku = null;
      document.getElementById('btn-attach-sku-label').textContent = this.sku?.sku || 'привязать товар';
      this.renderSlideTabs(); this.renderPalettes(); this.renderJar(); this.renderRefList();
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
      this.log('открыт проект «'+p.name+'»', 'ok');
    },

    async saveProject(){
      this.layersBySlide[this.slide] = this.layers;
      const body = {
        name: this.project_name,
        sku_id: this.sku?.id || null,
        palette_id: this.palette?.id || null,
        custom_color: this.palette ? null : this.customColor,
        jar_path: this.jar_path,
        ref_paths: this.ref_paths,
        layers_json: this.layersBySlide,
        current_slide: this.slide,
        brief: this.brief,
      };
      try {
        const res = await fetch(this.project_id ? '/api/projects/'+this.project_id : '/api/projects', {
          method: this.project_id ? 'PATCH' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
        const j = await res.json();
        this.project_id = j.id;
        this.projects = await api('/api/projects');
        this.renderProjectPicker();
        document.getElementById('proj-pick').value = j.id;
        this.log('✓ проект сохранён · #'+j.id, 'ok');
      } catch(e) {
        this.log('✗ не удалось сохранить: '+e.message, 'err');
      }
    },

    async deleteProject(){
      if (!this.project_id) { this.log('проект ещё не сохранён', 'warn'); return; }
      if (!confirm('Удалить проект «'+this.project_name+'»?')) return;
      try {
        await fetch('/api/projects/'+this.project_id, { method:'DELETE' });
        this.log('✓ проект удалён', 'ok');
        this.projects = await api('/api/projects');
        this.renderProjectPicker();
        this.newProject();
      } catch(e) { this.log('✗ '+e.message, 'err'); }
    },
  };

  // ============ BOOT ============
`;
  src = src.slice(0, i) + NEW + src.slice(j + endMarker.length) + (src.slice(j + endMarker.length).startsWith('\\n') ? '' : '\\n');
}

writeFileSync(fpath, src, 'utf8');
console.log('done');
