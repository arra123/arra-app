// Заменяет секцию <section data-page="generate"> на рабочую версию
import { readFileSync, writeFileSync } from 'node:fs';

const fpath = 'C:/Claude/Work/cards/site/index.html';
let src = readFileSync(fpath, 'utf8');

const startMarker = '<section class="tab-page active" data-page="generate">';
const endMarker = '<!-- ─────────── 2. БАЗА ПРОМПТОВ ─────────── -->';
const i = src.indexOf(startMarker);
const j = src.indexOf(endMarker, i);
if (i < 0 || j < 0) { console.error('markers not found'); process.exit(1); }

const NEW = `<section class="tab-page active" data-page="generate">
  <div class="max-w-[1320px] mx-auto px-8 py-10">

    <div class="mb-8 flex items-end justify-between flex-wrap gap-4">
      <h1 class="text-[36px] font-semibold tracking-tight">Генерация</h1>
      <button class="sbtn sbtn-md sbtn-outline" id="btn-reset-gen"><i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>Сбросить</button>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-[420px_1fr] gap-5">

      <div class="flex flex-col gap-5">

        <div class="r-card accent-blue p-7 relative">
          <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
          <label class="slabel">1 · Артикул</label>
          <div class="relative mb-3">
            <i data-lucide="search" class="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[var(--slate-10)]"></i>
            <input class="sinput pl-9" placeholder="Найти артикул…" id="gen-sku-q" />
          </div>
          <div id="gen-sku-list" class="flex flex-col gap-1 max-h-[300px] overflow-y-auto">
            <div class="text-[12px] text-[var(--slate-10)] px-3 py-4">загрузка…</div>
          </div>
        </div>

        <div class="r-card accent-purple p-7 relative">
          <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
          <label class="slabel">2 · Палитра</label>
          <div id="gen-palette-grid" class="grid grid-cols-4 gap-2 mb-3"></div>
          <div class="flex items-center gap-2">
            <input type="color" id="gen-palette-custom" value="#4a96d4" class="w-10 h-10 rounded-lg cursor-pointer border" style="border-color:var(--slate-6)" />
            <div class="flex-1 min-w-0">
              <div class="text-[12px] text-slate-12 font-medium truncate" id="gen-palette-label">—</div>
              <div class="text-[11px] mono text-[var(--slate-10)] truncate" id="gen-palette-hex">выбери из набора или возьми любой цвет</div>
            </div>
            <button class="sbtn sbtn-sm sbtn-ghost" id="gen-palette-use-custom" style="font-size:11px">кастом</button>
          </div>
        </div>

        <div class="r-card accent-amber p-7 relative">
          <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
          <label class="slabel">3 · Эталон банки</label>
          <div id="gen-jar-preview" class="rounded-lg overflow-hidden mb-3 border flex items-center justify-center" style="border-color:var(--slate-6); aspect-ratio:1; background:#0c0c0e">
            <div class="text-[12px] text-[var(--slate-10)]">не выбрана</div>
          </div>
          <div class="flex items-center gap-2">
            <button id="gen-jar-pick" class="sbtn sbtn-md sbtn-secondary flex-1"><i data-lucide="folder-open" class="w-3.5 h-3.5"></i>Из библиотеки</button>
            <button id="gen-jar-clear" class="sbtn sbtn-md sbtn-ghost" title="Очистить"><i data-lucide="x" class="w-3.5 h-3.5"></i></button>
          </div>
          <div class="text-[10.5px] text-[var(--slate-10)] mono mt-2 break-all" id="gen-jar-path">—</div>
        </div>

        <div class="r-card p-7 relative">
          <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
          <label class="slabel">4 · Качество</label>
          <div class="flex gap-2 mb-5" id="gen-quality">
            <button data-q="low" class="ftab" data-cost="1.6">low</button>
            <button data-q="medium" class="ftab active" data-cost="17">medium</button>
            <button data-q="high" class="ftab" data-cost="68">high</button>
          </div>

          <div class="flex items-center justify-between gap-4 pt-4" style="border-top:1px solid var(--slate-6)">
            <div>
              <div class="text-[13.5px] font-medium text-slate-12">Dry-run</div>
              <div class="text-[12px] text-[var(--slate-11)] mt-0.5">Без вызова OpenAI · бесплатно</div>
            </div>
            <input type="checkbox" id="gen-dry-run" class="sswitch" checked />
          </div>
        </div>

      </div>

      <div class="flex flex-col gap-5">

        <div class="r-card accent-purple p-8 relative">
          <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
          <div class="flex items-end justify-between mb-2 flex-wrap gap-2">
            <h3 class="text-[18px] font-semibold">6 слайдов серии</h3>
            <div class="text-[12.5px] text-[var(--slate-11)]" id="gen-subtitle">выбери артикул чтобы начать</div>
          </div>
          <div id="gen-slides" class="grid grid-cols-2 md:grid-cols-3 gap-4 mt-5"></div>
        </div>

        <div class="r-card accent-green p-7 relative">
          <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
          <div class="grid grid-cols-3 gap-5 mb-6">
            <div>
              <div class="section-cap">слайдов</div>
              <div class="text-[24px] font-semibold mt-2 text-slate-12" id="gen-count">0</div>
            </div>
            <div>
              <div class="section-cap">оценка</div>
              <div class="text-[24px] font-semibold mt-2 text-slate-12" id="gen-cost">—</div>
            </div>
            <div>
              <div class="section-cap">время</div>
              <div class="text-[24px] font-semibold mt-2 text-slate-12" id="gen-time">—</div>
            </div>
          </div>
          <div class="flex items-center gap-3 flex-wrap">
            <button class="sbtn sbtn-md sbtn-secondary flex-1 min-w-[180px]" id="btn-test-run" disabled><i data-lucide="zap" class="w-3.5 h-3.5"></i>Тест 1 слайд</button>
            <button class="rbtn-primary" id="btn-gen-all" disabled><i data-lucide="sparkles" class="w-3.5 h-3.5"></i>Сгенерировать серию</button>
          </div>
          <div id="gen-status" class="text-[12.5px] mt-4 text-[var(--slate-11)] min-h-[18px]"></div>
        </div>

        <div class="r-card p-7 relative">
          <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
          <div class="flex items-center justify-between mb-5">
            <h3 class="text-[16px] font-semibold">Последние генерации</h3>
            <button class="sbtn sbtn-sm sbtn-ghost" id="btn-refresh-hist"><i data-lucide="refresh-cw" class="w-3 h-3"></i></button>
          </div>
          <div class="relative">
            <div class="tl-line"></div>
            <div class="flex flex-col gap-7" id="gen-history">
              <div class="text-sm text-[var(--slate-11)]">загрузка…</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="jar-modal" class="hidden fixed inset-0 z-50 flex items-center justify-center" style="background:rgba(0,0,0,.7); backdrop-filter:blur(8px)">
    <div class="r-card relative p-6" style="width:92vw; max-width:960px; max-height:88vh; overflow-y:auto">
      <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-[18px] font-semibold">Выбери эталон-банку из библиотеки</h3>
        <button class="sbtn sbtn-icon-sm sbtn-ghost" id="jar-modal-close"><i data-lucide="x" class="w-4 h-4"></i></button>
      </div>
      <input class="sinput mb-4" placeholder="Поиск по имени или папке…" id="jar-modal-q" />
      <div id="jar-modal-grid" class="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3"></div>
    </div>
  </div>
</section>

`;

src = src.slice(0, i) + NEW + src.slice(j);
writeFileSync(fpath, src, 'utf8');
console.log(`section replaced: ${j-i} → ${NEW.length} bytes`);
