from PIL import Image, ImageDraw, ImageFont
import pathlib

OUT = r"C:\Claude\Work\cards\mindmap_v2.png"
W, H = 1900, 1180
BG = (24, 26, 33)
INK = (235, 235, 240)
DIM = (130, 135, 150)

P = {
    "core":    (255, 170, 60),
    "data":    (200, 130, 255),
    "process": (110, 175, 255),
    "pain":    (230, 90, 90),
    "solve":   (90, 200, 130),
    "next":    (255, 220, 100),
}

def font(size, bold=False):
    p = r"C:\Windows\Fonts\segoeuib.ttf" if bold else r"C:\Windows\Fonts\segoeui.ttf"
    return ImageFont.truetype(p, size) if pathlib.Path(p).exists() else ImageFont.load_default()

def node(d, cx, cy, title, items, color, w=340, ts=18, is_=14):
    ft = font(ts, True); fi = font(is_)
    pad = 14; lh = is_ + 8; th = ts + 10
    h = th + pad + len(items)*lh + pad
    x0, y0 = cx - w//2, cy - h//2
    x1, y1 = cx + w//2, cy + h//2
    d.rounded_rectangle((x0,y0,x1,y1), 14, fill=(36,40,52), outline=color, width=3)
    d.rounded_rectangle((x0,y0,x1,y0+th+8), 14, fill=color)
    d.text((x0+pad, y0+8), title, font=ft, fill=(20,20,28))
    y = y0 + th + pad
    for it in items:
        d.text((x0+pad, y), "•  " + it, font=fi, fill=INK)
        y += lh
    return (x0,y0,x1,y1)

def line(d, a, b, c=(70,75,90), w=2):
    d.line([a,b], fill=c, width=w)

img = Image.new("RGB", (W,H), BG)
d = ImageDraw.Draw(img)

d.text((40, 28), "cards — что мы знаем после звонка + чата GPT", font=font(32, True), fill=INK)
d.text((40, 70), "коллега-менеджер 2 недели итерировал воркфлоу, мы вытащили его финальную версию", font=font(16), fill=DIM)

# CENTRE
center = (W//2, H//2 + 30)
core = node(d, *center, "ВОРКФЛОУ КАРТОЧКИ GRAFLAB",
    ["6 слайдов на SKU, 1086×1449 px",
     "канон зафиксирован 25 апреля",
     "MVP = автоматизировать этот пайплайн"],
    P["core"], w=400, ts=18)

# 1. Канон 6 слайдов (top-left)
n1 = node(d, 290, 250, "КАНОН 6 СЛАЙДОВ",
    ["1. Главный — банка крупная + компоненты",
     "2. Состав/дозировки — банка иначе",
     "3. Польза + девушка/офисный 1",
     "4. Польза + мужчина/офисный 2",
     "5. Преимущества формулы (без людей)",
     "6. Для кого / премиальность / мини-банка"],
    P["core"], w=400)

# 2. Палитра по категории (top-center)
n2 = node(d, W//2, 220, "ПАЛИТРА ПО КАТЕГОРИИ",
    ["Энергия / антиокс → ОРАНЖЕВЫЙ",
     "Мозг / фокус → СИНИЙ",
     "Longevity / детокс → СВЕТЛО-ЗЕЛЁНЫЙ",
     "Сосуды / кровоток → КРАСНО-РОЗОВЫЙ",
     "Пищеварение → ФИОЛЕТОВЫЙ"],
    P["data"], w=380)

# 3. Запреты по тексту (top-right)
n3 = node(d, W-280, 250, "ЗАПРЕТЫ В ТЕКСТЕ",
    ["❌ лечит / омолаживает",
     "❌ против болезни / диагнозы",
     "✅ поддержка / защита / комфорт",
     "✅ ресурс / баланс / активный ритм",
     "по-категорийно: серрапт ≠ воспаления,",
     "псиллиум ≠ токсины, бенфо ≠ память"],
    P["solve"], w=380)

# 4. Боль (bottom-left)
n4 = node(d, 290, H-260, "ГЛАВНАЯ БОЛЬ",
    ["GPT-image НЕ держит банку стабильно",
     "20 генераций = 20 разных банок",
     "форма, крышка, текст «плывут»",
     "→ дешёвый вид всей серии",
     "прозрачный фон GPT тоже не делает"],
    P["pain"], w=400)

# 5. Решение (bottom-center)
n5 = node(d, W//2, H-260, "РЕШЕНИЕ (РАБОЧЕЕ)",
    ["1. Генерим банку на ЗЕЛЁНОМ фоне",
     "2. Photoshop → удалить фон → PNG",
     "3. PNG = brand-asset на SKU (неизменяем)",
     "4. GPT генерит ТОЛЬКО фон без банки",
     "5. Композит PNG в фон вручную в PS",
     "→ единственный стабильный pipeline"],
    P["process"], w=420)

# 6. Что сделать в нашем инструменте (bottom-right)
n6 = node(d, W-300, H-260, "ЧТО ВСТРАИВАЕМ В MVP",
    ["c_brand_jars: PNG банки на SKU",
     "генератор фонов через Nano Banana",
     "auto-composite PNG в фон (Sharp/PIL)",
     "remove.bg API для авто-вырезания",
     "пресеты палитры по категории",
     "валидатор запретных слов"],
    P["next"], w=400)

# connect center to all
cx, cy = center
for box in (n1, n2, n3, n4, n5, n6):
    bx = (box[0]+box[2])//2
    by = (box[1]+box[3])//2
    line(d, (cx,cy), (bx,by))

# Footer status
d.text((40, H-58), "Статус:", font=font(15, True), fill=INK)
d.text((110, H-58), "✅ изучили папку  ✅ звонок (13:52) транскрибирован  ✅ чат GPT (136 сообщ.) распарсен  → готовы к схеме БД", font=font(15), fill=(180,200,180))

img.save(OUT, "PNG")
print(OUT)
