import sys, time, json, pathlib
from faster_whisper import WhisperModel

AUDIO = r"C:\Claude\Work\cards\call_audio.wav"
OUT_TXT = r"C:\Claude\Work\cards\call_transcript.txt"
OUT_JSON = r"C:\Claude\Work\cards\call_transcript.json"

print("loading model medium...", flush=True)
t0 = time.time()
model = WhisperModel("medium", device="cpu", compute_type="int8")
print(f"model ready in {time.time()-t0:.1f}s", flush=True)

t0 = time.time()
segments, info = model.transcribe(
    AUDIO,
    language="ru",
    vad_filter=True,
    beam_size=1,
)
print(f"detected language: {info.language} (p={info.language_probability:.2f}), duration={info.duration:.1f}s", flush=True)

txt_lines = []
json_segs = []
for seg in segments:
    line = f"[{seg.start:7.1f} -> {seg.end:7.1f}] {seg.text.strip()}"
    print(line, flush=True)
    txt_lines.append(line)
    json_segs.append({"start": seg.start, "end": seg.end, "text": seg.text.strip()})

pathlib.Path(OUT_TXT).write_text("\n".join(txt_lines), encoding="utf-8")
pathlib.Path(OUT_JSON).write_text(json.dumps(json_segs, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"\ntranscription done in {time.time()-t0:.1f}s", flush=True)
print(f"saved: {OUT_TXT}", flush=True)
