"""
Тест #19: главное — заголовок выше (Y=80-150 в raw), как у Игоря.
+ уточняю иконку для альфа-липоевой (выраженная молекула с связями).
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test19_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test19_final.png")

PROMPT = """The attached image is slide 1 of a product card series. Generate slide 2 of the SAME series.

=== BRAND CANVAS (must match slide 1 — same brain background, same title style/case/position, blue family palette only, no yellow/gold/orange, hexagonal glass-morphism icons) ===

CRITICAL: the TITLE must be in the EXACT SAME POSITION as on slide 1. Look at slide 1: title "Бенфотиамин" sits with a small top margin (~80px from top edge). On slide 2 we use same X, same Y, same size. Just the text is "БЕНФОТИАМИН" UPPERCASE.

=== LAYOUT MAP for the 1024×1536 canvas ===

  Y=0    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Y=0..80    EMPTY blue background (small top margin, like on slide 1)
  Y=80..160   "БЕНФОТИАМИН" UPPERCASE title (large bold dark navy)
  Y=170..220   "СОСТАВ И ДОЗИРОВКА" subtitle (smaller, blue)
  Y=230..235   solid blue divider line (~80px wide, 4px tall)
  Y=245..275   "В 1 КАПСУЛЕ" tiny grey caption
  Y=320..420   row 1: [shield] БЕНФОТИАМИН .... 350 мг
  Y=440..540   row 2: [molecule] АЛЬФА-ЛИПОЕВАЯ КИСЛОТА .... 100 мг
  Y=560..660   row 3: [leaf] БЕРБЕРИН .... 20 мг
  Y=680..780   row 4: [Mg-ring] МАГНИЙ ГЛИЦИНАТ .... 100 мг
  Y=800..900   row 5: [brain] АЦЕТИЛ-L-КАРНИТИН .... 100 мг
  Y=1020..1140   bottom 3 plates: [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО
  Y=1140..1536   EMPTY blue background (bottom margin — DO NOT place anything below Y=1140)
  Y=1536 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Each ingredient row layout: [hex icon, ~80px tall] [name CAPS, navy bold] ........ [dose: large number + small "мг" RIGHT of it on the SAME baseline].

Icons (specific shapes):
   1. БЕНФОТИАМИН — shield outline (geometric shield silhouette)
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — chemical molecule outline: 3 atoms in a triangular arrangement, connected by visible bonds (like a benzene-ring or hexagonal molecular structure). Make sure it looks scientifically like a molecule, NOT a star.
   3. БЕРБЕРИН — leaf outline (single leaf silhouette)
   4. МАГНИЙ ГЛИЦИНАТ — "Mg" lettermark inside a thin ring (the letters "Mg" clearly readable)
   5. АЦЕТИЛ-L-КАРНИТИН — brain outline (top-down brain silhouette)

Each bottom plate: [icon] + 2-line text. Light-blue or light-gray separators between plates. NO yellow/gold.

=== FORBIDDEN ===
- NO product jar, NO pedestal, NO shadow ring.
- NO horizontal light streaks between rows.
- NO yellow/gold/orange anywhere.
- NO medical claims.
- NO garbled / pseudo Cyrillic.

Portrait, premium calm cognitive-tech mood.
"""

print("test #19: title at Y=80, better molecule icon...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
img_cropped = img.crop((0, 0, img.width, img.height - 171))
img_cropped.resize((1080, 1440), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"saved: {OUT_FINAL}")
