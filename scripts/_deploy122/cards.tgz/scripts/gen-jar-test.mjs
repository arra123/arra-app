import 'dotenv/config';
import OpenAI from 'openai';
import fs from 'node:fs';
import path from 'node:path';

const client = new OpenAI({
  apiKey: process.env.PROXYAPI_KEY,
  baseURL: process.env.PROXYAPI_BASE_URL,
});

const prompt = `Photorealistic 3D render of a premium dietary supplement jar.

Bottle shape: short cylindrical plastic jar with a wide white screw cap on top, slightly rounded shoulders, smooth matte white plastic body. The bottle is the same proportional shape as a typical 60-capsule supplement bottle.

Label design (covers most of the front of the bottle):
- Top center: brand mark — a geometric diamond outline with a stylized letter "G" inside, in deep navy blue with thin gold accents
- Below brand mark: word "GRAFLAB" in bold sans-serif, deep navy blue
- Center of label: large elegant title "RESVERA COMPLEX" in dark navy
- Below title: a thin gold horizontal divider line
- Below divider: small caption "DIETARY SUPPLEMENT" in spaced-out letters
- Bottom of label: three small round gold-rimmed seals/badges, evenly spaced horizontally
- A handwritten cursive script "Будь здоров!" in dark blue ink, top right corner of the label

Camera: front-facing, eye level, full bottle visible, centered in frame, perfectly vertical, no perspective distortion.

Lighting: soft studio lighting, gentle reflections on the white plastic, no harsh shadows.

Background: solid flat chroma green color (RGB 0, 177, 64), absolutely uniform, no gradient, no shadow on the background, clean for chroma key removal.

The label should be perfectly readable. Text must be in proper Latin/Cyrillic letters, not gibberish.`;

console.log('генерим банку (1024x1536, medium)...');
const t0 = Date.now();

const result = await client.images.generate({
  model: 'gpt-image-2',
  prompt,
  size: '1024x1536',
  quality: 'medium',
  n: 1,
});

const dt = ((Date.now() - t0) / 1000).toFixed(1);
console.log(`готово за ${dt}s`);

const item = result.data[0];
const outDir = path.resolve('output');
fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, 'jar_v1.png');

if (item.b64_json) {
  fs.writeFileSync(outPath, Buffer.from(item.b64_json, 'base64'));
} else if (item.url) {
  const resp = await fetch(item.url);
  fs.writeFileSync(outPath, Buffer.from(await resp.arrayBuffer()));
}

console.log(`сохранено: ${outPath}`);
console.log(`usage:`, result.usage ?? '(нет в ответе)');
