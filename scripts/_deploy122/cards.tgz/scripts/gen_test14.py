"""
Тест #14: убираю top-crop в 0. Crop только снизу 171px.
Это сохраняет верхний воздух → заголовок не прижат к границе.
+ просим модель не ставить фоновые streaks между рядами.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test14_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test14_final.png")

PROMPT = """The attached image is slide 1 of a product card. Create slide 2 of the same card — "Состав и дозировка".

CRITICAL CONSISTENCY RULES (must match slide 1):
- Title position: same X (left margin) and same Y (~120-160px from the top edge — NOT touching the top, generous breathing room above) as on slide 1.
- Title size, font, color: same dark navy bold sans-serif as on slide 1.
- Title text: "БЕНФОТИАМИН" — ALL UPPERCASE.
- Color palette: blue family only (navy, royal, cyan, light cyan, white). NO yellow, NO gold, NO orange.

Header layout below the title (top-left, vertically stacked):

  ┌─────────────────────
  │  "БЕНФОТИАМИН"               ← title in UPPERCASE
  │  "СОСТАВ И ДОЗИРОВКА"        ← subtitle, smaller, blue
  │  ────                         ← short solid blue divider, ~80px wide, 3-4px tall, NO gradient, NO gold
  │  "В 1 КАПСУЛЕ"               ← small grey caption, BELOW the line, left-aligned
  └─────────────────────

5 ingredient ROWS, each is a horizontal glass-morphism plate (rounded corners, hexagonal icon on the left). Layout per row: [hex icon] [INGREDIENT NAME, dark navy bold caps] [DOSE: number large bold + "мг" smaller, both on the SAME LINE, "мг" RIGHT of the number].

NO horizontal light streaks or background light sweeps running BETWEEN the rows. The rows sit on a clean uniform blue background (with the brain neural network in the upper-right corner only as decorative element). Avoid any dotted/dashed lines or decorative streaks separating the rows.

Icons:
   1. БЕНФОТИАМИН — 350 мг — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — molecule outline
   3. БЕРБЕРИН — 20 мг — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — brain outline

Bottom row: 3 small horizontal plates side by side (NOT round medallions).
Plates: [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО.
Separators between plates: thin LIGHT-BLUE or LIGHT-GRAY lines. ABSOLUTELY NO YELLOW/GOLD anywhere.

CRITICAL SAFE MARGINS:
- AT LEAST 130 px clear background ABOVE the title — the title must visually breathe, not touch the top.
- AT LEAST 100 px clear background BELOW the bottom badges.
- AT LEAST 60 px clear margin on left and right.

HARD RULES:
- NO product jar, NO pedestal, NO platform, NO disc, NO shadow ring.
- "мг" RIGHT of the number, SAME baseline.
- Real Cyrillic only.
- Title position must MATCH slide 1's title position (same Y from top).
- Portrait orientation, premium calm tech mood.
"""

print("test #14: top crop = 0, bottom crop = 171, more breathing room above title...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))

# КРИТИЧЕСКОЕ: top_crop = 0, bottom_crop = 171 (вместо 85+86 симметричного)
img = Image.open(OUT_RAW)
top_crop = 0
bottom_crop = 171
img_cropped = img.crop((0, top_crop, img.width, img.height - bottom_crop))
print(f"crop: top={top_crop}, bottom={bottom_crop}, result={img_cropped.size}")
assert img_cropped.size == (1024, 1365), f"unexpected {img_cropped.size}"
img_cropped.resize((1080, 1440), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"saved: {OUT_FINAL}")
