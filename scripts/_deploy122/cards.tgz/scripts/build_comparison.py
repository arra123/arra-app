import sys, io, json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule, CellIsRule

SRC = '1777032414137-30701843 (1).xlsx'
OUT = 'output/Сравнение_цен_утилизация.xlsx'
PRICES_JSON = 'output/ozon_prices_raw.json'

# ---- load data ----
returns = pd.read_excel(SRC, sheet_name=0, header=5)
returns = returns[['Артикул товара', 'Наименование товара', 'OZON SKU ID',
                   'Стоимость товара', 'Статус возврата', 'Количество возвращаемых товаров',
                   'Дата оформления заказа']].copy()
returns.columns = ['offer_id', 'name', 'sku', 'old_price', 'status', 'qty', 'order_date']
returns['old_price'] = pd.to_numeric(returns['old_price'], errors='coerce')
returns['qty'] = pd.to_numeric(returns['qty'], errors='coerce').fillna(1).astype(int)

with open(PRICES_JSON, encoding='utf-8') as f:
    prices_data = json.load(f)
prices = pd.DataFrame(prices_data)

# ---- build current price lookup by offer_id ----
# one offer_id can appear only once, but guard against duplicates between sellers
prices_lookup = prices.drop_duplicates(subset=['offer_id'], keep='first').set_index('offer_id')

def get_current(offer_id):
    if offer_id in prices_lookup.index:
        row = prices_lookup.loc[offer_id]
        return row['price'], row['old_price'], row['seller']
    return None, None, None

returns[['current_price', 'crossed_out_price', 'seller_cabinet']] = returns['offer_id'].apply(
    lambda o: pd.Series(get_current(o))
)
returns['current_price'] = pd.to_numeric(returns['current_price'], errors='coerce')
returns['delta'] = returns['current_price'] - returns['old_price']
returns['delta_pct'] = returns.apply(
    lambda r: (r['delta'] / r['old_price']) if pd.notna(r['delta']) and pd.notna(r['old_price']) and r['old_price'] else None,
    axis=1
)

# summary numbers
total_old = float(returns['old_price'].sum())
total_new = float(returns['current_price'].sum(skipna=True))
matched = int(returns['current_price'].notna().sum())
unmatched = int(returns['current_price'].isna().sum())
unique_articles = returns['offer_id'].nunique()
util_count = len(returns)  # все 396 утилизированы

# ---- unique articles summary ----
by_sku = returns.groupby(['offer_id', 'name'], dropna=False).agg(
    qty=('offer_id', 'count'),
    sold_price_min=('old_price', 'min'),
    sold_price_max=('old_price', 'max'),
    sold_price_avg=('old_price', 'mean'),
    current_price=('current_price', 'first'),
    total_old=('old_price', 'sum'),
    seller=('seller_cabinet', 'first'),
).reset_index()
by_sku['total_new'] = by_sku['current_price'] * by_sku['qty']
by_sku['delta_per_unit'] = by_sku['current_price'] - by_sku['sold_price_avg']
by_sku['delta_pct'] = by_sku.apply(
    lambda r: (r['delta_per_unit'] / r['sold_price_avg']) if pd.notna(r['delta_per_unit']) and pd.notna(r['sold_price_avg']) and r['sold_price_avg'] else None,
    axis=1
)
by_sku = by_sku.sort_values('total_new', ascending=False, na_position='last').reset_index(drop=True)

# ---- missing (in returns but not in API) ----
missing = by_sku[by_sku['current_price'].isna()][['offer_id', 'name', 'qty', 'sold_price_avg']].reset_index(drop=True)

# ============== Build workbook ==============
wb = Workbook()

FONT = 'Calibri'
THIN = Side(border_style='thin', color='D0D0D0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
HEADER_FILL = PatternFill('solid', start_color='2C5F2E')
HEADER_FONT = Font(name=FONT, bold=True, color='FFFFFF', size=11)
TITLE_FONT = Font(name=FONT, bold=True, size=16, color='1A1A1A')
SUBTITLE_FONT = Font(name=FONT, italic=True, size=10, color='666666')
ZEBRA_FILL = PatternFill('solid', start_color='F7F7F5')
TOTAL_FILL = PatternFill('solid', start_color='E5602A')
TOTAL_FONT = Font(name=FONT, bold=True, color='FFFFFF', size=11)


def style_header(row, sheet, ncols):
    for c in range(1, ncols + 1):
        cell = sheet.cell(row=row, column=c)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.border = BORDER
    sheet.row_dimensions[row].height = 36


def style_body(sheet, first_row, last_row, ncols, money_cols=(), pct_cols=(), int_cols=(), center_cols=()):
    for r in range(first_row, last_row + 1):
        fill = ZEBRA_FILL if (r - first_row) % 2 == 1 else None
        for c in range(1, ncols + 1):
            cell = sheet.cell(row=r, column=c)
            cell.font = Font(name=FONT, size=11)
            cell.border = BORDER
            if fill:
                cell.fill = fill
            if c in money_cols:
                cell.number_format = '# ##0 ₽;[Red]-# ##0 ₽;-'
                cell.alignment = Alignment(horizontal='right', vertical='center')
            elif c in pct_cols:
                cell.number_format = '+0.0%;[Red]-0.0%;-'
                cell.alignment = Alignment(horizontal='right', vertical='center')
            elif c in int_cols:
                cell.number_format = '# ##0'
                cell.alignment = Alignment(horizontal='center', vertical='center')
            elif c in center_cols:
                cell.alignment = Alignment(horizontal='center', vertical='center')
            else:
                cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)


def set_widths(sheet, widths):
    for i, w in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(i)].width = w

# ============================
# Sheet 1: Сводка
# ============================
ws = wb.active
ws.title = 'Сводка'

ws['A1'] = 'Утилизация на OZON — стоимость по старым и новым ценам'
ws['A1'].font = TITLE_FONT
ws.merge_cells('A1:D1')

ws['A2'] = f'Отчёт возвратов OZON от 24.04.2026  ·  {util_count} позиций утилизировано  ·  {unique_articles} уникальных артикулов  ·  2 кабинета продавца'
ws['A2'].font = SUBTITLE_FONT
ws.merge_cells('A2:D2')

ws['A4'] = 'Показатель'
ws['B4'] = 'Значение'
style_header(4, ws, 2)

delta_abs = total_new - total_old
delta_pct = (delta_abs / total_old) if total_old else 0

kpi_rows = [
    ('Утилизировано позиций',                    util_count,                                 '# ##0'),
    ('Уникальных артикулов',                     unique_articles,                            '# ##0'),
    ('Сопоставлено с каталогом OZON',             f'{matched} из {util_count}',              '@'),
    ('Не найдено в каталоге',                    unmatched,                                  '# ##0'),
    ('', '', ''),
    ('Сумма по СТАРЫМ ценам (из отчёта)',        total_old,                                  '# ##0 ₽'),
    ('Сумма по ТЕКУЩИМ ценам (из OZON)',         total_new,                                  '# ##0 ₽'),
    ('Изменение (₽)',                            delta_abs,                                  '+# ##0 ₽;[Red]-# ##0 ₽'),
    ('Изменение (%)',                            delta_pct,                                  '+0.0%;[Red]-0.0%'),
]
start_row = 5
for i, (label, val, fmt) in enumerate(kpi_rows):
    r = start_row + i
    if label == '':
        ws.row_dimensions[r].height = 8
        continue
    a = ws.cell(row=r, column=1, value=label)
    a.font = Font(name=FONT, size=11)
    a.border = BORDER
    a.alignment = Alignment(horizontal='left', vertical='center')
    c = ws.cell(row=r, column=2, value=val)
    bold = label.startswith(('Сумма', 'Изменение'))
    c.font = Font(name=FONT, size=11, bold=bold)
    if fmt != '@':
        c.number_format = fmt
    c.alignment = Alignment(horizontal='right', vertical='center')
    c.border = BORDER
    if i % 2 == 1:
        a.fill = ZEBRA_FILL
        c.fill = ZEBRA_FILL
    if label.startswith('Сумма по ТЕКУЩИМ'):
        c.fill = PatternFill('solid', start_color='E8F5E8')
        c.font = Font(name=FONT, size=13, bold=True, color='2C5F2E')
    ws.row_dimensions[r].height = 22

# Legend
leg_start = start_row + len(kpi_rows) + 2
ws.cell(row=leg_start, column=1, value='Что в этом файле').font = Font(name=FONT, bold=True, size=12)
legend = [
    ('Сводка',               'ключевые цифры — сколько стоила утилизация раньше и сейчас'),
    ('Цены по артикулам',    '117 уникальных артикулов: старая цена продажи → новая, Δ, Δ%'),
    ('Полный список',        'все 396 строк возвратов — старая цена, новая, разница'),
    ('Не найдено',           'артикулы из отчёта, которых нет в каталоге OZON (проверить руками)'),
    ('Весь каталог OZON',    'все 303 товара из обоих кабинетов — цена, старая цена, кабинет'),
]
ws.cell(row=leg_start + 1, column=1, value='Лист').font = HEADER_FONT
ws.cell(row=leg_start + 1, column=2, value='Что внутри').font = HEADER_FONT
style_header(leg_start + 1, ws, 2)
for i, (name, desc) in enumerate(legend):
    r = leg_start + 2 + i
    a = ws.cell(row=r, column=1, value=name)
    a.font = Font(name=FONT, size=11, bold=True)
    a.border = BORDER
    a.alignment = Alignment(horizontal='left', vertical='center')
    b = ws.cell(row=r, column=2, value=desc)
    b.font = Font(name=FONT, size=11)
    b.border = BORDER
    b.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
    if i % 2 == 1:
        a.fill = ZEBRA_FILL
        b.fill = ZEBRA_FILL
    ws.row_dimensions[r].height = 22

set_widths(ws, [44, 26])
ws.sheet_view.showGridLines = False

# ============================
# Sheet 2: Цены по артикулам
# ============================
ws2 = wb.create_sheet('Цены по артикулам')
ws2['A1'] = 'Изменение цен по уникальным артикулам'
ws2['A1'].font = TITLE_FONT
ws2.merge_cells('A1:J1')
ws2['A2'] = 'Старая цена = средняя цена продажи из отчёта возвратов. Новая цена = актуальная из OZON API.'
ws2['A2'].font = SUBTITLE_FONT
ws2.merge_cells('A2:J2')

headers = ['Артикул', 'Наименование', 'Кабинет', 'Кол-во утил.',
           'Старая цена (ср.)', 'Новая цена',
           'Δ за шт.', 'Δ %',
           'Сумма ст.', 'Сумма нов.']
for i, h in enumerate(headers, 1):
    ws2.cell(row=4, column=i, value=h)
style_header(4, ws2, 10)

for i, row in by_sku.iterrows():
    r = 5 + i
    ws2.cell(row=r, column=1, value=row['offer_id'])
    ws2.cell(row=r, column=2, value=row['name'])
    ws2.cell(row=r, column=3, value=row['seller'] if pd.notna(row['seller']) else 'НЕ НАЙДЕНО')
    ws2.cell(row=r, column=4, value=int(row['qty']))
    ws2.cell(row=r, column=5, value=float(row['sold_price_avg']) if pd.notna(row['sold_price_avg']) else None)
    ws2.cell(row=r, column=6, value=float(row['current_price']) if pd.notna(row['current_price']) else None)
    ws2.cell(row=r, column=7, value=float(row['delta_per_unit']) if pd.notna(row['delta_per_unit']) else None)
    ws2.cell(row=r, column=8, value=float(row['delta_pct']) if pd.notna(row['delta_pct']) else None)
    ws2.cell(row=r, column=9, value=float(row['total_old']) if pd.notna(row['total_old']) else None)
    ws2.cell(row=r, column=10, value=float(row['total_new']) if pd.notna(row['total_new']) else None)

last_row = 4 + len(by_sku)
style_body(ws2, 5, last_row, 10,
           money_cols=(5, 6, 7, 9, 10),
           pct_cols=(8,),
           int_cols=(4,),
           center_cols=(1, 3))

# Totals row
total_row = last_row + 1
ws2.cell(row=total_row, column=1, value='ИТОГО').font = TOTAL_FONT
ws2.cell(row=total_row, column=2, value=f'{len(by_sku)} артикулов').font = TOTAL_FONT
ws2.cell(row=total_row, column=4, value=f'=SUM(D5:D{last_row})').font = TOTAL_FONT
ws2.cell(row=total_row, column=9, value=f'=SUM(I5:I{last_row})').font = TOTAL_FONT
ws2.cell(row=total_row, column=10, value=f'=SUM(J5:J{last_row})').font = TOTAL_FONT
for c in range(1, 11):
    cell = ws2.cell(row=total_row, column=c)
    cell.fill = TOTAL_FILL
    cell.border = BORDER
    if c == 1:
        cell.alignment = Alignment(horizontal='center', vertical='center')
    elif c == 4:
        cell.number_format = '# ##0'
        cell.alignment = Alignment(horizontal='center', vertical='center')
    elif c in (9, 10):
        cell.number_format = '# ##0 ₽'
        cell.alignment = Alignment(horizontal='right', vertical='center')
    else:
        cell.alignment = Alignment(horizontal='left', vertical='center')
ws2.row_dimensions[total_row].height = 26

# Conditional formatting on delta %
pct_range = f'H5:H{last_row}'
ws2.conditional_formatting.add(
    pct_range,
    CellIsRule(operator='greaterThan', formula=['0'], fill=PatternFill('solid', start_color='E8F5E8'))
)
ws2.conditional_formatting.add(
    pct_range,
    CellIsRule(operator='lessThan', formula=['0'], fill=PatternFill('solid', start_color='FCE7E7'))
)

set_widths(ws2, [14, 60, 18, 12, 14, 14, 12, 10, 14, 14])
ws2.freeze_panes = 'A5'
ws2.sheet_view.showGridLines = False
ws2.auto_filter.ref = f'A4:J{last_row}'

# ============================
# Sheet 3: Полный список
# ============================
ws3 = wb.create_sheet('Полный список')
ws3['A1'] = 'Все утилизированные позиции с текущими ценами'
ws3['A1'].font = TITLE_FONT
ws3.merge_cells('A1:I1')
ws3['A2'] = f'{len(returns)} строк — по одной на каждый возврат'
ws3['A2'].font = SUBTITLE_FONT
ws3.merge_cells('A2:I2')

headers = ['Артикул', 'Наименование', 'SKU OZON', 'Статус',
           'Старая цена (продажа)', 'Новая цена (OZON)',
           'Δ', 'Δ %', 'Дата заказа']
for i, h in enumerate(headers, 1):
    ws3.cell(row=4, column=i, value=h)
style_header(4, ws3, 9)

full_sorted = returns.sort_values('order_date', ascending=False).reset_index(drop=True)
for i, row in full_sorted.iterrows():
    r = 5 + i
    ws3.cell(row=r, column=1, value=row['offer_id'])
    ws3.cell(row=r, column=2, value=row['name'])
    ws3.cell(row=r, column=3, value=str(row['sku']) if pd.notna(row['sku']) else '')
    ws3.cell(row=r, column=4, value=row['status'])
    ws3.cell(row=r, column=5, value=float(row['old_price']) if pd.notna(row['old_price']) else None)
    ws3.cell(row=r, column=6, value=float(row['current_price']) if pd.notna(row['current_price']) else None)
    ws3.cell(row=r, column=7, value=float(row['delta']) if pd.notna(row['delta']) else None)
    ws3.cell(row=r, column=8, value=float(row['delta_pct']) if pd.notna(row['delta_pct']) else None)
    d = row['order_date']
    if pd.notna(d):
        cell = ws3.cell(row=r, column=9, value=d)
        cell.number_format = 'DD.MM.YYYY'

last_row = 4 + len(full_sorted)
style_body(ws3, 5, last_row, 9,
           money_cols=(5, 6, 7),
           pct_cols=(8,),
           center_cols=(1, 3, 4, 9))

# Totals
total_row = last_row + 1
ws3.cell(row=total_row, column=1, value='ИТОГО').font = TOTAL_FONT
ws3.cell(row=total_row, column=2, value=f'{len(returns)} позиций').font = TOTAL_FONT
ws3.cell(row=total_row, column=5, value=f'=SUM(E5:E{last_row})').font = TOTAL_FONT
ws3.cell(row=total_row, column=6, value=f'=SUM(F5:F{last_row})').font = TOTAL_FONT
ws3.cell(row=total_row, column=7, value=f'=SUM(G5:G{last_row})').font = TOTAL_FONT
for c in range(1, 10):
    cell = ws3.cell(row=total_row, column=c)
    cell.fill = TOTAL_FILL
    cell.border = BORDER
    if c == 1:
        cell.alignment = Alignment(horizontal='center', vertical='center')
    elif c in (5, 6, 7):
        cell.number_format = '# ##0 ₽'
        cell.alignment = Alignment(horizontal='right', vertical='center')
    else:
        cell.alignment = Alignment(horizontal='left', vertical='center')
ws3.row_dimensions[total_row].height = 26

# Conditional formatting on delta
delta_range = f'G5:G{last_row}'
ws3.conditional_formatting.add(
    delta_range,
    CellIsRule(operator='greaterThan', formula=['0'], fill=PatternFill('solid', start_color='E8F5E8'))
)
ws3.conditional_formatting.add(
    delta_range,
    CellIsRule(operator='lessThan', formula=['0'], fill=PatternFill('solid', start_color='FCE7E7'))
)

set_widths(ws3, [14, 60, 14, 16, 14, 14, 12, 10, 14])
ws3.freeze_panes = 'A5'
ws3.sheet_view.showGridLines = False
ws3.auto_filter.ref = f'A4:I{last_row}'

# ============================
# Sheet 4: Не найдено
# ============================
ws4 = wb.create_sheet('Не найдено')
ws4['A1'] = 'Артикулы из отчёта, отсутствующие в каталоге OZON'
ws4['A1'].font = TITLE_FONT
ws4.merge_cells('A1:D1')
ws4['A2'] = 'Возможные причины: артикул снят с продажи, передан другому кабинету, или изменён offer_id'
ws4['A2'].font = SUBTITLE_FONT
ws4.merge_cells('A2:D2')

headers = ['Артикул', 'Наименование', 'Кол-во утил.', 'Старая цена (ср.)']
for i, h in enumerate(headers, 1):
    ws4.cell(row=4, column=i, value=h)
style_header(4, ws4, 4)

for i, row in missing.iterrows():
    r = 5 + i
    ws4.cell(row=r, column=1, value=row['offer_id'])
    ws4.cell(row=r, column=2, value=row['name'])
    ws4.cell(row=r, column=3, value=int(row['qty']))
    ws4.cell(row=r, column=4, value=float(row['sold_price_avg']) if pd.notna(row['sold_price_avg']) else None)

last_row = 4 + len(missing) if len(missing) else 5
if len(missing) == 0:
    ws4.cell(row=5, column=1, value='Все артикулы из отчёта найдены в каталоге ✓').font = Font(name=FONT, italic=True, color='2C5F2E')
    ws4.merge_cells('A5:D5')
else:
    style_body(ws4, 5, last_row, 4, money_cols=(4,), int_cols=(3,), center_cols=(1,))

set_widths(ws4, [14, 70, 14, 16])
ws4.freeze_panes = 'A5'
ws4.sheet_view.showGridLines = False

# ============================
# Sheet 5: Весь каталог OZON
# ============================
ws5 = wb.create_sheet('Весь каталог OZON')
ws5['A1'] = 'Весь каталог товаров обоих кабинетов'
ws5['A1'].font = TITLE_FONT
ws5.merge_cells('A1:F1')
ws5['A2'] = f'{len(prices)} товаров, актуальные цены OZON на 24.04.2026'
ws5['A2'].font = SUBTITLE_FONT
ws5.merge_cells('A2:F2')

headers = ['Кабинет', 'Артикул (offer_id)', 'Product ID',
           'Текущая цена', 'Старая (зачёркн.)', 'Цена после акций']
for i, h in enumerate(headers, 1):
    ws5.cell(row=4, column=i, value=h)
style_header(4, ws5, 6)

prices_sorted = prices.sort_values(['seller', 'offer_id']).reset_index(drop=True)
for i, row in prices_sorted.iterrows():
    r = 5 + i
    ws5.cell(row=r, column=1, value=row['seller'])
    ws5.cell(row=r, column=2, value=row['offer_id'])
    ws5.cell(row=r, column=3, value=row['product_id'])
    ws5.cell(row=r, column=4, value=float(row['price']) if pd.notna(row['price']) else None)
    ws5.cell(row=r, column=5, value=float(row['old_price']) if pd.notna(row['old_price']) else None)
    ws5.cell(row=r, column=6, value=float(row['marketing_price']) if pd.notna(row['marketing_price']) else None)

last_row = 4 + len(prices_sorted)
style_body(ws5, 5, last_row, 6, money_cols=(4, 5, 6), center_cols=(1, 2, 3))

set_widths(ws5, [22, 16, 14, 14, 16, 16])
ws5.freeze_panes = 'A5'
ws5.sheet_view.showGridLines = False
ws5.auto_filter.ref = f'A4:F{last_row}'

wb.save(OUT)
print('Saved:', OUT)
print(f'\nSummary:')
print(f'  Утилизировано: {util_count}')
print(f'  Уникальных артикулов: {unique_articles}')
print(f'  Сопоставлено с каталогом: {matched}')
print(f'  Не найдено: {unmatched}')
print(f'  Сумма по СТАРЫМ ценам: {total_old:,.2f} ₽'.replace(',', ' '))
print(f'  Сумма по ТЕКУЩИМ ценам: {total_new:,.2f} ₽'.replace(',', ' '))
print(f'  Δ: {(total_new - total_old):+,.2f} ₽ ({(total_new - total_old) / total_old * 100:+.1f}%)'.replace(',', ' '))
