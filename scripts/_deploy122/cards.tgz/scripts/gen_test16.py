"""
Тест #16: финальный шаблонный промпт.
Двухслойный: BRAND CANVAS (повторяется) + SLIDE CONTENT (свой).
Компактно, без перечисления каждого правила по 5 раз.
"""
import os, time, base64, pathlib
from openai import OpenAI
from PIL import Image
from dotenv import load_dotenv

load_dotenv(r"C:\Claude\Work\cards\.env")
client = OpenAI(
    api_key=os.environ["PROXYAPI_KEY"],
    base_url=os.environ["PROXYAPI_BASE_URL"],
)

REF = pathlib.Path(r"C:\Claude\Work\cards\карточки\бенфо новый лучшая\бенфо новый1.png")
OUT_RAW = pathlib.Path(r"C:\Claude\Work\cards\output\test16_raw.png")
OUT_FINAL = pathlib.Path(r"C:\Claude\Work\cards\output\test16_final.png")

PROMPT = """The attached image is slide 1 of a product card series. Generate slide 2 of the SAME series.

=== BRAND CANVAS (must match slide 1 exactly — these are the brand anchors of the whole 6-slide series) ===
- Background: identical light-cyan blue gradient with the same brain neural network silhouette in the SAME position, SAME size, SAME opacity as on slide 1. The brain is the brand anchor — never shrink, never move, never change.
- Title "БЕНФОТИАМИН" (UPPERCASE): identical Y position, X position, font, weight, size and dark navy color as on slide 1. Generous margin above the title (~150px from the top edge), like on slide 1.
- Color palette: strictly blue family (navy / royal / cyan / light cyan / white). NO yellow, NO gold, NO orange.
- Decorative divider under any header subtitle: simple solid blue line, ~80px wide, 3-4px tall — same style as slide 1.
- Hexagonal glass-morphism icon plates: same shape, same edge style as on slide 1.

=== SLIDE-2-SPECIFIC CONTENT ===
Header (top-left, below the title):
- Subtitle "СОСТАВ И ДОЗИРОВКА" (smaller, blue)
- Solid blue divider line (see brand canvas rules)
- Tiny grey caption "В 1 КАПСУЛЕ"

Body — 5 ingredient rows in horizontal glass-morphism plates. Each row: [hex icon] [name CAPS, navy bold] [dose: number large bold + "мг" small RIGHT of the number, same baseline].
Rows:
   1. БЕНФОТИАМИН — 350 мг — shield outline
   2. АЛЬФА-ЛИПОЕВАЯ КИСЛОТА — 100 мг — molecule outline
   3. БЕРБЕРИН — 20 мг — leaf outline
   4. МАГНИЙ ГЛИЦИНАТ — 100 мг — "Mg" lettermark in thin ring
   5. АЦЕТИЛ-L-КАРНИТИН — 100 мг — brain outline

Bottom — 3 small horizontal plates (NOT round medallions): [star] ОТБОРНЫЕ ИНГРЕДИЕНТЫ | [capsule] 60 КАПСУЛ | [crown] ПРЕМИАЛЬНОЕ КАЧЕСТВО. Stay within the visible area, do not touch the bottom edge (leave ~150px margin below).

=== FORBIDDEN ===
- NO product jar, NO pedestal, NO platform, NO disc, NO shadow ring on this slide.
- NO horizontal light streaks running between the rows.
- NO yellow / gold / orange anywhere.
- NO medical claims (no "лечит", "против болезни", диагнозы).
- NO garbled / pseudo Cyrillic letters — every word must read correctly.

Portrait, premium calm cognitive-tech mood.
"""

print("test #16: two-layer prompt (brand canvas + slide content)...")
t0 = time.time()
with open(REF, "rb") as f:
    result = client.images.edit(
        model="gpt-image-2",
        image=f,
        prompt=PROMPT,
        size="1024x1536",
        quality="medium",
        n=1,
    )
print(f"done in {time.time()-t0:.1f}s")
print(f"usage: {result.usage}")

OUT_RAW.write_bytes(base64.b64decode(result.data[0].b64_json))
img = Image.open(OUT_RAW)
img_cropped = img.crop((0, 85, img.width, img.height - 86))
img_cropped.resize((1080, 1440), Image.LANCZOS).save(OUT_FINAL, "PNG")
print(f"saved: {OUT_FINAL}")
