// Сканирует карточки/ + output/, определяет: товар (по папке), номер слайда (по имени),
// тип (card/jar/reference), доминантный цвет (sharp), категорию палитры по hue.
// Записывает в c_library_assets.
import 'dotenv/config';
import pg from 'pg';
import sharp from 'sharp';
import { readdir, stat, readFile } from 'node:fs/promises';
import { join, extname, basename, dirname } from 'node:path';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();
await c.query(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));

// === МАППИНГИ ===
// нормализация имени папки → product_code и palette_cat
const FOLDER_MAP = [
  { match: /^аста/i,                product: 'asta',         palette: 'energy',    note: 'astaxanthin · энергия' },
  { match: /^nmn/i,                 product: 'nmn',          palette: 'longevity', note: 'NMN · longevity' },
  { match: /^бенфо/i,               product: 'benfo',        palette: 'cognitive', note: 'бенфотиамин · cognitive' },
  { match: /(любмро|люмбро|lumbro)/i, product: 'lumbro',      palette: 'cardio',    note: 'lumbro-natto-serra · cardio' },
  { match: /^псиллиум/i,            product: 'psyllium',     palette: 'digestive', note: 'псиллиум · пищеварение' },
  { match: /^(ресвератрол|ресветарол)/i, product: 'resveratrol', palette: 'longevity', note: 'ресвератрол · longevity' },
  { match: /^серрапептаза/i,        product: 'serrapeptase', palette: 'cardio',    note: 'серрапептаза · сосуды' },
  { match: /^референс/i,            product: null,           palette: null,        note: 'референсы конкурентов', type: 'reference' },
  { match: /^(сейф|старое|новая)/i, product: null,           palette: null,        note: 'архив',                  type: 'archive' },
  { match: /^для промта/i,          product: null,           palette: null,        note: 'материалы для промптов', type: 'reference' },
  { match: /^wb_/i,                  product: null,           palette: null,        note: 'спарсено с Wildberries (см _meta.json)' },
];

// определяем тип файла
function inferType(filename, folderInfo) {
  if (folderInfo?.type) return folderInfo.type;
  const lower = filename.toLowerCase();
  if (/^банка/i.test(filename) || /^банка/i.test(filename) || lower.includes('jar') || lower.includes('прозрач')) return 'jar';
  return 'card';
}

// определяем номер слайда по имени файла
// напр.: бенфо новый1.png → 1, серрапептаза10.png → 10, 01.webp → 1, 13.webp → 13
function inferSlide(filename) {
  const base = basename(filename, extname(filename));
  // если просто число (включая 01, 02, 13) — это номер
  if (/^\d+$/.test(base)) {
    const n = +base;
    if (n >= 1 && n <= 50) return n;
  }
  // ищем последовательность цифр в конце (1-2 знака)
  const m = base.match(/(\d{1,2})(?=[^0-9]*$)/);
  if (m) {
    const n = +m[1];
    if (n >= 1 && n <= 50) return n;
  }
  return null;
}

// доминантный цвет → hex + category
async function dominantColor(absPath) {
  try {
    // ресайз до 50×50, средние цвета
    const buf = await sharp(absPath).resize(50, 50, { fit: 'inside' }).removeAlpha().raw().toBuffer({ resolveWithObject: true });
    const { data, info } = buf;
    let r = 0, g = 0, b = 0;
    const px = info.width * info.height;
    for (let i = 0; i < data.length; i += info.channels) {
      r += data[i]; g += data[i+1]; b += data[i+2];
    }
    r = Math.round(r/px); g = Math.round(g/px); b = Math.round(b/px);
    const hex = '#' + [r,g,b].map(x => x.toString(16).padStart(2,'0')).join('');
    return { hex, r, g, b };
  } catch (e) { return null; }
}

// hue → palette_cat
function hueToCat(r, g, b) {
  const max = Math.max(r,g,b), min = Math.min(r,g,b);
  const d = max - min;
  if (d < 25) return null; // серый — не определяем
  let h = 0;
  if (max === r) h = ((g - b) / d) % 6;
  else if (max === g) h = (b - r) / d + 2;
  else h = (r - g) / d + 4;
  h = Math.round(h * 60);
  if (h < 0) h += 360;
  if (h < 20)  return 'cardio';      // красно-розовый
  if (h < 50)  return 'energy';      // оранжевый
  if (h < 70)  return 'immunity';    // жёлтый
  if (h < 170) return 'detox';       // зелёный/мятный
  if (h < 220) return 'cognitive';   // голубой
  if (h < 270) return 'longevity';   // фиолетовый
  if (h < 330) return 'beauty';      // розовый
  return 'cardio';                    // красный
}

// === СКАН ===
async function* walk(dir, rel='') {
  let entries;
  try { entries = await readdir(dir, { withFileTypes: true }); } catch { return; }
  for (const e of entries) {
    const abs = join(dir, e.name);
    const r = (rel ? rel + '/' : '') + e.name;
    if (e.isDirectory()) {
      if (['node_modules', '.git', 'output'].includes(e.name)) continue;
      yield* walk(abs, r);
    } else {
      yield { abs, rel: r, name: e.name, ext: extname(e.name).toLowerCase() };
    }
  }
}

// очищаем перед инсертом
await c.query('truncate table c_library_assets restart identity');

let n = 0, skipped = 0, errors = 0;
const cardsRoot = join(ROOT, 'карточки');
for await (const f of walk(cardsRoot, 'карточки')) {
  if (!['.png','.jpg','.jpeg','.webp'].includes(f.ext)) { skipped++; continue; }
  try {
    const folderName = f.rel.split('/')[1] || ''; // карточки/<folder>/...
    const folderInfo = FOLDER_MAP.find(m => m.match.test(folderName));
    const type = inferType(f.name, folderInfo);
    const slide = type === 'jar' ? null : inferSlide(f.name);
    // для wb_NNN — продукт = весь folder name (wb_927416199 как уникальный артикул)
    let product = folderInfo?.product || null;
    if (!product && /^wb_/i.test(folderName)) product = folderName.toLowerCase();
    let palette = folderInfo?.palette || null;
    let dominant = null;
    let dimensions = { width: null, height: null };
    let st = null;
    try { st = await stat(f.abs); } catch {}
    try {
      const meta = await sharp(f.abs).metadata();
      dimensions = { width: meta.width, height: meta.height };
    } catch {}
    // если палитра не задана картой папки — определим по доминанту
    if (!palette) {
      dominant = await dominantColor(f.abs);
      if (dominant) palette = hueToCat(dominant.r, dominant.g, dominant.b);
    } else {
      dominant = await dominantColor(f.abs);
    }
    await c.query(
      `insert into c_library_assets(path,file_name,folder,type,product_code,slide_kind,palette_cat,dominant_hex,size_w,size_h,byte_size,mtime,notes)
       values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
       on conflict (path) do update set
         type=excluded.type, product_code=excluded.product_code, slide_kind=excluded.slide_kind,
         palette_cat=excluded.palette_cat, dominant_hex=excluded.dominant_hex,
         size_w=excluded.size_w, size_h=excluded.size_h, byte_size=excluded.byte_size,
         mtime=excluded.mtime, notes=excluded.notes`,
      [
        f.rel, f.name, folderName, type, product, slide, palette,
        dominant?.hex || null,
        dimensions.width, dimensions.height,
        st?.size || null,
        st?.mtime || null,
        folderInfo?.note || null,
      ]
    );
    n++;
    if (n % 25 === 0) console.log(`  ${n} assets...`);
  } catch (e) {
    errors++;
    console.warn('err', f.rel, e.message);
  }
}

const stats = await c.query(`
  select type, count(*)::int n from c_library_assets group by type order by n desc
`);
console.log(`\n=== ИТОГО ===`);
console.log(`scan: ${n} indexed · ${skipped} skipped · ${errors} errors`);
console.log('по типам:');
for (const r of stats.rows) console.log(`  ${r.type.padEnd(12)} ${r.n}`);

const pstats = await c.query(`
  select product_code, count(*)::int n from c_library_assets where product_code is not null group by product_code order by n desc
`);
console.log('по товарам:');
for (const r of pstats.rows) console.log(`  ${r.product_code.padEnd(15)} ${r.n}`);

const palstats = await c.query(`
  select palette_cat, count(*)::int n from c_library_assets where palette_cat is not null group by palette_cat order by n desc
`);
console.log('по палитрам:');
for (const r of palstats.rows) console.log(`  ${r.palette_cat.padEnd(15)} ${r.n}`);

await c.end();
console.log('done');
