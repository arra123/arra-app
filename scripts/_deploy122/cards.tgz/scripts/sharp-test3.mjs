import { existsSync } from 'node:fs';
import sharp from 'sharp';
import { writeFile } from 'node:fs/promises';

function pickFontFile(weight) {
  const isBold = +weight >= 600;
  const candidates = isBold
    ? ['C:/Windows/Fonts/arialbd.ttf']
    : ['C:/Windows/Fonts/arial.ttf'];
  for (const p of candidates) { try { if (existsSync(p)) return p; } catch {} }
  return null;
}
const fontfile = pickFontFile(900);
console.log('fontfile:', fontfile, 'exists:', fontfile && existsSync(fontfile));

const opts = {
  text: `<span foreground="#ffffff">АСТАКСАНТИН</span>`,
  font: 'Arial Bold 56',
  rgba: true,
  width: 956,
  align: 'centre',
  spacing: 0,
  dpi: 72,
  fontfile,
};
const buf = await sharp({ text: opts }).png().toBuffer();
await writeFile('C:/Claude/Work/cards/output/font3-real.png', buf);
console.log('done');
