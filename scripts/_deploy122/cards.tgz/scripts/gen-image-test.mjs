import 'dotenv/config';
import OpenAI from 'openai';
import fs from 'node:fs';
import path from 'node:path';

const client = new OpenAI({
  apiKey: process.env.PROXYAPI_KEY,
  baseURL: process.env.PROXYAPI_BASE_URL,
});

const prompt = 'A simple flat illustration of a friendly cat, white background, vector art style';

console.log('генерим тест...');
const t0 = Date.now();

const result = await client.images.generate({
  model: 'gpt-image-2',
  prompt,
  size: '1024x1024',
  quality: 'low',
  n: 1,
});

const dt = ((Date.now() - t0) / 1000).toFixed(1);
console.log(`готово за ${dt}s`);

const item = result.data[0];
const outDir = path.resolve('output');
fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, 'test_image.png');

if (item.b64_json) {
  fs.writeFileSync(outPath, Buffer.from(item.b64_json, 'base64'));
} else if (item.url) {
  const resp = await fetch(item.url);
  fs.writeFileSync(outPath, Buffer.from(await resp.arrayBuffer()));
}

console.log(`сохранено: ${outPath}`);
console.log(`usage:`, result.usage ?? '(нет в ответе)');
