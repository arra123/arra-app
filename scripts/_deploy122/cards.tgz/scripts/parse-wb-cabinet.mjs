// Парсер кабинета WB: тянет карточки + фото + описание + характеристики.
// Использование:
//   node scripts/parse-wb-cabinet.mjs <irina|eugeny> [limit]
// Примеры:
//   node scripts/parse-wb-cabinet.mjs irina 10     — первые 10 карточек
//   node scripts/parse-wb-cabinet.mjs irina        — все карточки (пагинация)
//
// Anti-duplicate:
//   · в БД через ON CONFLICT(nm_id) DO UPDATE — повторный запуск обновит метаданные
//   · фото скипаются если файл уже есть на диске
//
// Структура на диске:
//   карточки/наши_<account>/<vendorCode>_<nmID>/_meta.json
//   карточки/наши_<account>/<vendorCode>_<nmID>/photos/01.jpg, 02.jpg, ...

import 'dotenv/config';
import pg from 'pg';
import { mkdir, writeFile, access, readFile } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

// ─── аргументы ───
const acc = (process.argv[2] || '').toLowerCase();
const limit = process.argv[3] ? +process.argv[3] : null; // null = все
if (!['irina', 'eugeny'].includes(acc)) {
  console.error('Usage: node scripts/parse-wb-cabinet.mjs <irina|eugeny> [limit]');
  process.exit(1);
}
const TOKEN = process.env[`WB_TOKEN_${acc.toUpperCase()}`];
if (!TOKEN) {
  console.error(`нет WB_TOKEN_${acc.toUpperCase()} в .env`);
  process.exit(2);
}

console.log(`\n=== WB · кабинет «${acc}» ${limit ? `· первые ${limit} карточек` : '· все карточки'} ===\n`);

// ─── БД ───
const c = new pg.Client({
  host: process.env.PGHOST, port: +process.env.PGPORT,
  database: process.env.PGDATABASE, user: process.env.PGUSER,
  password: process.env.PGPASSWORD, ssl: false,
});
await c.connect();

// схема под WB-данные (создаём если нет)
await c.query(`
  create table if not exists c_wb_products (
    nm_id           bigint primary key,
    account         text not null,
    vendor_code     text,
    title           text,
    brand           text,
    description     text,
    subject_id      integer,
    subject_name    text,
    photo_count     integer,
    characteristics jsonb,
    sizes           jsonb,
    dimensions      jsonb,
    tags            jsonb,
    raw             jsonb,
    wb_created_at   timestamptz,
    wb_updated_at   timestamptz,
    fetched_at      timestamptz default now()
  );
  create index if not exists ix_c_wb_products_account on c_wb_products(account);
  create index if not exists ix_c_wb_products_subject on c_wb_products(subject_name);
  alter table c_wb_products add column if not exists tech_card    jsonb;     -- рецепт из sklad
  alter table c_wb_products add column if not exists composition  jsonb;     -- активные вещества + дозировки
  alter table c_wb_products add column if not exists usage_text   text;      -- способ применения
  alter table c_wb_products add column if not exists benefits     jsonb;     -- полезные свойства для слайда (массив строк)
  alter table c_wb_products add column if not exists sklad_id     integer;   -- id товара в products_s
  alter table c_wb_products add column if not exists sklad_folder text;      -- folder_path в sklad
  alter table c_wb_products add column if not exists cost_price   numeric(12,2);

  create table if not exists c_wb_photos (
    id            serial primary key,
    nm_id         bigint references c_wb_products(nm_id) on delete cascade,
    idx           integer not null,
    url           text not null,
    local_path    text,
    byte_size     integer,
    width         integer,
    height        integer,
    downloaded_at timestamptz,
    unique(nm_id, idx)
  );
`);

// ─── подключаемся к sklad для тех-карт ───
const sklad = new pg.Client({
  host: '5.42.100.180', port: 5432, database: 'bd2',
  user: 'danila', password: 'Iw)7oH$nbu=T%m', ssl: false,
});
let skladOK = false;
try { await sklad.connect(); skladOK = true; console.log('· sklad ok'); }
catch(e){ console.log('· sklad недоступен:', e.code); }

async function fetchTechCard(vendorCode) {
  if (!skladOK || !vendorCode) return null;
  try {
    const p = await sklad.query('select id, name, sale_price, cost_price, folder_path, source_json from products_s where article = $1 limit 1', [vendorCode]);
    if (!p.rows[0]) return null;
    const prod = p.rows[0];
    const rc = await sklad.query(`
      select rm.name as ingredient, mr.quantity, rm.unit, rm.category, rm.material_group
      from material_recipe_s mr
      join raw_materials_s rm on rm.id = mr.ingredient_id
      where mr.material_id = $1
      order by mr.sort_order
    `, [prod.id]);
    return {
      sklad_id: prod.id,
      sklad_folder: prod.folder_path,
      cost_price: prod.cost_price ? Number(prod.cost_price) : null,
      sale_price: prod.sale_price ? Number(prod.sale_price) : null,
      ingredients: rc.rows.map(r => ({
        name: r.ingredient,
        quantity: Number(r.quantity),
        unit: r.unit,
        category: r.category,
        group: r.material_group,
      })),
    };
  } catch(e){ console.log('  sklad err for', vendorCode, ':', e.message); return null; }
}

// ─── извлечение «способа применения» и «состава» из WB-данных ───
function extractFromCharacteristics(card) {
  const out = { usage_text: null, composition: [] };
  for (const ch of (card.characteristics || [])) {
    const name = String(ch.name || '').toLowerCase();
    const val = Array.isArray(ch.value) ? ch.value.join(', ') : String(ch.value || '');
    if (/способ\s*прим|применение|приём|prиём|инструкц/i.test(name)) out.usage_text = val;
    if (/состав|ингредиент|active|активн/i.test(name)) {
      // часто состав — массив строк типа "Витамин C — 100 мг"
      const items = Array.isArray(ch.value) ? ch.value : [val];
      for (const it of items) {
        const m = String(it).match(/^(.+?)[\s—-]+(\d+(?:[.,]\d+)?)\s*(мг|мкг|г|МЕ|ме|iu|IU|млрд)/iu);
        if (m) out.composition.push({ substance: m[1].trim(), amount: +m[2].replace(',','.'), unit: m[3] });
        else out.composition.push({ substance: String(it).trim() });
      }
    }
  }
  // если usage_text пустой — попробуем найти в description секцию
  if (!out.usage_text && card.description) {
    const m = card.description.match(/(?:способ\s*прим|применение|приём)[:\s]*([^\n]{20,500})/i);
    if (m) out.usage_text = m[1].trim();
  }
  return out;
}

// ─── скачивание одной картинки с проверкой дубликата на диске ───
async function downloadPhoto(url, outPath) {
  try {
    await access(outPath);
    return { skipped: true };
  } catch {}
  const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
  if (!r.ok) return { error: `HTTP ${r.status}` };
  const buf = Buffer.from(await r.arrayBuffer());
  await writeFile(outPath, buf);
  return { saved: true, size: buf.length };
}

// ─── одна страница списка карточек ───
// см. https://dev.wildberries.ru/openapi/work-with-products
async function fetchCardsPage(cursor) {
  const body = {
    settings: {
      cursor: { limit: cursor?.pageLimit || 100, ...(cursor?.updatedAt ? { updatedAt: cursor.updatedAt, nmID: cursor.nmID } : {}) },
      filter: { withPhoto: -1 },
    },
  };
  const r = await fetch('https://content-api.wildberries.ru/content/v2/get/cards/list', {
    method: 'POST',
    headers: { 'Authorization': TOKEN, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!r.ok) {
    const t = await r.text();
    throw new Error(`Content API ${r.status}: ${t.slice(0, 300)}`);
  }
  return await r.json();
}

// ─── основной цикл ───
let processed = 0;
let savedCards = 0, savedPhotos = 0, skippedPhotos = 0, errors = 0;
let cursor = { pageLimit: limit && limit < 100 ? limit : 100 };

outer:
while (true) {
  process.stdout.write(`fetching cards (offset ${processed})... `);
  let data;
  try { data = await fetchCardsPage(cursor); }
  catch (e) { console.error('\n  ✗', e.message); break; }

  const cards = data.cards || [];
  console.log(`got ${cards.length}`);
  if (!cards.length) break;

  for (const card of cards) {
    if (limit && processed >= limit) break outer;
    const nm = card.nmID;
    const vc = (card.vendorCode || `nm${nm}`).replace(/[\\\/:*?"<>|]/g, '_');
    const folderRel = `карточки/наши_${acc}/${vc}_${nm}`;
    const folderAbs = join(ROOT, folderRel);
    await mkdir(join(folderAbs, 'photos'), { recursive: true });

    const photos = card.photos || [];

    // c_folder_meta — чтобы поиск в библиотеке находил по title/brand
    await c.query(`
      create table if not exists c_folder_meta (
        folder text primary key, display_name text, full_name text,
        source text, source_id text, brand text, source_url text,
        pics_total integer, notes text, updated_at timestamptz default now()
      );
      alter table c_folder_meta add column if not exists full_name text;
    `);
    const folderForMeta = `${folderRel}/photos`;
    // короткое имя для дерева — title (или vendorCode, если title пустой)
    // подпись под именем сделаем vendorCode + nmID (см. bucketize в site/index.html)
    const shortTitle = (card.title || card.vendorCode || `nm${nm}`).slice(0, 60);
    await c.query(`
      insert into c_folder_meta(folder, display_name, full_name, source, source_id, brand, source_url, pics_total, notes)
      values($1,$2,$3,$4,$5,$6,$7,$8,$9)
      on conflict (folder) do update set
        display_name = excluded.display_name,
        full_name    = excluded.full_name,
        source       = excluded.source,
        source_id    = excluded.source_id,
        brand        = excluded.brand,
        source_url   = excluded.source_url,
        pics_total   = excluded.pics_total,
        notes        = excluded.notes,
        updated_at   = now()
    `, [
      folderForMeta,
      shortTitle,                                                       // короткое: для дерева
      card.title || null,                                               // полное: для модала
      `wb_cabinet_${acc}`,                                              // источник
      String(nm),
      card.brand || null,
      `https://www.wildberries.ru/catalog/${nm}/detail.aspx`,
      photos.length,
      card.vendorCode || null,                                          // notes: артикул как подсказка
    ]);

    // тех-карта из sklad + способ применения / состав из WB-характеристик
    const tech = await fetchTechCard(card.vendorCode);
    const extracted = extractFromCharacteristics(card);

    // upsert в c_wb_products СНАЧАЛА (FK для c_wb_photos)
    await c.query(`
      insert into c_wb_products(
        nm_id, account, vendor_code, title, brand, description,
        subject_id, subject_name, photo_count,
        characteristics, sizes, dimensions, tags, raw,
        wb_created_at, wb_updated_at,
        tech_card, composition, usage_text, sklad_id, sklad_folder, cost_price,
        fetched_at
      )
      values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22, now())
      on conflict (nm_id) do update set
        account = excluded.account,
        vendor_code = excluded.vendor_code,
        title = excluded.title,
        brand = excluded.brand,
        description = excluded.description,
        subject_id = excluded.subject_id,
        subject_name = excluded.subject_name,
        photo_count = excluded.photo_count,
        characteristics = excluded.characteristics,
        sizes = excluded.sizes,
        dimensions = excluded.dimensions,
        tags = excluded.tags,
        raw = excluded.raw,
        wb_updated_at = excluded.wb_updated_at,
        tech_card    = excluded.tech_card,
        composition  = excluded.composition,
        usage_text   = excluded.usage_text,
        sklad_id     = excluded.sklad_id,
        sklad_folder = excluded.sklad_folder,
        cost_price   = excluded.cost_price,
        fetched_at = now()
    `, [
      nm, acc, card.vendorCode, card.title, card.brand, card.description,
      card.subjectID, card.subjectName, photos.length,
      JSON.stringify(card.characteristics || []),
      JSON.stringify(card.sizes || []),
      JSON.stringify(card.dimensions || null),
      JSON.stringify(card.tags || []),
      JSON.stringify(card),
      card.createdAt || null,
      card.updatedAt || null,
      tech ? JSON.stringify(tech) : null,
      extracted.composition.length ? JSON.stringify(extracted.composition) : null,
      extracted.usage_text,
      tech?.sklad_id || null,
      tech?.sklad_folder || null,
      tech?.cost_price || null,
    ]);

    // _meta.json
    const meta = {
      nm_id: nm,
      account: acc,
      vendor_code: card.vendorCode,
      title: card.title,
      brand: card.brand,
      description: card.description,
      subject_id: card.subjectID,
      subject_name: card.subjectName,
      photos_count: photos.length,
      characteristics: card.characteristics || [],
      sizes: card.sizes || [],
      dimensions: card.dimensions || null,
      tags: card.tags || [],
      wb_created_at: card.createdAt || null,
      wb_updated_at: card.updatedAt || null,
      fetched_at: new Date().toISOString(),
    };
    await writeFile(join(folderAbs, '_meta.json'), JSON.stringify(meta, null, 2), 'utf8');

    // фото
    let dl = 0, sk = 0, er = 0;
    for (let i = 0; i < photos.length; i++) {
      const url = photos[i].big || photos[i].hq || photos[i].c516x688;
      if (!url) continue;
      const ext = (url.match(/\.(\w+)(?:\?|$)/)?.[1] || 'jpg').toLowerCase();
      const filename = `${String(i + 1).padStart(2, '0')}.${ext}`;
      const filepath = join(folderAbs, 'photos', filename);
      const localRel = `${folderRel}/photos/${filename}`;
      const r = await downloadPhoto(url, filepath);
      if (r.saved) {
        dl++; savedPhotos++;
        await c.query(`
          insert into c_wb_photos(nm_id, idx, url, local_path, byte_size, downloaded_at)
          values($1,$2,$3,$4,$5, now())
          on conflict (nm_id, idx) do update set
            url = excluded.url, local_path = excluded.local_path,
            byte_size = excluded.byte_size, downloaded_at = now()
        `, [nm, i + 1, url, localRel, r.size || null]);
      } else if (r.skipped) {
        sk++; skippedPhotos++;
        // обновим только URL/localPath на случай если переименовали
        await c.query(`
          insert into c_wb_photos(nm_id, idx, url, local_path)
          values($1,$2,$3,$4)
          on conflict (nm_id, idx) do update set url = excluded.url, local_path = excluded.local_path
        `, [nm, i + 1, url, localRel]);
      } else {
        er++; errors++;
        console.log(`    ✗ photo ${filename}: ${r.error}`);
      }
    }

    savedCards++;
    processed++;
    const titleShort = (card.title || '').slice(0, 60);
    console.log(`  ✓ #${nm} · ${vc} · ${photos.length} фото (${dl} dl / ${sk} skip${er ? ' / ' + er + ' err' : ''}) · ${titleShort}`);
  }

  // пагинация: cursor от ответа
  cursor = data.cursor && data.cursor.total >= cards.length
    ? { pageLimit: 100, updatedAt: data.cursor.updatedAt, nmID: data.cursor.nmID }
    : null;
  if (!cursor || (data.cursor?.total || 0) < (cursor.pageLimit || 100)) break;
  if (limit && processed >= limit) break;
}

console.log(`\n=== ИТОГО ===`);
console.log(`карточек: ${savedCards}`);
console.log(`фото:    ${savedPhotos} скачано · ${skippedPhotos} уже было · ${errors} ошибок`);
console.log(`папка:   карточки/наши_${acc}/`);
console.log(`\nЗапусти: node scripts/scan-library.mjs — чтобы перетегировать.`);
await c.end();
if (skladOK) await sklad.end();
