import sharp from 'sharp';
import { writeFile } from 'node:fs/promises';

async function tryOne(label, opts) {
  try {
    const buf = await sharp({ text: opts }).png().toBuffer();
    await writeFile(`C:/Claude/Work/cards/output/font-test-${label}.png`, buf);
    const meta = await sharp(buf).metadata();
    console.log(label, 'OK', meta.width + 'x' + meta.height);
  } catch (e) {
    console.log(label, 'ERR', e.message);
  }
}

const text = 'АСТАКСАНТИН';
await tryOne('1-noFont',         { text, width: 600, dpi: 72, rgba: true });
await tryOne('2-fontOnly',       { text, font: 'sans 48', width: 600, dpi: 72, rgba: true });
await tryOne('3-fontfileOnly',   { text, fontfile: 'C:/Windows/Fonts/arial.ttf', width: 600, dpi: 72, rgba: true });
await tryOne('4-bothArial',      { text, font: 'Arial 48', fontfile: 'C:/Windows/Fonts/arial.ttf', width: 600, dpi: 72, rgba: true });
await tryOne('5-markup',         { text: '<span foreground="white">АСТАКСАНТИН</span>', font: 'Arial 48', fontfile: 'C:/Windows/Fonts/arial.ttf', width: 600, dpi: 72, rgba: true });
