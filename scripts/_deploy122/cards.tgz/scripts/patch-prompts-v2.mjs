// Полная переработка раздела «База промптов»: канон 6 слайдов, запреты, мои промпты с оценками, brand canvas
import { readFileSync, writeFileSync } from 'node:fs';

const fpath = 'C:/Claude/Work/cards/site/index.html';
let src = readFileSync(fpath, 'utf8');

// 1) HTML
{
  const start = src.indexOf('<!-- ─────────── 2. БАЗА ПРОМПТОВ ─────────── -->');
  const end = src.indexOf('<!-- ─────────── 3. БИБЛИОТЕКА ─────────── -->', start);
  if (start < 0 || end < 0) throw new Error('prompts markers');

  const NEW = `<!-- ─────────── 2. БАЗА ПРОМПТОВ ─────────── -->
<section class="tab-page" data-page="prompts">
  <div class="max-w-[1320px] mx-auto px-8 py-10">

    <div class="mb-7">
      <h1 class="text-[36px] font-semibold tracking-tight">База промптов</h1>
    </div>

    <div class="flex items-center gap-2 mb-6 flex-wrap" id="prompts-view-tabs">
      <button class="ftab active" data-pview="canon"><i data-lucide="layers" class="w-3 h-3"></i>Канон 6 слайдов</button>
      <button class="ftab" data-pview="black"><i data-lucide="shield-x" class="w-3 h-3"></i>Запреты</button>
      <button class="ftab" data-pview="my"><i data-lucide="git-branch" class="w-3 h-3"></i>Мои промпты</button>
      <button class="ftab" data-pview="brand"><i data-lucide="bookmark" class="w-3 h-3"></i>Brand canvas</button>
      <button class="ftab" data-pview="rated"><i data-lucide="thumbs-up" class="w-3 h-3"></i>Оценки</button>
    </div>

    <!-- ── Канон 6 слайдов ── -->
    <div id="pview-canon" class="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div class="text-[12px] text-[var(--slate-10)]">загрузка…</div>
    </div>

    <!-- ── Запреты ── -->
    <div id="pview-black" class="hidden flex flex-col gap-4">
      <div class="text-[12px] text-[var(--slate-10)]">загрузка…</div>
    </div>

    <!-- ── Мои промпты ── -->
    <div id="pview-my" class="hidden grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-4">
      <div class="r-card p-3 relative">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
        <div class="relative mb-2 px-2 pt-2">
          <i data-lucide="search" class="w-3.5 h-3.5 absolute left-5 top-1/2 -translate-y-1/2 text-[var(--slate-10)]"></i>
          <input class="sinput pl-9" placeholder="Поиск…" id="prompts-search" />
        </div>
        <div class="flex flex-col gap-1 mt-3" id="prompts-list">
          <div class="text-[12px] text-[var(--slate-10)] px-3 py-4">загрузка…</div>
        </div>
      </div>
      <div class="r-card accent-blue p-7 relative" id="prompt-detail">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
        <div id="prompt-detail-header" class="text-[13px] text-[var(--slate-10)]">— выбери промпт слева —</div>
        <div id="prompt-detail-stats" class="hidden grid grid-cols-2 md:grid-cols-4 gap-4 my-7"></div>
        <div id="prompt-body-view" class="code-mini" style="display:none"></div>
      </div>
    </div>

    <!-- ── Brand canvas ── -->
    <div id="pview-brand" class="hidden">
      <div class="r-card accent-purple p-7 relative max-w-[820px]">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
        <h3 class="text-[18px] font-semibold mb-1">brand canvas — общий слой бренда</h3>
        <p class="text-[13px] text-[var(--slate-11)] mb-5">Подставляется в начало каждого промпта. Кодифицирует tone of voice, цвета, шрифты, запреты — чтобы AI не выдумывал.</p>
        <div class="code-mini"><span class="tk-comment"># brand-canvas · GRAflab v3</span>
<span class="tk-keyword">brand</span>: GRAflab · российский бренд БАДов
<span class="tk-keyword">tone</span>: <span class="tk-string">"уверенно, без обещаний, с фактами"</span>
<span class="tk-keyword">avoid</span>: [<span class="tk-string">"лечит"</span>, <span class="tk-string">"гарантирует"</span>, <span class="tk-string">"чудо"</span>, <span class="tk-string">"100%"</span>]
<span class="tk-keyword">prefer</span>: [<span class="tk-string">"способствует"</span>, <span class="tk-string">"поддерживает"</span>]

<span class="tk-keyword">visual</span>:
  format: 1086x1449
  font: Inter, Manrope
  jar_position: front_centered
  title_case: UPPERCASE</div>
        <div class="flex gap-2 mt-5">
          <button class="sbtn sbtn-md sbtn-secondary"><i data-lucide="edit-3" class="w-3.5 h-3.5"></i>Редактировать</button>
          <button class="sbtn sbtn-md sbtn-outline"><i data-lucide="history" class="w-3.5 h-3.5"></i>История версий</button>
        </div>
      </div>
    </div>

    <!-- ── Оценки ── -->
    <div id="pview-rated" class="hidden flex flex-col gap-3">
      <div class="text-[12px] text-[var(--slate-10)]">загрузка…</div>
    </div>
  </div>
</section>

`;
  src = src.slice(0, start) + NEW + src.slice(end);
}

// 2) JS — переписываем БИБЛИОТЕКА → пропускаем, она ОК. Переписываем функцию loadPrompts на новую логику
{
  // Найти и заменить старую loadPrompts/renderPromptsList/selectPrompt блок
  const startMarker = '  // ============ ПРОМПТЫ ============';
  const endMarker = '  // ============ БИБЛИОТЕКА';
  let i = src.indexOf(startMarker);
  let j = -1;
  if (i < 0) {
    // если такого маркера нет — найдём loadPrompts function как старт
    const m1 = src.indexOf('  let _allPrompts = [];');
    const m2 = src.indexOf('  // ============ БИБЛИОТЕКА', m1);
    if (m1 < 0 || m2 < 0) throw new Error('prompts JS markers');
    i = m1; j = m2;
  } else {
    j = src.indexOf(endMarker, i);
  }
  if (j < 0) throw new Error('end marker missing');

  const NEW = `  // ============ ПРОМПТЫ v2 (канон, запреты, мои, оценки) ============
  let _canonData = null, _blackData = null, _allPrompts = [], _ratingsData = null, _activePromptId = null;

  async function loadPrompts(){
    // переключатели view-табов
    document.querySelectorAll('#prompts-view-tabs [data-pview]').forEach(b => {
      b.onclick = () => switchPromptView(b.dataset.pview);
    });
    await switchPromptView('canon');
  }

  async function switchPromptView(v){
    document.querySelectorAll('#prompts-view-tabs [data-pview]').forEach(b => b.classList.toggle('active', b.dataset.pview === v));
    ['canon','black','my','brand','rated'].forEach(x => {
      const el = document.getElementById('pview-' + x);
      if (el) el.classList.toggle('hidden', x !== v);
      if (el && x === v && !el.classList.contains('hidden')) el.style.display = '';
    });
    if (v === 'canon')  return renderCanon();
    if (v === 'black')  return renderBlacklist();
    if (v === 'my')     return renderMyPrompts();
    if (v === 'rated')  return renderRated();
  }

  async function renderCanon(){
    const cont = document.getElementById('pview-canon');
    if (!_canonData) _canonData = await api('/api/canon');
    cont.innerHTML = _canonData.map((s, i) => {
      const accent = ['accent-blue','accent-green','accent-amber','accent-pink','accent-purple','accent-blue'][i] || '';
      return \`<div class="r-card \${accent} p-6 relative">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
        <div class="flex items-center gap-3 mb-3">
          <div class="w-9 h-9 rounded-lg flex items-center justify-center mono text-[15px] font-semibold" style="background:rgba(255,255,255,.05); border:1px solid var(--slate-6)">\${s.slide_kind}</div>
          <div>
            <div class="text-[16px] font-semibold text-slate-12">\${esc(s.title)}</div>
            <div class="text-[12px] text-[var(--slate-11)]">\${esc(s.description||'')}</div>
          </div>
        </div>
        <div class="grid grid-cols-1 gap-3 text-[12.5px] mt-4">
          <div>
            <div class="section-cap mb-1.5" style="color:var(--green-11)">обязательно</div>
            <ul class="flex flex-col gap-1 text-[var(--slate-11)]">\${(s.must_have||[]).map(x => \`<li class="flex gap-2"><i data-lucide="check" class="w-3 h-3 mt-0.5 flex-shrink-0" style="color:var(--green-11)"></i>\${esc(x)}</li>\`).join('') || '—'}</ul>
          </div>
          <div>
            <div class="section-cap mb-1.5" style="color:var(--red-11)">нельзя</div>
            <ul class="flex flex-col gap-1 text-[var(--slate-11)]">\${(s.must_avoid||[]).map(x => \`<li class="flex gap-2"><i data-lucide="x" class="w-3 h-3 mt-0.5 flex-shrink-0" style="color:var(--red-11)"></i>\${esc(x)}</li>\`).join('') || '—'}</ul>
          </div>
          <div>
            <div class="section-cap mb-1.5" style="color:var(--slate-10)">мягкие варианты</div>
            <ul class="flex flex-col gap-1 text-[var(--slate-11)]">\${(s.soft_options||[]).map(x => \`<li class="flex gap-2"><span class="text-[var(--slate-10)]">·</span>\${esc(x)}</li>\`).join('') || '—'}</ul>
          </div>
          \${s.character_hint ? \`<div><div class="section-cap mb-1.5" style="color:var(--blue-11)">персонаж</div><div class="text-[var(--slate-11)]">\${esc(s.character_hint)}</div></div>\` : ''}
        </div>
      </div>\`;
    }).join('');
    lucide.createIcons();
  }

  async function renderBlacklist(){
    const cont = document.getElementById('pview-black');
    if (!_blackData) _blackData = await api('/api/blacklist');
    const grouped = {};
    for (const w of _blackData) (grouped[w.scope] = grouped[w.scope] || []).push(w);
    const scopes = Object.keys(grouped).sort((a,b) => a === 'global' ? -1 : 1);
    cont.innerHTML = scopes.map(scope => {
      const items = grouped[scope];
      const title = scope === 'global' ? 'Глобальные (по всем категориям)' : 'Категория · ' + scope;
      const accent = scope === 'global' ? 'accent-pink' : 'accent-amber';
      return \`<div class="r-card \${accent} p-6 relative">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-[16px] font-semibold">\${esc(title)}</h3>
          <span class="text-[11px] mono text-[var(--slate-10)]">\${items.length} слов</span>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          \${items.map(w => \`<div class="rounded-lg p-3 flex flex-col gap-1" style="background:rgba(255,255,255,.02); border:1px solid var(--slate-6)">
            <div class="flex items-center gap-2">
              <span class="badge-r bounced">\${esc(w.word)}</span>
              \${w.alternative ? \`<i data-lucide="arrow-right" class="w-3 h-3 text-[var(--slate-10)]"></i><span class="badge-r delivered">\${esc(w.alternative)}</span>\` : ''}
            </div>
            \${w.reason ? \`<div class="text-[11.5px] text-[var(--slate-11)] mt-1">\${esc(w.reason)}</div>\` : ''}
          </div>\`).join('')}
        </div>
      </div>\`;
    }).join('');
    lucide.createIcons();
  }

  async function renderMyPrompts(){
    const list = document.getElementById('prompts-list');
    list.innerHTML = '<div class="text-[12px] text-[var(--slate-10)] px-3 py-4">загрузка…</div>';
    if (!_allPrompts.length) _allPrompts = await api('/api/prompts');

    // группировка по slide_kind
    const bySlide = {};
    for (const p of _allPrompts) (bySlide[p.slide_kind] = bySlide[p.slide_kind] || []).push(p);

    const SLIDE_TITLES = ['HERO','СОСТАВ','ВЫГОДЫ A','ВЫГОДЫ B','ПРЕИМУЩЕСТВА','ДЛЯ КОГО'];
    list.innerHTML = '';
    for (let k = 1; k <= 6; k++) {
      const group = bySlide[k] || [];
      const sec = document.createElement('div');
      sec.innerHTML = \`<div class="section-cap mt-3 mb-1.5 px-2">слайд \${k} · \${SLIDE_TITLES[k-1]}</div>\`;
      list.appendChild(sec.firstChild);
      for (const p of group) {
        const stBadge = p.status === 'live' ? 'delivered' : p.status === 'draft' ? 'draft' : 'opened';
        const btn = document.createElement('button');
        btn.className = 'prompt-item ' + (p.id === _activePromptId ? 'active' : '');
        btn.dataset.prompt = p.id;
        btn.style.cssText = 'padding:8px 10px';
        btn.innerHTML = \`<div class="flex items-center justify-between gap-2 mb-0.5">
          <span class="text-[13px] font-medium text-slate-12 truncate">\${esc(p.name)}</span>
          <span class="badge-r \${stBadge} badge-sm" style="flex-shrink:0">v\${p.version}</span>
        </div>
        <div class="text-[11px] text-[var(--slate-10)] truncate">\${p.runs} запусков\${p.approval_rate != null ? ' · '+p.approval_rate+'%' : ''}</div>\`;
        btn.onclick = () => selectPrompt(p.id);
        list.appendChild(btn);
      }
    }
    if (_allPrompts.length && !_activePromptId) selectPrompt(_allPrompts[0].id);
  }

  async function selectPrompt(id){
    _activePromptId = id;
    document.querySelectorAll('#prompts-list .prompt-item').forEach(x => x.classList.toggle('active', +x.dataset.prompt === id));
    const p = await api('/api/prompts/' + id);
    const stBadge = p.status === 'live' ? 'delivered' : p.status === 'draft' ? 'draft' : 'opened';
    document.getElementById('prompt-detail-header').innerHTML = \`
      <div class="flex items-center gap-2 mb-2">
        <span class="badge-r \${stBadge}">v\${p.version} · \${esc(p.status)}</span>
        <span class="text-[11px] mono text-[var(--slate-10)]">слайд \${p.slide_kind}</span>
      </div>
      <h2 class="text-[22px] font-semibold tracking-tight">\${esc(p.name)}</h2>
      <p class="text-[13px] text-[var(--slate-11)] mt-1">\${esc(p.notes || '—')}</p>
      <div class="flex gap-2 mt-4">
        <button class="sbtn sbtn-sm sbtn-secondary" onclick="navigator.clipboard.writeText(\\\`\${(p.body||'').replace(/\`/g,'\\\\\`')}\\\`); this.innerHTML='<i data-lucide=check class=\\\\'w-3 h-3\\\\'></i>скопировано'; lucide.createIcons()"><i data-lucide="copy" class="w-3 h-3"></i>скопировать в буфер</button>
        <button class="sbtn sbtn-sm sbtn-outline"><i data-lucide="play" class="w-3 h-3"></i>тест в Генерации</button>
      </div>
    \`;
    const totalCost = (p.history||[]).reduce((a,h) => a + (Number(h.cost_rub) || 0), 0);
    const okRuns = (p.history||[]).filter(h => h.status==='success').length;
    const totalRuns = (p.history||[]).length;
    const approval = totalRuns ? Math.round(100*okRuns/totalRuns) : null;
    const stats = document.getElementById('prompt-detail-stats');
    stats.classList.remove('hidden');
    stats.style.display = 'grid';
    stats.innerHTML = \`
      <div><div class="section-cap">одобрено</div><div class="text-[20px] font-semibold mt-1.5" style="color:var(--green-11)">\${approval==null?'—':approval+'%'}</div></div>
      <div><div class="section-cap">запусков</div><div class="text-[20px] font-semibold mt-1.5 text-slate-12">\${totalRuns}</div></div>
      <div><div class="section-cap">потрачено</div><div class="text-[20px] font-semibold mt-1.5 text-slate-12">\${totalCost.toFixed(0)} ₽</div></div>
      <div><div class="section-cap">api</div><div class="text-[14px] font-medium mt-2 text-[var(--slate-11)] mono truncate">\${esc(p.endpoint)} · \${esc(p.size)}</div></div>
    \`;
    const body = document.getElementById('prompt-body-view');
    body.style.display = 'block';
    body.textContent = p.body || '';
    lucide.createIcons();
  }

  async function renderRated(){
    const cont = document.getElementById('pview-rated');
    if (!_ratingsData) _ratingsData = await api('/api/ratings');
    if (!_ratingsData.length) { cont.innerHTML = '<div class="text-[13px] text-[var(--slate-11)]">пока нет оценок · оцени генерации в разделе «Генерация»</div>'; return; }
    cont.innerHTML = _ratingsData.map(r => {
      const ico = r.rating === 1 ? 'thumbs-up' : 'thumbs-down';
      const col = r.rating === 1 ? 'var(--green-11)' : 'var(--red-11)';
      return \`<div class="r-card p-5 relative flex items-start gap-4">
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
        <div class="flex-shrink-0 w-9 h-9 rounded-lg flex items-center justify-center" style="background:rgba(255,255,255,.04); color:\${col}; border:1px solid var(--slate-6)">
          <i data-lucide="\${ico}" class="w-4 h-4"></i>
        </div>
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-3 mb-1 flex-wrap">
            <span class="text-[13px] font-medium text-slate-12">\${esc(r.prompt_name || 'промпт')}</span>
            <span class="text-[11px] mono text-[var(--slate-10)]">слайд \${r.slide_kind || '—'} · \${esc(r.sku || 'без товара')}</span>
            \${r.cost_rub ? \`<span class="badge-r draft badge-sm">\${r.cost_rub} ₽</span>\` : ''}
          </div>
          <div class="text-[13px] text-[var(--slate-11)]">\${esc(r.note || '—')}</div>
        </div>
        <div class="text-[11px] text-[var(--slate-10)] mono flex-shrink-0">\${new Date(r.created_at).toLocaleDateString('ru')}</div>
      </div>\`;
    }).join('');
    lucide.createIcons();
  }

  document.getElementById('prompts-search')?.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase().trim();
    const items = q ? _allPrompts.filter(p => p.name.toLowerCase().includes(q) || (p.notes||'').toLowerCase().includes(q)) : _allPrompts;
    // упрощённо — только names
    const list = document.getElementById('prompts-list');
    list.innerHTML = items.map(p => {
      const stBadge = p.status === 'live' ? 'delivered' : p.status === 'draft' ? 'draft' : 'opened';
      return \`<button class="prompt-item \${p.id===_activePromptId?'active':''}" data-prompt="\${p.id}" style="padding:8px 10px">
        <div class="flex items-center justify-between gap-2">
          <span class="text-[13px] font-medium text-slate-12 truncate">\${esc(p.name)}</span>
          <span class="badge-r \${stBadge} badge-sm">v\${p.version}</span>
        </div>
        <div class="text-[11px] text-[var(--slate-10)] truncate">слайд \${p.slide_kind} · \${p.runs} запусков</div>
      </button>\`;
    }).join('');
    list.querySelectorAll('[data-prompt]').forEach(b => b.onclick = () => selectPrompt(+b.dataset.prompt));
  });

  // ============ БИБЛИОТЕКА`;

  src = src.slice(0, i) + NEW + src.slice(j + endMarker.length);
}

writeFileSync(fpath, src, 'utf8');
console.log('done');
