from PIL import Image, ImageDraw, ImageFont
import pathlib

OUT = r"C:\Claude\Work\cards\mindmap_objects.png"
W, H = 1900, 1200
BG = (24,26,33); INK=(235,235,240); DIM=(130,135,150)
P={"raster":(230,90,90),"obj":(255,200,80),"hybrid":(90,200,130),"core":(255,170,60),"data":(110,175,255),"warn":(255,150,100)}

def font(s,b=False):
    p = r"C:\Windows\Fonts\segoeuib.ttf" if b else r"C:\Windows\Fonts\segoeui.ttf"
    return ImageFont.truetype(p,s) if pathlib.Path(p).exists() else ImageFont.load_default()
def card(d,x,y,w,h,title,items,color,verdict,verdict_color,ts=18,is_=14):
    ft=font(ts,True); fi=font(is_); pad=14; lh=is_+8; th=ts+10
    d.rounded_rectangle((x,y,x+w,y+h),14,fill=(36,40,52),outline=color,width=3)
    d.rounded_rectangle((x,y,x+w,y+th+8),14,fill=color)
    d.text((x+pad,y+8),title,font=ft,fill=(20,20,28))
    yy=y+th+pad
    for it in items:
        d.text((x+pad,yy),"•  "+it,font=fi,fill=INK); yy+=lh
    d.rounded_rectangle((x+pad,y+h-32, x+w-pad, y+h-6),8,fill=verdict_color)
    d.text((x+pad+10, y+h-29), verdict, font=font(13,True), fill=(20,20,28))

img=Image.new("RGB",(W,H),BG); d=ImageDraw.Draw(img)
d.text((40,28),"Слайды как «одна картинка» или как «объекты, которые двигаешь»?",font=font(30,True),fill=INK)
d.text((40,68),"короткий ответ: гибрид — фон через AI, всё остальное (тексты/плитки/банка) — слои на canvas",font=font(15),fill=DIM)

# 3 cards top
y0 = 130; cw = 600; ch = 380; gap = 30
card(d, 40, y0, cw, ch, "ВАРИАНТ A — RASTER (как сейчас)",
  ["AI отдаёт готовый PNG целиком",
   "менеджер либо берёт, либо просит перегенерить",
   "композитим только PNG банки сверху",
   "",
   "плюс: быстро накидать MVP",
   "минус: нельзя двигать, нельзя поправить опечатку",
   "минус: нужно перегенерить весь слайд",
   "минус: текст плывёт (особенно kirillica)",
   "минус: дозировки могут получиться неровные"],
  P["raster"], "СЛАБО — постоянно перегенерять", P["raster"])

card(d, 40+cw+gap, y0, cw, ch, "ВАРИАНТ Б — OBJECTS (Figma-like)",
  ["AI отдаёт JSON-структуру слайда:",
   "  заголовок, плитки, координаты, цвета",
   "frontend рендерит на canvas (Konva.js)",
   "менеджер двигает мышью, правит текст",
   "иконки — из библиотеки (lucide / phosphor)",
   "финальный экспорт → PNG (Konva.toDataURL)",
   "",
   "плюс: полный контроль и редактируемость",
   "минус: фоны не такие 'живые' как у AI"],
  P["obj"], "СИЛЬНО, но без AI-фонов скучно", P["obj"])

card(d, 40+2*(cw+gap), y0, cw, ch, "ВАРИАНТ В — ГИБРИД (рекомендую)",
  ["AI генерит ТОЛЬКО фон через gpt-image-1",
   "  (с маской 'оставь место под банку')",
   "поверх фона — слои canvas:",
   "  • PNG банки (drag-and-drop)",
   "  • плитки преимуществ (компонент)",
   "  • заголовки (редактируемый текст)",
   "  • иконки (lucide)",
   "всё двигается, тексты правятся без перегена",
   "",
   "→ AI делает то, в чём он силён (фон)",
   "→ мы делаем то, в чём AI слаб (текст, верстка)"],
  P["hybrid"], "БЕРЁМ ЭТОТ ВАРИАНТ", P["hybrid"])

# Bottom: stack architecture
y1 = y0 + ch + 40
d.rounded_rectangle((40, y1, W-40, H-40), 14, fill=(36,40,52), outline=P["core"], width=3)
d.rounded_rectangle((40, y1, W-40, y1+38), 14, fill=P["core"])
d.text((60, y1+8), "Стек редактора (если идём гибридом)", font=font(20,True), fill=(20,20,28))

stack = [
  ("Frontend",     "Next.js + React + TypeScript", "стандартный фреймворк, как и был в плане"),
  ("Canvas-движок","Konva.js (или Fabric.js)",     "drag-and-drop объекты, слои, экспорт в PNG, есть React-обёртка react-konva"),
  ("Текст",        "TipTap или Lexical",           "редактируемый rich-text внутри объекта"),
  ("Иконки",       "lucide-react + наша библиотека","единая стилистика, можно добавлять SVG бренда"),
  ("Шрифты",       "Inter / Manrope (Google Fonts)","kirillica + premium вид"),
  ("Фон от AI",    "OpenAI gpt-image-1 (Images API)","генерим только фон, без банки и текста"),
  ("Банка",        "PNG из c_brand_jars",          "по SKU, неизменяемый объект, drag-and-drop"),
  ("Хранилище",    "S3 twcstorage.ru/sprav/graflab/","фоны, банки, готовые слайды"),
  ("БД",           "Postgres, префикс c_*",        "слайды, версии, шаблоны промптов, палитры"),
  ("Финал-экспорт","Konva.toDataURL → PNG 1086×1449","или server-side через node-canvas, под WB/Ozon"),
]
yy = y1 + 60
col1, col2, col3 = 80, 380, 800
d.text((col1, yy), "Слой", font=font(15,True), fill=INK)
d.text((col2, yy), "Что берём", font=font(15,True), fill=INK)
d.text((col3, yy), "Зачем", font=font(15,True), fill=INK)
yy += 28
for layer, what, why in stack:
    d.text((col1, yy), layer, font=font(14,True), fill=P["data"])
    d.text((col2, yy), what, font=font(14), fill=INK)
    d.text((col3, yy), why, font=font(14), fill=DIM)
    yy += 26

img.save(OUT,"PNG"); print(OUT)
