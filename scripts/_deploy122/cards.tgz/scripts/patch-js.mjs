// Заменяет JS блок Библиотека+Генерация на новые версии
import { readFileSync, writeFileSync } from 'node:fs';

const fpath = 'C:/Claude/Work/cards/site/index.html';
let src = readFileSync(fpath, 'utf8');

const startMarker = '  // ============ БИБЛИОТЕКА ============';
const endMarker = '  // ============ BOOT ============';
const i = src.indexOf(startMarker);
const j = src.indexOf(endMarker, i);
if (i < 0 || j < 0) throw new Error('markers not found');

const NEW = `  // ============ БИБЛИОТЕКА (дерево по папкам) ============
  let _libTree = null;
  async function loadLibrary(){
    const cont = document.getElementById('library-tree');
    if (!cont) return;
    cont.innerHTML = '<div class="text-[12px] text-[var(--slate-10)]">загрузка…</div>';
    _libTree = await api('/api/library/tree');
    renderLibrary();
  }
  function renderLibrary(){
    const cont = document.getElementById('library-tree');
    if (!cont || !_libTree) return;
    const q = (document.getElementById('lib-q')?.value || '').toLowerCase().trim();
    let totalFiles = 0, totalShown = 0;
    const html = [];
    for (const grp of _libTree) {
      const matched = q ? grp.files.filter(f => f.name.toLowerCase().includes(q) || grp.folder.toLowerCase().includes(q)) : grp.files;
      totalFiles += grp.files.length;
      if (!matched.length) continue;
      totalShown += matched.length;
      const folderShort = grp.folder.replace(/^карточки\\//,'').replace(/^output$/,'output (генерации)');
      html.push(\`<details class="r-card relative" open>
        <span class="r-glow-1"></span><span class="r-glow-2"></span><span class="r-glow-3"></span>
        <summary class="cursor-pointer px-5 py-4 flex items-center gap-3 list-none" style="user-select:none">
          <i data-lucide="chevron-right" class="w-4 h-4 text-[var(--slate-10)] transition" style="transform:rotate(90deg)"></i>
          <span class="text-[15px] font-medium text-slate-12">\${esc(folderShort)}</span>
          <span class="text-[11px] mono text-[var(--slate-10)] ml-auto">\${matched.length} \${matched.length === grp.files.length ? '' : '/ '+grp.files.length} файл.</span>
        </summary>
        <div class="px-5 pb-5 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
          \${matched.map(f => {
            const isImg = ['.png','.jpg','.jpeg','.webp','.gif'].includes(f.ext);
            return \`<a class="file-tile" href="\${f.url}" target="_blank" title="\${esc(f.name)}">
              <div class="file-preview" style="\${isImg ? \`background:#0c0c0e url('\${f.url}') center/contain no-repeat\` : 'background:#15151a; display:flex; align-items:center; justify-content:center'}">
                \${isImg ? '' : '<i data-lucide="file" class="w-7 h-7 text-[var(--slate-9)]"></i>'}
              </div>
              <div class="file-meta">
                <div class="text-[12px] font-medium text-slate-12 truncate">\${esc(f.name)}</div>
                <div class="text-[10px] text-[var(--slate-10)] mono">\${(f.size/1024/1024).toFixed(1)} MB</div>
              </div>
            </a>\`;
          }).join('')}
        </div>
      </details>\`);
    }
    cont.innerHTML = html.join('') || '<div class="text-[12px] text-[var(--slate-10)]">ничего не найдено</div>';
    const stats = document.getElementById('lib-stats');
    if (stats) stats.textContent = q ? \`\${totalShown} из \${totalFiles} файлов\` : \`\${totalFiles} файлов в \${_libTree.length} папках\`;
    lucide.createIcons();
  }

  // загрузка файла
  async function uploadFiles(files, into = 'карточки/Загруженное') {
    if (!files?.length) return;
    const fd = new FormData();
    for (const f of files) fd.append('files', f);
    fd.append('folder', into);
    try {
      const r = await fetch('/api/library/upload', { method:'POST', body: fd });
      const j = await r.json();
      if (j.ok) await loadLibrary();
    } catch (e) { console.error(e); }
  }
  document.getElementById('lib-upload-btn')?.addEventListener('click', () => document.getElementById('lib-upload-input').click());
  document.getElementById('lib-upload-input')?.addEventListener('change', e => uploadFiles(e.target.files));
  document.getElementById('lib-q')?.addEventListener('input', renderLibrary);
  document.getElementById('lib-refresh')?.addEventListener('click', loadLibrary);


  // ============ ГЕНЕРАЦИЯ (canvas-композитор) ============
  const SLIDE_TITLES = ['HERO','СОСТАВ','ВЫГОДЫ A','ВЫГОДЫ B','ПРЕИМУЩЕСТВА','ДЛЯ КОГО'];

  const Gen = {
    skus: [], palettes: [], jarFiles: [],
    sku: null, palette: null, jar_path: null,
    quality: 'medium', dry_run: true,
    slide: 1,
    customColor: '#4a96d4',
    layers: [],         // [{id, type:'text'|'image', x,y,w,fs?, content, color?, align?}]
    layersBySlide: {1:[],2:[],3:[],4:[],5:[],6:[]},
    selectedId: null,
    zoom: 1,
    _libModalMode: 'jar', // 'jar' | 'image-add'

    async init(){
      [this.skus, this.palettes] = await Promise.all([api('/api/skus'), api('/api/palettes')]);
      this.renderSkuSelect();
      this.renderSlideTabs();
      this.renderPalettes();
      this.bindControls();
      if (this.skus.length) this.selectSku(this.skus[0].id);
    },

    renderSkuSelect(){
      const sel = document.getElementById('gen-sku');
      sel.innerHTML = '<option value="">— выбери товар —</option>' + this.skus.map(s =>
        \`<option value="\${s.id}">\${esc(s.name_ru)} · \${esc(s.sku)}</option>\`
      ).join('');
      sel.onchange = e => { if (e.target.value) this.selectSku(+e.target.value); };
    },

    renderSlideTabs(){
      const cont = document.getElementById('gen-slide-tabs');
      cont.innerHTML = SLIDE_TITLES.map((t,i) =>
        \`<button class="ftab \${this.slide===i+1?'active':''}" data-slide="\${i+1}" style="padding:6px 10px; font-size:12px">\${i+1} · \${t}</button>\`
      ).join('');
      cont.querySelectorAll('[data-slide]').forEach(b => b.onclick = () => this.switchSlide(+b.dataset.slide));
    },

    switchSlide(n){
      this.layersBySlide[this.slide] = this.layers;
      this.slide = n;
      this.layers = this.layersBySlide[n] || [];
      this.selectedId = null;
      this.renderSlideTabs();
      this.renderCanvas();
      this.renderLayers();
      this.updateInspector();
      document.getElementById('gen-canvas-title').textContent = \`слайд \${n} · \${SLIDE_TITLES[n-1]}\`;
    },

    selectSku(id){
      this.sku = this.skus.find(s => s.id === id);
      if (!this.sku) return;
      document.getElementById('gen-sku').value = id;
      // палитра по умолчанию
      if (this.sku.palette_code) {
        this.palette = this.palettes.find(p => p.code === this.sku.palette_code) || this.palettes[0];
      }
      this.jar_path = this.sku.jar_master_path || null;
      // если HERO/СОСТАВ/ДЛЯ КОГО — добавим автотекст с названием на slide-1 если ещё пусто
      if (!this.layersBySlide[1].length) {
        this.layersBySlide[1] = [
          { id:'auto-title', type:'text', x:50, y:14, w:90, fs:48, content: (this.sku.name_en || this.sku.name_ru || '').toUpperCase(), color:'#ffffff', align:'center', weight:700 },
        ];
      }
      this.layers = this.layersBySlide[this.slide];
      this.renderPalettes();
      this.renderJar();
      this.renderCanvas();
      this.renderLayers();
      this.log(\`товар: \${this.sku.name_ru} (\${this.sku.sku})\`);
    },

    renderPalettes(){
      const grid = document.getElementById('gen-palette-grid');
      grid.innerHTML = this.palettes.map(p => {
        const active = this.palette?.id === p.id;
        return \`<button data-pal="\${p.code}" title="\${esc(p.code)}" style="aspect-ratio:1; border-radius:6px; background:linear-gradient(135deg, \${p.hex_main}, \${p.hex_accent}); border:\${active?'2px solid #fafafa':'1px solid var(--slate-6)'}; cursor:pointer"></button>\`;
      }).join('');
      grid.querySelectorAll('[data-pal]').forEach(b => b.onclick = () => {
        this.palette = this.palettes.find(p => p.code === b.dataset.pal);
        this.renderPalettes(); this.renderCanvas();
        document.getElementById('gen-palette-info').textContent = \`\${this.palette.code} · \${this.palette.hex_main} → \${this.palette.hex_accent}\`;
      });
      if (this.palette) document.getElementById('gen-palette-info').textContent = \`\${this.palette.code} · \${this.palette.hex_main} → \${this.palette.hex_accent}\`;
    },

    renderJar(){
      const m = document.getElementById('gen-jar-mini');
      const lab = document.getElementById('gen-jar-path');
      if (this.jar_path) {
        m.innerHTML = \`<img src="/static/\${encodeURI(this.jar_path)}" style="width:100%; height:100%; object-fit:contain" onerror="this.parentElement.innerHTML='<div class=\\\\'text-[11px] text-[var(--red-11)]\\\\'>не найден</div>'" />\`;
        lab.textContent = this.jar_path;
      } else {
        m.innerHTML = '<div class="text-[11px] text-[var(--slate-10)]">не выбрана</div>';
        lab.textContent = '—';
      }
    },

    renderCanvas(){
      const c = document.getElementById('gen-canvas');
      const palGrad = this.palette
        ? \`linear-gradient(135deg, \${this.palette.hex_main}, \${this.palette.hex_accent})\`
        : \`linear-gradient(135deg, \${this.customColor}, \${this.customColor})\`;
      c.style.background = palGrad;
      c.innerHTML = '';
      // hint
      if (!this.layers.length && !([1,2,6].includes(this.slide) && this.jar_path)) {
        const hint = document.createElement('div');
        hint.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.5);font-size:12px;pointer-events:none';
        hint.textContent = 'пустой холст · нажми Текст или Загрузить';
        c.appendChild(hint);
      }
      // банка как фон-слой (для слайдов 1,2,6)
      if ([1,2,6].includes(this.slide) && this.jar_path) {
        const j = document.createElement('img');
        j.src = '/static/' + encodeURI(this.jar_path);
        j.style.cssText = 'position:absolute; left:50%; top:55%; transform:translate(-50%,-50%); width:60%; pointer-events:none';
        j.draggable = false;
        c.appendChild(j);
      }
      // элементы
      for (const L of this.layers) this.renderLayer(c, L);
    },

    renderLayer(c, L){
      const el = document.createElement(L.type === 'text' ? 'div' : 'div');
      el.dataset.lid = L.id;
      const isText = L.type === 'text';
      const baseStyle = \`position:absolute; left:\${L.x}%; top:\${L.y}%; width:\${L.w}%; transform:translate(-50%,-50%); cursor:move; \${this.selectedId===L.id ? 'outline:2px dashed #fafafa; outline-offset:2px':''}\`;
      if (isText) {
        el.style.cssText = baseStyle + \`; color:\${L.color||'#fff'}; text-align:\${L.align||'center'}; font-size:\${L.fs||32}px; font-weight:\${L.weight||700}; line-height:1.1; text-shadow:0 2px 8px rgba(0,0,0,.4); padding:4px\`;
        el.textContent = L.content || '';
      } else {
        el.style.cssText = baseStyle;
        const img = document.createElement('img');
        img.src = L.content;
        img.style.cssText = 'width:100%; display:block; pointer-events:none';
        img.draggable = false;
        img.onerror = () => { el.innerHTML = '<div style="color:#f47174;font-size:11px;text-align:center">img not found</div>'; };
        el.appendChild(img);
      }
      // drag
      el.addEventListener('pointerdown', (e) => this.startDrag(e, L));
      el.addEventListener('click', (e) => { e.stopPropagation(); this.selectLayer(L.id); });
      c.appendChild(el);
    },

    startDrag(e, L){
      e.stopPropagation(); e.preventDefault();
      this.selectLayer(L.id);
      const c = document.getElementById('gen-canvas');
      const rect = c.getBoundingClientRect();
      const startX = e.clientX, startY = e.clientY;
      const oX = L.x, oY = L.y;
      const move = (ev) => {
        const dxp = (ev.clientX - startX) / rect.width * 100;
        const dyp = (ev.clientY - startY) / rect.height * 100;
        L.x = Math.max(0, Math.min(100, oX + dxp));
        L.y = Math.max(0, Math.min(100, oY + dyp));
        this.renderCanvas();
        this.updateInspector();
      };
      const up = () => {
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    },

    addText(){
      const id = 'L'+Date.now();
      const L = { id, type:'text', x:50, y:50, w:80, fs:32, content:'Новый текст', color:'#ffffff', align:'center', weight:700 };
      this.layers.push(L);
      this.layersBySlide[this.slide] = this.layers;
      this.selectedId = id;
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
    },

    addImage(url){
      const id = 'L'+Date.now();
      const L = { id, type:'image', x:50, y:50, w:30, content: url };
      this.layers.push(L);
      this.layersBySlide[this.slide] = this.layers;
      this.selectedId = id;
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
    },

    selectLayer(id){
      this.selectedId = id;
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
    },

    deleteLayer(id){
      this.layers = this.layers.filter(L => L.id !== id);
      this.layersBySlide[this.slide] = this.layers;
      if (this.selectedId === id) this.selectedId = null;
      this.renderCanvas(); this.renderLayers(); this.updateInspector();
    },

    renderLayers(){
      const cont = document.getElementById('gen-layers');
      const cnt = document.getElementById('gen-layers-count');
      cnt.textContent = this.layers.length;
      if (!this.layers.length) { cont.innerHTML = '<div class="text-[12px] text-[var(--slate-10)] py-2">пусто</div>'; return; }
      cont.innerHTML = this.layers.map(L => {
        const active = this.selectedId === L.id;
        const ico = L.type === 'text' ? 'type' : 'image';
        const lbl = L.type === 'text' ? (L.content || 'текст').slice(0, 24) : 'картинка';
        return \`<button class="prompt-item \${active?'active':''}" data-lid="\${L.id}" style="display:flex; align-items:center; gap:8px; padding:8px 10px; font-size:12px">
          <i data-lucide="\${ico}" class="w-3.5 h-3.5 text-[var(--slate-11)]"></i>
          <span class="flex-1 text-left truncate text-slate-12">\${esc(lbl)}</span>
          <button data-del="\${L.id}" class="text-[var(--slate-10)] hover:text-[var(--red-11)]" title="удалить"><i data-lucide="x" class="w-3 h-3"></i></button>
        </button>\`;
      }).join('');
      cont.querySelectorAll('[data-lid]').forEach(b => b.onclick = (e) => {
        if (e.target.closest('[data-del]')) { this.deleteLayer(e.target.closest('[data-del]').dataset.del); return; }
        this.selectLayer(b.dataset.lid);
      });
      lucide.createIcons();
    },

    updateInspector(){
      const ins = document.getElementById('gen-inspector');
      const L = this.layers.find(l => l.id === this.selectedId);
      if (!L) { ins.classList.add('hidden'); return; }
      ins.classList.remove('hidden');
      document.getElementById('ins-text').value = L.type === 'text' ? (L.content || '') : '';
      document.getElementById('ins-text').disabled = L.type !== 'text';
      document.getElementById('ins-x').value = Math.round(L.x);
      document.getElementById('ins-y').value = Math.round(L.y);
      document.getElementById('ins-w').value = Math.round(L.w);
      document.getElementById('ins-fs').value = L.fs || 32;
      document.getElementById('ins-fs').disabled = L.type !== 'text';
      document.getElementById('ins-color').value = L.color || '#ffffff';
      document.querySelectorAll('#ins-align [data-align]').forEach(b => b.classList.toggle('active', b.dataset.align === (L.align || 'center')));
    },

    bindInspector(){
      const upd = (k, val) => {
        const L = this.layers.find(l => l.id === this.selectedId); if (!L) return;
        L[k] = val;
        this.renderCanvas(); this.renderLayers();
      };
      document.getElementById('ins-text').oninput = e => upd('content', e.target.value);
      document.getElementById('ins-x').oninput = e => upd('x', +e.target.value);
      document.getElementById('ins-y').oninput = e => upd('y', +e.target.value);
      document.getElementById('ins-w').oninput = e => upd('w', +e.target.value);
      document.getElementById('ins-fs').oninput = e => upd('fs', +e.target.value);
      document.getElementById('ins-color').oninput = e => upd('color', e.target.value);
      document.querySelectorAll('#ins-align [data-align]').forEach(b => b.onclick = () => upd('align', b.dataset.align));
      document.getElementById('ins-delete').onclick = () => this.selectedId && this.deleteLayer(this.selectedId);
    },

    bindControls(){
      // tools
      document.getElementById('tool-add-text').onclick = () => this.addText();
      document.getElementById('tool-add-from-lib').onclick = () => this.openLibModal('image-add');
      document.getElementById('tool-upload').onclick = () => document.getElementById('tool-upload-input').click();
      document.getElementById('tool-upload-input').onchange = async (e) => {
        for (const f of e.target.files) {
          const url = URL.createObjectURL(f);
          this.addImage(url);
        }
      };

      // jar pick (другой режим модалки)
      document.getElementById('gen-jar-pick').onclick = () => this.openLibModal('jar');
      document.getElementById('jar-modal-close').onclick = () => this.closeLibModal();
      document.getElementById('jar-modal').onclick = (e) => { if (e.target.id === 'jar-modal') this.closeLibModal(); };
      document.getElementById('jar-modal-q').oninput = (e) => {
        const q = e.target.value.toLowerCase().trim();
        this.renderJarGrid(this.jarFiles.filter(f => !q || (f.path||'').toLowerCase().includes(q)));
      };

      // quality / dry
      document.querySelectorAll('#gen-quality button').forEach(b => {
        b.onclick = () => {
          document.querySelectorAll('#gen-quality button').forEach(x => x.classList.remove('active'));
          b.classList.add('active');
          this.quality = b.dataset.q;
        };
      });
      document.getElementById('gen-dry-run').onchange = e => { this.dry_run = e.target.checked; };

      // palette custom
      document.getElementById('gen-palette-custom').oninput = e => {
        this.customColor = e.target.value;
        this.palette = null;
        document.querySelectorAll('#gen-palette-grid [data-pal]').forEach(b => b.style.borderColor = 'var(--slate-6)');
        document.getElementById('gen-palette-info').textContent = 'кастом · ' + e.target.value;
        this.renderCanvas();
      };

      // launch
      document.getElementById('btn-gen-fire').onclick = () => this.fire(false);
      document.getElementById('btn-gen-test').onclick = () => this.fire(true);
      document.getElementById('btn-gen-clear-canvas').onclick = () => {
        if (!confirm('Очистить холст текущего слайда?')) return;
        this.layers = []; this.layersBySlide[this.slide] = [];
        this.renderCanvas(); this.renderLayers(); this.updateInspector();
      };

      // zoom
      document.getElementById('gen-zoom-in').onclick = () => this.setZoom(Math.min(2, this.zoom + 0.1));
      document.getElementById('gen-zoom-out').onclick = () => this.setZoom(Math.max(0.4, this.zoom - 0.1));

      // canvas click — снять выделение
      document.getElementById('gen-canvas').onclick = () => { this.selectedId = null; this.renderCanvas(); this.renderLayers(); this.updateInspector(); };

      this.bindInspector();
    },

    setZoom(z){
      this.zoom = z;
      const c = document.getElementById('gen-canvas');
      c.style.width = (480 * z) + 'px';
      document.getElementById('gen-zoom-label').textContent = Math.round(z*100) + '%';
    },

    async openLibModal(mode){
      this._libModalMode = mode;
      document.getElementById('jar-modal-title').textContent = mode === 'jar' ? 'Выбери эталон-банку' : 'Картинка для слоя';
      const modal = document.getElementById('jar-modal');
      modal.classList.remove('hidden');
      const grid = document.getElementById('jar-modal-grid');
      grid.innerHTML = '<div class="col-span-full text-center text-[12px] text-[var(--slate-10)] py-8">загрузка…</div>';
      if (!this.jarFiles.length) {
        const files = await api('/api/library/files?folder=all');
        this.jarFiles = files.filter(f => ['.png','.jpg','.jpeg','.webp'].includes(f.ext));
      }
      this.renderJarGrid(this.jarFiles);
    },
    closeLibModal(){ document.getElementById('jar-modal').classList.add('hidden'); },
    renderJarGrid(files){
      const grid = document.getElementById('jar-modal-grid');
      if (!files.length) { grid.innerHTML = '<div class="col-span-full text-center text-[12px] text-[var(--slate-10)] py-8">ничего не найдено</div>'; return; }
      grid.innerHTML = files.slice(0, 200).map(f =>
        \`<button class="file-tile" data-pick="\${esc(f.path)}" data-url="\${esc(f.url)}" style="text-align:left">
          <div class="file-preview" style="background:#0c0c0e url('\${f.url}') center/contain no-repeat"></div>
          <div class="file-meta">
            <div class="text-[11.5px] font-medium text-slate-12 truncate">\${esc(f.name)}</div>
            <div class="text-[10px] text-[var(--slate-10)] mono truncate">\${esc((f.path||'').replace('карточки/',''))}</div>
          </div>
        </button>\`
      ).join('');
      grid.querySelectorAll('[data-pick]').forEach(el => el.onclick = () => {
        if (this._libModalMode === 'jar') {
          this.jar_path = el.dataset.pick;
          this.renderJar(); this.renderCanvas();
          this.log(\`банка: \${this.jar_path}\`);
        } else {
          this.addImage(el.dataset.url);
          this.log(\`+ слой: \${el.dataset.url}\`);
        }
        this.closeLibModal();
      });
    },

    log(msg, kind='info'){
      const el = document.getElementById('gen-log');
      const time = new Date().toLocaleTimeString('ru');
      const color = kind === 'err' ? 'var(--red-11)' : kind === 'ok' ? 'var(--green-11)' : kind === 'warn' ? 'var(--yellow-11)' : 'var(--slate-11)';
      const div = document.createElement('div');
      div.style.color = color;
      div.textContent = \`[\${time}] \${msg}\`;
      el.appendChild(div);
      el.scrollTop = el.scrollHeight;
    },

    composePrompt(){
      // строим описание из layers + палитры + банки + slide_kind canon
      const tpl = SLIDE_TITLES[this.slide-1];
      const palWords = this.palette ? \`\${this.palette.code} palette: \${this.palette.hex_main} → \${this.palette.hex_accent}, \${this.palette.bg_object||''}\` : \`custom hex \${this.customColor}\`;
      const elems = this.layers.map(L => {
        if (L.type === 'text') return \`- TEXT "\${L.content}" at \${Math.round(L.x)}%/\${Math.round(L.y)}% (size \${L.fs||32}px, align \${L.align||'center'}, color \${L.color||'#fff'})\`;
        return \`- IMAGE at \${Math.round(L.x)}%/\${Math.round(L.y)}% width \${Math.round(L.w)}% (src: \${L.content})\`;
      }).join('\\n');
      const jar = ([1,2,6].includes(this.slide) && this.jar_path) ? \`\\nGRAFLAB jar reference: /static/\${this.jar_path} centered ~55% Y\` : '';
      return \`Slide \${this.slide} · \${tpl} · \${palWords}\${jar}\\n\\nElements:\\n\${elems}\\n\\nMatch GRAflab brand canvas: real Cyrillic, no medical claims, premium calm tone, portrait 1086x1449.\`;
    },

    async fire(testMode){
      if (!this.sku) { this.log('сначала выбери товар', 'err'); return; }
      const slidesToRun = testMode ? [this.slide] : [1,2,3,4,5,6];
      this.log(\`старт · \${slidesToRun.length} слайд(ов) · \${this.dry_run?'dry-run':'РЕАЛЬНЫЙ'} · \${this.quality}\`, 'info');
      if (!this.dry_run) {
        const cost = slidesToRun.length * { low:1.6, medium:17, high:68 }[this.quality];
        if (!confirm(\`Реально потратится ~\${cost.toFixed(1)} ₽ через ProxyAPI. Продолжить?\`)) { this.log('отменено', 'warn'); return; }
      }
      let ok = 0, fail = 0;
      for (const sl of slidesToRun) {
        this.log(\`→ слайд \${sl}\`, 'info');
        try {
          const promptText = this.slide === sl ? this.composePrompt() : null;
          const res = await fetch('/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              sku_id: this.sku.id,
              slide_kind: sl,
              prompt_id: null,
              prompt_text: promptText,  // расширенный композиционный
              dry_run: this.dry_run,
            }),
          });
          const j = await res.json();
          if (j.ok) { ok++; this.log(\`  ✓ слайд \${sl} · \${j.generation_id}\${j.cost_rub?' · '+j.cost_rub+' ₽':''}\`, 'ok'); }
          else { fail++; this.log(\`  ✗ слайд \${sl} · \${j.error || 'ошибка'}\`, 'err'); }
        } catch(e) { fail++; this.log(\`  ✗ слайд \${sl} · \${e.message}\`, 'err'); }
      }
      this.log(\`готово: \${ok}/\${slidesToRun.length}\${fail?\` · провалов \${fail}\`:''}\`, ok===slidesToRun.length?'ok':'warn');
      loadGenerations();
    },
  };

  // ============ BOOT ============
`;

src = src.slice(0, i) + NEW + src.slice(j + endMarker.length) + (src.slice(j + endMarker.length).startsWith('\n') ? '' : '\n');
// дополним: дальше идёт сама функция boot — её мы НЕ трогаем
writeFileSync(fpath, src, 'utf8');
console.log('JS patched');
