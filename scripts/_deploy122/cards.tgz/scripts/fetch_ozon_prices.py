import sys, io, json, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import requests

SELLERS = [
    {"name": "GRAFLAB (2843272)", "client_id": "2843272", "api_key": "aa4a0bcf-49d3-4230-94c9-759fb19b8abf"},
    {"name": "IP-2 (163276)",     "client_id": "163276",  "api_key": "35bbfde5-9eb8-47f5-b765-1e0a2d09c58d"},
]

BASE = "https://api-seller.ozon.ru"


def headers(s):
    return {
        "Client-Id": s["client_id"],
        "Api-Key": s["api_key"],
        "Content-Type": "application/json",
    }


def fetch_prices(seller):
    """Returns list of dicts with offer_id, product_id, price, old_price, marketing_price, etc."""
    all_items = []
    cursor = ""
    page = 0
    while True:
        page += 1
        body = {
            "cursor": cursor,
            "filter": {"visibility": "ALL"},
            "limit": 1000,
        }
        r = requests.post(f"{BASE}/v5/product/info/prices", headers=headers(seller), json=body, timeout=60)
        if r.status_code != 200:
            print(f"[{seller['name']}] page {page} HTTP {r.status_code}: {r.text[:300]}")
            break
        data = r.json()
        items = data.get("items", [])
        all_items.extend(items)
        print(f"[{seller['name']}] page {page}: +{len(items)} (total {len(all_items)})")
        cursor = data.get("cursor", "")
        if not cursor or not items:
            break
        time.sleep(0.15)
    return all_items


def flatten(item, seller_name):
    price = item.get("price", {}) or {}
    cs = item.get("commissions", {}) or {}
    return {
        "seller": seller_name,
        "offer_id": item.get("offer_id"),
        "product_id": item.get("product_id"),
        "price":          float(price.get("price") or 0) or None,
        "old_price":      float(price.get("old_price") or 0) or None,
        "min_price":      float(price.get("min_price") or 0) or None,
        "marketing_price": float(price.get("marketing_price") or 0) or None,
        "marketing_seller_price": float(price.get("marketing_seller_price") or 0) or None,
        "currency": price.get("currency_code"),
        "vat": price.get("vat"),
    }


def main():
    rows = []
    for s in SELLERS:
        items = fetch_prices(s)
        for it in items:
            rows.append(flatten(it, s["name"]))
    print(f"\nTotal rows: {len(rows)}")
    # dump JSON for later use
    with open("output/ozon_prices_raw.json", "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2, default=str)
    print("Saved output/ozon_prices_raw.json")


if __name__ == "__main__":
    main()
